"""Launch the browser worker from the signed-in Windows desktop, preserving its data."""
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import Request, build_opener, ProxyHandler
import webbrowser


def portal_url(root):
    settings=Path(root)/'config.json'
    values=json.loads(settings.read_text(encoding='utf-8-sig')) if settings.exists() else {}
    port=values.get('portal_port',8791)
    if type(port) is not int or not 1024 <= port <= 65535:
        raise RuntimeError('Invalid local portal port.')
    return f'http://127.0.0.1:{port}/google-login/'


def listening(port):
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=1):return True
    except OSError:return False


def call_worker(root,action=None):
    saved=json.loads((Path(root)/'scene-server'/'session.json').read_text(encoding='utf-8'))
    if saved.get('port')!=8788:raise RuntimeError('Unexpected browser worker port; no process was stopped.')
    request=Request('http://127.0.0.1:8788/api/'+(action or 'state'),
        data=b'{}' if action else None,
        headers={'X-Omni-Token':saved['token'],'Content-Type':'application/json'})
    with build_opener(ProxyHandler({})).open(request,timeout=4) as response:
        return json.load(response)


def require_desktop_runtime(root=None):
    from sceneforge.production.profile_proxy import password_storage_available
    from sceneforge.production.chrome_runtime import resolve_chrome
    if os.name!='nt':raise RuntimeError('This desktop worker setup requires Windows.')
    if not password_storage_available():
        raise RuntimeError('Windows password protection is unavailable. Run Start Browser Worker.cmd by double-clicking it from your normal Windows desktop, not inside a restricted automation terminal.')
    if importlib.util.find_spec('playwright') is None:
        raise RuntimeError('Playwright is missing. Run: python -m pip install -r Scene-Studio-Browser-Worker\\requirements.txt')
    root = Path(root) if root is not None else Path(os.environ.get('SCENE_PROFILE_DATA', str(Path.home()/'Documents'/'Codex'/'SceneStudioVideoPool')))
    return resolve_chrome(root, remember=True)


def prepare_existing_worker(root, generation_window_mode=None, saved_profile_generation=None):
    if not listening(8788):return False
    try:state=call_worker(root)
    except Exception:
        raise RuntimeError('Port 8788 is occupied by a worker that could not be verified. No process was stopped.') from None
    matching_mode=generation_window_mode is None or state.get('generation_window_mode')==generation_window_mode
    matching_mode=matching_mode and (saved_profile_generation is None or state.get('saved_profile_generation')==saved_profile_generation)
    if state.get('proxy_password_storage') and not state.get('shutting_down') and matching_mode:
        return True
    if state.get('busy'):
        raise RuntimeError('The preview worker is busy. Finish or cancel its sign-in/job, then run this launcher again.')
    try:call_worker(root,'shutdown')
    except Exception:
        raise RuntimeError('The old preview cannot be restarted automatically. Update the preview worker and try again. No accounts were changed.') from None
    deadline=time.monotonic()+12
    while time.monotonic()<deadline:
        if not listening(8788):return False
        time.sleep(.2)
    raise RuntimeError('The old worker is still stopping. Wait briefly and retry.')


def main():
    root=Path(os.environ.get('SCENE_PROFILE_DATA',str(Path.home()/'Documents'/'Codex'/'SceneStudioVideoPool')))
    require_desktop_runtime(root)
    if prepare_existing_worker(root, generation_window_mode='headless', saved_profile_generation=6):
        print('Your browser worker is already ready. Return to Google Account Pool.')
        webbrowser.open(portal_url(root))
        return
    source=Path(__file__).resolve().parent
    child=subprocess.Popen([sys.executable,'-m','sceneforge.scene_server','--root',str(root),'--port','8788','--no-browser'],cwd=source)
    try:
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            if child.poll() is not None:raise RuntimeError('Browser worker exited during startup. Review the message above.')
            try:
                state=call_worker(root)
                if state.get('proxy_password_storage'):break
            except Exception:pass
            time.sleep(.25)
        else:raise RuntimeError('The browser worker did not become ready. No account was connected.')
        print('Browser worker ready. Windows password protection is available.')
        print('Keep this window open. Complete Google login in the Chrome window opened by the admin page.')
        webbrowser.open(portal_url(root))
        child.wait()
    finally:
        if child.poll() is None:child.terminate()


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('Browser worker stopped.')
    except Exception as exc:
        print('Setup needs attention:',str(exc))
        sys.exit(1)
