"""Bundled Windows profile host; the existing web admin is its user interface."""
import argparse
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import webbrowser

from worker_bootstrap import prepare_existing_worker, require_desktop_runtime, portal_url
from sceneforge.production.master import _write_atomic
from sceneforge.production.scene_queue import browser_lock
from sceneforge.production.profile_proxy import password_storage_available
from sceneforge.scene_server import make_server
from sceneforge.production.chrome_runtime import resolve_chrome

BUILD_VERSION = '2026.10.08.13'


def data_root():
    return Path(os.environ.get('SCENE_PROFILE_DATA', str(Path.home() / 'Documents' / 'Codex' / 'SceneStudioVideoPool'))).resolve()


def configure_desktop_logging():
    """Keep HTTP responses independent of Windows console selection/output."""
    folder = data_root() / 'scene-server'
    folder.mkdir(parents=True, exist_ok=True)
    stream = (folder / 'desktop-worker.log').open('a', encoding='utf-8', buffering=1)
    sys.stdout = stream
    sys.stderr = stream
    return stream


def serve():
    root = data_root()
    executable = require_desktop_runtime(root)
    if prepare_existing_worker(root, generation_window_mode='headless', saved_profile_generation=6):
        print('Your desktop profile host is already ready.')
        webbrowser.open(portal_url(root))
        return
    with browser_lock(root / 'scene-server'):
        config_path = root / 'config.json'
        config = json.loads(config_path.read_text(encoding='utf-8-sig')) if config_path.exists() else {}
        accounts = Path(config['master_log_dir']) if config.get('master_log_dir') else root / 'scene-accounts'
        accounts.mkdir(parents=True, exist_ok=True)
        server = make_server(root, accounts, 8788)
        try:
            _write_atomic(root / 'scene-server' / 'session.json', json.dumps({'port': 8788, 'token': server.service.token}))
            print('9 SIGMA SCENE STUDIO - DESKTOP PROFILE HOST')
            print('Build:', BUILD_VERSION)
            print('Ready. Windows password protection is available.')
            print('Chrome:', executable)
            print('Local profile data:', root)
            print('Admin:', portal_url(root))
            print('Desktop host runs in the background. Complete Google verification in Chrome.')
            print('Generation browsers run in the background, one profile at a time.')
            print('Press Ctrl+C to stop the host; saved profiles are kept.')
            webbrowser.open(portal_url(root))
            server.serve_forever()
        finally:
            server.service.stop.set()
            server.server_close()
            if server.service.worker:
                server.service.worker.join()


def self_test(path):
    import playwright
    from playwright.sync_api import sync_playwright
    from sceneforge.ffmpeg_tools import find_tool
    driver = Path(playwright.__file__).parent / 'driver' / 'node.exe'
    report = {'build_version': BUILD_VERSION, 'playwright_driver_present': driver.is_file(),
              'windows_password_protection': password_storage_available(),
              'data_root': str(data_root())}
    try:
        report['chrome_executable'] = str(resolve_chrome(data_root()))
        report['chrome_found'] = True
    except RuntimeError as exc:
        report['chrome_found'] = False
        report['chrome_error'] = str(exc)
    probe = find_tool('ffprobe')
    report['video_validator'] = bool(probe and subprocess.run([probe, '-version'], capture_output=True, timeout=15).returncode == 0)
    with tempfile.TemporaryDirectory(prefix='scene-desktop-check-') as temporary:
        accounts = Path(temporary) / 'accounts'
        accounts.mkdir()
        server = make_server(Path(temporary) / 'root', accounts, 0)
        try:
            report['worker_server'] = server.service.state()['accounts'] == []
            report['background_generation'] = server.service.state().get('generation_window_mode') == 'headless'
            report['worker_web_assets'] = (Path(__file__).parent / 'sceneforge' / 'scene_web' / 'index.html').is_file()
        finally:
            server.server_close()
    try:
        with sync_playwright() as runtime:
            report['playwright_driver_started'] = bool(runtime.chromium.name)
    except Exception as exc:
        report['playwright_driver_started'] = False
        report['driver_error_type'] = type(exc).__name__
    Path(path).write_text(json.dumps(report, indent=2), encoding='utf-8')
    return 0 if all(report.get(key) for key in ('worker_server', 'worker_web_assets', 'playwright_driver_present', 'playwright_driver_started', 'video_validator', 'chrome_found')) else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--self-test', metavar='REPORT_PATH')
    parser.add_argument('--chrome-path', metavar='CHROME_EXE', help='Full path to a standard or portable chrome.exe')
    args = parser.parse_args()
    if args.chrome_path:
        os.environ['SCENE_CHROME_PATH'] = args.chrome_path
    if args.self_test:
        sys.exit(self_test(args.self_test))
    if getattr(sys, 'frozen', False):
        configure_desktop_logging()
    try:
        serve()
    except KeyboardInterrupt:
        print('Desktop profile host stopped.')
    except Exception as exc:
        print('Setup needs attention:', str(exc))
        if getattr(sys, 'frozen', False) and os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, str(exc), 'Scene Studio setup needs attention', 0x10)
        elif sys.stdin and sys.stdin.isatty():
            input('Press Enter to close this message...')
        sys.exit(1)
