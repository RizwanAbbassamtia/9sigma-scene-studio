"""Cut the planned segments and join them into one episode file.

One joining pipeline for every export -- the manual editor, a production,
a batch -- with nothing to choose:

  1. plan_jobs     the cut list from the clips' keep spans: a clean cut
                   inside a scene, a short blend where the scene changes,
                   a fade at the episode's two ends. No ffmpeg; this is what
                   the editor quotes as the length.
  2. refine        the continuity engine reads the frames at every join and
                   settles it: a blend that would ghost becomes a cut, a
                   flash inside a scene gets a blend, dead frames at the
                   edges are trimmed, neighbouring colour is matched.
  3. cut           every piece is encoded once, near lossless, at the
                   source size and frame rate; blends are rendered from the
                   two sources the same way.
  4. deliver       the pieces are stitched and encoded ONCE at delivery
                   quality, scaled to the output size in that pass, with
                   captions burned in the same pass when asked for.
  5. check         the finished file is decoded and its joins looked at for
                   black or frozen frames; anything found is written to the
                   edit log beside the video.
"""
from __future__ import annotations

import hashlib
import math
import os
import shutil
import tempfile
import threading
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace
from typing import Callable, Dict, List, NamedTuple, Optional, Tuple

from . import continuity
from . import encoders
from .captions import build as build_cues, write_srt
from .config import Config
from .encoders import video_args
from .ffmpeg_tools import STALLED, TIMED_OUT, find_tool, require, run, run_with_progress
from .logging_setup import get
from .models import Clip, Episode, Flag, ReviewState

log = get("assemble")
Progress = Optional[Callable[[int, int, str], None]]

NO_SHIFT = (0.0, 0.0, 0.0)


class Job(NamedTuple):
    clip: Clip
    index: int          # which keep-span of that clip
    start: float
    end: float
    fade_in: bool       # fade up from black at the start of this piece
    fade_out: bool      # fade down to black at its end
    lead: float = 0.0   # seconds given up at the start to a blend before it
    trail: float = 0.0  # seconds given up at the end to a blend after it
    fade_ms: int = 0    # length of this piece's fades; 0 means the usual
    ramp_in: bool = False   # audio ramp over the first few ms (a clean cut)
    ramp_out: bool = False  # and over the last few
    shift: Tuple[float, float, float] = NO_SHIFT   # colour shift (dY, dU, dV) laid on this piece


class Dissolve(NamedTuple):
    """A cross-dissolve between jobs[before] and jobs[after], rendered on its
    own from the tail of one source clip and the head of the next."""
    before: int
    after: int
    seconds: float


def _segment_seconds(path: Path) -> float:
    """How long an encoded segment actually turned out."""
    ffprobe = find_tool("ffprobe")
    if not ffprobe:
        return 0.0
    result = run([ffprobe, "-v", "error", "-show_entries", "format=duration",
                  "-of", "csv=p=0", str(path)])
    try:
        return float(result.stdout.decode("utf-8", "replace").strip())
    except (ValueError, AttributeError):
        return 0.0


def _workers() -> int:
    cpus = os.cpu_count() or 2
    return max(1, min(4, cpus // 2))


def _keepers(episode: Episode, include_pending: bool) -> List[Clip]:
    keepers: List[Clip] = []
    for clip in sorted(episode.clips, key=lambda c: c.number):
        if clip.state == ReviewState.REJECTED:
            continue
        if clip.state == ReviewState.PENDING and not include_pending:
            continue
        keepers.append(clip)
    return keepers


# ------------------------------------------------------------- planning
def plan_jobs(episode: Episode, include_pending: bool, blend_seconds: float, edge_ms: int,
              micro_seconds: float = 0.0):
    """The structural cut list, before any frame is looked at.

    Inside a scene every join is a clean cut at the word-safe boundary;
    where the scene changes (the previous clip ends its scene) there is a
    short blend; the episode fades up at its start and down at its end. A
    cut made inside one clip (a removed repeat, a tightened pause) gets a
    `micro_seconds` blend so neither the picture nor the music bed jumps.
    Returns (jobs, dissolves). Each blend borrows its length from the end
    of one job and the start of the next, recorded as trail and lead.
    """
    keepers = _keepers(episode, include_pending)
    jobs: List[Job] = []
    for position, clip in enumerate(keepers):
        spans = [s for s in clip.keep if s.duration > 0.02]
        for index, span in enumerate(spans):
            first = index == 0
            last = index == len(spans) - 1
            edge_in = position == 0 and first
            edge_out = position == len(keepers) - 1 and last
            jobs.append(Job(clip=clip, index=index, start=span.start, end=span.end,
                            fade_in=edge_in, fade_out=edge_out, fade_ms=edge_ms))

    dissolves: List[Dissolve] = []
    for i in range(len(jobs) - 1):
        a, b = jobs[i], jobs[i + 1]
        if a.fade_out or b.fade_in:
            continue                     # an episode edge
        if a.clip is b.clip:
            seconds = micro_seconds      # a cut inside one clip: the shortest blend there is
        elif a.clip.ends_scene:
            seconds = blend_seconds      # a scene change
        else:
            continue                     # same scene: a shot change, clean cut
        if seconds <= 0:
            continue
        minimum = 2 * seconds + 0.3
        if (a.end - a.start) < minimum or (b.end - b.start) < minimum:
            continue                     # too short to give anything up
        jobs[i] = a._replace(trail=seconds)
        jobs[i + 1] = b._replace(lead=seconds)
        dissolves.append(Dissolve(before=i, after=i + 1, seconds=seconds))
    return _with_ramps(jobs), dissolves


def _with_ramps(jobs: List[Job]) -> List[Job]:
    """Whatever edge is left as a plain cut gets its audio ramp."""
    return [job._replace(ramp_in=not job.fade_in and job.lead == 0.0,
                         ramp_out=not job.fade_out and job.trail == 0.0) for job in jobs]


def _blend_seconds(episode: Episode, config: Config, include_pending: bool) -> float:
    blend = max(0.0, config.blend_ms) / 1000.0
    keepers = _keepers(episode, include_pending)
    if keepers:
        # A whole number of frames, so the body a blend borrows from ends
        # on exactly the frame the blend starts on.
        blend = _snap(blend, _fps(keepers[0]))
    return blend


def jobs_for(episode: Episode, config: Config, include_pending: bool = True):
    """The cut list this config makes, with every length taken from the
    config, so the planner and the builder cannot disagree."""
    keepers = _keepers(episode, include_pending)
    fps = _fps(keepers[0]) if keepers else 24.0
    micro = _snap(max(0.0, config.micro_blend_ms) / 1000.0, fps)
    return plan_jobs(episode, include_pending, _blend_seconds(episode, config, include_pending),
                     config.edge_fade_ms, micro)


def refine(jobs: List[Job], dissolves: List[Dissolve], config: Config, workers: int = 0):
    """Settle every join from the frames on either side of it. Returns
    (jobs, dissolves, records); the records are the continuity log."""
    if len(jobs) < 2:
        return jobs, dissolves, []
    pieces = [(job.clip.path, job.start + job.lead, job.end - job.trail) for job in jobs]
    sigs = continuity.signatures(pieces, workers or _workers())
    blend = max(0.0, config.blend_ms) / 1000.0
    ramp = config.cut_audio_ramp_ms / 1000.0
    jobs = list(jobs)
    settled: List[Dissolve] = []
    records: List[continuity.JoinRecord] = []
    # A clip's colour shift is decided at its first piece and carried
    # through its other pieces; each clip is matched to what the viewer
    # will actually see of the previous one (its own shift included).
    shifts: Dict[int, Tuple[float, float, float]] = {}
    planned = {(d.before, d.after): d for d in dissolves}
    for i in range(len(jobs) - 1):
        a, b = jobs[i], jobs[i + 1]
        if a.clip is b.clip:
            # Pieces of one source: the plan's micro blend stands; no
            # frames are read and no colour is matched across it.
            micro = planned.get((i, i + 1))
            if micro is not None:
                settled.append(micro)
            continue
        if a.fade_out or b.fade_in:
            continue                                    # the episode's own edges
        fps = _fps(a.clip)
        tail, head = sigs[i].tail, sigs[i + 1].head
        # -- dead frames at the edges: trimmed, never into a word ----------
        tail_floor = max(a.start + config.min_clip_seconds, _last_speech_end(a) + continuity.SPEECH_MARGIN)
        head_ceiling = min(b.end - config.min_clip_seconds, _first_speech_start(b) - continuity.SPEECH_MARGIN)
        new_end, new_start = continuity.edge_trims(tail, head, tail_floor, head_ceiling, a.end, b.start)
        new_end, new_start = _snap(new_end, fps), _snap(new_start, _fps(b.clip))
        # Under a frame is the snap, not a trim.
        trimmed_tail = (a.end - new_end) if a.end - new_end >= 0.5 / fps else 0.0
        trimmed_head = (new_start - b.start) if new_start - b.start >= 0.5 / _fps(b.clip) else 0.0
        if trimmed_tail:
            a = a._replace(end=new_end)
        if trimmed_head:
            b = b._replace(start=new_start)
        # -- the join --------------------------------------------------------
        join = continuity.decide(tail, head, a.clip.ends_scene, a.end - a.start, b.end - b.start,
                                 _snap(blend, fps))
        if join.kind == "blend" and join.seconds > 0:
            a = a._replace(trail=join.seconds)
            b = b._replace(lead=join.seconds)
            settled.append(Dissolve(before=i, after=i + 1, seconds=join.seconds))
        else:
            a = a._replace(trail=0.0)
            b = b._replace(lead=0.0)
        # -- colour ------------------------------------------------------------
        shift = NO_SHIFT
        if config.colour_match and b.index == 0:
            seen = continuity.Edge(luma=tail.luma + shifts.get(a.clip.number, NO_SHIFT)[0],
                                   u=tail.u + shifts.get(a.clip.number, NO_SHIFT)[1],
                                   v=tail.v + shifts.get(a.clip.number, NO_SHIFT)[2],
                                   motion=tail.motion, frames=tail.frames)
            shift = continuity.colour_shift(seen, head)
            shifts[b.clip.number] = shift
        b = b._replace(shift=shifts.get(b.clip.number, NO_SHIFT))
        jobs[i], jobs[i + 1] = a, b
        records.append(continuity.JoinRecord(a.clip.number, b.clip.number, join.kind, join.seconds, join.reason,
                                             trimmed_tail, trimmed_head, shift))
    # every piece of a shifted clip carries the shift
    jobs = [job._replace(shift=shifts.get(job.clip.number, job.shift)) for job in jobs]
    jobs = _with_ramps(jobs)
    del ramp
    return jobs, settled, records


def _last_speech_end(job: Job) -> float:
    ends = [s.end for s in list(job.clip.speech) + list(job.clip.speech_soft) if job.start <= s.end <= job.end]
    return max(ends) if ends else job.start


def _first_speech_start(job: Job) -> float:
    starts = [s.start for s in list(job.clip.speech) + list(job.clip.speech_soft) if job.start <= s.start <= job.end]
    return min(starts) if starts else job.end


def join_warnings(episode: Episode, include_pending: bool = True):
    """Joins whose two sides do not belong together, as (before, after,
    reason) clip-number triples. These are told to the editor rather than
    hidden under a blend: a clip that starts mid-word, or a hard cut
    inside a scene across a missing clip number, jumps whatever join is
    laid over it."""
    from .autocut import _setting_of
    out = []
    keepers = _keepers(episode, include_pending)
    for a, b in zip(keepers, keepers[1:]):
        start = b.cut_start
        if start is not None and start > 0.02:
            for soft in list(b.speech_soft) + list(b.speech):
                if soft.start + 0.02 < start < soft.end - 0.02:
                    out.append((a.number, b.number,
                                "starts in the middle of a word at {:.2f}s".format(start)))
                    break
        if (a.scene and b.scene and abs(b.scene.number - a.scene.number) > 1
                and _setting_of(a) == _setting_of(b)):
            out.append((a.number, b.number,
                        "scene {} is missing between it and clip {}, and both are in the "
                        "same setting, so a hard cut here jumps".format(
                            a.scene.number + 1, a.number)))
    return out


def flag_joins(episode: Episode) -> int:
    """Set Flag.JOIN_RISK on every clip whose join was warned about, and
    clear it everywhere else. Idempotent; run after every edit."""
    warned = {}
    for _before, after, reason in join_warnings(episode):
        warned.setdefault(after, reason)
    for clip in episode.clips:
        reason = warned.get(clip.number, "")
        clip.join_warning = reason
        if reason:
            clip.flags.add(Flag.JOIN_RISK)
        else:
            clip.flags.discard(Flag.JOIN_RISK)
    return len(warned)


def _pieces(episode: Episode, config: Config, include_pending: bool = True):
    """The finished video as an ordered list of (clip number, seconds).

    Exactly the sequence `build` writes -- body, blend, body, blend -- so
    the length quoted before an export is the length that comes out of it,
    give or take the few frames the continuity engine trims at the joins.
    Each blend is attributed to the clip it blends into.
    """
    jobs, dissolves = jobs_for(episode, config, include_pending)
    bridge_after = {d.before: d for d in dissolves}
    pieces = []
    for order, job in enumerate(jobs):
        fps = _fps(job.clip)
        start = _snap(job.start + job.lead, fps)
        end = _snap(job.end - job.trail, fps)
        pieces.append((job.clip.number, max(1.0 / fps, end - start)))
        dissolve = bridge_after.get(order)
        if dissolve is not None:
            pieces.append((jobs[order + 1].clip.number, dissolve.seconds))
    return pieces


def planned_timeline(episode: Episode, config: Config,
                     include_pending: bool = True):
    """(total seconds, where each clip starts) for the video this config makes."""
    total = 0.0
    offsets: Dict[int, float] = {}
    for number, seconds in _pieces(episode, config, include_pending):
        offsets.setdefault(number, total)
        total += seconds
    return total, offsets


def planned_seconds(episode: Episode, config: Config,
                    include_pending: bool = True) -> float:
    return planned_timeline(episode, config, include_pending)[0]


# ------------------------------------------------------------- the size
RATIOS = {"16:9": 16 / 9, "9:16": 9 / 16, "4:3": 4 / 3, "1:1": 1.0}


def ratio_name(width: int, height: int) -> str:
    """'16:9', '9:16', '1:1', '4:3' or 'WxH' for anything else."""
    if width <= 0 or height <= 0:
        return "unknown"
    ratio = width / height
    for name, value in RATIOS.items():
        if abs(ratio - value) / value < 0.03:
            return name
    return "{}x{}".format(width, height)


def output_size(episode: Episode, config: Config, include_pending: bool = True) -> Tuple[int, int, str]:
    """(width, height, ratio) of the finished video, read from the clips.

    The clips decide the shape: 16:9 clips make a 16:9 video, 9:16 clips a
    9:16 one. A config that names a shape refuses clips of another; clips
    of mixed shapes are refused with the odd ones named. Nothing is ever
    cropped or stretched. config.output_height names the short side (1080
    for 1920x1080 or 1080x1920; 0 keeps the source size); the long side
    follows the source's own proportions.
    """
    keepers = [c for c in _keepers(episode, include_pending) if c.media and c.media.width > 0]
    if not keepers:
        raise ValueError("no clip could be measured, so the output size is unknown")
    shapes = Counter(ratio_name(c.media.width, c.media.height) for c in keepers)
    ratio, count = shapes.most_common(1)[0]
    if len(shapes) > 1:
        odd = [c.number for c in keepers if ratio_name(c.media.width, c.media.height) != ratio]
        raise ValueError("the clips are not all the same shape: {} are {}, but clip(s) {} are not. Nothing is "
                         "cropped or stretched; replace the odd ones or leave them out.".format(
                             count, ratio, ", ".join(str(n) for n in odd[:20])))
    wanted = config.aspect_ratio if config.aspect_ratio in ("16:9", "9:16") else "auto"
    if wanted != "auto" and ratio != wanted:
        raise ValueError("this production is set to {} but the clips are {}. Nothing is cropped or stretched: "
                         "supply {} clips, or set the video format to follow the clips.".format(wanted, ratio, wanted))
    source = keepers[0].media
    # "1080p" names the short side, the way the platforms do: 1920x1080
    # for a landscape video, 1080x1920 for a vertical one.
    short = int(config.output_height) if config.output_height and config.output_height > 0 else min(
        source.width, source.height)
    if source.width >= source.height:
        height, width = short, short * source.width / source.height
    else:
        width, height = short, short * source.height / source.width
    return int(round(width / 2.0)) * 2, int(round(height / 2.0)) * 2, ratio


def project_fps(episode: Episode, include_pending: bool = True) -> float:
    """The frame rate the whole video runs at: the most common source rate."""
    rates = [round(_fps(c), 3) for c in _keepers(episode, include_pending)]
    if not rates:
        return 24.0
    return Counter(rates).most_common(1)[0][0]


# ------------------------------------------------------------- encoding
def _encode(build_args, seconds: float, what: str, config: Config):
    """Run one encode with a deadline. If it fails or stalls while a hardware
    encoder is in use, give the hardware up for this process and do the
    piece again on the CPU. `build_args` is called each time so it picks up
    the encoder that is now in force."""
    timeout = max(45.0, 10.0 * max(seconds, 1.0))
    args = build_args()
    result = run(args, timeout=timeout)
    # Retry on the CPU whenever THIS attempt used the hardware -- not only
    # when the hardware is still in force. Pieces are cut four at a time; when
    # Quick Sync failed on several at once, the first demoted it and the
    # others, seeing the CPU already chosen, gave up without a retry: clips
    # 2, 3 and 4 of a 240-clip test were dropped that way (24 Sep 2026).
    if result.returncode != 0 and encoders.uses_hardware(args):
        detail = result.stderr.decode("utf-8", "replace")[-200:].strip() if result.stderr else ""
        mine = not encoders.is_demoted()        # this call is the one setting the hardware aside
        encoders.demote("{}: {}".format(what, detail or "exit {}".format(result.returncode)))
        result = run(build_args(), timeout=timeout)
        if result.returncode != 0 and mine:
            # The CPU could not do it either: the source is at fault, not
            # the encoder. A broken download must not push the rest of the
            # export (and the conform pass) onto the CPU.
            encoders.reinstate("{} failed on the CPU as well, so the source is at fault".format(what))
    return result


PIECE_SUFFIX = ".mov"


def _piece_args(config: Config) -> List[str]:
    """One set of settings for every piece: near lossless video at the
    source size, PCM audio.

    The audio of a piece is PCM, not AAC. An AAC piece starts with 1024
    priming samples (21 ms) and ends on a whole frame, so every piece came
    out 21 ms longer than its picture and the concat held the last frame
    that long at every join. PCM is sample-exact, and the audio is encoded
    to AAC once, at delivery. The pieces are .mov because mp4 will not
    carry PCM.
    """
    return video_args(config.video_encoder, "intermediate") + [
        "-fps_mode", "cfr",                   # one frame per tick: the piece's frame count is its length
        "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2",
        "-video_track_timescale", "24000",
        "-avoid_negative_ts", "make_zero",
    ]


def _fps(clip: Clip) -> float:
    return clip.media.fps if clip.media and clip.media.fps > 0 else 24.0


def _floor_frame(seconds: float, fps: float) -> float:
    """The last whole frame boundary at or before `seconds`."""
    return math.floor(seconds * fps + 1e-6) / fps


def _snap(seconds: float, fps: float) -> float:
    """The nearest frame boundary. A cut on the grid gives the picture and
    the sound the same length, so neither stream waits for the other at
    the join. The move is at most half a frame, inside the word guard."""
    return round(seconds * fps) / fps


# ffmpeg keeps a frame when its timestamp is >= the seek point, compared in
# microseconds. A frame at 7/24 s is 291666 us and the seek point written as
# 0.291667 is a microsecond later, so the frame is lost and the picture
# starts a frame after the sound. Seeking half a millisecond early keeps the
# frame on the boundary and none before it; the sound moves by the same
# half millisecond, so the two stay together.
_SEEK_EPS = 0.0005


def _t(seconds: float) -> str:
    return "{:.6f}".format(max(0.0, seconds))


def _rate_filter(clip: Clip, fps: float) -> List[str]:
    """Bring a clip whose rate differs from the project's onto it. Clips
    already on the project rate are left alone: no dropped or doubled
    frames where none are needed."""
    if abs(_fps(clip) - fps) > 0.5:
        return ["fps={:.3f}".format(fps)]
    return []


def render_dissolve(before: Job, after: Job, seconds: float, dest: Path,
                    config: Config, fps: float) -> bool:
    """Cross-dissolve the last `seconds` of one job into the first `seconds`
    of the next, straight from the two source clips.

    Rendering each join on its own keeps memory flat however long the episode
    is; a single xfade chain over 150 inputs would have to hold them all.
    A side ffmpeg cannot read is repaired (rescue_source) and the blend is
    made once more from the copies, which share the sources' timeline.
    """
    ffmpeg = require("ffmpeg")
    seconds = _snap(seconds, fps)
    count = max(1, int(round(seconds * fps)))
    a_from = _snap(before.end, _fps(before.clip)) - seconds
    b_from = _snap(after.start, _fps(after.clip))
    fa = ",".join(_rate_filter(before.clip, fps) + [continuity.colour_filter(before.shift)]).strip(",")
    fb = ",".join(_rate_filter(after.clip, fps) + [continuity.colour_filter(after.shift)]).strip(",")
    fa = (fa + ",") if fa else ""
    fb = (fb + ",") if fb else ""
    graph = (
        "[0:v]trim=start={a}:duration={d},setpts=PTS-STARTPTS,{fa}format=yuv420p[va];"
        "[1:v]trim=start={b}:duration={d},setpts=PTS-STARTPTS,{fb}format=yuv420p[vb];"
        "[va][vb]xfade=transition=fade:duration={d}:offset=0,trim=duration={d}[v];"
        "[0:a]atrim=start={a}:duration={d},asetpts=PTS-STARTPTS,"
        "aformat=sample_rates=48000:channel_layouts=stereo{ma}[aa];"
        "[1:a]atrim=start={b}:duration={d},asetpts=PTS-STARTPTS,"
        "aformat=sample_rates=48000:channel_layouts=stereo{mb}[ab];"
        "[aa][ab]acrossfade=d={d}:c1=tri:c2=tri,atrim=duration={d}[a]"
    ).format(a=_t(a_from - _SEEK_EPS), b=_t(b_from - _SEEK_EPS), d=_t(seconds), fa=fa, fb=fb,
             ma=",volume=0" if before.clip.muted else "",
             mb=",volume=0" if after.clip.muted else "")

    def args_for(first: Path, second: Path):
        def build():
            return [
                ffmpeg, "-nostdin", "-loglevel", "error", "-y",
                "-i", str(first),
                "-i", str(second),
                "-filter_complex", graph,
                "-map", "[v]", "-map", "[a]",
                "-t", _t(seconds), "-frames:v", str(count),
            ] + _piece_args(config) + [str(dest)]
        return build
    what = "blend into clip {}".format(after.clip.number)
    result = _encode(args_for(before.clip.path, after.clip.path), seconds, what, config)
    note = ""
    if result.returncode != 0:
        reason = _last_line(result.stderr) or "exit {}".format(result.returncode)
        log.warning("Blend failed between clips %d and %d: %s", before.clip.number, after.clip.number, reason)
        note = "ffmpeg: " + reason
        first = rescue_source(before.clip, dest.parent)
        second = rescue_source(after.clip, dest.parent)
        if first is None or second is None:
            note += "; no repaired copy could be made"
        else:
            result = _encode(args_for(first, second), seconds, what + " (repaired)", config)
            if result.returncode == 0:
                note = "rescued: blend into clip {} made from repaired copies".format(after.clip.number)
                log.info("Blend between clips %d and %d made from their repaired copies",
                         before.clip.number, after.clip.number)
            else:
                note += "; the repaired copies failed too ({})".format(_last_line(result.stderr) or "exit")
    _CUT_NOTES[str(dest)] = note
    return result.returncode == 0 and dest.exists() and dest.stat().st_size > 0


def body_span(job: Job) -> Tuple[float, float]:
    """The source span a job's piece covers, on the clip's frame grid. A
    blend either side has already claimed its lead and trail."""
    clip_fps = _fps(job.clip)
    start = _snap(job.start + job.lead, clip_fps)
    end = _snap(job.end - job.trail, clip_fps)
    if end - start < 1.0 / clip_fps:
        end = start + 1.0 / clip_fps
    return start, end


def piece_frames(job: Job, fps: float, limit: Optional[float] = None) -> int:
    """How many output frames a job's piece is: its span on the clip's own
    frame grid, brought to the output rate and rounded to whole frames,
    cut to `limit` (the source's usable end) when the file stops early.
    The sound is cut to exactly this many frames' worth, so a piece at
    another frame rate no longer carries a fraction of a frame of sound
    past its picture (measured 2 Oct 2026: +6.7 ms per 25-fps piece,
    -8.3 ms per 24-fps piece, eight of which made a segment 0.07 s off its
    plan)."""
    start, end = body_span(job)
    if limit is not None and limit > 0:
        end = min(end, limit)
    return max(1, int(round((end - start) * fps)))


def cut_segment(job: Job, dest: Path, config: Config, fps: float, frames: Optional[int] = None,
                got: Optional[float] = None) -> bool:
    """Encode one span, near lossless. Output seeking keeps the cut
    frame-accurate.

    Output seeking (-ss after -i) is frame-accurate, which matters because
    caption timings are derived from the planned durations -- a frame of
    drift per segment would desync them by seconds across a full episode.
    The cost is that frames reach the filters with their ORIGINAL
    timestamps, so fade offsets have to be expressed on the source clip's
    timeline, not from zero. Getting this wrong is silent and ugly:
    `fade=out` holds black once it finishes, so an early fade blacks out
    the rest of the segment.

    A source ffmpeg cannot cut -- a download that broke off, a stream it
    decodes only part of -- is decoded once with errors ignored into a
    clean copy (rescue_source) and the piece is cut from that, with the
    same filters on the same timeline. A copy that ends early gives a
    shorter piece, its fades and ramps moved to the real end, and a note
    the export puts in the edit log.
    """
    ffmpeg = require("ffmpeg")
    start, end = body_span(job)
    # The piece is `frames` whole output frames: the picture is capped at
    # that count and the sound cut at exactly that many frames' worth.
    if frames is None:
        frames = piece_frames(job, fps)
    end = start + frames / fps
    base_video: List[str] = _rate_filter(job.clip, fps)
    colour = continuity.colour_filter(job.shift)
    if colour:
        base_video.append(colour)

    def filters(end_at: float) -> Tuple[List[str], List[str]]:
        duration = max(0.05, end_at - start)
        fade = min((job.fade_ms or config.edge_fade_ms) / 1000.0, duration / 2.0)
        # A clean cut ramps the audio over a few milliseconds at each edge:
        # the picture still snaps, the sound cannot click.
        ramp = min(config.cut_audio_ramp_ms / 1000.0, duration / 4.0)
        video = list(base_video)
        audio: List[str] = []
        if job.fade_in and fade > 0:
            video.append("fade=t=in:st={:.3f}:d={:.3f}".format(start, fade))
            audio.append("afade=t=in:st={:.3f}:d={:.3f}".format(start, fade))
        if job.fade_out and fade > 0:
            at = max(start, end_at - fade)
            video.append("fade=t=out:st={:.3f}:d={:.3f}".format(at, fade))
            audio.append("afade=t=out:st={:.3f}:d={:.3f}".format(at, fade))
        if job.ramp_in and ramp > 0:
            audio.append("afade=t=in:st={:.3f}:d={:.3f}".format(start, ramp))
        if job.ramp_out and ramp > 0:
            audio.append("afade=t=out:st={:.3f}:d={:.3f}".format(end_at - ramp, ramp))
        if job.clip.muted:
            # Silence, not absence: the piece keeps its stereo track so the
            # concat sees the same streams in every file.
            audio = ["volume=0"]
        # A source whose sound stops before its picture (ordinary: AAC
        # frames are 1024 samples, so a healthy clip's sound can end a few
        # tens of milliseconds before its last frame) is padded with
        # silence; the output -to then trims every piece's sound at exactly
        # `count` frames' worth, so a piece's sound and picture agree.
        audio.append("apad")
        return video, audio

    def args_for(source: Path, end_at: float):
        count = max(1, int(round((end_at - start) * fps)))
        # Both edges move by the same half millisecond, so the sound is
        # exactly `count` frames' worth even when the start is 0 and cannot
        # move earlier (that lost 24 samples per piece; measured 2 Oct 2026).
        seek = max(0.0, start - _SEEK_EPS)

        def build():
            video, audio = filters(end_at)
            built = [
                ffmpeg, "-nostdin", "-loglevel", "error", "-y",
                "-i", str(source),
                "-ss", _t(seek),
                "-to", _t(seek + count / fps),
                "-frames:v", str(count),
            ]
            if video:
                built += ["-vf", ",".join(video)]
            if audio:
                built += ["-af", ",".join(audio)]
            return built + _piece_args(config) + [str(dest)]
        return build

    what = "clip {}".format(job.clip.number)
    if got is not None:
        # The first cut went through but came out `got` seconds long: the
        # file ran out of picture and sound before the planned end. Seen 29
        # Sep 2026: a "10s" 720p download that stops at 9 s -- its header
        # says 10 s, so the plan kept its tail to 10.01 s, and the export
        # stopped with "came out 0.71 s instead of 1.71 s". When the span
        # runs to the clip's stated end, the file simply stops early: cut
        # again to where it really ends, so the fade and the sound ramp land
        # on the real end, and say how much is missing. Anywhere else the
        # stream has a hole, and the clip goes through the repair below.
        stated = job.clip.media.duration if job.clip.media else 0.0
        # The real end, as whole output frames below it.
        real_end = _floor_frame(start + got, fps)
        if stated > 0 and end >= stated - 0.1 and real_end - start >= 1.0 / fps:
            result = _encode(args_for(job.clip.path, real_end), max(0.05, got), what + " (to its real end)", config)
            if result.returncode == 0 and dest.exists() and dest.stat().st_size > 0:
                note = "rescued: cut to where the file really ends; the file ends {:.2f} s early".format(end - real_end)
                log.info("Clip %d stops %.2f s before its stated length; cut to its real end", job.clip.number,
                         end - real_end)
                _CUT_NOTES[str(dest)] = note
                return True
        result = SimpleNamespace(returncode=1, stdout=b"", stderr="came out {:.2f} s instead of {:.2f} s".format(
            got, end - start).encode("utf-8"))
    else:
        result = _encode(args_for(job.clip.path, end), max(0.05, end - start), what, config)
    note = ""
    if result.returncode != 0:
        reason = _last_line(result.stderr) or "exit {}".format(result.returncode)
        log.warning("Cut failed for clip %d: %s", job.clip.number, reason)
        note = "ffmpeg: " + reason
        rescued = rescue_source(job.clip, dest.parent)
        if rescued is None:
            note += "; no repaired copy could be made"
        else:
            available = _shorter_stream(rescued)
            end_here = min(end, _floor_frame(available, fps)) if available > 0 else end
            if end_here - start < 1.0 / fps:
                note += "; the repaired copy ends before this point"
            else:
                result = _encode(args_for(rescued, end_here), max(0.05, end_here - start), what + " (repaired)", config)
                if result.returncode == 0:
                    short = end - end_here
                    note = "rescued: cut from a repaired copy of the source" + (
                        "; the file ends {:.2f} s early".format(short) if short > 0.05 else "")
                    log.info("Clip %d cut from its repaired copy%s", job.clip.number,
                             " ({:.2f} s short)".format(short) if short > 0.05 else "")
                else:
                    note += "; the repaired copy failed too ({})".format(_last_line(result.stderr) or "exit")
    _CUT_NOTES[str(dest)] = note
    return result.returncode == 0 and dest.exists() and dest.stat().st_size > 0


# What happened to each piece, by its destination: "" when it went
# through, "ffmpeg: ..." (the last line ffmpeg wrote) when it could not be
# made, "rescued: ..." when it was cut from a repaired copy of its source.
# Pieces are cut on several threads; each writes only its own key.
_CUT_NOTES: Dict[str, str] = {}
RESCUE_SUFFIX = ".rescued.mov"
# One repair per source at a time: two pieces of one damaged clip are cut
# on two threads, and both would otherwise write the same copy at once.
_RESCUE_LOCKS: Dict[str, threading.Lock] = {}
_RESCUE_GUARD = threading.Lock()


def cut_note(dest) -> str:
    return _CUT_NOTES.get(str(dest), "")


def _last_line(stderr) -> str:
    text = stderr.decode("utf-8", "replace") if stderr else ""
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    return lines[-1][-160:] if lines else ""


def _shorter_stream(path: Path) -> float:
    """How far a repaired copy really goes: the shorter of its picture and
    its sound. A broken download's sound can outlast its picture at the
    break, and the container reports the longer one."""
    from .export_job import probe as ffprobe
    found = ffprobe(path)
    streams = [x for x in (found.video_seconds, found.audio_seconds) if x > 0]
    return min(streams) if streams else found.seconds


def rescue_source(clip: Clip, folder: Path) -> Optional[Path]:
    """A clean copy of a source clip ffmpeg could not cut: decoded once with
    errors ignored and damaged packets dropped, written as constant-rate
    H.264 with PCM sound at the clip's own frame rate, and kept beside the
    pieces so a clip that appears twice is repaired once. None when even
    that fails -- the file is beyond ffmpeg, and the export says so.

    Seen 28 Sep 2026: thirteen 720p downloads in one folder that ffprobe
    read but ffmpeg would not re-encode; the editor got "could not be
    encoded" thirteen times and no reason."""
    ffmpeg = require("ffmpeg")
    key = hashlib.sha1(str(clip.path).encode("utf-8", "replace")).hexdigest()[:12]
    dest = Path(folder) / "rescued_{}_{}{}".format(clip.number, key, RESCUE_SUFFIX)
    with _RESCUE_GUARD:
        lock = _RESCUE_LOCKS.setdefault(str(dest), threading.Lock())
    with lock:
        if dest.is_file() and dest.stat().st_size > 0:
            return dest
        seconds = clip.media.duration if clip.media else 0.0
        partial = dest.with_name(dest.stem + ".part.mov")
        result = run([
            ffmpeg, "-nostdin", "-loglevel", "error", "-y",
            "-fflags", "+genpts+discardcorrupt", "-err_detect", "ignore_err",
            "-i", str(clip.path), "-map", "0:v:0", "-map", "0:a?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "12", "-pix_fmt", "yuv420p",
            "-fps_mode", "cfr", "-r", "{:.3f}".format(_fps(clip)),
            "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2",
            "-video_track_timescale", "24000", "-avoid_negative_ts", "make_zero", str(partial),
        ], timeout=max(120.0, 15.0 * max(seconds, 1.0)))
        if result.returncode != 0 or not partial.is_file() or partial.stat().st_size == 0:
            log.warning("Clip %d could not be repaired either: %s", clip.number,
                        _last_line(result.stderr) or "exit {}".format(result.returncode))
            partial.unlink(missing_ok=True)
            return None
        partial.replace(dest)
        log.info("Clip %d repaired into %s", clip.number, dest.name)
        return dest


# Seconds without any new output before the final encode (or the seam check)
# is called hung and killed. A working encoder writes output every second;
# three minutes leaves room for a slow start on a busy laptop.
DELIVERY_STALL = 180.0


def deliver(segments: List[Path], output: Path, config: Config, size: Tuple[int, int],
            srt: Optional[Path] = None, seconds: float = 0.0,
            on_progress: Optional[Callable[[float], None]] = None) -> None:
    """The one delivery encode: the pieces stitched in order, scaled once to
    the output size, captions burned in the same pass, AAC audio at 48 kHz.

    The subtitles filter takes a path inside a filter string, where Windows
    drive letters and backslashes both need escaping. Running ffmpeg from
    the file's own folder and passing a bare filename sidesteps that.
    """
    ffmpeg = require("ffmpeg")
    listing = output.parent / (output.stem + "_concat.txt")
    listing.write_text(
        "\n".join("file '{}'".format(p.as_posix().replace("'", "'\\''")) for p in segments),
        encoding="utf-8",
    )
    width, height = size
    filters: List[str] = []
    if any((p for p in segments)):
        filters.append("scale={}:{}:flags=lanczos".format(width, height))
    if srt is not None:
        style = ("FontName={},FontSize={},PrimaryColour=&H00FFFFFF,OutlineColour=&H90000000,BorderStyle=3,"
                 "Outline=1,Shadow=0,MarginV=28".format(config.caption_font, config.caption_font_size))
        filters.append("subtitles={}:force_style='{}'".format(srt.name, style))
    try:
        def args():
            return [
                ffmpeg, "-nostdin", "-loglevel", "error", "-y",
                "-f", "concat", "-safe", "0", "-i", str(listing),
                "-vf", ",".join(filters + ["format=yuv420p"]),
            ] + video_args(config.video_encoder, "delivery", config.delivery_crf, config.delivery_preset) + [
                "-c:a", "aac", "-b:a", config.audio_bitrate, "-ar", "48000",
                "-movflags", "+faststart",
                str(output),
            ]
        # The whole episode in one pass takes a while (a 50-minute episode
        # runs for most of an hour on a laptop CPU), so ffmpeg reports how
        # far it has got and a job that stops moving is killed after
        # DELIVERY_STALL seconds -- a hung hardware encoder is caught in
        # minutes and the encode starts again on the CPU.
        timeout = max(600.0, 4.0 * max(seconds, 60.0))
        cwd = str(srt.parent) if srt is not None else None
        result = run_with_progress(args(), on_progress, DELIVERY_STALL, timeout, cwd)
        if result.returncode != 0 and encoders.hardware_active(config.video_encoder):
            detail = result.stderr.decode("utf-8", "replace")[-200:].strip() if result.stderr else ""
            encoders.demote("delivery: " + (detail or "exit {}".format(result.returncode)))
            if on_progress is not None:
                on_progress(-1.0)                     # tells the caller the encode starts again
            result = run_with_progress(args(), on_progress, DELIVERY_STALL, timeout, cwd)
        if result.returncode != 0:
            detail = result.stderr.decode("utf-8", "replace")[-500:] if result.stderr else ""
            raise RuntimeError("the final encode failed: " + detail)
    finally:
        listing.unlink(missing_ok=True)


# ----------------------------------------------------------- seam check
def _clock(seconds: float) -> str:
    seconds = int(max(0.0, seconds))
    return "{}:{:02d}".format(seconds // 60, seconds % 60)


def seam_check(output: Path, join_times: List[float], window: float = 0.5,
               on_progress: Optional[Callable[[float], None]] = None) -> List[str]:
    """Decode the finished file and look for black or frozen frames near
    each join. Returns the findings in words; an empty list is a clean
    pass. A check that could not run says so as its one finding."""
    ffmpeg = find_tool("ffmpeg")
    if not ffmpeg:
        return ["seam check skipped: ffmpeg not found"]
    duration = join_times[-1] if join_times else 0.0
    result = run_with_progress([ffmpeg, "-nostdin", "-i", str(output), "-an",
                                "-vf", "scale=160:90:flags=area,blackdetect=d=0.08:pix_th=0.04,"
                                       "freezedetect=n=0.002:d=0.4",
                                "-f", "null", "-"], on_progress, DELIVERY_STALL,
                               max(1800.0, 2.0 * duration))
    if result.returncode in (TIMED_OUT, STALLED):
        return ["seam check skipped: " + result.stderr.decode("utf-8", "replace").splitlines()[-1]]
    text = result.stderr.decode("utf-8", "replace") if result.stderr else ""
    findings: List[str] = []
    import re
    blacks = [(float(m.group(1)), float(m.group(2))) for m in re.finditer(
        r"black_start:([\d.]+) black_end:([\d.]+)", text)]
    freezes = [float(m.group(1)) for m in re.finditer(r"freeze_start: ([\d.]+)", text)]
    joins = sorted(join_times)

    def near(at: float) -> Optional[float]:
        for join in joins:
            if abs(join - at) <= window:
                return join
        return None
    for start, end in blacks:
        if start < 0.1 or (joins and end > joins[-1] and near(end) is None and start > joins[-1]):
            continue                                    # the episode's own fades
        join = near(start) or near(end)
        findings.append("black frames {:.2f}–{:.2f} s{}".format(
            start, end, " at the join at {:.2f} s".format(join) if join is not None else ""))
    for at in freezes:
        join = near(at)
        if join is not None:
            findings.append("frozen frames from {:.2f} s at the join at {:.2f} s".format(at, join))
    return findings


# ---------------------------------------------------------------- build
def edit_log_path(output: Path) -> Path:
    return output.with_name(output.stem.replace(".part", "") + " - edit log.txt")


def build(
    episode: Episode,
    config: Config,
    output: Path,
    include_pending: bool = True,
    progress: Progress = None,
    keep_segments_dir: Optional[Path] = None,
    cancel=None,
) -> Path:
    """Settle every join, then export in checked, resumable segments (export_job.py)."""
    output = Path(output)
    jobs, dissolves = jobs_for(episode, config, include_pending)
    if not jobs:
        raise ValueError("nothing to assemble: no clips are approved or pending")
    width, height, ratio = output_size(episode, config, include_pending)
    fps = project_fps(episode, include_pending)
    output.parent.mkdir(parents=True, exist_ok=True)


    edit_log: List[str] = ["Output: {}x{} ({}), {:.3f} fps, encoder {}".format(
        width, height, ratio, fps, encoders.describe(config.video_encoder))]
    records: List[continuity.JoinRecord] = []
    if config.continuity_analysis:
        if progress:
            progress(0, 1, "reading the joins")
        jobs, dissolves, records = refine(jobs, dissolves, config)
        edit_log.append("Joins: {} cuts, {} blends".format(
            sum(1 for r in records if r.kind == "cut"), sum(1 for r in records if r.kind == "blend")))
        edit_log += [r.line() for r in records]
    else:
        edit_log.append("Joins: planned without reading the frames (continuity_analysis is off)")
    cuts = [(job.clip, cut) for job in jobs if job.index == 0 for cut in job.clip.cuts]
    if cuts:
        edit_log.append("Automatic cuts: {}".format(len(cuts)))
        for clip, cut in cuts:
            edit_log.append("clip {} ({}): {} — {}{}; confidence {}{}".format(
                clip.number, clip.path.name, cut.get("reason", ""),
                "removed {:.2f} s ".format(cut["removed"]) if cut.get("removed") else "",
                "at {:.2f}–{:.2f} s".format(cut.get("from", 0.0), cut.get("to", 0.0)),
                cut.get("confidence", ""), ("; " + cut["detail"]) if cut.get("detail") else ""))

    # The export: segmented, checkpointed and resumable (export_job.py).
    from .export_job import export
    srt_path = output.with_name(output.stem.replace(".part", "") + ".srt")
    captions = None
    if config.captions == "burn":
        # Written again before every segment from the lengths measured so
        # far, so the burned cues follow the picture exactly.
        def captions(measured, path):
            cues = build_cues(episode, config, actual_durations=measured or None)
            return bool(cues) and write_srt(cues, path) is not None
    log.info("Assembling %d pieces, %d blends, %dx%d, %.3f fps", len(jobs), len(dissolves), width, height, fps)
    result = export(jobs, dissolves, config, output, (width, height), fps, captions=captions,
                    progress=progress, keep_folder=keep_segments_dir, cancel=cancel)
    if config.captions == "srt":
        # Measure what was actually encoded rather than trusting the plan,
        # so captions cannot drift away from the picture over a long episode.
        cues = build_cues(episode, config, actual_durations=result.measured)
        write_srt(cues, srt_path)
    edit_log += result.log
    if result.rescues:
        edit_log.append("Repaired clips: {}".format(len(result.rescues)))
        edit_log += ["  " + r for r in result.rescues]
        for r in result.rescues:
            log.warning("Repaired clip: %s", r)
    edit_log.append("Seam check: {}".format(
        "off" if not config.seam_check else "clean" if not result.findings
        else "{} finding(s)".format(len(result.findings))))
    edit_log += ["  " + f for f in result.findings]
    for finding in result.findings:
        log.warning("Seam check: %s", finding)
    try:
        edit_log_path(output).write_text("\n".join(edit_log) + "\n", encoding="utf-8")
    except OSError as exc:
        log.warning("The edit log could not be written: %s", exc)
    return output
