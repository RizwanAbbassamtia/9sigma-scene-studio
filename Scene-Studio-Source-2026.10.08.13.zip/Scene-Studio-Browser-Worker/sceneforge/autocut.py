"""Turn detected speech into a concrete keep-plan for each clip.

The rule is deliberately conservative: keep everything from just before the
first word to just after the last one, and keep a wordless clip up to where
its content stops. Anything more aggressive risks clipping dialogue or a
reaction, and a re-render costs far more than a second of extra footage.

Every automatic removal is written to the clip's cut log with its reason
and confidence, and the plan is rebuilt from the analysis every time, so
running it twice on the same footage never removes more.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

from .config import Config
from .models import Clip, Episode, Flag, ReviewState, SpeechSpan
from .motion import PROFILE_WINDOW
from . import repetition as repetition_rules


MAX_CALIBRATION_PASSES = 6
CALIBRATION_TOLERANCE = 0.01     # 1% between passes counts as settled


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))



def _merge_close(spans: List[SpeechSpan], max_gap: float) -> List[SpeechSpan]:
    """Join spans separated by less than max_gap so we do not cut mid-sentence."""
    if not spans:
        return []
    merged = [spans[0]]
    for span in spans[1:]:
        last = merged[-1]
        if span.start - last.end <= max_gap:
            merged[-1] = SpeechSpan(last.start, span.end)
        else:
            merged.append(span)
    return merged


def _true_silence_within(clip: Clip, lo: float, hi: float) -> float:
    """Longest stretch of whole-mix silence inside (lo, hi), in seconds."""
    longest = 0.0
    for span in clip.silence:
        a, b = max(span.start, lo), min(span.end, hi)
        if b - a > longest:
            longest = b - a
    return longest


def _split_on_silence(spans: List[SpeechSpan], clip: Clip, config: Config) -> List[SpeechSpan]:
    """Merge speech spans, except across a pause that is truly silent.

    A pause is cut only when nothing at all is playing under it -- no voice,
    no music, no ambience -- for at least min_silent_gap_ms. A pause with music
    under it stays, because cutting it would make the music jump. That is the
    whole difference between this and _merge_close.
    """
    if not spans:
        return []
    if not config.tighten_mid_gaps:
        return [SpeechSpan(spans[0].start, spans[-1].end)]
    max_gap = config.max_mid_gap_ms / 1000.0
    need = config.min_silent_gap_ms / 1000.0
    merged = [spans[0]]
    for span in spans[1:]:
        last = merged[-1]
        gap = span.start - last.end
        if gap > max_gap and _true_silence_within(clip, last.end, span.start) >= need:
            merged.append(span)
        else:
            merged[-1] = SpeechSpan(last.start, span.end)
    return merged


def _pad(spans: List[SpeechSpan], head: float, tail: float, mid: float,
         duration: float) -> List[SpeechSpan]:
    """Breathing room: head before the first word, tail after the last, and a
    short margin either side of a tightened mid-scene pause."""
    out = []
    last = len(spans) - 1
    for index, span in enumerate(spans):
        start = span.start - (head if index == 0 else mid)
        end = span.end + (tail if index == last else mid)
        out.append(SpeechSpan(_clamp(start, 0.0, duration), _clamp(end, 0.0, duration)))
    return out


def _guard_words(clip: Clip, spans: List[SpeechSpan], config: Config,
                 duration: float) -> List[SpeechSpan]:
    """Push each cut outward past any quiet speech it would otherwise land on.

    The main detector is tuned not to mistake a music bed for a voice, which
    means it can leave off the soft start of a word or a trailing consonant.
    The soft pass hears those. If any of it lies within word_guard_ms of a
    planned cut, or straddles it, the cut moves to clear it by a tenth of a
    second. Nothing here ever moves a cut inward.
    """
    if not spans or not clip.speech_soft:
        return spans
    guard = config.word_guard_ms / 1000.0
    margin = 0.1
    out: List[SpeechSpan] = []
    for span in spans:
        start, end = span.start, span.end
        for soft in clip.speech_soft:
            if soft.start < start and soft.end > start - guard:
                start = min(start, soft.start - margin)
            if soft.end > end and soft.start < end + guard:
                end = max(end, soft.end + margin)
        out.append(SpeechSpan(_clamp(start, 0.0, duration), _clamp(end, 0.0, duration)))
    return out


def plan_clip(clip: Clip, config: Config,
              chars_per_second: float | None = None,
              has_script: bool = True) -> None:
    """Fill in clip.keep, clip.flags and clip.state. Idempotent.

    `chars_per_second` overrides the configured seed with a rate measured
    from this episode. It affects quality flags only, never the cut.

    `has_script` says whether the episode has a script at all. Without one
    the audio is the only script there is: a clip with speech is dialogue and
    a clip without is B-roll, and neither is a surprise worth a flag.
    """
    _plan(clip, config, chars_per_second, has_script)
    if config.trim_mode == "manual" and clip.media and clip.media.duration > 0:
        # The editor asked to do the trimming. Everything the analysis found
        # is kept for the panel; only the cut itself is handed over untouched.
        clip.keep = [SpeechSpan(0.0, clip.media.duration)]
        if clip.state == ReviewState.REJECTED:
            clip.state = ReviewState.PENDING


def _plan(clip: Clip, config: Config, chars_per_second: float | None,
          has_script: bool) -> None:
    rate = (chars_per_second if chars_per_second and chars_per_second > 0
            else config.chars_per_second)
    # Planning is idempotent, so the flags and the cut log this pass owns
    # are cleared first; otherwise a re-plan would leave the old verdict
    # behind alongside the new one -- or remove a little more each time.
    clip.flags.discard(Flag.SPEECH_TRUNCATED)
    clip.flags.discard(Flag.SPEECH_MUCH_SHORTER)
    clip.flags.discard(Flag.REPEATED_SPEECH)
    clip.cuts = []
    duration = clip.media.duration if clip.media else 0.0
    if duration <= 0:
        clip.flags.add(Flag.UNREADABLE)
        clip.keep = []
        clip.state = ReviewState.PENDING
        return

    head = config.head_pad_ms / 1000.0
    # Once the dialogue is done the rest of the clip is dead weight, so it goes.
    # How much is held back depends on what comes next: a continuation inside the
    # same scene can cut tight, a scene change needs room to land.
    tail = (config.scene_change_tail_ms if clip.ends_scene else config.tail_pad_ms) / 1000.0
    if has_script and clip.scene is not None:
        scripted = clip.scene.has_dialogue
    else:
        # No script, or a script that does not mention this clip (its number
        # is missing; NO_SCENE_MATCH says so): the audio is the script.
        # Speech heard is dialogue and is trimmed as dialogue -- never
        # planned as a wordless clip and kept whole.
        scripted = bool(clip.speech)

    # --- scripted dialogue --------------------------------------------------
    if scripted:
        if not clip.speech:
            # The script says someone speaks and nothing was heard: a bad render.
            clip.flags.add(Flag.SCRIPTED_BUT_SILENT)
            clip.keep = [SpeechSpan(0.0, duration)]
            clip.state = ReviewState.PENDING
            return

        spans = _split_on_silence(clip.speech, clip, config)
        mid = config.max_mid_gap_ms / 2000.0
        clip.keep = _guard_words(clip, _pad(spans, head, tail, mid, duration),
                                 config, duration)
        _log_tightened_pauses(clip, spans, duration)
        _apply_repetitions(clip, config)
        if clip.scene is not None:
            _flag_dialogue_quality(clip, config, duration, rate)
        return

    # --- scenes scripted "no says" -----------------------------------------
    if clip.speech and has_script and clip.scene is not None:
        # Usually ambient human voice (children, a distant argument), not dialogue.
        clip.flags.add(Flag.SPEECH_NOT_SCRIPTED)

    action = config.no_dialogue_action
    if action == "delete":
        clip.keep = []
        clip.state = ReviewState.REJECTED
        return
    if action == "keep":
        clip.keep = [SpeechSpan(0.0, duration)]
        return

    if config.content_aware_trimming:
        # No dialogue is not no value: the clip is kept up to where its
        # content stops -- movement, a camera move, sound under it -- and
        # only the dead stretch after that goes. Unmeasured motion means
        # nothing is known, so nothing is removed.
        end, why, confidence = _end_of_value(clip, config, duration)
        if end is None:
            clip.keep = [SpeechSpan(0.0, duration)]
            clip.cuts.append(_cut("Kept whole", 0.0, "low", duration, duration, why))
        else:
            # Nothing of value at all: the bare minimum, without a tail
            # that would only hold the dead frames a little longer.
            keep = min(duration, max(config.min_clip_seconds, end + tail) if end > 0 else config.min_clip_seconds)
            clip.keep = [SpeechSpan(0.0, keep)]
            removed = duration - keep
            if removed > 0.3:
                clip.cuts.append(_cut("Static/dead segment", removed, confidence, keep, duration, why))
        if action == "review":
            clip.state = ReviewState.PENDING
        return

    target = min(config.no_dialogue_seconds, duration)
    clip.keep = [SpeechSpan(0.0, max(config.min_clip_seconds, target))]
    if duration - clip.keep[0].end > 0.3:
        clip.cuts.append(_cut("No dialogue: fixed length", duration - clip.keep[0].end, "high",
                              clip.keep[0].end, duration, "content-aware trimming is off"))
    if action == "review":
        clip.state = ReviewState.PENDING


def _cut(reason: str, removed: float, confidence: str, start: float, end: float, detail: str = "") -> dict:
    return {"reason": reason, "removed": round(removed, 2), "confidence": confidence,
            "from": round(start, 3), "to": round(end, 3), "detail": detail}


def _quiet_at(clip: Clip, at: float) -> bool:
    """True when the whole mix is silent at this source time."""
    return any(span.start <= at < span.end for span in clip.silence)


def _end_of_value(clip: Clip, config: Config, duration: float) -> Tuple[Optional[float], str, str]:
    """Where a wordless clip's content stops: (end, why, confidence).

    A half-second window counts as content when something moves in it
    (motion_keep_threshold), or when sound plays under it and the picture
    is at least alive (motion_alive_threshold) rather than frozen. The end
    is the end of the last such window. None when motion was not measured.
    """
    profile = list(clip.motion_profile)
    if not profile:
        return None, "motion could not be measured, so nothing was removed", "low"
    last = -1
    for index, motion in enumerate(profile):
        middle = (index + 0.5) * PROFILE_WINDOW
        if motion >= config.motion_keep_threshold:
            last = index
        elif motion >= config.motion_alive_threshold and not _quiet_at(clip, middle):
            last = index
    if last < 0:
        return 0.0, "nothing moves and nothing plays in this clip", "medium"
    end = min(duration, (last + 1) * PROFILE_WINDOW)
    dead = duration - end
    if dead <= 0.3:
        return duration, "content runs to the end", "high"
    tail = profile[last + 1:]
    frozen = all(m < config.motion_frozen_threshold for m in tail)
    why = "after {:.1f} s the picture is {} and {}".format(
        end, "frozen" if frozen else "still", "silent" if _quiet_at(clip, end + 0.1) else "only the bed plays")
    return end, why, "high" if frozen else "medium"


def _log_tightened_pauses(clip: Clip, spans: List[SpeechSpan], duration: float) -> None:
    """A tightened mid-clip pause is a removal too, and goes in the log."""
    for a, b in zip(clip.keep, clip.keep[1:]):
        gap = b.start - a.end
        if gap > 0.05:
            clip.cuts.append(_cut("Silent pause tightened", gap, "high", a.end, b.start,
                                  "the whole mix was silent for {:.2f} s".format(gap)))


def _apply_repetitions(clip: Clip, config: Config) -> None:
    """Remove the high-confidence repeated words, flag the rest.

    Two gates beyond the detector's own: the picture must be nearly still
    across the removal (a jump cut in a talking head is a few pixels; in a
    walk it is a leap), and both sides of the cut must stay long enough to
    play. A removal refused for either reason is flagged instead, never
    made. The removal is a new gap in `keep`; the export joins the two
    sides with a short blend so the music bed does not jump.
    """
    mode = config.repetition_cleanup
    if mode == "off" or not clip.repetitions:
        return
    for raw in clip.repetitions:
        rep = repetition_rules.from_dict(raw)
        if rep is None:
            continue
        start, end = rep.remove
        if rep.confidence != "high" or mode == "flag":
            clip.flags.add(Flag.REPEATED_SPEECH)
            clip.cuts.append(_cut("Repeated word kept for review", 0.0, rep.confidence, start, end, rep.reason))
            continue
        index = next((i for i, span in enumerate(clip.keep) if span.start <= start and end <= span.end), None)
        if index is None:
            continue                                     # already outside the kept material
        motion = _motion_between(clip, start - 0.1, end + 0.1)
        if motion is not None and motion > config.repetition_max_motion:
            clip.flags.add(Flag.REPEATED_SPEECH)
            clip.cuts.append(_cut("Repeated word kept for review", 0.0, "medium", start, end,
                                  "the picture moves too much ({:.1f}) for a clean removal".format(motion)))
            continue
        span = clip.keep[index]
        cut_start, cut_end = max(span.start, start - 0.02), min(span.end, end - 0.02)
        if cut_start - span.start < config.min_clip_seconds or span.end - cut_end < config.min_clip_seconds \
                or cut_end - cut_start < 0.1:
            clip.flags.add(Flag.REPEATED_SPEECH)
            clip.cuts.append(_cut("Repeated word kept for review", 0.0, "medium", start, end,
                                  "too close to the edge of the kept material to cut cleanly"))
            continue
        clip.keep[index:index + 1] = [SpeechSpan(span.start, cut_start), SpeechSpan(cut_end, span.end)]
        clip.cuts.append(_cut("Repeated word detected", cut_end - cut_start, "high", cut_start, cut_end,
                              "{} copies; removed the duplicates and kept the last ({})".format(rep.copies, rep.reason)))


def _motion_between(clip: Clip, start: float, end: float) -> Optional[float]:
    """The strongest half-second of motion inside [start, end], or None
    when motion was not measured."""
    if not clip.motion_profile:
        return None
    first = max(0, int(start / PROFILE_WINDOW))
    last = min(len(clip.motion_profile) - 1, int(end / PROFILE_WINDOW))
    if last < first:
        return None
    return max(clip.motion_profile[first:last + 1])


def _flag_dialogue_quality(clip: Clip, config: Config, duration: float,
                           rate: float) -> None:
    last_end = clip.speech[-1].end
    if last_end >= duration - config.truncation_margin_ms / 1000.0:
        # Speech is still going when the clip runs out. Only a problem if the
        # script implies more dialogue than we actually heard.
        expected = clip.scene.expected_speech_seconds(rate)
        if expected > clip.speech_seconds + 1.0:
            clip.flags.add(Flag.SPEECH_TRUNCATED)

    expected = clip.scene.expected_speech_seconds(rate)
    if expected > 0 and clip.speech_seconds < expected * config.short_speech_ratio:
        clip.flags.add(Flag.SPEECH_MUCH_SHORTER)


def _setting_of(clip: Clip) -> str:
    """What location this clip is in, for deciding where scenes break.

    The script's setting is authoritative. Failing that the filename slug is
    used, because generators name files after the scene prompt and consecutive
    clips in one location share it.

    A slug that is empty or just a number carries no location, so it resolves
    to one shared value. Treating "76" and "77" as different settings would put
    a scene change between every pair of clips.
    """
    if clip.scene and clip.scene.setting:
        return clip.scene.setting.strip().lower()
    slug = clip.slug.strip().lower()
    if not slug or slug.isdigit():
        return ""
    return slug


def mark_scene_boundaries(episode: Episode) -> int:
    """Flag the last clip of each scene and number the scenes. Returns the count."""
    clips = sorted(episode.clips, key=lambda c: c.number)
    count = 0
    scene = 1
    for index, clip in enumerate(clips):
        clip.scene_index = scene
        if index + 1 >= len(clips):
            clip.ends_scene = True          # the episode itself ends here
            count += 1
            continue
        clip.ends_scene = _setting_of(clip) != _setting_of(clips[index + 1])
        if clip.ends_scene:
            count += 1
            scene += 1
    return count


def plan_episode(episode: Episode, config: Config) -> None:
    """Plan every cut, calibrating the speaking rate to this episode's own audio.

    The rate only drives quality flags, never a cut, but getting it wrong makes
    those flags useless: a rate set for one language will call every clip in
    another either truncated or short. So the first pass uses the configured
    seed, the rate is measured from the clips that came out clean, and the
    second pass re-flags with that. Nothing about one project's footage leaks
    into the next.
    """
    # Boundaries first: the tail margin a clip gets depends on whether the next
    # one is a new scene, so this has to be known before any cut is planned.
    mark_scene_boundaries(episode)
    has_script = episode.script_path is not None

    for clip in episode.clips:
        plan_clip(clip, config, has_script=has_script)

    # Calibration excludes truncated clips, and which clips count as truncated
    # depends on the rate, so one pass leaves the answer dependent on the seed.
    # Iterating to a fixed point makes the result a property of the footage
    # rather than of whatever the config happened to say.
    rate = 0.0
    for _ in range(MAX_CALIBRATION_PASSES):
        measured = calibrate_chars_per_second(episode)
        if measured <= 0:
            break
        if rate and abs(measured - rate) / rate < CALIBRATION_TOLERANCE:
            rate = measured
            break
        rate = measured
        for clip in episode.clips:
            plan_clip(clip, config, chars_per_second=rate, has_script=has_script)

    episode.measured_chars_per_second = rate


def trimmed_clip_numbers(episode: Episode) -> List[int]:
    """The clips the plan actually shortened, for the editor's reference."""
    out = []
    for clip in sorted(episode.clips, key=lambda c: c.number):
        if clip.state == ReviewState.REJECTED or not clip.media:
            continue
        if clip.media.duration - clip.cut_duration > 0.05:
            out.append(clip.number)
    return out


def auto_approve(episode: Episode) -> int:
    """Approve every clip that raised no flags. Returns how many were approved."""
    count = 0
    for clip in episode.clips:
        if clip.state != ReviewState.PENDING:
            continue
        if not clip.flags and clip.keep:
            clip.state = ReviewState.APPROVED
            count += 1
    return count


def calibrate_chars_per_second(episode: Episode) -> float:
    """Derive the speaking rate from clips that were not truncated.

    Truncated clips would drag the rate upward, so they are excluded.
    """
    chars = 0
    seconds = 0.0
    for clip in episode.clips:
        if not clip.scene or not clip.scene.has_dialogue or not clip.speech:
            continue
        if Flag.SPEECH_TRUNCATED in clip.flags:
            continue
        chars += clip.scene.dialogue_chars
        seconds += clip.speech_seconds
    if seconds <= 0:
        return 0.0
    return chars / seconds
