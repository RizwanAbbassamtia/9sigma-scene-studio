"""Extract one frame per clip for the filmstrip, cached on disk.

167 clips means 167 ffmpeg calls the first time a project opens. They run in
parallel and land in .sceneforge/thumbs beside the footage, so every later open
is instant.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Dict, Optional

from .ffmpeg_tools import find_tool, run
from .logging_setup import get
from .models import Episode

log = get("thumbs")

THUMB_DIR = ".sceneforge/thumbs"
THUMB_WIDTH = 192
Progress = Optional[Callable[[int, int, str], None]]


def thumb_path(source_dir: Path, number: int) -> Path:
    return Path(source_dir) / THUMB_DIR / "{:05d}.jpg".format(number)


def extract(clip_path: Path, dest: Path, at_seconds: float = 1.0,
            width: int = THUMB_WIDTH) -> bool:
    """Grab a single frame. Seeks before -i, which is fast and accurate enough."""
    ffmpeg = find_tool("ffmpeg")
    if not ffmpeg:
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    result = run([
        ffmpeg, "-nostdin", "-loglevel", "error", "-y",
        "-ss", "{:.2f}".format(max(0.0, at_seconds)),
        "-i", str(clip_path),
        "-frames:v", "1",
        "-vf", "scale={}:-2".format(width),
        "-q:v", "4",
        str(dest),
    ])
    return result.returncode == 0 and dest.exists() and dest.stat().st_size > 0


def ensure(episode: Episode, progress: Progress = None,
           workers: int = 4) -> Dict[int, Path]:
    """Make sure every clip has a thumbnail. Returns {clip number: path}."""
    todo = []
    found: Dict[int, Path] = {}

    for clip in episode.clips:
        dest = thumb_path(episode.source_dir, clip.number)
        if dest.exists() and dest.stat().st_size > 0:
            found[clip.number] = dest
        else:
            todo.append((clip, dest))

    if not todo:
        return found

    log.info("Extracting %d thumbnails", len(todo))
    done = 0

    def work(item):
        clip, dest = item
        # A frame a second in avoids fade-ins and black opening frames
        at = 1.0
        if clip.media and clip.media.duration:
            at = min(1.0, clip.media.duration * 0.15)
        return clip.number, dest, extract(clip.path, dest, at)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        for number, dest, ok in pool.map(work, todo):
            done += 1
            if ok:
                found[number] = dest
            if progress:
                progress(done, len(todo), "thumbnail {}".format(number))

    log.info("Thumbnails ready: %d of %d clips", len(found), len(episode.clips))
    return found


def invalidate(source_dir: Path, number: int) -> None:
    """Drop one cached thumbnail, e.g. after a clip is replaced."""
    path = thumb_path(source_dir, number)
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass
