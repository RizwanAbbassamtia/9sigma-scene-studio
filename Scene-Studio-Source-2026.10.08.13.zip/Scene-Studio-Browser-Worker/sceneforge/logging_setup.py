"""File logging, so a failure three days from now is diagnosable.

Without this a crash tells you only that something went wrong. With it there is
a timestamped file naming the clip, the operation and the traceback, which is
usually enough to fix the problem without reproducing it.
"""
from __future__ import annotations

import logging
import logging.handlers
import platform
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = _PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "sceneforge.log"

_configured = False


def setup(verbose: bool = False) -> Path:
    """Configure logging once. Safe to call repeatedly."""
    global _configured
    if _configured:
        return LOG_FILE

    LOG_DIR.mkdir(parents=True, exist_ok=True)

    # Five 2 MB files is a few weeks of normal use and stays small enough to send
    handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=2 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s  %(levelname)-7s  %(name)-22s  %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    ))

    root = logging.getLogger()
    root.setLevel(logging.DEBUG if verbose else logging.INFO)
    root.addHandler(handler)

    if verbose:
        console = logging.StreamHandler(sys.stderr)
        console.setFormatter(logging.Formatter("%(levelname)-7s %(message)s"))
        root.addHandler(console)

    _configured = True

    log = logging.getLogger("sceneforge")
    log.info("=" * 70)
    log.info("SceneForge starting  %s", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    log.info("%s  |  Python %s", platform.platform(), platform.python_version())
    return LOG_FILE


def install_exception_hook(on_error: Optional[Callable[[str], None]] = None) -> None:
    """Route unhandled exceptions to the log instead of a silent death.

    A GUI has no console, so without this an uncaught exception closes the
    window with nothing to show for it.
    """
    log = logging.getLogger("sceneforge.crash")
    previous = sys.excepthook

    def hook(exc_type, exc_value, exc_tb):
        if issubclass(exc_type, KeyboardInterrupt):
            previous(exc_type, exc_value, exc_tb)
            return
        text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        log.error("Unhandled exception\n%s", text)
        if on_error is not None:
            try:
                on_error(text)
            except Exception:                                  # noqa: BLE001
                pass

    sys.excepthook = hook


def get(name: str) -> logging.Logger:
    return logging.getLogger("sceneforge." + name)
