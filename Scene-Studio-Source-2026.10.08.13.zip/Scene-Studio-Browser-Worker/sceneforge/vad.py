"""Speech detection with Silero VAD (ONNX, CPU).

Volume thresholds are useless on this footage: every clip carries an ambient bed
and a music bed, so nothing is ever truly quiet. Silero scores the probability
that a 32 ms window contains *speech*, which is what we actually need, and it is
language-agnostic -- the dialogue here is Urdu.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import List, Optional

import numpy as np

from .audio import SAMPLE_RATE, decode
from .models import SpeechSpan

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = _PROJECT_ROOT / "vendor" / "models" / "silero_vad.onnx"

WINDOW = 512          # samples per inference step at 16 kHz (32 ms)
CONTEXT = 64          # v5 expects the tail of the previous window prepended
_STATE_SHAPE = (2, 1, 128)


class ModelMissing(RuntimeError):
    pass


def _claim_dll_slot_before_onnx() -> None:
    """Load Qt before onnxruntime, or the interpreter segfaults on Windows.

    Both libraries pull in their own native runtimes. If onnxruntime is imported
    first, a later `import PySide6.QtMultimedia` crashes the process outright --
    no exception, no traceback, just exit code 139. Importing any Qt module
    first claims the slot and both then coexist happily.

    Importing QtCore is enough and costs a fraction of a second. It is skipped
    entirely when PySide6 is not installed, so command-line use is unaffected.
    """
    if "PySide6.QtCore" in sys.modules:
        return
    if importlib.util.find_spec("PySide6") is None:
        return
    try:
        import PySide6.QtCore  # noqa: F401
    except Exception:                                          # noqa: BLE001
        pass


class VoiceDetector:
    """Wraps the ONNX session. Build once, reuse across every clip."""

    def __init__(self, model_path: Path = MODEL_PATH, threads: int = 1):
        if not Path(model_path).exists():
            raise ModelMissing("Silero VAD model not found at {}".format(model_path))
        _claim_dll_slot_before_onnx()
        import onnxruntime as ort

        options = ort.SessionOptions()
        options.inter_op_num_threads = threads
        options.intra_op_num_threads = threads
        options.log_severity_level = 3
        self._session = ort.InferenceSession(
            str(model_path), sess_options=options, providers=["CPUExecutionProvider"]
        )
        self._sr = np.array(SAMPLE_RATE, dtype=np.int64)

    def probabilities(self, samples: np.ndarray) -> np.ndarray:
        """Speech probability for each 512-sample window.

        Silero v5 is stateful in two ways: an LSTM state carried between windows,
        and a 64-sample audio context prepended to each window. Omitting the
        context does not error -- it silently returns near-zero for everything,
        which looks exactly like "no speech found".
        """
        state = np.zeros(_STATE_SHAPE, dtype=np.float32)
        context = np.zeros((1, CONTEXT), dtype=np.float32)
        usable = (len(samples) // WINDOW) * WINDOW
        if usable == 0:
            return np.zeros(0, dtype=np.float32)

        probs = np.empty(usable // WINDOW, dtype=np.float32)
        for index, start in enumerate(range(0, usable, WINDOW)):
            chunk = samples[start : start + WINDOW].reshape(1, WINDOW)
            out, state = self._session.run(
                ["output", "stateN"],
                {
                    "input": np.concatenate([context, chunk], axis=1),
                    "state": state,
                    "sr": self._sr,
                },
            )
            context = chunk[:, -CONTEXT:]
            probs[index] = out[0][0]
        return probs


def spans_from_probabilities(
    probs: np.ndarray,
    threshold: float = 0.5,
    min_speech_ms: int = 250,
    min_silence_ms: int = 300,
    sample_rate: int = SAMPLE_RATE,
) -> List[SpeechSpan]:
    """Turn per-window probabilities into speech spans, in seconds.

    Uses hysteresis: speech starts at `threshold` but only ends once the score
    drops below a lower bar and stays there, so a brief dip mid-sentence does not
    split one line into two.
    """
    if probs.size == 0:
        return []

    window_seconds = WINDOW / sample_rate
    min_speech = min_speech_ms / 1000.0
    min_silence = min_silence_ms / 1000.0
    exit_threshold = max(0.0, threshold - 0.15)

    spans: List[SpeechSpan] = []
    triggered = False
    start = 0.0
    pending_end: Optional[float] = None

    for index, prob in enumerate(probs):
        now = index * window_seconds

        if prob >= threshold:
            pending_end = None
            if not triggered:
                triggered = True
                start = now
            continue

        if triggered and prob < exit_threshold:
            if pending_end is None:
                pending_end = now
            elif now - pending_end >= min_silence:
                if pending_end - start >= min_speech:
                    spans.append(SpeechSpan(start, pending_end))
                triggered = False
                pending_end = None

    if triggered:
        end = probs.size * window_seconds
        if end - start >= min_speech:
            spans.append(SpeechSpan(start, end))

    return spans


def detect(
    path: Path,
    detector: VoiceDetector,
    threshold: float = 0.5,
    min_speech_ms: int = 250,
    min_silence_ms: int = 300,
) -> List[SpeechSpan]:
    samples = decode(Path(path))
    if samples is None:
        return []
    probs = detector.probabilities(samples)
    return spans_from_probabilities(probs, threshold, min_speech_ms, min_silence_ms)
