"""Pull mono PCM out of a clip with ffmpeg, ready for the VAD."""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np

from .ffmpeg_tools import require, run

SAMPLE_RATE = 16_000


def decode(path: Path, sample_rate: int = SAMPLE_RATE) -> Optional[np.ndarray]:
    """Return mono float32 samples in [-1, 1], or None if the clip has no usable audio."""
    ffmpeg = require("ffmpeg")
    result = run([
        ffmpeg,
        "-nostdin",
        "-loglevel", "error",
        "-i", str(path),
        "-vn",
        "-ac", "1",
        "-ar", str(sample_rate),
        "-f", "s16le",
        "-",
    ])
    if result.returncode != 0 or not result.stdout:
        return None
    samples = np.frombuffer(result.stdout, dtype=np.int16)
    if samples.size == 0:
        return None
    return samples.astype(np.float32) / 32768.0


# --- true silence -----------------------------------------------------------
# Voice detection says where people speak. It says nothing about music or an
# ambient bed, and every clip carries both. "True silence" here means the
# whole mix is quiet: no voice, no music, no traffic. Only those gaps are safe
# to cut out of the middle of a scene; cutting where music plays would make
# the music jump.

SILENCE_WINDOW_MS = 50


def loudness_db(samples: np.ndarray, sample_rate: int = SAMPLE_RATE,
                window_ms: int = SILENCE_WINDOW_MS) -> np.ndarray:
    """RMS level per window, in dBFS. -100 marks digital silence."""
    step = max(1, int(sample_rate * window_ms / 1000))
    count = samples.size // step
    if count == 0:
        return np.zeros(0, dtype=np.float32)
    frames = samples[: count * step].reshape(count, step)
    rms = np.sqrt(np.mean(frames.astype(np.float64) ** 2, axis=1))
    with np.errstate(divide="ignore"):
        db = 20.0 * np.log10(np.maximum(rms, 1e-5))
    return db.astype(np.float32)


def silence_spans(samples: np.ndarray, threshold_db: float = -45.0,
                  min_ms: int = 400, sample_rate: int = SAMPLE_RATE):
    """Spans where the whole mix sits below threshold_db for at least min_ms."""
    from .models import SpeechSpan

    db = loudness_db(samples, sample_rate)
    window = SILENCE_WINDOW_MS / 1000.0
    min_len = min_ms / 1000.0
    spans = []
    start = None
    for index, level in enumerate(db):
        quiet = level < threshold_db
        if quiet and start is None:
            start = index * window
        elif not quiet and start is not None:
            end = index * window
            if end - start >= min_len:
                spans.append(SpeechSpan(start, end))
            start = None
    if start is not None:
        end = db.size * window
        if end - start >= min_len:
            spans.append(SpeechSpan(start, end))
    return spans


def music_ratio(samples: np.ndarray, speech, silence, sample_rate: int = SAMPLE_RATE) -> float:
    """Share of the non-speech time that carries sound (music or ambience).

    1.0 means the bed plays the whole way through; 0.0 means the clip is dead
    quiet whenever nobody speaks.
    """
    total = samples.size / float(sample_rate)
    speech_time = sum(s.duration for s in speech)
    quiet_time = sum(s.duration for s in silence)
    remainder = total - speech_time
    if remainder <= 0.2:
        return 1.0
    sounding = max(0.0, remainder - quiet_time)
    return max(0.0, min(1.0, sounding / remainder))
