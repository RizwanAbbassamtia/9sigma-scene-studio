"""A cheap answer to "does anything move in this clip?", and when.

Frames are pulled at 4 per second, shrunk to 64x36 greyscale, and the mean
absolute difference between consecutive frames is taken. A locked-off shot
of an empty room scores near 0; a person walking through it scores several
units; a camera pan scores higher still. It is not a glitch detector: it is
the one number the cut rule needs -- whether a wordless clip is action worth
keeping or a still frame padding a scene -- and, as a profile over time,
where in the clip the action stops.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

import numpy as np

from .ffmpeg_tools import require, run

WIDTH, HEIGHT, FPS = 64, 36, 4
PROFILE_WINDOW = 0.5          # seconds per profile value


def motion_profile(path: Path, window: float = PROFILE_WINDOW) -> List[float]:
    """Mean frame difference per `window` seconds, first to last. Empty
    when the clip could not be read: the caller must treat that as
    "unknown", never as "still"."""
    ffmpeg = require("ffmpeg")
    result = run([
        ffmpeg, "-nostdin", "-loglevel", "error",
        "-i", str(path),
        "-an",
        "-vf", "fps={},scale={}:{}:flags=area,format=gray".format(FPS, WIDTH, HEIGHT),
        "-f", "rawvideo", "-",
    ])
    if result.returncode != 0 or not result.stdout:
        return []
    frame = WIDTH * HEIGHT
    count = len(result.stdout) // frame
    if count < 2:
        return []
    frames = np.frombuffer(result.stdout[: count * frame], dtype=np.uint8)
    frames = frames.reshape(count, HEIGHT, WIDTH).astype(np.int16)
    diffs = np.abs(frames[1:] - frames[:-1]).mean(axis=(1, 2))
    per_window = max(1, int(round(window * FPS)))
    out = []
    for start in range(0, len(diffs), per_window):
        chunk = diffs[start:start + per_window]
        out.append(float(chunk.mean()))
    return out


def motion_score(path: Path) -> float:
    profile = motion_profile(path)
    return float(np.mean(profile)) if profile else 0.0
