"""The retake sheet: which scenes have to be generated again, and why.

The analysis already knows every clip whose dialogue ran past the ten-second
ceiling, every clip the script says has speech but nothing was heard, every
clip with no audio, and every clip an editor rejected. Until now that
knowledge died in the editor's head. Written out as a CSV next to the export,
it goes to whoever runs the generator as a list of work.
"""
from __future__ import annotations

import csv
from pathlib import Path
from typing import List, NamedTuple

from .models import Clip, Episode, Flag, ReviewState

REASONS = {
    Flag.SPEECH_TRUNCATED: "Dialogue cut off at the end of the clip. Split the scene into two shorter ones.",
    Flag.SCRIPTED_BUT_SILENT: "The script has dialogue but nothing was heard. The generation failed.",
    Flag.NO_AUDIO_TRACK: "The clip has no audio track.",
    Flag.UNREADABLE: "The file could not be read.",
    Flag.JOIN_RISK: "The join into this clip is risky: it starts mid-word or a scene is missing before it. Retake or force a dip.",
    Flag.SPEECH_MUCH_SHORTER: "Far less speech than the script implies; a line may be missing.",
}
ORDER = [Flag.UNREADABLE, Flag.SCRIPTED_BUT_SILENT, Flag.NO_AUDIO_TRACK,
         Flag.SPEECH_TRUNCATED, Flag.SPEECH_MUCH_SHORTER]


class Retake(NamedTuple):
    clip: int
    file: str
    reason: str
    detail: str
    scripted_line: str
    seconds_missing: float


def _seconds_missing(clip: Clip, rate: float) -> float:
    """How much scripted speech never made it into the render, roughly."""
    if not clip.scene or rate <= 0:
        return 0.0
    expected = clip.scene.expected_speech_seconds(rate)
    return max(0.0, round(expected - clip.speech_seconds, 1))


def build(episode: Episode) -> List[Retake]:
    rate = episode.measured_chars_per_second or 0.0
    rows: List[Retake] = []
    for clip in sorted(episode.clips, key=lambda c: c.number):
        line = " / ".join("{}: {}".format(d.speaker, d.text) for d in clip.scene.dialogue) \
            if clip.scene and clip.scene.has_dialogue else ""
        reasons = [f for f in ORDER if f in clip.flags]
        if clip.state == ReviewState.REJECTED:
            rows.append(Retake(clip.number, clip.path.name, "Rejected by the editor",
                               clip.note or (REASONS.get(reasons[0], "") if reasons else ""),
                               line, _seconds_missing(clip, rate)))
            continue
        if not reasons:
            continue
        worst = reasons[0]
        rows.append(Retake(clip.number, clip.path.name,
                           {Flag.SPEECH_TRUNCATED: "Dialogue cut off",
                            Flag.SCRIPTED_BUT_SILENT: "No speech heard",
                            Flag.NO_AUDIO_TRACK: "No audio",
                            Flag.UNREADABLE: "Unreadable file",
                            Flag.SPEECH_MUCH_SHORTER: "Speech much shorter than scripted"}[worst],
                           REASONS[worst], line, _seconds_missing(clip, rate)))
    return rows


def write(rows: List[Retake], path: Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # utf-8-sig so Excel opens the Urdu script text correctly by double-click.
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Clip", "File", "Reason", "What to do", "Scripted line", "Seconds missing"])
        for row in rows:
            writer.writerow([row.clip, row.file, row.reason, row.detail, row.scripted_line,
                             "{:.1f}".format(row.seconds_missing) if row.seconds_missing else ""])
    return path


def sheet_path_for(export: Path) -> Path:
    export = Path(export)
    return export.with_name(export.stem + " - retakes.csv")
