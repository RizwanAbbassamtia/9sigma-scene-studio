"""The one place the product version lives.

Bump VERSION for every build handed to editors. The update check compares the
running version with the one published in latest.json, so a build that is not
bumped will never be offered as an update.

Versions are dotted integers: 9.01 < 9.02 < 9.10 < 9.11 < 10.0. Leading
zeros carry no meaning, so 9.01 and 9.1 are the same version -- keep to the
two-digit style to avoid the confusion.
"""
from __future__ import annotations

from typing import Tuple

VERSION = "9.24"
# The second product built from this code (sceneforge/product.py). Its own
# line: bump it for an Omni Flow build, leave VERSION alone.
OMNIFLOW_VERSION = "1.06"


def parse(text: str) -> Tuple[int, ...]:
    parts = []
    for piece in str(text).strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def is_newer(candidate: str, current: str = VERSION) -> bool:
    """True when `candidate` is a later version than `current`."""
    a, b = parse(candidate), parse(current)
    width = max(len(a), len(b))
    return a + (0,) * (width - len(a)) > b + (0,) * (width - len(b))
