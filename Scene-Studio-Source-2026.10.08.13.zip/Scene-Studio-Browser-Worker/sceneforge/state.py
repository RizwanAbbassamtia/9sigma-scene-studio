"""Persist review decisions next to the clips so work survives a restart.

Saved decisions describe a *particular* analysis. If the code that produced
that analysis has changed, or the script has, the saved cut points no longer
mean what they meant when they were written, and restoring them silently
replaces a correct plan with a stale one. So everything is stamped, and a stamp
that does not match is discarded rather than trusted.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import NamedTuple, Optional

from .logging_setup import get
from .models import JOIN_CHOICES, Episode, Flag, ReviewState, SpeechSpan

log = get("state")

STATE_DIR = ".sceneforge"
STATE_FILE = "state.json"
VERSION = 2

# Bump whenever ingest, script parsing or cut planning changes in a way that
# alters the plan for unchanged footage. Saved work from an older number is
# dropped instead of being layered on top of a different analysis.
#
#   1  original
#   2  script parser accepts "N:" numbering and speaker-before-says layouts;
#      filenames resolve embedded numbers (CLIP_003) and "(1)" takes. Plans
#      written by version 1 read every clip as having no dialogue.
#   3  whole-mix silence, music ratio and motion are measured per clip;
#      mid-scene pauses are tightened only across true silence; no-dialogue
#      clips with music and movement are kept whole.
#   4  word guard, 2 s B-roll, soft speech spans
#   5  content-aware trimming from a motion profile, repeated-word removal,
#      the cut log; wordless clips are no longer cut to a fixed length
ANALYSIS_VERSION = 5


class LoadResult(NamedTuple):
    restored: int          # clips whose decisions came back
    discarded: int         # clips whose saved entry no longer applies
    reason: str            # empty when nothing was thrown away

    @property
    def ok(self) -> bool:
        return self.restored > 0 and not self.reason


def state_path(source_dir: Path) -> Path:
    return Path(source_dir) / STATE_DIR / STATE_FILE


def _script_stamp(episode: Episode) -> str:
    """Identify the script by name and size, so an edited script invalidates."""
    path = episode.script_path
    if not path or not Path(path).exists():
        return "none"
    try:
        return "{}:{}".format(Path(path).name, Path(path).stat().st_size)
    except OSError:
        return "unknown"


def save(episode: Episode, editor: str = "") -> Path:
    path = state_path(episode.source_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "version": VERSION,
        "analysis_version": ANALYSIS_VERSION,
        "script": _script_stamp(episode),
        "episode": episode.name,
        "editor": editor,
        "updated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "clips": {
            str(clip.number): {
                # The file name is stored so a decision cannot be reattached to
                # a different clip that later takes the same number.
                "file": clip.path.name,
                "state": clip.state.value,
                "keep": [[round(k.start, 3), round(k.end, 3)] for k in clip.keep],
                "speech": [[round(s.start, 3), round(s.end, 3)] for s in clip.speech],
                "speech_soft": [[round(s.start, 3), round(s.end, 3)] for s in clip.speech_soft],
                "silence": [[round(s.start, 3), round(s.end, 3)] for s in clip.silence],
                "music_ratio": round(clip.music_ratio, 3),
                "motion": round(clip.motion_score, 3),
                "motion_profile": [round(m, 2) for m in clip.motion_profile],
                "repetitions": list(clip.repetitions),
                "cuts": list(clip.cuts),
                "flags": sorted(f.value for f in clip.flags),
                "note": clip.note,
                "fade_in": clip.fade_in,
                "fade_out": clip.fade_out,
                "join": clip.join,
                "muted": clip.muted,
            }
            for clip in episode.clips
        },
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def load_into(episode: Episode) -> LoadResult:
    """Restore saved decisions onto a freshly scanned Episode.

    Returns what happened, so the window can tell the editor when previous work
    was dropped instead of leaving them to wonder why the numbers moved.
    """
    path = state_path(episode.source_dir)
    if not path.exists():
        return LoadResult(0, 0, "")

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        log.warning("Could not read %s: %s", path, exc)
        return LoadResult(0, 0, "the saved file could not be read")

    if payload.get("version") != VERSION:
        log.info("Discarding state written by an older format")
        return LoadResult(0, len(payload.get("clips", {})),
                          "it was saved by an older version of SceneForge")

    if payload.get("analysis_version") != ANALYSIS_VERSION:
        log.info("Discarding state from analysis version %s (now %s)",
                 payload.get("analysis_version"), ANALYSIS_VERSION)
        return LoadResult(
            0, len(payload.get("clips", {})),
            "the clips have been re-analysed since, so the old cut points no "
            "longer apply")

    if payload.get("script") != _script_stamp(episode):
        log.info("Discarding state: the script changed")
        return LoadResult(0, len(payload.get("clips", {})),
                          "the script file has changed since it was saved")

    saved = payload.get("clips", {})
    restored = 0
    discarded = 0
    for clip in episode.clips:
        entry = saved.get(str(clip.number))
        if not entry:
            continue
        # A number can be claimed by a different file after a re-download, and
        # inheriting the old verdict would be wrong.
        if entry.get("file") and entry["file"] != clip.path.name:
            discarded += 1
            continue
        try:
            clip.state = ReviewState(entry.get("state", "pending"))
        except ValueError:
            clip.state = ReviewState.PENDING
        clip.keep = [SpeechSpan(float(a), float(b)) for a, b in entry.get("keep", [])]
        clip.speech = [SpeechSpan(float(a), float(b)) for a, b in entry.get("speech", [])]
        clip.speech_soft = [SpeechSpan(float(a), float(b)) for a, b in entry.get("speech_soft", [])]
        clip.silence = [SpeechSpan(float(a), float(b)) for a, b in entry.get("silence", [])]
        clip.music_ratio = float(entry.get("music_ratio", 1.0))
        clip.motion_score = float(entry.get("motion", 0.0))
        clip.motion_profile = [float(m) for m in entry.get("motion_profile", [])]
        clip.repetitions = [r for r in entry.get("repetitions", []) if isinstance(r, dict)]
        clip.cuts = [c for c in entry.get("cuts", []) if isinstance(c, dict)]
        clip.flags = {f for f in (_flag(v) for v in entry.get("flags", [])) if f}
        clip.note = entry.get("note", "")
        clip.fade_in = entry.get("fade_in")
        clip.fade_out = entry.get("fade_out")
        join = entry.get("join")
        clip.join = join if join in JOIN_CHOICES else None
        clip.muted = bool(entry.get("muted", False))
        restored += 1

    return LoadResult(restored, discarded, "")


class EditHistory:
    """Undo and redo for the timeline's cutting operations, one episode
    session long. Each entry is a copy of what one clip's edit looked like
    before an operation; undoing puts it back and parks the current look on
    the redo side. Nothing here is written to disk -- the state file records
    the result of each operation, not the road to it."""

    def __init__(self, limit: int = 200) -> None:
        self.limit = limit
        self._undo: list = []
        self._redo: list = []

    @staticmethod
    def snapshot(clip, label: str = "") -> dict:
        return {
            "number": clip.number,
            "label": label,
            "keep": [SpeechSpan(k.start, k.end) for k in clip.keep],
            "muted": clip.muted,
            "join": clip.join,
            "state": clip.state,
        }

    @staticmethod
    def _restore(clip, entry: dict) -> None:
        clip.keep = [SpeechSpan(k.start, k.end) for k in entry["keep"]]
        clip.muted = entry["muted"]
        clip.join = entry["join"]
        clip.state = entry["state"]

    def record(self, clip, label: str) -> None:
        """Call before changing the clip. A new edit discards the redo side."""
        self._undo.append(self.snapshot(clip, label))
        del self._undo[:-self.limit]
        self._redo.clear()

    def discard(self) -> None:
        """Forget the entry just recorded: the operation was refused."""
        if self._undo:
            self._undo.pop()

    @property
    def can_undo(self) -> bool:
        return bool(self._undo)

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    def undo(self, episode: Episode) -> Optional[dict]:
        return self._step(episode, self._undo, self._redo)

    def redo(self, episode: Episode) -> Optional[dict]:
        return self._step(episode, self._redo, self._undo)

    def _step(self, episode: Episode, take_from: list, give_to: list) -> Optional[dict]:
        while take_from:
            entry = take_from.pop()
            clip = next((c for c in episode.clips if c.number == entry["number"]), None)
            if clip is None:
                continue                     # the clip was replaced since
            give_to.append(self.snapshot(clip, entry["label"]))
            self._restore(clip, entry)
            return entry
        return None


def _flag(value: str) -> Optional[Flag]:
    try:
        return Flag(value)
    except ValueError:
        return None


def summary(episode: Episode) -> dict:
    """Compact progress record -- this is what gets pushed to GitHub."""
    counts = {s.value: 0 for s in ReviewState}
    for clip in episode.clips:
        counts[clip.state.value] += 1
    return {
        "episode": episode.name,
        "clips": len(episode.clips),
        "states": counts,
        "flagged": len(episode.flagged),
        "source_seconds": round(episode.source_seconds, 1),
        "planned_seconds": round(episode.planned_seconds, 1),
        "updated": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
