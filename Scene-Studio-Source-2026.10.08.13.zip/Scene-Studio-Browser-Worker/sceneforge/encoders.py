"""Pick the fastest H.264 encoder this machine can actually run, and the
settings for the two encodes an export makes.

ffmpeg lists every hardware encoder it was built with, whether or not the
hardware is present, so the list is no use on its own: on the build laptop
h264_nvenc appears yet the GPU has no encoder block. The only reliable test
is to encode half a second and see whether packets come out. That takes well
under a second per candidate and the answer is cached for the process.

Two qualities, because an export encodes twice and only one of them may be
allowed to cost anything:

  intermediate  every cut piece and every blend, at the source size, near
                lossless (libx264 crf 12, or the hardware encoder at the
                matching constant quality). These are stitched together
                without another encode and thrown away afterwards.
  delivery      the one encode the viewer sees: High profile, yuv420p,
                crf 18 (or the hardware equivalent, measured to match),
                scaled once, captions burned in the same pass if asked for.

Earlier builds encoded the pieces at delivery quality (crf 20 veryfast, or
Quick Sync at quality 23, which is visibly softer), scaled each piece on
its own, and re-encoded the whole file a second time to burn captions: two
or three lossy generations. Now there is one.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from .ffmpeg_tools import require, run
from .logging_setup import get

log = get("encoders")

# name -> (intermediate arguments, delivery arguments)
CANDIDATES: Dict[str, Dict[str, List[str]]] = {
    "qsv": {
        "intermediate": ["-c:v", "h264_qsv", "-global_quality", "12", "-preset", "veryfast", "-pix_fmt", "nv12"],
        # Measured on a 60 s 1080p excerpt of the real episode: ICQ 19 +
        # look-ahead + slower spent 8.3 Mbps for SSIM 0.9935; this spends
        # 5.2 Mbps for 0.9922, the same figure libx264 crf 18 medium gives,
        # in a tenth of the time.
        "delivery": ["-c:v", "h264_qsv", "-global_quality", "21", "-preset", "medium", "-look_ahead", "1",
                     "-maxrate", "12M", "-bufsize", "24M", "-profile:v", "high", "-level", "41", "-pix_fmt", "nv12"],
    },
    "nvenc": {
        "intermediate": ["-c:v", "h264_nvenc", "-preset", "p1", "-cq", "12", "-pix_fmt", "yuv420p"],
        "delivery": ["-c:v", "h264_nvenc", "-preset", "p6", "-rc", "vbr", "-cq", "19", "-b:v", "0",
                     "-profile:v", "high", "-level", "41", "-pix_fmt", "yuv420p"],
    },
    "amf": {
        "intermediate": ["-c:v", "h264_amf", "-quality", "speed", "-rc", "cqp", "-qp_i", "12", "-qp_p", "12",
                         "-pix_fmt", "yuv420p"],
        "delivery": ["-c:v", "h264_amf", "-quality", "quality", "-rc", "cqp", "-qp_i", "19", "-qp_p", "19",
                     "-profile:v", "high", "-level", "41", "-pix_fmt", "yuv420p"],
    },
}
ORDER = ["qsv", "nvenc", "amf"]
PROBE = {name: CANDIDATES[name]["intermediate"] for name in CANDIDATES}

_cache: Dict[str, Optional[str]] = {}
_demoted = False        # set once a hardware encoder failed mid-export


def demote(reason: str = "") -> None:
    """Stop using the hardware encoder for the rest of this process.

    A hardware encoder that hangs or errors on one piece will do it again on
    the next. Falling back to libx264 finishes the export slower rather than
    never; the log says it happened, so the next export can be looked at.
    """
    global _demoted
    if not _demoted:
        log.warning("Hardware encoder gave up (%s); using libx264 on the CPU from here on", reason)
    _demoted = True
    _cache.clear()


def is_demoted() -> bool:
    return _demoted


def reinstate(reason: str = "") -> None:
    """Undo a demotion made a moment ago: the CPU failed the same piece, so
    the encoder was not at fault (a source that will not decode), and the
    rest of the export need not run four times slower for it."""
    global _demoted
    if _demoted:
        log.info("Hardware encoder kept: %s", reason)
    _demoted = False
    _cache.clear()


def uses_hardware(args: List[str]) -> bool:
    """Whether a built ffmpeg command encodes on a hardware encoder."""
    return any(str(a).startswith("h264_") for a in args)


def reset() -> None:
    """Give the hardware another chance: a new export starts on it even
    when the previous one had to set it aside."""
    global _demoted
    if _demoted:
        log.info("Hardware encoder will be tried again for this export")
    _demoted = False
    _cache.clear()


def hardware_active(preference: str = "auto") -> bool:
    return choose(preference) is not None


def _works(name: str) -> bool:
    ffmpeg = require("ffmpeg")
    args = [ffmpeg, "-nostdin", "-loglevel", "error", "-y",
            "-f", "lavfi", "-i", "testsrc=size=640x360:rate=24", "-t", "0.5",
            ] + PROBE[name] + ["-f", "null", "-"]
    try:
        result = run(args)
    except Exception:                           # noqa: BLE001 - probe, not a gate
        return False
    return result.returncode == 0


def choose(preference: str = "auto") -> Optional[str]:
    """Return the hardware encoder to use, or None for libx264.

    preference: "auto" tries qsv, nvenc, amf in turn; "cpu" forces libx264;
    a specific name is used if it works and otherwise falls back to the CPU.
    """
    key = preference or "auto"
    if _demoted:
        return None
    if key in _cache:
        return _cache[key]
    chosen: Optional[str] = None
    if key == "cpu":
        chosen = None
    elif key in CANDIDATES:
        chosen = key if _works(key) else None
    else:
        for name in ORDER:
            if _works(name):
                chosen = name
                break
    log.info("Video encoder: %s", chosen or "libx264 (CPU)")
    _cache[key] = chosen
    return chosen


def video_args(preference: str, quality: str = "delivery", crf: int = 18, preset: str = "medium") -> List[str]:
    """Encoder arguments for one encode. `quality` is "intermediate" (the
    pieces) or "delivery" (the final file); `crf` and `preset` apply to the
    CPU delivery encode only -- the pieces are always near lossless."""
    name = choose(preference)
    if name is None:
        if quality == "intermediate":
            return ["-c:v", "libx264", "-preset", "ultrafast", "-crf", "12", "-pix_fmt", "yuv420p"]
        # Level 4.1 on every delivery encoder (1080p60 fits), so segments from
        # two encoders carry the same level in their parameter sets.
        return ["-c:v", "libx264", "-preset", preset, "-crf", str(crf), "-profile:v", "high",
                "-level", "41", "-pix_fmt", "yuv420p"]
    return list(CANDIDATES[name][quality])


def describe(preference: str) -> str:
    name = choose(preference)
    return {"qsv": "Intel Quick Sync", "nvenc": "NVIDIA NVENC", "amf": "AMD AMF"}.get(name or "", "libx264 (CPU)")
