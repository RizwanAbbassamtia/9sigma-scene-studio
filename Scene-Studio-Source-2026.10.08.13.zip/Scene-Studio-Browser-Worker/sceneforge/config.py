"""User-tunable settings, persisted as JSON next to the project."""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path

from .product import PRODUCT, PRODUCTS

CONFIG_NAME = "config.json"


@dataclass
class Config:
    # --- voice activity detection -------------------------------------------
    vad_threshold: float = 0.5           # 0-1; higher = stricter about what counts as speech
    vad_min_speech_ms: int = 250         # ignore blips shorter than this
    vad_min_silence_ms: int = 300        # gaps shorter than this do not split a span

    # --- trimming ------------------------------------------------------------
    head_pad_ms: int = 400               # breathing room kept before the first word
    tail_pad_ms: int = 800               # kept after the last word, mid-scene
    # When the next clip is a different setting the cut is a scene change, and a
    # scene change needs longer to land. Ending it as tightly as a continuation
    # feels rushed, so the tail is held for longer before moving on.
    scene_change_tail_ms: int = 1400
    # Mid-scene pauses are tightened only where the whole mix is quiet -- no
    # voice, no music, no ambience -- for at least min_silent_gap_ms. A pause
    # with music under it is left alone, because cutting it would make the
    # music jump. With dissolve transitions the tightened cut is a short
    # cross-dissolve rather than a visible jump.
    tighten_mid_gaps: bool = True
    max_mid_gap_ms: int = 700            # a quiet pause longer than this shrinks to it
    min_silent_gap_ms: int = 1200        # and only if the true silence lasts this long
    silence_db: float = -45.0            # below this the mix counts as silent
    # No dialogue is not no value. A wordless clip is kept up to where its
    # content stops -- movement, a reaction, a camera move, sound under it --
    # and only the dead stretch after that (frozen, black, silent) goes.
    # Off falls back to the fixed no_dialogue_seconds.
    content_aware_trimming: bool = True
    motion_keep_threshold: float = 1.5   # mean frame difference that counts as movement (~0 is a still frame)
    motion_alive_threshold: float = 0.6  # less than movement, more than a frozen frame: alive when sound plays too
    motion_frozen_threshold: float = 0.3 # below this the frames are identical: a frozen picture, not a still one
    # A word said twice by the generator ("I... I... I need"): auto removes
    # the high-confidence loops (repetition.py says what that means) and
    # flags the rest; flag never removes; off does nothing.
    repetition_cleanup: str = "auto"
    repetition_max_motion: float = 2.5   # a removal is refused where the picture moves more than this
    # A cut made inside one clip (a removed repeat, a tightened pause) is
    # joined with this short blend so neither the picture nor the music
    # bed jumps. Snapped to whole frames.
    micro_blend_ms: int = 120
    min_clip_seconds: float = 0.8        # never emit anything shorter than this
    # Never cut through a word. The detector is run a second time at this
    # lower threshold, which hears quiet consonants and trailing syllables the
    # main pass misses; any of that within word_guard_ms of a planned cut
    # pushes the cut outward to cover it.
    boundary_vad_threshold: float = 0.25
    word_guard_ms: int = 300
    # auto   the tool plans every cut; the editor adjusts what it got wrong
    # manual every clip starts at full length and the editor trims by hand;
    #        flags and speech are still detected and shown
    trim_mode: str = "auto"
    # Clips that raised no flag start approved, so a review is a pass over
    # the flagged ones rather than over everything. The editor can still step
    # through every clip and change any of them.
    auto_approve_clean: bool = True
    # The trimming rules above have changed since earlier builds. A config
    # file written before this version has its trimming policy reset to the
    # new defaults on load; everything else in it is kept.
    settings_version: int = 3

    # --- joins -----------------------------------------------------------------
    # There is nothing to choose: the continuity engine (continuity.py)
    # cuts inside a scene, blends about blend_ms where the scene changes or
    # a cut would flash, trims dead frames at the edges and matches
    # neighbouring colour, and the episode fades at its two ends only.
    blend_ms: int = 200                  # the baseline dissolve; snapped to whole frames
    edge_fade_ms: int = 1500             # fade up at the start and down at the end
    # Audio ramp either side of a cut. Short enough to sit inside the word
    # guard, long enough to stop a click.
    cut_audio_ramp_ms: int = 30
    continuity_analysis: bool = True     # read the frames at every join before deciding
    colour_match: bool = True            # shift a clip part-way toward its neighbour's colour
    seam_check: bool = True              # decode the export and look at the joins afterwards

    # --- captions ------------------------------------------------------------
    # off | srt | burn. Dialogue comes from the script, timed to the speech the
    # VAD actually heard, so nothing needs transcribing.
    captions: str = "off"
    caption_font: str = "Segoe UI"       # must cover Arabic script for Urdu
    caption_font_size: int = 22

    # --- scenes scripted "no says" ------------------------------------------
    # trim   -> cut to no_dialogue_seconds and keep in sequence
    # delete -> drop from the episode
    # keep   -> leave at full source length
    # review -> trim, but force a human decision on every one
    no_dialogue_action: str = "trim"
    no_dialogue_seconds: float = 2.0

    # --- quality flags -------------------------------------------------------
    # Starting guess only. Every project measures its own speaking rate from
    # its own audio and iterates to a fixed point, so this value does not
    # decide anything -- it just gives the first pass somewhere to begin.
    # Languages vary widely: Urdu in Arabic script runs near twice the
    # characters per second of English.
    chars_per_second: float = 18.0
    short_speech_ratio: float = 0.5      # flag if heard speech < ratio * scripted estimate
    truncation_margin_ms: int = 150      # speech ending within this of clip end = truncated
    motion_anomaly_percentile: float = 90.0  # top N% of motion scores get flagged

    # --- assembly ------------------------------------------------------------
    output_dir: str = "output"
    # Where the editor last chose to save an export. The save dialog opens
    # there next time; empty means fall back to output_dir.
    export_dir: str = ""
    # Height of the finished video. Source clips are 720p; 1080 upscales them
    # to 1920x1080 with a Lanczos filter, which is what the platforms expect.
    # 0 keeps the source resolution.
    output_height: int = 1080
    # auto follows the clips: 16:9 clips make a 16:9 video, 9:16 clips a
    # 9:16 one. "16:9" or "9:16" states what the clips must be and refuses
    # others. Height and ratio are separate: 1080 at 16:9 is 1920x1080,
    # 1080 at 9:16 is 1080x1920. Nothing is ever cropped or stretched.
    aspect_ratio: str = "auto"
    # auto | cpu | qsv | nvenc | amf. auto tries the graphics card's encoder
    # (Intel Quick Sync, NVIDIA, AMD) and falls back to libx264 on the CPU.
    # Measured 4x faster with Quick Sync on the build laptop.
    video_encoder: str = "auto"
    # The one delivery encode (see encoders.py). The pieces before it are
    # always near lossless, so these decide the quality of the file.
    # libx264 only: medium ran at 0.6x real time on the build laptop
    # (100 s per minute of 1080p); fast gives SSIM within 0.0002 of it.
    delivery_preset: str = "fast"
    # Long exports are made in segments of about this many seconds, each
    # encoded, checked and checkpointed on its own, then joined without a
    # second encode (export_job.py). Five minutes keeps a hardware encoder's
    # session short and a failure cheap.
    export_segment_seconds: int = 300
    # A running encode whose output has not moved for this long is frozen,
    # not slow; it is killed and that segment retried on the CPU.
    export_stall_seconds: int = 180
    delivery_crf: int = 18
    audio_bitrate: str = "256k"

    # --- recent projects -----------------------------------------------------
    recent_projects: list = field(default_factory=list)
    # Working folders of the automated productions created or opened here,
    # newest first: what Automate > Open production lists. Never opened on
    # its own at start-up.
    recent_productions: list = field(default_factory=list)
    # Batch folders created or opened here, newest first (Automate > Open batch).
    recent_batches: list = field(default_factory=list)

    # --- team sync -----------------------------------------------------------
    editor_name: str = ""
    editor_username: str = ""        # the signed-in account; stamps the team sheet's rows
    github_repo: str = ""                # e.g. "youruser/sceneforge-status"
    github_token_env: str = "SCENEFORGE_GITHUB_TOKEN"
    sync_enabled: bool = False

    # --- master log (the shared title queue and its worker) ------------------
    # The folder with master.json, titles.json and one sub-folder per
    # framework record; local or on a mapped/UNC share. Empty means the
    # menu asks for it the first time. Only opened on the menu click, never
    # at start-up: a sleeping NAS must not stall the app opening.
    master_log_dir: str = ""
    worker_poll_minutes: int = 2         # how often an idle worker looks for a queued title
    # Budgets for one Start worker press. They are the only spend control
    # the unattended loop has (spending_limit in a manifest is display-only),
    # so the worker stops with a status line when either is spent.
    worker_max_generations: int = 200    # clips submitted, across every title of the run
    worker_max_titles: int = 10          # titles processed per run

    # --- Omni Flash (video generation) --------------------------------------
    # Where the Generation API runs. Its document leaves the base URL blank,
    # so it is entered under Automate > API keys and kept here; the key
    # itself is sealed in credentials.json, never here.
    omniflash_base_url: str = ""
    omniflash_model: str = "omniflash-10s"

    # --- Google Gemini (Omni Flow's automatic clips) --------------------------
    # The model and video settings the Gemini key generates with; the key
    # itself is sealed in credentials.json. Billed per generated second by
    # Google; nothing here estimates it.
    gemini_model: str = "veo-3.1-generate-preview"
    gemini_aspect_ratio: str = "9:16"
    gemini_resolution: str = "720p"
    gemini_duration_seconds: int = 8

    # --- updates -------------------------------------------------------------
    # Where the app looks, after sign-in, for a newer build. The file is a
    # tiny JSON manifest; see sceneforge/updates.py and latest.json. Empty
    # string disables the check. The default is this product's channel
    # (sceneforge/product.py): Automation and Omni Flow never see each
    # other's releases.
    update_url: str = field(default_factory=lambda: PRODUCT.update_url)
    check_updates: bool = True
    # Checked again this often while the app stays open, and on every folder
    # opened, so an editor who never restarts still hears about a release.
    update_recheck_minutes: int = 60

    @classmethod
    def load(cls, directory: Path) -> "Config":
        path = Path(directory) / CONFIG_NAME
        if not path.exists():
            return cls()
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return cls()
        known = {f.name for f in fields(cls)}
        raw = _migrate(raw)
        # A config.json copied from the other product would point the update
        # check at the wrong channel; its default is swapped for ours.
        others = {p.update_url for p in PRODUCTS.values() if p.key != PRODUCT.key}
        if raw.get("update_url") in others:
            raw["update_url"] = PRODUCT.update_url
        return cls(**{k: v for k, v in raw.items() if k in known})

    def save(self, directory: Path) -> Path:
        path = Path(directory) / CONFIG_NAME
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        return path


# Keys whose saved value is a policy the tool has since changed its mind
# about, not a preference the editor chose. Reset when an old file is loaded.
_POLICY_KEYS = ("no_dialogue_seconds", "keep_no_voice_with_music_and_motion", "music_presence_ratio",
                # 3: the transition menus are gone; the continuity engine decides.
                "transition", "transition_ms", "dissolve_ms", "cinematic_dissolve_ms",
                "reencode_preset", "reencode_crf", "audio_bitrate")


def _migrate(raw: dict) -> dict:
    version = int(raw.get("settings_version", 1) or 1)
    current = Config.settings_version
    if version >= current:
        return raw
    raw = {k: v for k, v in raw.items() if k not in _POLICY_KEYS}
    raw["settings_version"] = current
    return raw


def remember_project(config: "Config", folder, directory, limit: int = 8) -> None:
    """Move a folder to the front of the recent list and persist it."""
    path = str(folder)
    recent = [p for p in config.recent_projects if p != path]
    recent.insert(0, path)
    config.recent_projects = recent[:limit]
    try:
        config.save(directory)
    except OSError:
        pass
