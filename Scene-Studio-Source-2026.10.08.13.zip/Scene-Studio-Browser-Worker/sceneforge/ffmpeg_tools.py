"""Locate and drive the bundled ffmpeg."""
from __future__ import annotations

import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Callable, List, Optional

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_VENDOR_BIN = _PROJECT_ROOT / "vendor" / "bin"

# Windows hides console windows for subprocesses launched from a GUI
_NO_WINDOW = 0x08000000 if hasattr(subprocess, "CREATE_NO_WINDOW") else 0


class FFmpegMissing(RuntimeError):
    pass


@lru_cache(maxsize=4)
def find_tool(name: str) -> Optional[str]:
    """Prefer the vendored copy so editors never depend on a system install."""
    vendored = _VENDOR_BIN / (name + ".exe")
    if vendored.exists():
        return str(vendored)
    found = shutil.which(name)
    if found:
        return found
    # winget drops ffmpeg under a versioned Packages folder
    packages = Path.home() / "AppData" / "Local" / "Microsoft" / "WinGet" / "Packages"
    if packages.is_dir():
        for candidate in packages.glob("Gyan.FFmpeg*/**/bin/" + name + ".exe"):
            return str(candidate)
    return None


def require(name: str = "ffmpeg") -> str:
    tool = find_tool(name)
    if not tool:
        raise FFmpegMissing(
            "{} not found. Put {}.exe in vendor/bin or install it on PATH.".format(name, name)
        )
    return tool


TIMED_OUT = -9
STALLED = -10


# ------------------------------------------------------------ process ownership
# Every tool this app starts joins one Windows job object that kills its
# members when the job's last handle closes. The app holds that handle for its
# lifetime, so closing the window, a crash, or Task Manager ending the app
# takes every ffmpeg with it -- no encoder is left running on its own for an
# hour, holding the output file and the graphics card.
_job = None
_job_lock = threading.Lock()


def _job_handle():
    global _job
    if not sys.platform.startswith("win"):
        return None
    with _job_lock:
        if _job is not None:
            return _job or None
        try:
            import ctypes
            from ctypes import wintypes

            class _Basic(ctypes.Structure):
                _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                            ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                            ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                            ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD),
                            ("SchedulingClass", wintypes.DWORD)]

            class _Io(ctypes.Structure):
                _fields_ = [(name, ctypes.c_uint64) for name in (
                    "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                    "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]

            class _Extended(ctypes.Structure):
                _fields_ = [("BasicLimitInformation", _Basic), ("IoInfo", _Io),
                            ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                            ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]

            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.CreateJobObjectW.restype = wintypes.HANDLE
            kernel32.CreateJobObjectW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR]
            kernel32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p,
                                                         wintypes.DWORD]
            kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
            handle = kernel32.CreateJobObjectW(None, None)
            info = _Extended()
            info.BasicLimitInformation.LimitFlags = 0x2000      # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            if not handle or not kernel32.SetInformationJobObject(handle, 9, ctypes.byref(info),
                                                                  ctypes.sizeof(info)):   # 9 = extended limits
                _job = False
                return None
            _job = (kernel32, handle)
        except (OSError, AttributeError):
            _job = False
            return None
    return _job


def _own(process: subprocess.Popen) -> None:
    job = _job_handle()
    if not job:
        return
    try:
        kernel32, handle = job
        kernel32.AssignProcessToJobObject(handle, int(process._handle))
    except (OSError, AttributeError, ValueError, TypeError):
        pass


def _kill_tree(process: subprocess.Popen) -> None:
    """Kill the job and anything it started, so no child is left holding
    the output pipes open (the readers would wait on it)."""
    if sys.platform.startswith("win"):
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(process.pid)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=_NO_WINDOW)
    try:
        process.kill()
    except OSError:
        pass
    process.wait()


def run(args: List[str], capture: bool = True,
        cwd: Optional[str] = None, timeout: Optional[float] = None) -> subprocess.CompletedProcess:
    """Run a short tool call (a probe, one piece of a clip). With a timeout,
    a process that outlives it is killed with everything it started and the
    result says so (returncode TIMED_OUT) instead of raising. Long jobs use
    run_with_progress, which watches ffmpeg's progress instead of the clock."""
    process = subprocess.Popen(args, stdout=subprocess.PIPE if capture else None, stderr=subprocess.PIPE,
                               creationflags=_NO_WINDOW, cwd=cwd)
    _own(process)
    try:
        out, err = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        _kill_tree(process)
        out, err = process.communicate()
        return subprocess.CompletedProcess(
            args, TIMED_OUT, out or b"",
            (err or b"") + "timed out after {:.0f}s".format(timeout or 0).encode("ascii"))
    return subprocess.CompletedProcess(args, process.returncode, out or b"", err or b"")


@dataclass
class Progress:
    """What ffmpeg reports about a running job (-progress pipe:1)."""
    seconds: float = 0.0          # output time written so far
    frame: int = 0
    fps: float = 0.0
    speed: float = 0.0            # 2.3 means 2.3x real time
    size: int = 0                 # bytes written


CANCELLED = -11


def run_with_progress(args: List[str], on_progress: Optional[Callable[[Progress], None]] = None,
                      stall_after: float = 180.0, timeout: Optional[float] = None,
                      cwd: Optional[str] = None,
                      cancel: Optional[threading.Event] = None) -> subprocess.CompletedProcess:
    """Run one long ffmpeg job, reporting how far it has got and killing it
    if it stops moving.

    `args` must be a full ffmpeg command; `-progress pipe:1 -nostats` is put
    right after the program name, so ffmpeg writes key=value blocks to stdout
    as it goes (out_time_us, frame, fps, speed, total_size). A job whose
    output time has not moved for `stall_after` seconds is frozen, not slow --
    a slow encode still moves every second -- and is killed with its whole
    process tree; the result is STALLED. `timeout` is an optional outer bound
    that exports do not use: a legitimate two-hour encode must never be cut
    short by the clock.

    stdout is read line by line as it arrives and stderr by its own thread,
    keeping only its last 64 KB, so neither pipe can fill up and block ffmpeg
    and nothing grows however long the job runs.
    """
    command = [args[0], "-progress", "pipe:1", "-nostats"] + list(args[1:])
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               creationflags=_NO_WINDOW, cwd=cwd)
    _own(process)
    state = {"out": -1.0, "moved": time.monotonic()}
    current = Progress()
    errors: List[bytes] = []

    def read_progress():
        for raw in process.stdout:
            key, _, value = raw.decode("ascii", "replace").strip().partition("=")
            try:
                if key in ("out_time_us", "out_time_ms"):          # both are microseconds
                    current.seconds = max(0.0, int(value) / 1_000_000.0)
                elif key == "frame":
                    current.frame = int(value)
                elif key == "fps":
                    current.fps = float(value)
                elif key == "speed":
                    current.speed = float(value.rstrip("x"))
                elif key == "total_size":
                    current.size = int(value)
                elif key == "progress" and current.seconds > state["out"]:   # end of one block
                    state["out"] = current.seconds
                    state["moved"] = time.monotonic()
                    if on_progress is not None:
                        try:
                            on_progress(Progress(**vars(current)))
                        except Exception:                           # noqa: BLE001 - never kill the job
                            pass
            except ValueError:
                continue                                            # "N/A" before the first frame

    def read_errors():
        tail = b""
        for chunk in iter(lambda: process.stderr.read(8192), b""):
            tail = (tail + chunk)[-65536:]
        errors.append(tail)

    readers = [threading.Thread(target=read_progress, daemon=True),
               threading.Thread(target=read_errors, daemon=True)]
    for reader in readers:
        reader.start()
    started = time.monotonic()
    code: Optional[int] = None
    reason = b""
    while code is None:
        try:
            code = process.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            now = time.monotonic()
            if cancel is not None and cancel.is_set():
                reason = b"cancelled"
                code = CANCELLED
            elif now - state["moved"] > stall_after:
                reason = "stalled: no progress for {:.0f}s".format(stall_after).encode("ascii")
                code = STALLED
            elif timeout is not None and now - started > timeout:
                reason = "timed out after {:.0f}s".format(timeout).encode("ascii")
                code = TIMED_OUT
            if code is not None:
                _kill_tree(process)
    for reader in readers:
        reader.join(timeout=5)
    for pipe in (process.stdout, process.stderr):
        try:
            pipe.close()
        except OSError:
            pass
    stderr = (errors[0] if errors else b"") + reason
    done = subprocess.CompletedProcess(command, code, b"", stderr)
    done.frames = current.frame          # frames ffmpeg wrote (or decoded, for a null output)
    return done
