"""Find a word the generator said twice, from the sound alone.

AI dialogue sometimes loops: "I... I... I need to leave", "the the the
house". No transcription is needed to hear it -- the repeated word is the
same sound played again, a fraction of a second apart -- so this looks at
the audio the way a waveform editor would:

  1. each stretch of speech is split into units at the dips in its energy
     envelope (roughly syllables and short words);
  2. each unit gets a fingerprint: band energies over time, squeezed to a
     fixed length so a slightly slower repeat still lines up;
  3. neighbouring units are compared; a run of near-identical short units
     is a candidate repetition.

Intentional repetition -- "No! No! No!", "Run! Run!", chanting -- is kept.
It does not look like a loop: it is louder, the copies differ in energy
and length, and the gaps between them are longer. The confidence rules
below say exactly what counts:

  high     near-identical copies (similarity >= 0.95), even in loudness
           (within 20 %), tightly spaced (gaps < 250 ms), no shouting.
           Trimmed automatically, and written to the cut log.
  medium   similar but not identical (0.88-0.95), or spaced/uneven copies.
           Never trimmed; the clip is flagged for a person.
  low      anything else. Nothing is done.

Removal keeps the LAST copy, so the sentence runs on naturally, and takes
the copies before it out. Whether a removal is safe for the picture is
the cut planner's decision (autocut.py), not this module's.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from .models import SpeechSpan

SAMPLE_RATE = 16000
FRAME_MS = 25
HOP_MS = 10
BANDS = 24
FINGERPRINT_FRAMES = 16

MIN_UNIT_SECONDS = 0.08        # shorter than this is a click, not a word
MAX_UNIT_SECONDS = 0.9         # a repeated *word*, not a repeated sentence
DIP_RATIO = 0.35               # an envelope dip below this share of the neighbouring peaks splits units
MIN_DIP_MS = 40
MAX_GAP_HIGH = 0.25            # seconds between copies for a loop
MAX_GAP_MEDIUM = 0.6
HIGH_SIMILARITY = 0.95
MEDIUM_SIMILARITY = 0.88
LOUDNESS_TOLERANCE = 0.20      # copies within this share of each other's RMS look mechanical
SHOUT_RATIO = 1.8              # a unit this much louder than the clip's speech is emphasis, not a loop


@dataclass
class Unit:
    start: float               # seconds, clip time
    end: float
    rms: float
    fingerprint: np.ndarray

    @property
    def duration(self) -> float:
        return self.end - self.start


@dataclass
class Repetition:
    """A run of copies of one sound. `remove` is the interval to take out
    (every copy but the last); `keep_from` is where the kept copy starts."""
    copies: int
    similarity: float
    confidence: str            # high | medium | low
    remove: Tuple[float, float]
    keep_from: float
    reason: str

    @property
    def removed_seconds(self) -> float:
        return max(0.0, self.remove[1] - self.remove[0])


# ------------------------------------------------------------- analysis
def _envelope(samples: np.ndarray, sample_rate: int) -> Tuple[np.ndarray, int]:
    hop = int(sample_rate * HOP_MS / 1000)
    frame = int(sample_rate * FRAME_MS / 1000)
    if len(samples) < frame:
        return np.zeros(0), hop
    count = 1 + (len(samples) - frame) // hop
    idx = np.arange(frame)[None, :] + hop * np.arange(count)[:, None]
    frames = samples[idx]
    return np.sqrt((frames ** 2).mean(axis=1) + 1e-12), hop


def _band_energies(samples: np.ndarray, sample_rate: int) -> np.ndarray:
    """[frames, BANDS] log energies on a mel-like (log-spaced) band grid."""
    hop = int(sample_rate * HOP_MS / 1000)
    frame = int(sample_rate * FRAME_MS / 1000)
    if len(samples) < frame:
        return np.zeros((0, BANDS))
    count = 1 + (len(samples) - frame) // hop
    idx = np.arange(frame)[None, :] + hop * np.arange(count)[:, None]
    window = np.hanning(frame)
    spectrum = np.abs(np.fft.rfft(samples[idx] * window, axis=1)) ** 2
    freqs = np.fft.rfftfreq(frame, 1.0 / sample_rate)
    edges = np.geomspace(100.0, min(7000.0, sample_rate / 2.0), BANDS + 1)
    out = np.zeros((count, BANDS))
    for band in range(BANDS):
        mask = (freqs >= edges[band]) & (freqs < edges[band + 1])
        if mask.any():
            out[:, band] = spectrum[:, mask].sum(axis=1)
    return np.log(out + 1e-9)


def _resample_rows(matrix: np.ndarray, rows: int) -> np.ndarray:
    if len(matrix) == 0:
        return np.zeros((rows, matrix.shape[1] if matrix.ndim == 2 else BANDS))
    positions = np.linspace(0, len(matrix) - 1, rows)
    lower = np.floor(positions).astype(int)
    upper = np.minimum(lower + 1, len(matrix) - 1)
    weight = (positions - lower)[:, None]
    return matrix[lower] * (1 - weight) + matrix[upper] * weight


def _fingerprint(samples: np.ndarray, sample_rate: int) -> np.ndarray:
    """Spectral shape over time. Each frame's band vector has its own mean
    taken out, so the fingerprint is what the sound is, not how loud it
    is at each moment -- every word has the same rise-and-fall envelope,
    and comparing envelopes would call any two words the same."""
    bands = _band_energies(samples, sample_rate)
    if len(bands):
        bands = bands - bands.mean(axis=1, keepdims=True)
    return _resample_rows(bands, FINGERPRINT_FRAMES).ravel()


def similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity of two mean-removed fingerprints, 0..1."""
    norm = float(np.linalg.norm(a) * np.linalg.norm(b))
    if norm <= 0:
        return 0.0
    return max(0.0, float(np.dot(a, b) / norm))


def split_units(samples: np.ndarray, span: SpeechSpan, sample_rate: int = SAMPLE_RATE) -> List[Unit]:
    """Cut one speech span into units at the dips of its energy envelope."""
    lo, hi = int(span.start * sample_rate), int(span.end * sample_rate)
    piece = samples[lo:hi].astype(np.float32)
    env, hop = _envelope(piece, sample_rate)
    if len(env) < 3:
        return []
    peak = float(env.max())
    if peak <= 0:
        return []
    min_dip = max(1, int(MIN_DIP_MS / HOP_MS))
    # A dip is a run of frames below DIP_RATIO of the larger of the peaks
    # either side of it. Boundaries fall at the middle of each dip.
    bounds = [0]
    i = 0
    while i < len(env):
        if env[i] < DIP_RATIO * peak:
            j = i
            while j < len(env) and env[j] < DIP_RATIO * peak:
                j += 1
            if j - i >= min_dip and i > 0 and j < len(env):
                left = float(env[max(0, i - 20):i].max()) if i > 0 else peak
                right = float(env[j:j + 20].max()) if j < len(env) else peak
                if env[i:j].max() < DIP_RATIO * max(left, right):
                    bounds.append((i + j) // 2)
            i = j
        else:
            i += 1
    bounds.append(len(env))
    units: List[Unit] = []
    for a, b in zip(bounds, bounds[1:]):
        seg = env[a:b]
        if len(seg) == 0:
            continue
        # trim the unit to where its own energy lives
        loud = np.where(seg >= DIP_RATIO * seg.max())[0]
        if len(loud) == 0:
            continue
        a2, b2 = a + int(loud[0]), a + int(loud[-1]) + 1
        start = span.start + a2 * hop / sample_rate
        end = span.start + (b2 * hop + int(sample_rate * FRAME_MS / 1000)) / sample_rate
        end = min(end, span.end)
        if end - start < MIN_UNIT_SECONDS:
            continue
        s0, s1 = int((start - span.start) * sample_rate), int((end - span.start) * sample_rate)
        unit_samples = piece[s0:s1]
        units.append(Unit(start=start, end=end, rms=float(np.sqrt((unit_samples ** 2).mean() + 1e-12)),
                          fingerprint=_fingerprint(unit_samples, sample_rate)))
    return units


def find_repetitions(samples: np.ndarray, speech: List[SpeechSpan],
                     sample_rate: int = SAMPLE_RATE) -> List[Repetition]:
    """Every run of repeated units in the clip's speech, with a confidence."""
    if samples is None or len(samples) == 0 or not speech:
        return []
    all_units: List[Unit] = []
    for span in speech:
        all_units += split_units(samples, span, sample_rate)
    if len(all_units) < 2:
        return []
    speech_rms = float(np.median([u.rms for u in all_units])) or 1e-6
    out: List[Repetition] = []
    i = 0
    while i < len(all_units) - 1:
        run = [all_units[i]]
        sims: List[float] = []
        j = i + 1
        while j < len(all_units):
            prev, cur = run[-1], all_units[j]
            if cur.duration > MAX_UNIT_SECONDS or prev.duration > MAX_UNIT_SECONDS:
                break
            gap = cur.start - prev.end
            if gap > MAX_GAP_MEDIUM:
                break
            ratio = cur.duration / max(1e-6, prev.duration)
            if not 0.6 <= ratio <= 1.6:
                break
            sim = similarity(prev.fingerprint, cur.fingerprint)
            if sim < MEDIUM_SIMILARITY:
                break
            run.append(cur)
            sims.append(sim)
            j += 1
        if len(run) >= 2:
            out.append(_grade(run, sims, speech_rms))
            i = j
        else:
            i += 1
    return out


def _grade(run: List[Unit], sims: List[float], speech_rms: float) -> Repetition:
    gaps = [b.start - a.end for a, b in zip(run, run[1:])]
    loudness = [u.rms for u in run]
    spread = (max(loudness) - min(loudness)) / max(1e-6, max(loudness))
    shouted = max(loudness) > SHOUT_RATIO * speech_rms
    lowest = min(sims)
    reasons = []
    high = lowest >= HIGH_SIMILARITY and max(gaps) < MAX_GAP_HIGH and spread <= LOUDNESS_TOLERANCE and not shouted
    if high:
        reasons.append("{} near-identical copies (similarity {:.2f}), evenly loud, {:.0f} ms apart".format(
            len(run), lowest, 1000 * max(gaps)))
        confidence = "high"
    else:
        confidence = "medium"
        if lowest < HIGH_SIMILARITY:
            reasons.append("copies are similar but not identical ({:.2f})".format(lowest))
        if max(gaps) >= MAX_GAP_HIGH:
            reasons.append("copies are {:.0f} ms apart".format(1000 * max(gaps)))
        if spread > LOUDNESS_TOLERANCE:
            reasons.append("loudness varies {:.0f} %".format(100 * spread))
        if shouted:
            reasons.append("shouted ({:.1f}x the clip's speech level)".format(max(loudness) / speech_rms))
        reasons.append("kept for a person to hear")
    return Repetition(copies=len(run), similarity=lowest, confidence=confidence,
                      remove=(run[0].start, run[-1].start), keep_from=run[-1].start,
                      reason="; ".join(reasons))


def to_dict(rep: Repetition) -> dict:
    return {"copies": rep.copies, "similarity": round(rep.similarity, 3), "confidence": rep.confidence,
            "remove": [round(rep.remove[0], 3), round(rep.remove[1], 3)], "keep_from": round(rep.keep_from, 3),
            "reason": rep.reason}


def from_dict(raw: dict) -> Optional[Repetition]:
    try:
        return Repetition(copies=int(raw["copies"]), similarity=float(raw["similarity"]),
                          confidence=str(raw["confidence"]), remove=(float(raw["remove"][0]), float(raw["remove"][1])),
                          keep_from=float(raw["keep_from"]), reason=str(raw.get("reason", "")))
    except (KeyError, TypeError, ValueError, IndexError):
        return None
