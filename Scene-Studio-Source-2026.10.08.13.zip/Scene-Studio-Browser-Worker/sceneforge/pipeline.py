"""Run ingest -> voice detection -> cut planning as one step."""
from __future__ import annotations

import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Optional

from .autocut import auto_approve, plan_episode
from .config import Config
from .ingest import scan
from .models import Episode, Flag
from .vad import VoiceDetector, spans_from_probabilities
from .audio import decode, music_ratio, silence_spans
from .motion import motion_profile
from . import repetition

Progress = Optional[Callable[[int, int, str], None]]


def analyse(
    source_dir: Path,
    config: Config,
    progress: Progress = None,
    approve_clean: Optional[bool] = None,
) -> Episode:
    """Scan the folder, detect speech in every clip, and plan the cuts.

    `approve_clean` defaults to the config: unflagged clips start approved
    when the tool is doing the trimming, and never when the editor is.
    """
    if approve_clean is None:
        approve_clean = config.auto_approve_clean and config.trim_mode != "manual"
    episode = scan(source_dir, config)
    detector = VoiceDetector()

    # Clips are independent, so several are listened to and watched at
    # once: the sound decode and the motion pass are ffmpeg processes and
    # the voice model runs on one thread per call, so three at a time on a
    # four-core laptop is where the gain stops. The order of the results
    # and of the progress line is the clip order, whatever finished first.
    total = len(episode.clips)
    with ThreadPoolExecutor(max_workers=analysis_workers()) as pool:
        futures = [pool.submit(_analyse_clip, clip, detector, config) for clip in episode.clips]
        for index, (clip, future) in enumerate(zip(episode.clips, futures), start=1):
            future.result()
            if progress:
                progress(index, total, "clip {}".format(clip.number))

    plan_episode(episode, config)
    if approve_clean:
        auto_approve(episode)
    return episode


def analysis_workers() -> int:
    cpus = os.cpu_count() or 2
    return max(1, min(3, cpus // 2))


def _analyse_clip(clip, detector: VoiceDetector, config: Config) -> None:
    """Everything the analysis learns about one clip, written onto it."""
    samples = decode(clip.path)
    if samples is None:
        clip.flags.add(Flag.NO_AUDIO_TRACK)
    else:
        probabilities = detector.probabilities(samples)
        clip.speech = spans_from_probabilities(
            probabilities,
            threshold=config.vad_threshold,
            min_speech_ms=config.vad_min_speech_ms,
            min_silence_ms=config.vad_min_silence_ms,
        )
        # The same scores read leniently, so the cut planner can see the
        # quiet edge of a word the strict reading left off. Short blips
        # count here: a single trailing consonant is exactly the point.
        clip.speech_soft = spans_from_probabilities(
            probabilities,
            threshold=config.boundary_vad_threshold,
            min_speech_ms=100,
            min_silence_ms=config.vad_min_silence_ms,
        )
        # Whole-mix silence and how much of the rest carries sound: the
        # cut rule needs both to know which pauses are safe to tighten
        # and which no-dialogue clips are action rather than padding.
        clip.silence = silence_spans(samples, threshold_db=config.silence_db)
        clip.music_ratio = music_ratio(samples, clip.speech, clip.silence)
        # A word the generator said twice: heard, recorded, and left to
        # the cut rule (and its confidence gates) to act on.
        try:
            clip.repetitions = [repetition.to_dict(r) for r in
                                repetition.find_repetitions(samples, clip.speech)]
        except Exception:                      # noqa: BLE001 - a finding, not a gate
            clip.repetitions = []
    try:
        clip.motion_profile = motion_profile(clip.path)
    except Exception:                          # noqa: BLE001 - a score, not a gate
        clip.motion_profile = []
    clip.motion_score = (sum(clip.motion_profile) / len(clip.motion_profile)) if clip.motion_profile else 0.0
