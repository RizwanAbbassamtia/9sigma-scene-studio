"""The continuity engine: how one clip becomes the next without the viewer
noticing, decided from the pictures rather than from a menu.

For every join the last few frames of one side and the first few of the
other are read at postage-stamp size -- brightness, colour, how much is
moving, whether the frames are frozen or black -- and one of three joins is
chosen:

  cut     a clean cut, with a 30 ms audio ramp so nothing clicks. The default
          inside a scene, and the choice at a scene change when either side
          is moving enough that a dissolve would show a ghost.
  blend   a short cross-dissolve, about 0.2 s. The default at a scene change,
          and used inside a scene when the brightness jumps enough that a cut
          would flash.
  dip     through black; only at the episode's own start and end.

Two repairs are made before anything is encoded: frozen or black frames on
either side of a cut are trimmed (never into speech), and when neighbouring
clips differ in brightness or colour the incoming clip is shifted part of
the way toward the outgoing one -- a small, capped shift that softens a
mismatch without recolouring a deliberately darker scene.

Thresholds were read off the real 160-clip episode (see DEVELOPMENT.md):
edge brightness runs 72-109 of 255 with neighbours 5-20 apart, edge motion
0.3-1.5 at rest and 3-5 when someone moves, and many generated clips end on
7-13 identical frames.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

from .ffmpeg_tools import require, run
from .logging_setup import get

log = get("continuity")

W, H, FPS = 64, 36, 24
WINDOW = 0.30            # seconds read on each side of a join
BLEND_SECONDS = 0.20     # the baseline dissolve; a few frames either way after frame snapping
MIN_BLEND_BODY = 0.9     # a piece shorter than this gives nothing up to a blend

# Decision thresholds.
GHOST_MOTION = 2.5       # mean frame difference above which a dissolve doubles the subject
FLASH_LUMA = 28.0        # brightness jump (of 255) inside a scene that a cut would flash
FROZEN_DIFF = 0.35       # frame difference below which two frames count as the same
BLACK_LUMA = 8.0
MAX_EDGE_TRIM = 0.6      # seconds of frozen/black frames trimmed off an edge at most
SPEECH_MARGIN = 0.15     # never trim closer than this to the last word

# Colour matching: shift the incoming clip toward the outgoing one by this
# share of the difference, never more than the cap. Deliberate lighting
# differences survive; accidental ones soften.
MATCH_LUMA_FROM = 8.0
MATCH_SHARE = 0.5
MATCH_CAP_LUMA = 10.0
MATCH_CAP_CHROMA = 6.0


@dataclass
class Edge:
    """What the frames at one side of a cut look like."""
    luma: float = 0.0
    u: float = 128.0
    v: float = 128.0
    motion: float = 0.0            # mean absolute difference between consecutive frames
    frozen: float = 0.0            # seconds of identical frames at the cut
    black: float = 0.0             # seconds of black frames at the cut
    frames: int = 0

    @property
    def ok(self) -> bool:
        return self.frames > 0


@dataclass
class Signature:
    head: Edge = field(default_factory=Edge)
    tail: Edge = field(default_factory=Edge)


@dataclass
class Join:
    kind: str                      # cut | blend
    seconds: float = 0.0
    reason: str = ""


# ------------------------------------------------------------- reading
def _frames(path: Path, start: float, seconds: float) -> Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """(Y, U, V) planes of the window, at 64x36, as int16 arrays [n, h, w]."""
    ffmpeg = require("ffmpeg")
    result = run([ffmpeg, "-nostdin", "-loglevel", "error",
                  "-ss", "{:.3f}".format(max(0.0, start)), "-i", str(path),
                  "-t", "{:.3f}".format(max(0.05, seconds)), "-an",
                  "-vf", "fps={},scale={}:{}:flags=area,format=yuv420p".format(FPS, W, H),
                  "-f", "rawvideo", "-"])
    if result.returncode != 0 or not result.stdout:
        return None
    frame_bytes = W * H + 2 * (W // 2) * (H // 2)
    count = len(result.stdout) // frame_bytes
    if count < 1:
        return None
    raw = np.frombuffer(result.stdout[:count * frame_bytes], dtype=np.uint8).reshape(count, frame_bytes)
    y = raw[:, :W * H].reshape(count, H, W).astype(np.int16)
    u = raw[:, W * H:W * H + (W // 2) * (H // 2)].reshape(count, H // 2, W // 2).astype(np.int16)
    v = raw[:, W * H + (W // 2) * (H // 2):].reshape(count, H // 2, W // 2).astype(np.int16)
    return y, u, v


def _edge(planes, at_end: bool) -> Edge:
    y, u, v = planes
    n = len(y)
    diffs = np.abs(y[1:] - y[:-1]).mean(axis=(1, 2)) if n > 1 else np.zeros(0)
    order = diffs[::-1] if at_end else diffs
    frozen = 0
    for value in order:
        if value < FROZEN_DIFF:
            frozen += 1
        else:
            break
    lumas = y.mean(axis=(1, 2))
    order_l = lumas[::-1] if at_end else lumas
    black = 0
    for value in order_l:
        if value < BLACK_LUMA:
            black += 1
        else:
            break
    return Edge(luma=float(lumas.mean()), u=float(u.mean()), v=float(v.mean()),
                motion=float(diffs.mean()) if len(diffs) else 0.0,
                frozen=(frozen + 1) / FPS if frozen else 0.0, black=black / FPS, frames=n)


def edge_signature(path: Path, cut: float, side: str, seconds: float = WINDOW) -> Edge:
    """The frames just before (`side` "tail") or just after ("head") a
    source time. An unreadable window is an empty Edge, never an error."""
    try:
        start = cut - seconds if side == "tail" else cut
        planes = _frames(Path(path), start, seconds)
    except Exception as exc:                            # noqa: BLE001 - a reading, not a gate
        log.warning("Could not read the %s of %s at %.2f s: %s", side, path, cut, exc)
        return Edge()
    if planes is None:
        return Edge()
    return _edge(planes, at_end=(side == "tail"))


def signatures(pieces: List[Tuple[Path, float, float]], workers: int = 4) -> List[Signature]:
    """One Signature per (path, start, end) piece, read in parallel: the
    head at `start`, the tail at `end`."""
    def work(item):
        path, start, end = item
        return Signature(head=edge_signature(path, start, "head"),
                         tail=edge_signature(path, end, "tail"))
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        return list(pool.map(work, pieces))


# ------------------------------------------------------------- deciding
def decide(before: Edge, after: Edge, scene_change: bool, body_before: float, body_after: float,
           blend_seconds: float = BLEND_SECONDS) -> Join:
    """The join between two pieces. `body_*` are the pieces' lengths, so a
    blend is never asked of a piece too short to give the overlap up."""
    short = body_before < MIN_BLEND_BODY or body_after < MIN_BLEND_BODY
    known = before.ok and after.ok
    moving = known and (before.motion > GHOST_MOTION or after.motion > GHOST_MOTION)
    if scene_change:
        if short:
            return Join("cut", reason="scene change, but a piece is too short for a blend")
        if moving:
            return Join("cut", reason="scene change cut on movement ({:.1f}/{:.1f}): a blend would ghost".format(
                before.motion, after.motion))
        return Join("blend", blend_seconds, "scene change: {:.2f} s blend".format(blend_seconds))
    # inside a scene
    if known and abs(after.luma - before.luma) > FLASH_LUMA and not moving and not short:
        return Join("blend", blend_seconds, "brightness jumps {:.0f} → {:.0f}: softened with a blend".format(
            before.luma, after.luma))
    return Join("cut", reason="continuous action: clean cut")


def edge_trims(tail: Edge, head: Edge, tail_floor: float, head_ceiling: float,
               tail_end: float, head_start: float) -> Tuple[float, float]:
    """How far to pull the outgoing cut in (frozen or black frames at the
    end of the piece) and the incoming cut forward, bounded by MAX_EDGE_TRIM
    and by the speech margins the caller passes (`tail_floor` is the
    earliest the end may move to, `head_ceiling` the latest the start may).
    Returns (new_end, new_start)."""
    new_end, new_start = tail_end, head_start
    dead = max(tail.frozen, tail.black)
    if dead >= 2.0 / FPS:
        new_end = max(tail_floor, tail_end - min(dead, MAX_EDGE_TRIM))
    dead = max(head.frozen, head.black)
    if dead >= 2.0 / FPS:
        new_start = min(head_ceiling, head_start + min(dead, MAX_EDGE_TRIM))
    return new_end, new_start


def colour_shift(before: Edge, after: Edge) -> Tuple[float, float, float]:
    """(dY, dU, dV) to add to the incoming clip so its first frames sit
    closer to the outgoing clip's last ones. Zero when the difference is
    small enough to pass, and never past the caps."""
    if not (before.ok and after.ok):
        return 0.0, 0.0, 0.0
    dy = before.luma - after.luma
    du = before.u - after.u
    dv = before.v - after.v
    if abs(dy) < MATCH_LUMA_FROM and abs(du) < MATCH_CAP_CHROMA and abs(dv) < MATCH_CAP_CHROMA:
        return 0.0, 0.0, 0.0
    clamp = lambda value, cap: max(-cap, min(cap, value * MATCH_SHARE))   # noqa: E731
    return clamp(dy, MATCH_CAP_LUMA), clamp(du, MATCH_CAP_CHROMA), clamp(dv, MATCH_CAP_CHROMA)


def colour_filter(shift: Tuple[float, float, float]) -> str:
    """An ffmpeg filter applying the shift, or "" for none. lutyuv adds a
    constant to each plane and clips the result to the plane's range
    itself -- the gentlest correction there is. No commas in the
    expression: a comma inside a -vf chain would split the filter."""
    dy, du, dv = shift
    if abs(dy) < 0.5 and abs(du) < 0.5 and abs(dv) < 0.5:
        return ""
    parts = []
    if abs(dy) >= 0.5:
        parts.append("y=val+{:.1f}".format(dy))
    if abs(du) >= 0.5:
        parts.append("u=val+{:.1f}".format(du))
    if abs(dv) >= 0.5:
        parts.append("v=val+{:.1f}".format(dv))
    return "lutyuv=" + ":".join(parts)


# ----------------------------------------------------------- the report
@dataclass
class JoinRecord:
    """One line of the continuity log: what was decided at a join and why."""
    before: int
    after: int
    kind: str
    seconds: float
    reason: str
    trimmed_tail: float = 0.0
    trimmed_head: float = 0.0
    shift: Tuple[float, float, float] = (0.0, 0.0, 0.0)

    def line(self) -> str:
        extra = []
        if self.trimmed_tail >= 0.01:
            extra.append("trimmed {:.2f} s of dead frames off the end of clip {}".format(self.trimmed_tail, self.before))
        if self.trimmed_head >= 0.01:
            extra.append("trimmed {:.2f} s of dead frames off the start of clip {}".format(self.trimmed_head, self.after))
        if any(abs(x) >= 0.5 for x in self.shift):
            extra.append("clip {} shifted Y{:+.0f} U{:+.0f} V{:+.0f}".format(self.after, *self.shift))
        return "clip {} → {}: {}{} — {}{}".format(
            self.before, self.after, self.kind, " {:.2f} s".format(self.seconds) if self.seconds else "",
            self.reason, ("; " + "; ".join(extra)) if extra else "")
