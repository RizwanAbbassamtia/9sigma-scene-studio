"""Which product this checkout or install is: 9 Sigma Automation or 9 Sigma
Omni Flow. One codebase, two fully separate products on the same machine.

Everything that must differ between them -- the name on screen, the install
folder, the installer's file name and mutex, the update channel, the version
line, the DPAPI entropy that seals API keys -- is read from `PRODUCT`, never
written into a module by hand. The build (tools/make_setup_exe.py) drops a
`product.json` into the payload root; a checkout without one is the
Automation profile, so the existing product behaves exactly as before.
`SCENEFORGE_PRODUCT=omniflow` selects the other profile in development.

Standard library only: sceneforge.launch imports this before Qt exists.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

from .version import OMNIFLOW_VERSION, VERSION

PRODUCT_FILE = "product.json"
ENV_VAR = "SCENEFORGE_PRODUCT"
OWNER = "RizwanAbbassamtia"


@dataclass(frozen=True)
class Product:
    key: str
    name: str
    folder: str
    update_repo: str
    version: str
    bat_name: str
    cli_bat: str

    @property
    def installer_name(self) -> str:
        return "Install-{}.exe".format(self.folder)

    @property
    def payload_name(self) -> str:
        return "{}-Setup.zip".format(self.folder)

    @property
    def mutex(self) -> str:
        return "Local\\{}-Setup".format(self.folder)

    @property
    def update_url(self) -> str:
        return "https://raw.githubusercontent.com/{}/main/latest.json".format(self.update_repo)

    @property
    def seal_entropy(self) -> bytes:
        # Different entropy per product: neither can open the other's sealed keys.
        return self.folder.encode("ascii")

    @property
    def user_agent(self) -> str:
        return "{}/{}".format(self.folder, self.version)

    @property
    def data_dir(self) -> Path:
        """Per-product settings under LOCALAPPDATA: keys, frameworks, email, worker id."""
        return Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / self.folder

    def to_dict(self) -> Dict[str, str]:
        """What the build writes to product.json (the installer reads it too)."""
        return {"key": self.key, "name": self.name, "folder": self.folder, "version": self.version,
                "installer_name": self.installer_name, "payload_name": self.payload_name,
                "mutex": self.mutex, "update_repo": self.update_repo, "update_url": self.update_url,
                "bat_name": self.bat_name, "cli_bat": self.cli_bat}


PRODUCTS: Dict[str, Product] = {
    "automation": Product(key="automation", name="9 Sigma Automation", folder="9SigmaAutomation",
                          update_repo=OWNER + "/9sigma-updates", version=VERSION,
                          bat_name="9SigmaAutomation.bat", cli_bat="9sigma-cli.bat"),
    "omniflow": Product(key="omniflow", name="9 Sigma Omni Flow", folder="9SigmaOmniFlow",
                        update_repo=OWNER + "/9sigma-omniflow-updates", version=OMNIFLOW_VERSION,
                        bat_name="9SigmaOmniFlow.bat", cli_bat="9sigma-omniflow-cli.bat"),
}
DEFAULT_KEY = "automation"


def app_root() -> Path:
    """The folder holding the `sceneforge` package: where product.json lives."""
    return Path(__file__).resolve().parent.parent


def load_product(root: Optional[Path] = None, env: Optional[Dict[str, str]] = None) -> Product:
    """product.json in the app root wins; then the environment; then Automation.
    An unknown or unreadable key falls back rather than failing to start."""
    path = Path(root if root is not None else app_root()) / PRODUCT_FILE
    key = ""
    if path.exists():
        try:
            key = str(json.loads(path.read_text(encoding="utf-8")).get("key", ""))
        except (OSError, ValueError):
            key = ""
    if not key:
        key = (os.environ if env is None else env).get(ENV_VAR, "")
    return PRODUCTS.get(key.strip().lower(), PRODUCTS[DEFAULT_KEY])


PRODUCT = load_product()
