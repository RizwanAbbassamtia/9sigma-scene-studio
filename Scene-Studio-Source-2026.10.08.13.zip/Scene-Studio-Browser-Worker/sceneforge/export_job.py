"""The export itself: segmented, checkpointed, resumable.

Why this exists (24 Sep 2026). Editors' exports froze at "547 / 550 --
encoding the final video (526 pieces)" once an episode passed about 225
clips. The old pipeline cut every piece, then sent the WHOLE episode through
one ffmpeg process to encode it at delivery quality (assemble.deliver). That
one process grew with the episode: 50 minutes of video in a single hardware
encoder session, with no progress on screen, a deadline of four times the
video's length before a frozen encoder was noticed (3 h 20 min for a
50-minute episode), and a retry that started the entire episode again on the
CPU. Every piece lived in %TEMP% until the end, and anything that stopped the
export threw all of it away.

The design now:

  plan       the pieces (one per kept span, one per blend) in play order,
             grouped into segments of about `export_segment_seconds` (five
             minutes by default), each at a piece boundary
  per segment, one at a time:
    cut      the segment's pieces, near lossless, in parallel; each one
             measured and checked against its planned length
    encode   the segment at delivery quality, video to MPEG-TS and sound to
             PCM, in one ffmpeg process watched through -progress: a job
             whose output stops moving for `export_stall_seconds` is killed
             with its process tree; a stalled or failed hardware encode is
             retried on the CPU for THIS segment, and the hardware encoder is
             set aside for the rest of the export
    check    the segment is probed and decoded end to end (the seam check
             rides on the same decode); only then is it marked done in the
             manifest and its pieces deleted, so the disk holds one
             segment's pieces at a time however long the episode is
  audio      the segments' PCM joined and encoded to AAC once
  join       the segments' video and the AAC joined by stream copy -- the
             video is never encoded a second time
  validate   the finished file's length is compared with the plan's; a file
             that came out short is a failure, not a finished export

Everything lives in a folder beside the output (<output folder>/
.9sigma-export/<file name>/) with export_manifest.json recording each piece
and segment by a fingerprint of what went into it. Export the same episode
to the same file again after a crash, a power cut or a closed window, and
the finished segments are reused; change one clip and only the segments that
contain it are made again. The folder is removed once the finished file has
been validated, and kept whenever the export stops.

Segments are MPEG-TS because a TS file carries the encoder's parameter sets
in the stream: a segment made by Quick Sync and the next made by libx264 join
by stream copy and decode cleanly (tested: 360 of 360 frames, no errors), and
a TS cut short by a power cut is still readable up to where it stopped.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from . import encoders
from .config import Config
from .ffmpeg_tools import CANCELLED, STALLED, Progress, find_tool, require, run, run_with_progress
from .logging_setup import get

log = get("export")

MANIFEST = "export_manifest.json"
FORMAT = 1
WORK_FOLDER = ".9sigma-export"


JOIN_STALL = 3600.0       # the join's faststart copy of a 2-hour file on a slow drive says nothing for minutes
SEGMENT_TOLERANCE = 0.07  # seconds a segment's picture and sound may differ: under two frames at 30 fps
PIECE_SOUND_SLACK = 48    # samples (a millisecond) a piece's sound may differ from its frames' worth
NEED_GB = 3.0             # free space a segment's near-lossless pieces may take while it is made


CPU_NAME = "libx264 (CPU)"      # encoders.describe() for the CPU encoder


class ExportError(RuntimeError):
    """An export that stopped. The message is for the editor: what went
    wrong, and that exporting again to the same file continues it."""


# ------------------------------------------------------------------ plan
@dataclass
class Piece:
    key: str                 # file stem in the work folder
    kind: str                # "cut" or "blend"
    index: int               # job index (cut) or dissolve index (blend)
    clip: int                # the clip number this time belongs to
    name: str                # the clip's file name, for messages
    expected: float          # planned seconds (= frames / fps)
    fingerprint: str
    frames: int = 0          # planned output frames; the plan, the cut and the check all use this
    short: float = 0.0       # seconds the source ends before the span it was planned to cover


@dataclass
class Segment:
    number: int              # 1-based, for people
    pieces: List[Piece]
    fingerprint: str = ""

    @property
    def expected(self) -> float:
        return sum(p.expected for p in self.pieces)


def _digest(*parts) -> str:
    return hashlib.sha256(repr(parts).encode("utf-8")).hexdigest()[:20]


def _source(path: Path) -> Tuple[str, int, int]:
    try:
        st = Path(path).stat()
        return str(path), st.st_size, st.st_mtime_ns
    except OSError:
        return str(path), -1, -1


def plan(jobs, dissolves, config: Config, fps: float, usable: Optional[Dict[str, float]] = None) -> List[Piece]:
    """Every piece in play order: body, blend, body, blend, ...

    One plan in whole frames at the output rate. Each piece is a number of
    frames; its seconds are frames / fps; the cut makes exactly that many
    frames with exactly that much sound, and the checks count them. A
    source that stops before its stated length (`usable`: path -> the end
    its picture really reaches) is planned to its real end here, not
    discovered half way through the export."""
    from .assemble import _snap, body_span, piece_frames
    usable = usable or {}
    settings = (config.edge_fade_ms, config.cut_audio_ramp_ms, round(fps, 3), "frames")
    after = {d.before: (i, d) for i, d in enumerate(dissolves)}
    pieces: List[Piece] = []
    for order, job in enumerate(jobs):
        start, end = body_span(job)
        limit = usable.get(str(job.clip.path))
        frames = piece_frames(job, fps, limit)
        short = max(0.0, end - (start + frames / fps)) if limit is not None and limit < end else 0.0
        pieces.append(Piece(
            key="{:05d}_{:04d}_{:02d}".format(order, job.clip.number, job.index), kind="cut", index=order,
            clip=job.clip.number, name=job.clip.path.name, expected=frames / fps,
            fingerprint=_digest("cut", _source(job.clip.path), job.clip.muted, job._replace(clip=None), settings,
                                frames),
            frames=frames, short=short))
        if order in after and order + 1 < len(jobs):
            i, dissolve = after[order]
            nxt = jobs[order + 1]
            blend_frames = max(1, int(round(_snap(dissolve.seconds, fps) * fps)))
            pieces.append(Piece(
                key="{:05d}_x_{:04d}_{:04d}".format(order, job.clip.number, nxt.clip.number), kind="blend",
                index=i, clip=nxt.clip.number, name=nxt.clip.path.name, expected=blend_frames / fps,
                fingerprint=_digest("blend", _source(job.clip.path), _source(nxt.clip.path), job.clip.muted,
                                    nxt.clip.muted, job._replace(clip=None), nxt._replace(clip=None),
                                    dissolve, settings, blend_frames),
                frames=blend_frames))
    return pieces


def group(pieces: List[Piece], target: float) -> List[Segment]:
    """Consecutive pieces in segments of about `target` seconds. A short
    tail joins the segment before it rather than standing alone."""
    target = max(30.0, float(target))
    segments: List[Segment] = []
    current: List[Piece] = []
    length = 0.0
    for piece in pieces:
        current.append(piece)
        length += piece.expected
        if length >= target:
            segments.append(Segment(len(segments) + 1, current))
            current, length = [], 0.0
    if current:
        if segments and length < 0.3 * target:
            segments[-1].pieces.extend(current)
        else:
            segments.append(Segment(len(segments) + 1, current))
    return segments


# -------------------------------------------------------------- manifest
class Manifest:
    """export_manifest.json: what is finished, so an interrupted export
    picks up where it stopped. Written through a temp file and a rename, so
    a power cut leaves the previous version, never half of one."""

    def __init__(self, folder: Path, output: Path):
        self.path = folder / MANIFEST
        self.data: dict = {"format": FORMAT, "output": str(output), "created": _now(),
                           "pieces": {}, "segments": {}, "history": []}
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            if raw.get("format") == FORMAT:
                self.data.update(raw)
        except (OSError, ValueError):
            pass

    def save(self) -> None:
        self.data["updated"] = _now()
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=1, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.path)

    def piece(self, piece: Piece) -> Optional[dict]:
        entry = self.data["pieces"].get(piece.key)
        return entry if entry and entry.get("fingerprint") == piece.fingerprint else None

    def segment(self, segment: Segment) -> Optional[dict]:
        return self.data["segments"].get(segment.fingerprint)

    def note(self, text: str) -> None:
        self.data["history"] = (self.data.get("history", []) + ["{}  {}".format(_now(), text)])[-200:]


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def work_folder(output: Path) -> Path:
    return Path(output).parent / WORK_FOLDER / Path(output).name


# ------------------------------------------------------------- probing
@dataclass
class Probe:
    ok: bool
    seconds: float = 0.0
    video: str = ""
    width: int = 0
    height: int = 0
    audio: str = ""
    audio_seconds: float = 0.0
    video_seconds: float = 0.0
    video_frames: int = 0          # from the container's sample table (0 when the format has none)
    audio_samples: int = 0         # PCM samples, exact (0 when unknown)
    sample_rate: int = 0
    channels: int = 0
    error: str = ""


def probe(path: Path) -> Probe:
    ffprobe = find_tool("ffprobe")
    if not ffprobe:
        return Probe(False, error="ffprobe not found")
    if not Path(path).is_file() or Path(path).stat().st_size == 0:
        return Probe(False, error="missing or empty")
    result = run([ffprobe, "-v", "error", "-show_entries",
                  "format=duration:stream=codec_type,codec_name,width,height,duration,sample_rate,channels,"
                  "nb_frames,duration_ts,time_base",
                  "-of", "json", str(path)], timeout=120)
    if result.returncode != 0:
        return Probe(False, error=result.stderr.decode("utf-8", "replace")[-200:].strip() or "unreadable")
    try:
        data = json.loads(result.stdout.decode("utf-8", "replace"))
    except ValueError:
        return Probe(False, error="unreadable")
    found = Probe(True)
    try:
        found.seconds = float(data.get("format", {}).get("duration", 0) or 0)
    except ValueError:
        pass
    for stream in data.get("streams", []):
        if stream.get("codec_type") == "video" and not found.video:
            found.video = stream.get("codec_name", "")
            found.width, found.height = int(stream.get("width", 0)), int(stream.get("height", 0))
            try:
                found.video_seconds = float(stream.get("duration", 0) or 0)
            except ValueError:
                pass
            try:
                found.video_frames = int(stream.get("nb_frames", 0) or 0)
            except ValueError:
                pass
        elif stream.get("codec_type") == "audio" and not found.audio:
            found.audio = stream.get("codec_name", "")
            found.sample_rate = int(stream.get("sample_rate", 0) or 0)
            found.channels = int(stream.get("channels", 0) or 0)
            try:
                found.audio_seconds = float(stream.get("duration", 0) or 0)
            except ValueError:
                pass
            try:
                # duration_ts is in the stream's time base; for PCM in wav or
                # mov that base is one sample, so the count is exact.
                base = str(stream.get("time_base", "") or "")
                ticks = int(stream.get("duration_ts", 0) or 0)
                if base.startswith("1/") and int(base[2:]) == found.sample_rate and found.sample_rate:
                    found.audio_samples = ticks
                elif found.sample_rate:
                    found.audio_samples = int(round(found.audio_seconds * found.sample_rate))
            except ValueError:
                pass
    return found


def _free_gb(folder: Path) -> float:
    try:
        return shutil.disk_usage(str(folder)).free / 1e9
    except OSError:
        return 1e9


def _listing(path: Path, files) -> Path:
    """A concat-demuxer list. A quote inside a name is written as '\'' --
    the demuxer's own rule -- so an output called "Shazia's Kitchen.mp4"
    (whose name is in every piece's path) still works."""
    quoted = ["file '{}'".format(Path(f).as_posix().replace("'", "'\\''")) for f in files]
    path.write_text("\n".join(quoted), encoding="utf-8")
    return path


class Cancelled(ExportError):
    """The export was stopped on purpose (the window closed); the work is kept."""


def _check_cancel(cancel: Optional[threading.Event]) -> None:
    """`cancel` is the export's own token (BuildWorker sets it when the
    window closes); a cancelled export stops at the next safe point."""
    if cancel is not None and cancel.is_set():
        raise Cancelled("The export was stopped. Export again to the same file to continue; the finished "
                        "segments are kept.")


def _clock(seconds: float) -> str:
    seconds = int(max(0.0, seconds))
    if seconds >= 3600:
        return "{}:{:02d}:{:02d}".format(seconds // 3600, seconds % 3600 // 60, seconds % 60)
    return "{}:{:02d}".format(seconds // 60, seconds % 60)


# ---------------------------------------------------------------- report
class Reporter:
    """Turns where the export is into the progress line: overall percent on
    the bar, and in words what is happening, on which encoder, how fast,
    and how long is left."""

    def __init__(self, callback, total_seconds: float, segments: int):
        self.callback = callback
        self.total = max(1.0, total_seconds)
        self.segments = segments
        self.started = time.monotonic()
        self.done_seconds = 0.0          # of finished segments
        self.overall = 0.0
        self.free = 0.0                  # credited without work (segments reused from an earlier run)

    def __call__(self, fraction: float, text: str, detail: str = "") -> None:
        self.overall = max(self.overall, min(1.0, fraction))
        if not self.callback:
            return
        elapsed = time.monotonic() - self.started
        parts = [text]
        if detail:
            parts.append(detail)
        parts.append("overall {}%".format(int(100 * self.overall)))
        parts.append("elapsed {}".format(_clock(elapsed)))
        worked = self.overall - self.free
        if 0.03 < worked and self.overall < 1.0 and elapsed > 20:
            parts.append("about {} left".format(_clock(elapsed / worked * (1.0 - self.overall))))
        self.callback(int(1000 * self.overall), 1000, "  ·  ".join(parts))

    def segment_fraction(self, segment: Segment, within: float) -> float:
        # 1 % for the checks before, 95 % across the segments by length, 4 % to finish.
        return 0.01 + 0.95 * (self.done_seconds + segment.expected * max(0.0, min(1.0, within))) / self.total


# ---------------------------------------------------------------- export
@dataclass
class Result:
    output: Path
    seconds: float
    segments: int
    reused: int
    encoders: List[str] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)
    rescues: List[str] = field(default_factory=list)      # clips cut from a repaired copy
    frames: int = 0                                       # output frames the finished file must hold
    measured: Dict[int, float] = field(default_factory=dict)
    log: List[str] = field(default_factory=list)


def export(jobs, dissolves, config: Config, output: Path, size: Tuple[int, int], fps: float,
           captions=None, progress=None, keep_folder: Optional[Path] = None,
           cancel: Optional[threading.Event] = None) -> Result:
    """Make `output` from the planned jobs and dissolves. See the module
    docstring for the steps. Raises ExportError with a message for the
    editor when it cannot finish; what was finished is kept.

    `captions`, when given, burns captions: a callable
    (measured: {clip number: seconds}, path) -> bool that writes the SRT for
    the whole episode timed from the lengths measured so far (the plan for
    the rest). It is called before each segment, so the cues on screen
    follow what was really encoded, never a plan that drifted."""
    from .assemble import cut_segment, render_dissolve, _workers
    output = Path(output)
    folder = Path(keep_folder) if keep_folder else work_folder(output)
    try:
        (folder / "pieces").mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise ExportError("The folder {} cannot be written ({}). Choose another place to save the "
                          "video.".format(output.parent, exc.strerror or exc))
    encoders.reset()                       # a fresh export tries the hardware encoder again
    cancel = cancel or threading.Event()   # this export's own token; nothing else can set it
    try:
        output.with_name(output.stem + ".joining" + (output.suffix or ".mp4")).unlink(missing_ok=True)
    except OSError as exc:
        raise ExportError("A half-written file from an earlier export, {}, is in use ({}). Close it and export "
                          "again.".format(output.stem + ".joining" + (output.suffix or ".mp4"), exc.strerror or exc))
    _check_cancel(cancel)
    manifest = Manifest(folder, output)
    width, height = size
    stall = float(getattr(config, "export_stall_seconds", 180) or 180)
    # -- 1. every source clip must be readable, and its real end known,
    #       before the plan is made --------------------------------------
    if progress:
        progress(0, 1000, "Checking {} source clips".format(len({str(j.clip.path) for j in jobs})))
    usable = _check_sources(jobs, manifest)
    pieces = plan(jobs, dissolves, config, fps, usable)
    segments = group(pieces, getattr(config, "export_segment_seconds", 300) or 300)
    burn: Optional[Path] = None
    planned_cues = None
    if captions is not None:
        # A fixed name inside the work folder: the subtitles filter reads a
        # file name out of its filter string, where a comma or a quote in
        # the episode's name would break it.
        burn = folder / "captions.srt"
        if captions({}, burn) and burn.is_file():
            planned_cues = hashlib.sha256(burn.read_bytes()).hexdigest()
        else:
            burn = None
    delivery = (width, height, config.delivery_crf, config.delivery_preset, config.audio_bitrate,
                config.caption_font, config.caption_font_size, planned_cues)
    for segment in segments:
        segment.fingerprint = _digest(delivery, [p.fingerprint for p in segment.pieces])
    total = sum(s.expected for s in segments)
    report = Reporter(progress, total, len(segments))
    result = Result(output, 0.0, len(segments), 0)
    manifest.data.update({"size": [width, height], "fps": fps, "expected_seconds": round(total, 3),
                          "segment_count": len(segments), "clip_count": len({p.clip for p in pieces})})
    reused = sum(1 for s in segments if _segment_ready(manifest.segment(s), folder))
    manifest.note("export started: {} segments, {} pieces, {} ({} already done)".format(
        len(segments), len(pieces), _clock(total), reused))
    manifest.save()
    log.info("Export %s: %d pieces in %d segments, %s planned, %d segment(s) already done in %s",
             output.name, len(pieces), len(segments), _clock(total), reused, folder)
    _remove_stale(folder, segments, pieces, manifest)

    # -- 2. the segments, one at a time; each one's check beside the next --
    # (Two segments' pieces can be on disk at once: the guard below lets the
    # settled segment's pieces go first when the drive is tight.)
    # The check (a decode of the whole segment, on the CPU) took about a
    # quarter of an export while the encoder sat idle. Now segment n is
    # checked on a thread while segment n+1 is cut and encoded; a check that
    # fails sends its segment back through the ordinary encode-and-check
    # path before the export goes on, so the order of the finished
    # segments, and of everything recorded about them, is unchanged.
    checker = ThreadPoolExecutor(max_workers=1)
    pending: Optional[Tuple[Segment, dict, dict]] = None

    def settle(redo: bool = True) -> None:
        """Wait for the pending check. A segment that passed is done; one
        that failed is made again (`redo`), or -- when the export is
        already stopping for another reason -- left "failed" so the next
        export makes it again and reuses everything else."""
        nonlocal pending
        if pending is None:
            return
        segment, entry, work = pending
        pending = None
        problem, findings = work["future"].result()
        title = work["title"]
        if not problem:
            entry.update(status="done", findings=findings, frames=work.get("frames", entry.get("frames", 0)), finished=_now(),
                         video_bytes=work["video"].stat().st_size, audio_bytes=work["audio"].stat().st_size)
            manifest.note("{} done on {} ({})".format(title, entry.get("encoder", ""), _clock(entry["seconds"])))
            manifest.save()
            if keep_folder is None:
                for path in work["pieces"]:
                    path.unlink(missing_ok=True)      # its pieces are in the segment now
            work["listing"].unlink(missing_ok=True)
        else:
            log.warning("%s failed its check after encoding: %s", title, problem)
            manifest.note("{} check failed: {}".format(title, problem))
            entry.update(status="failed", error=problem)
            manifest.save()
            for path in (work["video"], work["audio"]):
                path.unlink(missing_ok=True)
            if not redo:
                return
            on_cpu = ""
            if encoders.hardware_active(config.video_encoder) and not _not_the_encoder(problem):
                encoders.demote("{}: {}".format(title, problem))
                on_cpu = " on the CPU"
            report.done_seconds -= segment.expected
            report(report.segment_fraction(segment, 0.3), title,
                   "the check found a problem ({}); making it again{}".format(problem, on_cpu))
            # A segment that did not add up is deterministic: before any
            # second encode its pieces are counted against the plan (a few
            # probes, not a five-minute encode); a piece that is off is the
            # cause and is named; pieces that agree give the encoder one
            # more try, on the other encoder when there is one.
            if _is_length_problem(problem):
                off = _pieces_off_plan(work.get("present", []), work.get("frames_of", {}), fps)
                if off:
                    entry.update(status="failed", error="{}: {}".format(problem, "; ".join(off[:5])))
                    manifest.note("{}: {}".format(title, entry["error"]))
                    manifest.save()
                    raise ExportError("{} could not be encoded after 1 try ({}). Replace or reject the clip "
                                      "named and export again to the same file; the finished segments are "
                                      "kept.".format(title, entry["error"]))
            entry = _make_segment(segment, len(segments), jobs, dissolves, config, fps, size, folder, manifest,
                                  report, stall, burn, cut_segment, render_dissolve, _workers, work["offset"],
                                  keep_folder, captions, result.measured, cancel,
                                  length_tries=1 if _is_length_problem(problem) else 2)
            report.done_seconds += segment.expected
        _collect(result, entry, segment)

    try:
        for segment in segments:
            entry = manifest.segment(segment)
            if _segment_ready(entry, folder):
                settle()
                result.reused += 1
                report.done_seconds += segment.expected
                report.free += 0.95 * segment.expected / report.total
                _collect(result, entry, segment)
                report(report.segment_fraction(segment, 0.0),
                       "Segment {} of {} already done".format(segment.number, len(segments)))
                continue
            if pending is not None and _free_gb(folder) < NEED_GB:
                settle()                     # a tight disk: the last segment's pieces go before more are cut
            # Where this segment sits in the episode, and the clip lengths
            # measured so far, for the caption burn: the segment before it
            # is encoded but not yet collected, so its figures are added by
            # hand. Without this the captions of segment 2 would be burned
            # at segment 1's times.
            offset, measured = result.seconds, result.measured
            if pending is not None:
                ahead = pending[1]
                offset += ahead.get("seconds", 0.0)
                measured = dict(result.measured)
                for clip, length in ahead.get("clips", {}).items():
                    measured[int(clip)] = measured.get(int(clip), 0.0) + length
            work: dict = {"offset": offset}
            entry = _make_segment(segment, len(segments), jobs, dissolves, config, fps, size, folder, manifest,
                                  report, stall, burn, cut_segment, render_dissolve, _workers, offset,
                                  keep_folder, captions, measured, cancel, deferred=work)
            try:
                settle()                     # the one before must be settled before this one is queued
            except BaseException:
                # The one before could not be settled: this one is still
                # queued, so the error path below marks it too, and the
                # next export reuses it instead of encoding it again.
                work["future"] = checker.submit(_check_segment, work["video"], work["audio"], work["seconds"],
                                                size, work["joins"], config, stall, None, lambda p: None,
                                                work.get("frames", 0))
                pending = (segment, entry, work)
                raise
            report.done_seconds += segment.expected
            # No cancel token for the check: a cancel during the next encode
            # must not throw away a segment that is fully encoded. The check
            # is bounded by `stall` (a frozen decode is killed) and short.
            work["future"] = checker.submit(_check_segment, work["video"], work["audio"], work["seconds"], size,
                                            work["joins"], config, stall, None, lambda p: None, work.get("frames", 0))
            pending = (segment, entry, work)
        settle()
    except BaseException:
        # Whatever stopped the export, the segment already encoded is not
        # lost: its check is waited for and its entry marked, so the next
        # export reuses it (or, after a failed check, makes it again).
        if pending is not None:
            try:
                settle(redo=False)
            except Exception as exc:                   # noqa: BLE001 - the original error is the one to report
                log.warning("The pending segment check could not be settled: %s", exc)
        raise
    finally:
        checker.shutdown(wait=True)

    # -- 3. one encoder throughout, then the sound -------------------------
    ordered = [manifest.segment(s) for s in segments]
    result.log += _conform(segments, ordered, folder, config, size, report, stall, manifest, result, cancel)
    finish = 0.96
    report(finish, "Encoding the sound track")
    audio = folder / "audio.m4a"
    wav_list = _listing(folder / "audio.txt", [folder / e["audio"] for e in ordered])
    ffmpeg = require("ffmpeg")
    sound_seconds = sum(e["seconds"] for e in ordered)
    done = run_with_progress([ffmpeg, "-nostdin", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0",
                              "-i", str(wav_list), "-c:a", "aac", "-b:a", config.audio_bitrate, "-ar", "48000",
                              str(audio)],
                             lambda p: report(finish + 0.01 * p.seconds / max(1.0, sound_seconds),
                                              "Encoding the sound track"), stall, cancel=cancel)
    if done.returncode == CANCELLED:
        _check_cancel(cancel)
    found = probe(audio)
    if done.returncode != 0 or not found.ok or abs(found.audio_seconds - sound_seconds) > 0.5:
        raise ExportError("The sound track could not be made ({}). Export again to the same file to "
                          "try again; the finished segments are kept.".format(
                              _why(done) if done.returncode != 0 else found.error or "wrong length"))

    # -- 4. join by stream copy --------------------------------------------
    # faststart moves the index to the front in place (no second copy), but
    # says nothing on the progress pipe while it does: the join runs under
    # JOIN_STALL, not the encoder's stall window.
    need = (sum((folder / e["video"]).stat().st_size for e in ordered) + audio.stat().st_size) / 1e9 * 1.2
    if _free_gb(output.parent) < need:
        raise ExportError("Not enough space on the drive of {} to write the finished video: it needs about "
                          "{:.1f} GB and {:.1f} GB is free. Free some space and export again; the finished "
                          "segments are kept.".format(output.parent, need, _free_gb(output.parent)))
    report(0.97, "Joining {} segments".format(len(segments)))
    video_list = _listing(folder / "segments.txt", [folder / e["video"] for e in ordered])
    joining = output.with_name(output.stem + ".joining" + (output.suffix or ".mp4"))
    done = run_with_progress([ffmpeg, "-nostdin", "-loglevel", "error", "-y",
                              "-f", "concat", "-safe", "0", "-i", str(video_list), "-i", str(audio),
                              "-map", "0:v:0", "-map", "1:a:0", "-c", "copy", "-movflags", "+faststart",
                              "-video_track_timescale", str(int(round(fps * 1000))),   # 1001 ticks a frame at 23.976
                              str(joining)],
                             lambda p: report(0.97 + 0.02 * p.seconds / max(1.0, total),
                                              "Joining {} segments".format(len(segments))),
                             max(stall, JOIN_STALL), cancel=cancel)
    if done.returncode == CANCELLED:
        joining.unlink(missing_ok=True)
        _check_cancel(cancel)
    if done.returncode != 0:
        joining.unlink(missing_ok=True)
        raise ExportError("The segments could not be joined ({}). Export again to the same file; the "
                          "finished segments are kept.".format(_why(done)))

    # -- 5. the finished file must be what was planned ---------------------
    report(0.99, "Checking the finished video")
    expected = sum(e["seconds"] for e in ordered)
    final = probe(joining)
    problem = _final_problem(final, expected, width, height, sum(int(e.get("frames", 0) or 0) for e in ordered))
    if problem:
        for e in ordered:
            found = probe(folder / e["video"])
            if not found.ok or abs(found.seconds - e["seconds"]) > max(0.15, 0.002 * e["seconds"]):
                e["status"] = "damaged"                # made again next time
        manifest.note("final check failed: " + problem)
        manifest.save()
        joining.unlink(missing_ok=True)
        raise ExportError("The finished video failed its check: {}. Nothing was saved as {}; export again "
                          "to the same file to rebuild it from the kept segments.".format(problem, output.name))
    try:
        os.replace(joining, output)
    except OSError as exc:
        joining.unlink(missing_ok=True)
        raise ExportError("The finished video could not be saved as {} ({}). Close the video if it is open "
                          "in a player, then export again; the finished segments are kept.".format(
                              output.name, exc.strerror or exc))
    result.seconds = final.seconds
    manifest.note("finished: {} ({})".format(output.name, _clock(final.seconds)))
    manifest.save()
    log.info("Export finished: %s, %s, %d segments (%d reused), encoders %s",
             output.name, _clock(final.seconds), len(segments), result.reused, ", ".join(result.encoders))
    result.log.append("Export: {} segments ({} reused from an earlier run), {}; encoders: {}".format(
        len(segments), result.reused, _clock(final.seconds), ", ".join(result.encoders) or "none"))
    if keep_folder is None:
        shutil.rmtree(folder, ignore_errors=True)
        try:
            folder.parent.rmdir()                      # .9sigma-export, when nothing else is in it
        except OSError:
            pass
    report(1.0, "Done")
    return result


def _segment_ready(entry: Optional[dict], folder: Path) -> bool:
    """Done, and its two files still the size they were when it was checked
    (a later truncation -- a cleanup, antivirus, a copy that stopped -- must
    not be joined in and then fail the final check for ever)."""
    if not entry or entry.get("status") != "done":
        return False
    for name, size in ((entry.get("video", "?"), entry.get("video_bytes")),
                       (entry.get("audio", "?"), entry.get("audio_bytes"))):
        path = folder / name
        if not path.is_file() or (size is not None and path.stat().st_size != size):
            return False
    return True


def _collect(result: Result, entry: dict, segment: Segment) -> None:
    encoder = entry.get("encoder", "")
    if encoder and encoder not in result.encoders:
        result.encoders.append(encoder)
    result.findings += ["segment {}: {}".format(segment.number, f) for f in entry.get("findings", [])]
    result.rescues += ["segment {}: {}".format(segment.number, r) for r in entry.get("rescues", [])]
    result.frames += int(entry.get("frames", 0) or 0)
    for clip, seconds in entry.get("clips", {}).items():
        result.measured[int(clip)] = result.measured.get(int(clip), 0.0) + seconds
    result.seconds += entry.get("seconds", 0.0)


def _not_the_encoder(problem: str) -> bool:
    """A failure the encoder is not to blame for: setting the hardware aside
    would not help, it would only make the retry four times slower."""
    text = problem.lower()
    return any(word in text for word in ("disk is full", "no space", "permission denied", "not enough space"))


def _why(done) -> str:
    text = done.stderr.decode("utf-8", "replace").strip().splitlines() if done.stderr else []
    if done.returncode == STALLED:
        return "the encoder stopped responding"
    if any("No space left" in line for line in text):
        return "the disk is full"
    return (text[-1] if text else "exit {}".format(done.returncode))[:200]


def _final_problem(final: Probe, expected: float, width: int, height: int, frames: int = 0) -> str:
    if not final.ok:
        return "it cannot be read ({})".format(final.error)
    if final.video != "h264" or not final.audio:
        return "it has no {} track".format("video" if final.video != "h264" else "sound")
    if (final.width, final.height) != (width, height):
        return "it is {}x{}, not {}x{}".format(final.width, final.height, width, height)
    if frames and final.video_frames and final.video_frames != frames:
        # The segments are joined without re-encoding, so the frame count
        # is the sum of the segments' counts: a missing or doubled frame at
        # a join shows here.
        return "it has {} frames but should have {}".format(final.video_frames, frames)
    tolerance = max(1.0, 0.001 * expected)
    if abs(final.seconds - expected) > tolerance:
        return "it is {} long but should be {}".format(_clock(final.seconds), _clock(expected))
    if final.audio_seconds and abs(final.audio_seconds - final.seconds) > 0.5:
        return "its sound is {} but its picture {}".format(_clock(final.audio_seconds), _clock(final.seconds))
    return ""


def _check_sources(jobs, manifest: Optional["Manifest"] = None) -> Dict[str, float]:
    """Every source must open, and its picture's real end is measured
    before the plan is made. Returns {path: usable end} for the sources
    that stop before their stated length (a download that broke off keeps
    its header). The answer is kept in the manifest by the file's path,
    size and modification time, so a resumed export does not decode the
    same tails again; a replaced file is measured afresh."""
    clips = {}
    for job in jobs:
        clips[str(job.clip.path)] = job.clip
    cache = manifest.data.setdefault("sources", {}) if manifest is not None else {}

    def inspect(clip):
        found = probe(clip.path)
        if not found.ok or not found.video:
            return clip, found, None
        key = repr(_source(clip.path))
        known = cache.get(key)
        if known is not None:
            return clip, found, known.get("usable")
        usable = _usable_end(clip.path, found, clip.media.fps if clip.media and clip.media.fps > 0 else 0.0,
                             clip.media.duration if clip.media and clip.media.duration > 0 else 0.0)
        cache[key] = {"usable": usable, "checked": _now()}
        return clip, found, usable

    with ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(inspect, clips.values()))
    if manifest is not None:
        manifest.save()
    bad = ["clip {} ({}): {}".format(c.number, c.path.name, p.error or "no picture")
           for c, p, _ in results if not p.ok or not p.video]
    if bad:
        raise ExportError("{} source clip(s) cannot be read, so nothing was encoded: {}. Replace or reject "
                          "them and export again.".format(len(bad), "; ".join(bad[:10])))
    usable = {str(c.path): u for c, _, u in results if u}
    for c, _, u in results:
        if u:
            log.info("Clip %d (%s) stops at %.3f s; its header says %.3f s", c.number, c.path.name, u,
                     c.media.duration if c.media else 0.0)
    return usable


TAIL_SECONDS = 2.0        # how much of a source's end is decoded to find where its picture really stops


def _usable_end(path: Path, found: Probe, src_fps: float, stated: float = 0.0) -> Optional[float]:
    """Where a source's picture really ends, or None when it reaches
    `stated` -- the length the plan trusts (the clip's header length, the
    longer of its tracks). Only the last TAIL_SECONDS of picture are
    decoded, so a folder of 500 clips costs seconds, not minutes. None
    also when ffprobe cannot say: the plan then trusts the header and the
    cut's own frame check catches a shortfall."""
    stated = stated or found.seconds or found.video_seconds
    if stated <= 0:
        return None
    ffprobe = find_tool("ffprobe")
    if not ffprobe:
        return None
    picture = found.video_seconds or stated
    result = run([ffprobe, "-v", "error", "-select_streams", "v:0",
                  "-read_intervals", "{:.3f}%".format(max(0.0, min(stated, picture) - TAIL_SECONDS)),
                  "-show_entries", "frame=pts_time", "-of", "csv=p=0", str(path)], timeout=60)
    if result.returncode != 0 or not result.stdout:
        return None
    pts: List[float] = []
    for line in result.stdout.decode("utf-8", "replace").splitlines():
        token = line.strip().strip(",")
        try:
            pts.append(float(token))
        except ValueError:
            continue
    if not pts:
        return None
    pts.sort()
    last = pts[-1]
    if src_fps > 0:
        frame = 1.0 / src_fps
    elif len(pts) >= 2 and pts[-1] - pts[-2] > 0:
        frame = pts[-1] - pts[-2]                    # the clip's own spacing
    else:
        frame = 1.0 / 24.0                           # the same guess the cut planner makes
    end = last + frame
    if end >= stated - 0.5 * frame - 0.001:
        return None
    return end


def _remove_stale(folder: Path, segments: List[Segment], pieces: List[Piece], manifest: Manifest) -> None:
    """Files and manifest entries from an earlier plan that this one will
    never use."""
    wanted_pieces = {p.key for p in pieces}
    wanted_segments = {s.fingerprint for s in segments}
    for key in [k for k in manifest.data["pieces"] if k not in wanted_pieces]:
        del manifest.data["pieces"][key]
    for key in [k for k in manifest.data["segments"] if k not in wanted_segments]:
        del manifest.data["segments"][key]
    for path in (folder / "pieces").glob("*"):
        if path.stem not in wanted_pieces:
            path.unlink(missing_ok=True)
    wanted = {"seg_{}".format(s.fingerprint) for s in segments}
    for path in folder.glob("seg_*"):
        if path.stem not in wanted:
            path.unlink(missing_ok=True)


def _make_segment(segment: Segment, count: int, jobs, dissolves, config: Config, fps: float,
                  size: Tuple[int, int], folder: Path, manifest: Manifest, report: Reporter, stall: float,
                  burn_srt: Optional[Path], cut_segment, render_dissolve, workers, offset: float,
                  keep: Optional[Path] = None, captions=None, measured=None,
                  cancel: Optional[threading.Event] = None, deferred: Optional[dict] = None,
                  tries: int = 3, length_tries: int = 2) -> dict:
    """Cut the segment's pieces, encode it, check it. With `deferred` (a
    dict to fill) the check is left to the caller: the entry comes back
    "encoded" with what the check needs in `deferred`, so export() can run
    it beside the next segment's encode -- the check is a CPU decode, the
    encode is on the hardware, and the two do not compete."""
    title = "Segment {} of {}".format(segment.number, count)
    entry = {"number": segment.number, "status": "working", "started": _now(), "attempts": 0,
             "expected": round(segment.expected, 3), "pieces": [p.key for p in segment.pieces],
             "video": "seg_{}.ts".format(segment.fingerprint), "audio": "seg_{}.wav".format(segment.fingerprint)}
    manifest.data["segments"][segment.fingerprint] = entry
    manifest.save()

    # -- cut its pieces ------------------------------------------------------
    _check_cancel(cancel)
    if _free_gb(folder) < NEED_GB:
        entry.update(status="failed", error="disk full")
        manifest.save()
        raise ExportError("Not enough space on the drive of {} to make {}: {:.1f} GB is free and each "
                          "segment needs about {} GB while it is made. Free some space and export again; "
                          "the finished segments are kept.".format(folder.parent.parent, title.lower(),
                                                                    _free_gb(folder), NEED_GB))
    paths: Dict[str, Tuple[Path, float]] = {}
    todo = []
    rescues: List[str] = []

    def remember(piece: Piece, note: str) -> None:
        if note.startswith("rescued: "):
            rescues.append("clip {}: {}".format(piece.clip, note[len("rescued: "):]))

    frames_of: Dict[str, int] = {}
    for piece in segment.pieces:
        path = folder / "pieces" / (piece.key + ".mov")
        known = manifest.piece(piece)
        if known and path.is_file() and path.stat().st_size > 0:
            frames_of[piece.key] = int(known.get("frames") or round(known["seconds"] * fps))
            paths[piece.key] = (path, frames_of[piece.key] / fps)
            remember(piece, str(known.get("note", "")))
        else:
            todo.append(piece)

    from .assemble import cut_note

    def make(piece: Piece):
        """Cut one piece and check it against the plan: exactly its frames
        of picture, exactly that much sound. A piece short of picture (the
        source has less than its header says) is cut again to its real
        end, or repaired; its new length is recorded as the plan for it."""
        path = folder / "pieces" / (piece.key + ".mov")
        if piece.kind == "cut":
            ok = cut_segment(jobs[piece.index], path, config, fps, frames=piece.frames)
        else:
            d = dissolves[piece.index]
            ok = render_dissolve(jobs[d.before], jobs[d.after], d.seconds, path, config, fps)
        note = cut_note(path)
        if piece.short > 0.05 and not note:
            note = "rescued: cut to where the file really ends; the file ends {:.2f} s early".format(piece.short)
        if not ok:
            # ffmpeg's own last line rides along, so the editor reads the
            # reason instead of "could not be encoded" thirteen times.
            return piece, path, Probe(False, error="could not be encoded" + (" ({})".format(note) if note else "")), note, 0
        found = probe(path)
        got = found.video_frames if found.ok else 0
        if found.ok and got and got < piece.frames and piece.kind == "cut" and not note.startswith("rescued"):
            # Fewer frames than planned: the source ran out before the
            # planned end after all. Cut again to its real end, or repair.
            ok = cut_segment(jobs[piece.index], path, config, fps, frames=piece.frames, got=got / fps)
            note = cut_note(path)
            found = probe(path) if ok else Probe(False, error="has {} frames, not {} ({})".format(
                got, piece.frames, note or "no repair was possible"))
            got = found.video_frames if found.ok else 0
        if found.ok:
            made_frames = got or int(round(found.video_seconds * fps)) or int(round(found.seconds * fps))
            if made_frames != piece.frames and not (note.startswith("rescued") and made_frames < piece.frames):
                found = Probe(False, error="has {} frames, not {}".format(made_frames, piece.frames))
            else:
                want_samples = int(round(made_frames / fps * 48000))
                if found.audio_samples and abs(found.audio_samples - want_samples) > PIECE_SOUND_SLACK:
                    found = Probe(False, error="its sound is {} samples, not {} ({} frames)".format(
                        found.audio_samples, want_samples, made_frames))
            return piece, path, found, note, made_frames
        return piece, path, found, note, 0

    made = len(segment.pieces) - len(todo)
    failed: List[str] = []
    with ThreadPoolExecutor(max_workers=workers()) as pool:
        for piece, path, found, note, made_frames in pool.map(make, todo):
            made += 1
            if found.ok:
                frames_of[piece.key] = made_frames
                paths[piece.key] = (path, made_frames / fps)
                manifest.data["pieces"][piece.key] = {"fingerprint": piece.fingerprint,
                                                      "seconds": round(made_frames / fps, 4),
                                                      "frames": made_frames}
                if note.startswith("rescued: "):
                    manifest.data["pieces"][piece.key]["note"] = note
                remember(piece, note)
            elif piece.kind == "cut":
                failed.append("clip {} ({}): {}".format(piece.clip, piece.name, found.error))
            else:
                # A blend that cannot be made becomes a plain cut: the two
                # bodies are already short by the blend, so the picture skips
                # rather than the export stopping.
                log.warning("Blend into clip %d could not be made (%s); a cut is used", piece.clip, found.error)
            report(report.segment_fraction(segment, 0.3 * made / len(segment.pieces)), title,
                   "preparing clips {} of {}".format(made, len(segment.pieces)))
    manifest.save()
    _check_cancel(cancel)
    if failed:
        entry.update(status="failed", error="; ".join(failed[:5]))
        manifest.note("{} failed: {}".format(title, entry["error"]))
        manifest.save()
        if _free_gb(folder) < 0.5:
            raise ExportError("The drive of {} filled up while {} was being made. Free some space and "
                              "export again; the finished segments are kept.".format(folder.parent.parent,
                                                                                   title.lower()))
        raise ExportError("{} could not be made because {} could not be cut: {}. Replace or reject the "
                          "clip and export again to the same file; the finished segments are kept.".format(
                              title, "a clip" if len(failed) == 1 else "{} clips".format(len(failed)),
                              "; ".join(failed[:5])))
    present = [(paths[p.key], p) for p in segment.pieces if p.key in paths]
    total_frames = sum(frames_of[p.key] for _, p in present)
    seconds = total_frames / fps
    clips: Dict[str, float] = {}
    joins: List[float] = []
    at = 0.0
    for (_, s), piece in present:
        if at > 0:
            joins.append(at)
        clips[str(piece.clip)] = clips.get(str(piece.clip), 0.0) + s
        at += s
    listing = _listing(folder / "seg_{}.txt".format(segment.fingerprint), [path for (path, _), _ in present])

    # -- encode, check, retry ------------------------------------------------
    if burn_srt is not None and captions is not None:
        so_far = dict(measured or {})
        for key, length in clips.items():
            so_far[int(key)] = so_far.get(int(key), 0.0) + length
        captions(so_far, burn_srt)
    video, audio = folder / entry["video"], folder / entry["audio"]
    last_error = ""
    for attempt in range(1, max(1, tries) + 1):
        _check_cancel(cancel)
        entry["attempts"] = attempt
        name = encoders.describe(config.video_encoder)
        entry["encoder"] = name
        manifest.save()
        done = _encode_segment(listing, video, audio, config, size, seconds, offset, burn_srt, stall, cancel,
                               lambda p: report(report.segment_fraction(segment, 0.3 + 0.6 * p.seconds / max(0.1, seconds)),
                                                title, "encoding {}% on {}{}{}".format(
                                                    min(99, int(100 * p.seconds / max(0.1, seconds))), name,
                                                    ", {:.1f}x".format(p.speed) if p.speed else "",
                                                    " (try {})".format(attempt) if attempt > 1 else "")),
                               frames=total_frames)
        if done.returncode == CANCELLED:
            _check_cancel(cancel)
        problem = _why(done) if done.returncode != 0 else ""
        findings: List[str] = []
        if not problem and deferred is not None:
            entry.update(status="encoded", seconds=round(seconds, 4), frames=total_frames, clips=clips,
                         rescues=rescues)
            manifest.save()
            deferred.update(video=video, audio=audio, seconds=seconds, joins=joins, listing=listing,
                            pieces=[path for (path, _), _ in present], title=title, frames=total_frames,
                            present=present, frames_of=frames_of)
            return entry
        if not problem:
            report(report.segment_fraction(segment, 0.9), title, "checking")
            problem, findings = _check_segment(video, audio, seconds, size, joins, config, stall, cancel,
                                               lambda p: report(report.segment_fraction(
                                                   segment, 0.9 + 0.1 * p.seconds / max(0.1, seconds)),
                                                   title, "checking {}%".format(
                                                       min(99, int(100 * p.seconds / max(0.1, seconds))))),
                                               frames=total_frames)
        if not problem:
            entry.update(status="done", seconds=round(seconds, 4), frames=total_frames, clips=clips,
                         findings=findings, rescues=rescues,
                         finished=_now(), video_bytes=video.stat().st_size, audio_bytes=audio.stat().st_size)
            manifest.note("{} done on {} ({})".format(title, name, _clock(seconds)))
            manifest.save()
            if keep is None:
                for (path, _), _ in present:
                    path.unlink(missing_ok=True)      # its pieces are in the segment now
            listing.unlink(missing_ok=True)
            return entry
        last_error = problem
        video.unlink(missing_ok=True)
        audio.unlink(missing_ok=True)
        entry["error"] = problem
        manifest.note("{} try {} on {} failed: {}".format(title, attempt, name, problem))
        manifest.save()
        log.warning("%s try %d on %s failed: %s", title, attempt, name, problem)
        if _is_length_problem(problem):
            # The same pieces give the same segment every time: encoding it
            # a third time cannot help. Count the pieces on disk against
            # the plan first; a piece that is off is the cause and is
            # named; pieces that all agree point at the encoder, which
            # gets one more try (on the CPU when the hardware made it).
            off = _pieces_off_plan(present, frames_of, fps)
            if off:
                last_error = "{}: {}".format(problem, "; ".join(off[:5]))
                break
            if attempt >= length_tries:
                break
        if encoders.hardware_active(config.video_encoder) and not _not_the_encoder(problem):
            encoders.demote("{}: {}".format(title, problem))
            report(report.segment_fraction(segment, 0.3), title,
                   "the {} encoder stopped responding - retrying this segment on the CPU".format(name)
                   if "stopped responding" in problem else
                   "the {} encoder failed - retrying this segment on the CPU".format(name))
    entry.update(status="failed", error=last_error)
    manifest.save()
    raise ExportError("{} could not be encoded after {} {} ({}). Export again to the same file to "
                      "continue; the finished segments are kept.".format(
                          title, entry["attempts"], "try" if entry["attempts"] == 1 else "tries", last_error))


def _is_length_problem(problem: str) -> bool:
    text = problem.lower()
    return " frames, not " in text or " samples, not " in text or (" s, not " in text and "segment" in text)


def _pieces_off_plan(present, frames_of: Dict[str, int], fps: float) -> List[str]:
    """The pieces whose file no longer holds the frames (and the sound)
    the plan recorded for them -- the real cause of a segment that does
    not add up -- in words."""
    off = []
    for (path, _), piece in present:
        found = probe(path)
        want = frames_of.get(piece.key, 0)
        if not found.ok:
            off.append("clip {} piece cannot be read ({})".format(piece.clip, found.error))
        elif found.video_frames and want and found.video_frames != want:
            off.append("clip {} piece has {} frames, not {}".format(piece.clip, found.video_frames, want))
        elif found.audio_samples and want and abs(found.audio_samples - int(round(want / fps * 48000))) > PIECE_SOUND_SLACK:
            off.append("clip {} piece sound is {} samples, not {}".format(
                piece.clip, found.audio_samples, int(round(want / fps * 48000))))
    return off


def _encode_segment(listing: Path, video: Path, audio: Path, config: Config, size: Tuple[int, int],
                    seconds: float, offset: float, burn_srt: Optional[Path], stall: float,
                    cancel: Optional[threading.Event], on_progress, frames: int = 0):
    """One process: the segment's pieces in, its video (delivery quality,
    MPEG-TS) and its sound (PCM) out."""
    ffmpeg = require("ffmpeg")
    width, height = size
    filters = ["scale={}:{}:flags=lanczos".format(width, height)]
    cwd = None
    if burn_srt is not None:
        # The caption file is timed for the whole episode; lay the segment on
        # its place in the episode for the burn, then back to zero.
        style = ("FontName={},FontSize={},PrimaryColour=&H00FFFFFF,OutlineColour=&H90000000,BorderStyle=3,"
                 "Outline=1,Shadow=0,MarginV=28".format(config.caption_font, config.caption_font_size))
        filters += ["setpts=PTS+{:.6f}/TB".format(offset),
                    "subtitles={}:force_style='{}'".format(burn_srt.name, style),
                    "setpts=PTS-STARTPTS"]
        cwd = str(burn_srt.parent)              # the work folder; the name is captions.srt
    args = [ffmpeg, "-nostdin", "-loglevel", "error", "-y",
            "-f", "concat", "-safe", "0", "-i", str(listing),
            "-map", "0:v:0", "-vf", ",".join(filters + ["format=yuv420p"])] + \
        encoders.video_args(config.video_encoder, "delivery", config.delivery_crf, config.delivery_preset) + \
        ["-fps_mode", "cfr"] + (["-frames:v", str(frames)] if frames else []) + \
        ["-an", "-f", "mpegts", str(video),
         # The sound follows its timestamps: a clip kept whole loses 0.5 ms of
         # sound to the cut's seek margin (its start cannot move earlier), and
         # a few hundred of those put the sound a third of a second ahead of
         # the picture by the end of an hour (measured: 0.29 s over 66 min).
         # The resampler fills each such gap with silence where it belongs
         # (hard compensation from 0.1 ms; the default 1 sample/s would never
         # catch up), and the pad/trim make the segment's sound exactly as
         # long as its picture, so picture and sound stay locked.
         "-map", "0:a:0", "-vn",
         "-af", "aresample=async=1:min_hard_comp=0.0001:min_comp=0.0001:first_pts=0,"
                "apad=whole_dur={0:.6f},atrim=end={0:.6f}".format(seconds),
         "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", str(audio)]
    return run_with_progress(args, on_progress, stall, None, cwd, cancel=cancel)


def _conform(segments, ordered: List[dict], folder: Path, config: Config, size: Tuple[int, int],
             report: Reporter, stall: float, manifest: Manifest, result: Result,
             cancel: Optional[threading.Event] = None) -> List[str]:
    """A file made by two encoders plays in ffmpeg and on YouTube, but the
    mp4 carries the first segment's parameter sets and some hardware
    players trust only those. So when the hardware encoder was set aside
    part way, the segments made by the encoder in the minority are encoded
    again from their own video with the other one -- the fewest segments,
    once, and only when it happened."""
    from collections import Counter
    used = Counter(e.get("encoder", "") for e in ordered)
    if len(used) <= 1:
        return []
    target = used.most_common(1)[0][0]
    if target != CPU_NAME:
        # Most segments came from the hardware: give it one more chance for
        # the few CPU ones; if its probe fails now, everything it made is
        # redone on the CPU instead.
        encoders.reset()
        if encoders.describe(config.video_encoder) != target:
            target = CPU_NAME
    if target == CPU_NAME and encoders.hardware_active(config.video_encoder):
        encoders.demote("matching the file to the CPU segments")     # video_args must follow the target
    notes = []
    while True:
        todo = [(s, e) for s, e in zip(segments, ordered) if e.get("encoder") != target]
        if not todo:
            break
        failed = False                       # noqa: F841 - kept for the loop's shape
        for segment, entry in todo:
            _check_cancel(cancel)
            title = "Matching segment {} of {} to the {} encoder".format(segment.number, len(segments), target)
            video = folder / entry["video"]
            again = video.with_name(video.stem + ".re.ts")
            ffmpeg = require("ffmpeg")
            done = run_with_progress(
                [ffmpeg, "-nostdin", "-loglevel", "error", "-y", "-i", str(video), "-map", "0:v:0",
                 "-vf", "format=yuv420p"]
                + encoders.video_args(config.video_encoder, "delivery", config.delivery_crf, config.delivery_preset)
                + ["-an", "-f", "mpegts", str(again)],
                lambda p: report(0.955, title, "{}%".format(min(99, int(100 * p.seconds / max(0.1, entry["seconds"]))))),
                stall, None, None, cancel=cancel)
            if done.returncode == CANCELLED:
                again.unlink(missing_ok=True)
                _check_cancel(cancel)
            if done.returncode == CANCELLED:
                again.unlink(missing_ok=True)
                _check_cancel()
            problem = _why(done) if done.returncode != 0 else ""
            if not problem:
                problem, _ = _check_segment(again, folder / entry["audio"], entry["seconds"], size, [],
                                            config, stall, cancel, lambda p: None)
            if problem:
                again.unlink(missing_ok=True)
                log.warning("%s failed: %s", title, problem)
                if encoders.hardware_active(config.video_encoder) and not _not_the_encoder(problem):
                    # The hardware failed its second chance. Redoing every segment
                    # it made on the CPU could cost hours; the file is left as two
                    # encoders (every ffmpeg-based player and YouTube read it; the
                    # level and profile match) and the edit log says so.
                    encoders.demote(title + ": " + problem)
                    notes.append("segments were made by two encoders ({}); the {} encoder failed again while "
                                 "matching them, so the file was left as it is".format(
                                     ", ".join(sorted(used)), target))
                    log.warning("%s failed again; the file keeps two encoders", target)
                    return notes
                raise ExportError("{} failed ({}). Export again to the same file to try again; the finished "
                                  "segments are kept.".format(title, problem))
            os.replace(again, video)
            entry.update(encoder=target, video_bytes=video.stat().st_size, matched=_now())
            manifest.note(title.lower())
            manifest.save()
            notes.append("segment {} encoded again on {} so the file has one encoder".format(segment.number, target))
        if not failed:
            break
    result.encoders = [target]
    return notes


def _check_segment(video: Path, audio: Path, seconds: float, size: Tuple[int, int], joins: List[float],
                   config: Config, stall: float, cancel: Optional[threading.Event],
                   on_progress, frames: int = 0) -> Tuple[str, List[str]]:
    """Probe the segment, then decode every frame of it. A decode error is
    a damaged segment; the same pass looks for black or frozen frames at
    its joins (the seam check)."""
    found = probe(video)
    # A frame and a half: a segment whose sound and picture differ by more
    # than that is wrong, however long it is (0.2 % of five minutes would
    # have let 0.6 s pass -- and did hide a 21 ms shortfall per segment).
    tolerance = SEGMENT_TOLERANCE
    if not found.ok:
        return "the segment cannot be read ({})".format(found.error), []
    if found.video != "h264" or (found.width, found.height) != tuple(size):
        return "the segment is {} {}x{}".format(found.video, found.width, found.height), []
    if not frames and abs(found.seconds - seconds) > tolerance:
        return "the segment is {:.2f} s, not {:.2f} s".format(found.seconds, seconds), []
    sound = probe(audio)
    if not sound.ok:
        return "the segment's sound cannot be read ({})".format(sound.error), []
    if frames and sound.audio_samples:
        want = int(round(seconds * 48000))
        if abs(sound.audio_samples - want) > 2:
            return "the segment's sound is {} samples, not {}".format(sound.audio_samples, want), []
    elif abs(sound.seconds - seconds) > tolerance:
        return "the segment's sound is {:.2f} s, not {:.2f} s".format(sound.seconds, seconds), []
    ffmpeg = require("ffmpeg")
    graph = "scale=160:90:flags=area"
    if config.seam_check:
        graph += ",blackdetect=d=0.08:pix_th=0.04,freezedetect=n=0.002:d=0.4"
    done = run_with_progress([ffmpeg, "-nostdin", "-xerror", "-i", str(video), "-an", "-vf", graph,
                              "-f", "null", "-"], on_progress, stall, cancel=cancel)
    if done.returncode == CANCELLED:
        _check_cancel(cancel)
    if done.returncode != 0:
        return "the segment does not decode ({})".format(_why(done)), []
    decoded = int(getattr(done, "frames", 0) or 0)
    if frames and decoded and decoded != frames:
        # Every frame of the segment was decoded just now: the count is
        # the segment, not a header's opinion of it.
        return "the segment has {} frames, not {}".format(decoded, frames), []
    return "", _seam_findings(done.stderr.decode("utf-8", "replace"), joins) if config.seam_check else []


def _seam_findings(text: str, joins: List[float], window: float = 0.5) -> List[str]:
    import re
    findings = []

    def near(at: float) -> Optional[float]:
        for join in joins:
            if abs(join - at) <= window:
                return join
        return None
    for m in re.finditer(r"black_start:([\d.]+) black_end:([\d.]+)", text):
        start, end = float(m.group(1)), float(m.group(2))
        join = near(start) or near(end)
        if join is not None:
            findings.append("black frames {:.2f}-{:.2f} s at the join at {:.2f} s".format(start, end, join))
    for m in re.finditer(r"freeze_start: ([\d.]+)", text):
        join = near(float(m.group(1)))
        if join is not None:
            findings.append("frozen frames from {:.2f} s at the join at {:.2f} s".format(float(m.group(1)), join))
    return findings
