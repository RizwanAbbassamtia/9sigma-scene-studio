"""Seal a secret to the signed-in Windows account.

One helper over the Windows Data Protection API (DPAPI), used for every
secret the app keeps on disk: API keys, the mail password, and a remembered
sign-in password. A sealed value can be opened only by the same Windows
user on the same machine; a copy of the file elsewhere is noise. Nothing
here is ever logged.

On a platform without DPAPI `available()` is False and callers must not
store the secret at all -- there is no fallback that would be honest to
call sealed.
"""
from __future__ import annotations

import base64
import ctypes
import sys

from .product import PRODUCT

# Per product, so 9 Sigma Automation and 9 Sigma Omni Flow cannot open each
# other's sealed keys even under the same Windows account.
_ENTROPY = PRODUCT.seal_entropy


def available() -> bool:
    return sys.platform.startswith("win")


if available():
    import ctypes.wintypes

    class _Blob(ctypes.Structure):
        _fields_ = [("cbData", ctypes.wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    def _dpapi(data: bytes, protect: bool) -> bytes:
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        inp = _Blob(len(data), ctypes.cast(ctypes.create_string_buffer(data, len(data)),
                                           ctypes.POINTER(ctypes.c_char)))
        out = _Blob()
        entropy = _Blob(len(_ENTROPY), ctypes.cast(ctypes.create_string_buffer(_ENTROPY),
                                                   ctypes.POINTER(ctypes.c_char)))
        call = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
        if not call(ctypes.byref(inp), None, ctypes.byref(entropy), None, None, 0, ctypes.byref(out)):
            raise OSError("Windows could not {} the secret".format("seal" if protect else "open"))
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            kernel32.LocalFree(out.pbData)
else:
    def _dpapi(data: bytes, protect: bool) -> bytes:   # pragma: no cover - not Windows
        raise OSError("sealing needs Windows DPAPI")


def seal(text: str) -> str:
    """Text -> base64 of the sealed bytes. Raises OSError when it cannot."""
    return base64.b64encode(_dpapi(text.encode("utf-8"), True)).decode("ascii")


def unseal(sealed: str) -> str:
    """The reverse. Returns "" for anything that will not open, never raises."""
    if not sealed:
        return ""
    try:
        return _dpapi(base64.b64decode(sealed), False).decode("utf-8")
    except (OSError, ValueError):
        return ""
