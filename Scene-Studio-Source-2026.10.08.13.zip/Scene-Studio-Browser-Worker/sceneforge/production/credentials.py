"""API keys, kept where only this Windows account can read them.

Each key is sealed with the Windows Data Protection API (DPAPI) before it is
written, which ties it to the signed-in user: another account, or a copy of
the file on another machine, cannot open it. No password to remember, no
new dependency, nothing in plain text on disk, nothing ever logged.

Keys are asked for only when the chosen starting point needs that provider:
editing existing clips needs none of them.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, Optional

from ..product import PRODUCT
from ..seal import seal, unseal

# The API keys, the ones the API keys screen lists.
API_KEYS = ("openai", "anthropic", "omniflash")
# "gemini" is the Google Gemini key Omni Flow generates clips with. It is
# sealed exactly like the others but has its own dialog (gui/gemini_keys.py)
# rather than a row on the API keys screen, whose labels are per key.
GEMINI = "gemini"
# "smtp" is not an API key but the mail password the master-log worker
# sends notifications with; it is sealed exactly like the keys, and shown
# nowhere: the Email settings screen says only whether one is saved.
PROVIDERS = API_KEYS + (GEMINI, "smtp")
_STORE = PRODUCT.data_dir / "credentials.json"


class Credentials:
    def __init__(self, store: Optional[Path] = None):
        self.store = Path(store) if store else _STORE

    def _read(self) -> Dict[str, str]:
        try:
            return json.loads(self.store.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _write(self, data: Dict[str, str]) -> None:
        self.store.parent.mkdir(parents=True, exist_ok=True)
        self.store.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def set(self, provider: str, key: str) -> None:
        if provider not in PROVIDERS:
            raise KeyError(provider)
        data = self._read()
        data[provider] = seal(key.strip())
        self._write(data)

    def get(self, provider: str) -> str:
        sealed = self._read().get(provider, "")
        if not sealed:
            return ""
        return unseal(sealed)

    def has(self, provider: str) -> bool:
        return bool(self.get(provider))

    def delete(self, provider: str) -> None:
        data = self._read()
        data.pop(provider, None)
        self._write(data)

    @staticmethod
    def masked(key: str) -> str:
        """For the settings screen: enough to recognise, never enough to use."""
        if len(key) < 8:
            return "•" * len(key)
        return key[:4] + "…" + key[-4:]
