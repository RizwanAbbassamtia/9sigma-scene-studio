"""Multi-episode automation: several productions submitted together, run
one after another by one scheduler, each with its own folders, manifest,
checkpoints and log.

A batch is a folder holding `batch.json` (the rows and their status) and
one sub-folder per row where that row's production lives. Every row is an
ordinary production -- the same manifest, the same Runner, the same stage
engine as a single production -- so nothing here is a second pipeline; the
batch only decides which row runs next and writes what happened.

Rows are run ONE AT A TIME (the owner's choice: the laptops that run this
have one GPU and one Omni Flash key), oldest first within a priority, and
a row waiting for a person's approval does not hold the others up: the
scheduler moves on and comes back when the row is approved. A row that
fails is left failed with its reason; the rest carry on. A stop finishes
the current step and puts the running row back in the queue.

Sources are named, never guessed: a row says whether it holds a title, a
script, scene-prompt text, a folder of video clips, or a folder with an
edited composition in it, and only the fields for that source are read.
"""
from __future__ import annotations

import csv
import json
import os
import re
import tempfile
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional, Set

from ..config import Config
from ..logging_setup import get
from . import stages
from .credentials import Credentials
from .frameworks import Frameworks
from .manifest import (
    ASPECT_RATIOS, EditingMode, ErrorPolicy, Production, RESOLUTIONS, ReviewMode, SOURCE_START, SOURCE_TYPES,
    Stage, Status, stage_index, stages_between,
)
from .runner import Providers, Runner, Stopped
from .setup import make_providers, seed_production

log = get("production.batch")

BATCH_FILE = "batch.json"
STATUS_SHEET = "batch-status.csv"      # a read-only mirror of every row, for Excel
STATUS_COLUMNS = ["episode", "title", "source_type", "source_path", "range", "status", "stage", "progress",
                  "output", "error", "updated"]
SHEET_REFRESH_SECONDS = 5.0            # how often a running row's stage/progress reach the sheet
QUEUED, VALIDATING, RUNNING, WAITING, PAUSED, COMPLETED, FAILED, CANCELLED, BLOCKED = (
    "queued", "validating", "running", "waiting_approval", "paused", "completed", "failed", "cancelled", "blocked")
STATUS_WORDS = {QUEUED: "Queued", VALIDATING: "Validating", RUNNING: "Running", WAITING: "Waiting for approval",
                PAUSED: "Paused", COMPLETED: "Completed", FAILED: "Failed", CANCELLED: "Cancelled",
                BLOCKED: "Blocked (fix the row)"}
SOURCE_WORDS = {"title": "Title only (write the script)", "script": "Script text", "prompts": "Scene-prompt text",
                "script_prompts": "Script and scene-prompt text", "clips": "Video clips (folder)",
                "composition": "Edited composition (folder)"}
ROW_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$")


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@dataclass
class BatchRow:
    """One episode. Empty settings fall back to the batch defaults."""
    id: str = ""
    episode: str = ""                # as typed; unique within the batch only
    project: str = ""
    production_name: str = ""
    title: str = ""
    source_type: str = "clips"       # one of SOURCE_TYPES
    brief: str = ""                  # synopsis / notes for a title start
    script_path: str = ""
    prompts_path: str = ""
    clips_folder: str = ""
    timeline_path: str = ""          # the folder holding the edited composition
    start_stage: str = ""            # "" = decided by the source type
    end_stage: str = ""
    editing_mode: str = ""
    aspect_ratio: str = ""
    resolution: int = 0
    working_dir: str = ""
    output_dir: str = ""
    final_filename: str = ""
    generation_limit: int = -1       # -1 = the batch default
    priority: int = 5                # 1 runs first
    status: str = QUEUED
    stage: str = ""
    progress: str = ""
    error: str = ""
    export_path: str = ""
    production_dir: str = ""
    attempts: int = 0
    created: str = field(default_factory=now)
    updated: str = ""
    history: List[str] = field(default_factory=list)

    def note(self, text: str) -> None:
        self.updated = now()
        self.history.append("{}  {}".format(self.updated, text))
        del self.history[:-60]

    @property
    def label(self) -> str:
        return self.title or self.episode or self.id


@dataclass
class Batch:
    id: str
    name: str
    folder: str
    mock: bool = False
    defaults: Dict[str, object] = field(default_factory=dict)
    rows: List[BatchRow] = field(default_factory=list)
    created: str = field(default_factory=now)
    updated: str = ""
    max_generations: int = 200       # clips across the whole batch, per Start
    format_version: int = 1

    # ---------------------------------------------------------- lifecycle
    @classmethod
    def new(cls, name: str, folder: Path, mock: bool = False, **defaults) -> "Batch":
        batch = cls(id=uuid.uuid4().hex[:10], name=name.strip() or "Batch", folder=str(folder), mock=mock)
        batch.defaults = {"start_stage": "", "end_stage": Stage.EXPORT.value, "editing_mode": EditingMode.AUTOMATIC.value,
                          "aspect_ratio": "auto", "resolution": 1080, "output_dir": "", "final_filename": "",
                          "generation_limit": 0, "language": "Urdu", "target_minutes": 20.0,
                          "error_policy": ErrorPolicy.SKIP.value, "script_framework": "", "prompt_framework": ""}
        batch.defaults.update(defaults)
        return batch

    @property
    def path(self) -> Path:
        return Path(self.folder) / BATCH_FILE

    def row(self, row_id: str) -> BatchRow:
        for row in self.rows:
            if row.id == row_id:
                return row
        raise KeyError(row_id)

    def add(self, row: BatchRow) -> BatchRow:
        if not row.id or not ROW_ID.match(row.id) or any(r.id == row.id for r in self.rows):
            row.id = self._fresh_id(row)
        self.rows.append(row)
        return row

    def _fresh_id(self, row: BatchRow) -> str:
        stem = re.sub(r"[^A-Za-z0-9]+", "-", (row.episode or row.title or "row")).strip("-")[:20] or "row"
        candidate = stem
        n = 1
        while any(r.id == candidate for r in self.rows):
            n += 1
            candidate = "{}-{}".format(stem, n)
        return candidate

    def save(self) -> Path:
        self.updated = now()
        path = self.path
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(asdict(self), indent=2, ensure_ascii=False)
        fd, tmp = tempfile.mkstemp(prefix=".batch-", suffix=".json", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        self.write_status_sheet()
        return path

    @property
    def status_sheet(self) -> Path:
        return Path(self.folder) / STATUS_SHEET

    def write_status_sheet(self) -> None:
        """The sheet the editors keep open: one row per episode with its
        folder, status, stage, output and error. Written by the app after
        every change; UTF-8 with a BOM so Excel shows Urdu. Never read back.

        While Excel has the file open Windows refuses the replace, so the
        write is skipped -- no waiting, no retry -- and the next change
        writes it again; Excel would not show the new contents until the
        file is reopened anyway."""
        rows = []
        for row in self.rows:
            spec = resolve(self, row)
            rows.append({"episode": row.episode, "title": row.title, "source_type": spec["source_type"],
                         "source_path": spec["source_path"], "range": "{} → {}".format(
                             spec["start_stage"], spec["end_stage"]),
                         "status": STATUS_WORDS.get(row.status, row.status), "stage": row.stage,
                         "progress": row.progress, "output": row.export_path, "error": row.error,
                         "updated": row.updated})
        tmp = ""
        try:
            fd, tmp = tempfile.mkstemp(prefix=".status-", suffix=".csv", dir=str(Path(self.folder)))
            with os.fdopen(fd, "w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=STATUS_COLUMNS)
                writer.writeheader()
                writer.writerows(rows)
            os.replace(tmp, self.status_sheet)
            tmp = ""
        except PermissionError:
            log.info("%s is open elsewhere (Excel?); it will be written again on the next change", STATUS_SHEET)
        except Exception as exc:                            # noqa: BLE001 - a mirror must never break a run
            log.warning("%s could not be written: %s", STATUS_SHEET, exc)
        finally:
            if tmp and os.path.exists(tmp):
                try:
                    os.unlink(tmp)
                except OSError:
                    pass

    def _key(self, row: "BatchRow") -> str:
        """What makes a row the same episode as another: its source path
        when it has one; otherwise (a title row, or a row whose path cell
        is still blank) its source type, episode and title."""
        source = resolve(self, row)["source_path"]
        if source:
            return "path:" + os.path.normcase(os.path.abspath(source)).rstrip("\\/")
        return "text:{}|{}|{}".format(row.source_type, row.episode.strip().lower(), row.title.strip().lower())

    def has_source(self, path: str) -> bool:
        """True when a row already points at this folder or file."""
        if not path:
            return False
        wanted = "path:" + os.path.normcase(os.path.abspath(path)).rstrip("\\/")
        return any(self._key(row) == wanted for row in self.rows)

    def add_new(self, rows: List["BatchRow"]) -> tuple:
        """Add the rows whose source is not already in the batch. Returns
        (added, skipped): a sheet re-imported after new folders were typed
        into it only adds those folders."""
        added, skipped = [], []
        keys = {self._key(row) for row in self.rows}
        for row in rows:
            key = self._key(row)
            if key in keys:
                skipped.append(row)
                continue
            self.add(row)
            keys.add(key)
            added.append(row)
        return added, skipped

    @classmethod
    def load(cls, folder: Path) -> "Batch":
        raw = json.loads((Path(folder) / BATCH_FILE).read_text(encoding="utf-8"))
        known = {f.name for f in fields(cls)}
        rows = [BatchRow(**{k: v for k, v in r.items() if k in {f.name for f in fields(BatchRow)}})
                for r in raw.pop("rows", [])]
        batch = cls(**{k: v for k, v in raw.items() if k in known})
        batch.rows = rows
        batch.folder = str(folder)
        # A row that was running when the app died is back in the queue:
        # its production resumes from its checkpoints.
        for row in batch.rows:
            if row.status in (RUNNING, VALIDATING):
                row.status = QUEUED
                row.note("found running at load; queued again to resume from its checkpoints")
        return batch

    def counts(self) -> Dict[str, int]:
        out = {status: 0 for status in STATUS_WORDS}
        for row in self.rows:
            out[row.status] = out.get(row.status, 0) + 1
        return out


# --------------------------------------------------------------- resolve
def resolve(batch: Batch, row: BatchRow) -> Dict[str, object]:
    """The row's settings with the batch defaults filled in: what the
    production will actually be made from."""
    d = batch.defaults
    source = row.source_type if row.source_type in SOURCE_TYPES else "clips"
    start = row.start_stage or str(d.get("start_stage") or "") or SOURCE_START[source].value
    try:
        Stage(start)
    except ValueError:
        start = SOURCE_START[source].value
    end = row.end_stage or str(d.get("end_stage") or Stage.EXPORT.value)
    try:
        Stage(end)
    except ValueError:
        end = Stage.EXPORT.value
    if stage_index(end) < stage_index(start):
        end = start
    limit = row.generation_limit if row.generation_limit >= 0 else int(d.get("generation_limit") or 0)
    spec = {
        "source_type": source, "start_stage": start, "end_stage": end,
        "editing_mode": row.editing_mode or str(d.get("editing_mode") or EditingMode.AUTOMATIC.value),
        "aspect_ratio": row.aspect_ratio or str(d.get("aspect_ratio") or "auto"),
        "resolution": int(row.resolution or d.get("resolution") or 1080),
        "output_dir": row.output_dir or str(d.get("output_dir") or ""),
        "final_filename": row.final_filename or str(d.get("final_filename") or ""),
        "working_dir": row.working_dir or str(Path(batch.folder) / row.id),
        "generation_limit": limit,
        "language": str(d.get("language") or "Urdu"), "target_minutes": float(d.get("target_minutes") or 20.0),
        "error_policy": str(d.get("error_policy") or ErrorPolicy.SKIP.value),
        "script_framework": str(d.get("script_framework") or ""),
        "prompt_framework": str(d.get("prompt_framework") or ""),
        "title": row.title or row.episode or row.id,
        "name": row.production_name or row.project or row.title or row.id,
    }
    if spec["editing_mode"] not in {m.value for m in EditingMode}:
        spec["editing_mode"] = EditingMode.AUTOMATIC.value
    if spec["aspect_ratio"] not in ASPECT_RATIOS:
        spec["aspect_ratio"] = "auto"
    if spec["resolution"] not in RESOLUTIONS:
        spec["resolution"] = 1080
    if not spec["output_dir"]:
        spec["output_dir"] = spec["working_dir"]
    spec["source_path"] = {"clips": row.clips_folder, "composition": row.timeline_path or row.clips_folder,
                           "script": row.script_path, "prompts": row.prompts_path,
                           "script_prompts": row.prompts_path, "title": ""}[source]
    return spec


def validate_row(batch: Batch, row: BatchRow, credentials: Optional[Credentials] = None) -> List[str]:
    """What stops this row from running, in words. Empty means ready."""
    spec = resolve(batch, row)
    problems: List[str] = []
    source = spec["source_type"]
    path = spec["source_path"]
    if source in ("clips", "composition"):
        report = stages.clip_folder_report(path)
        problems += report["problems"]
        if not report["problems"] and source == "composition" and not report["composition"]:
            problems.append("no edited composition is saved beside those clips ({}); start from Editing instead".format(path))
    elif source in ("script", "prompts", "script_prompts"):
        if not path or not Path(path).is_file():
            problems.append("the {} file was not found: {}".format("script" if source == "script" else "scene-prompt", path or "(empty)"))
        elif source in ("prompts", "script_prompts"):
            from . import prompts as prompt_text
            try:
                items, found = prompt_text.parse_report(Path(path).read_text(encoding="utf-8", errors="replace"))
            except OSError as exc:
                items, found = [], ["could not be read: {}".format(exc)]
            if not items:
                problems.append("no numbered scene prompts in {}".format(path))
            problems += [p for p in found if "numbered" in p or "appears" in p or "no numbered" in p]
        if source == "script_prompts" and row.script_path and not Path(row.script_path).is_file():
            problems.append("the script file was not found: {}".format(row.script_path))
    elif source == "title":
        if not spec["title"].strip():
            problems.append("a title is needed to write a script from")
        if not batch.mock and not spec["script_framework"]:
            problems.append("no scriptwriting framework in the batch defaults")
    if source in ("title", "script") and not batch.mock and not spec["prompt_framework"]:
        problems.append("no scene-prompt framework in the batch defaults")
    if credentials is not None and not batch.mock:
        for stage in stages_between(spec["start_stage"], spec["end_stage"]):
            key = stages.STAGE_KEYS.get(stage)
            if key and not credentials.has(key):
                problems.append("the {} key is not set (Automate ▾ → API keys)".format(
                    {"openai": "OpenAI", "anthropic": "Anthropic", "omniflash": "Omni Flash"}[key]))
    if Stage.CLIPS in stages_between(spec["start_stage"], spec["end_stage"]) and not batch.mock \
            and int(spec["generation_limit"]) <= 0:
        problems.append("a generation limit is required for live clip generation")
    for label, folder in (("working folder", spec["working_dir"]), ("output folder", spec["output_dir"])):
        problem = stages._writable(folder)
        if problem:
            problems.append("{}: {}".format(label, problem))
    return problems


def validate_all(batch: Batch, credentials: Optional[Credentials] = None) -> Dict[str, List[str]]:
    """Every row's problems, plus the ones only visible across rows: the
    same source used twice, and two rows that would write the same file."""
    out: Dict[str, List[str]] = {}
    sources: Dict[str, str] = {}
    outputs: Dict[str, str] = {}
    for row in batch.rows:
        spec = resolve(batch, row)
        if row.status in (COMPLETED, CANCELLED):
            # Not checked again, but its source and output are still taken:
            # a new row pointing at the same folder is the same episode twice.
            if spec["source_path"] and row.status == COMPLETED:
                sources.setdefault(os.path.normcase(os.path.abspath(spec["source_path"])), row.id)
            continue
        problems = validate_row(batch, row, credentials)
        source = os.path.normcase(os.path.abspath(spec["source_path"])) if spec["source_path"] else ""
        if source:
            if source in sources:
                problems.append("the same source as row {} ({}); a folder is one episode".format(sources[source], spec["source_path"]))
            else:
                sources[source] = row.id
        stem = (spec["final_filename"] or spec["name"]).strip().lower()
        key = os.path.normcase(os.path.abspath(spec["output_dir"])) + "|" + stem
        if key in outputs:
            problems.append("would export the same file name as row {} into {}; give it a final filename".format(
                outputs[key], spec["output_dir"]))
        else:
            outputs[key] = row.id
        if problems:
            out[row.id] = problems
    return out


# ------------------------------------------------------------ productions
def production_for(batch: Batch, row: BatchRow, frameworks: Optional[Frameworks] = None) -> Production:
    """The row's production: loaded if it already exists (a resume), else
    created and seeded from the row's source. Saved either way."""
    spec = resolve(batch, row)
    working = Path(spec["working_dir"])
    if row.production_dir and (Path(row.production_dir) / "production.json").is_file():
        production = Production.load(Path(row.production_dir))
        production.batch_id = batch.id
        return production
    production = Production.new(
        spec["title"], spec["name"], working, episodes=1,
        language=spec["language"], target_minutes=spec["target_minutes"],
        synopsis=row.brief, clips_dir=str(working / "clips"), export_dir=spec["output_dir"],
        review_mode=ReviewMode.AUTOMATIC.value, error_policy=spec["error_policy"],
        start_stage=spec["start_stage"], end_stage=spec["end_stage"], source_type=spec["source_type"],
        editing_mode=spec["editing_mode"], aspect_ratio=spec["aspect_ratio"], resolution=spec["resolution"],
        final_filename=spec["final_filename"], batch_id=batch.id,
        generation_settings={"mock": batch.mock, "max_generations": int(spec["generation_limit"])},
        editing_settings={"output_height": spec["resolution"], "aspect_ratio": spec["aspect_ratio"]})
    if frameworks is not None:
        if spec["script_framework"]:
            ref = frameworks.latest(spec["script_framework"])
            if ref:
                production.script_framework = ref
        if spec["prompt_framework"]:
            ref = frameworks.latest(spec["prompt_framework"])
            if ref:
                production.prompt_framework = ref
    episode = production.episode(1)
    source = spec["source_type"]
    if source in ("clips", "composition"):
        seed_production(production, episode, source, Path(spec["source_path"]))
    elif source == "script_prompts":
        script_text = Path(row.script_path).read_text(encoding="utf-8", errors="replace") if row.script_path else ""
        seed_production(production, episode, source, script_text=script_text,
                        prompts_text=Path(spec["source_path"]).read_text(encoding="utf-8", errors="replace"))
    elif source in ("script", "prompts"):
        seed_production(production, episode, source, Path(spec["source_path"]))
    stages.prepare_range(production, episode, spec["start_stage"], spec["end_stage"])
    production.save()
    row.production_dir = str(working)
    return production


# ------------------------------------------------------------- gathering
def rows_from_folders(folders: List[Path], source_type: str = "clips") -> List[BatchRow]:
    """One row per chosen folder, in natural order, named after the folder."""
    rows = []
    for folder in sorted((Path(f) for f in folders), key=lambda p: stages.natural_key(p.name)):
        rows.append(BatchRow(episode=folder.name, title=folder.name, source_type=source_type,
                             clips_folder=str(folder), timeline_path=str(folder) if source_type == "composition" else ""))
    return rows


def rows_from_parent(parent: Path, source_type: str = "clips") -> List[BatchRow]:
    """One row per sub-folder that holds video files; other folders are
    left out rather than guessed at."""
    parent = Path(parent)
    if not parent.is_dir():
        return []
    folders = [p for p in parent.iterdir() if p.is_dir() and stages.video_files(p)]
    return rows_from_folders(folders, source_type)


# --------------------------------------------------------------- the sheet
CSV_COLUMNS = ["episode", "title", "project", "production_name", "source_type", "brief", "script_path",
               "prompts_path", "clips_folder", "timeline_path", "start_stage", "end_stage", "editing_mode",
               "aspect_ratio", "resolution", "output_dir", "final_filename", "generation_limit", "priority"]
CSV_HINT = ("# source_type: title | script | prompts | script_prompts | clips | composition. "
            "Leave a setting blank to use the batch default. start_stage/end_stage: script | prompts | clips | "
            "edit | export. editing_mode: automatic | review | manual. aspect_ratio: auto | 16:9 | 9:16. "
            "resolution: 720 | 1080.")
SAMPLE_ROWS = [
    {"episode": "001", "title": "Episode 1", "source_type": "clips", "clips_folder": r"D:\Productions\Ep001\clips"},
    {"episode": "002", "title": "Episode 2", "source_type": "composition", "timeline_path": r"D:\Productions\Ep002\clips",
     "start_stage": "export"},
    {"episode": "003", "title": "Episode 3", "source_type": "prompts", "prompts_path": r"D:\Productions\Ep003\prompts.txt",
     "generation_limit": "160"},
    {"episode": "004", "title": "Episode 4", "source_type": "script", "script_path": r"D:\Productions\Ep004\script.txt"},
    {"episode": "005", "title": "A title the tool writes the script for", "source_type": "title",
     "brief": "Synopsis and notes for the script writer", "end_stage": "prompts"},
]


def write_template(path: Path) -> Path:
    path = Path(path)
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        handle.write(CSV_HINT + "\n")
        writer = csv.DictWriter(handle, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        for row in SAMPLE_ROWS:
            writer.writerow({k: row.get(k, "") for k in CSV_COLUMNS})
    return path


def import_sheet(path: Path) -> tuple:
    """(rows, problems) from a CSV or Excel sheet. Excel needs openpyxl,
    which the runtime carries; CSV needs nothing."""
    path = Path(path)
    records: List[Dict[str, str]] = []
    problems: List[str] = []
    if path.suffix.lower() in (".xlsx", ".xlsm"):
        try:
            import openpyxl
        except ImportError:
            return [], ["Excel files need openpyxl; save the sheet as CSV UTF-8 instead"]
        book = openpyxl.load_workbook(path, read_only=True, data_only=True)
        sheet = book.active
        header = None
        for values in sheet.iter_rows(values_only=True):
            cells = ["" if v is None else str(v).strip() for v in values]
            if header is None:
                if any(c.lower() in CSV_COLUMNS for c in cells):
                    header = [c.lower() for c in cells]
                continue
            if not any(cells):
                continue
            records.append({header[i]: cells[i] for i in range(min(len(header), len(cells))) if header[i]})
    else:
        with open(path, "r", encoding="utf-8-sig", newline="") as handle:
            lines = [line for line in handle if not line.startswith("#")]
        reader = csv.DictReader(lines)
        header = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
        if "status" in header and "updated" in header and "source_path" in header:
            return [], ["{} is the status mirror the app writes, not a batch sheet; import the sheet you "
                        "typed the folders into (Save sheet template… gives its layout)".format(path.name)]
        for raw in reader:
            record = {(k or "").strip().lower(): (v or "").strip() for k, v in raw.items()}
            if any(record.values()):
                records.append(record)
    rows: List[BatchRow] = []
    for index, record in enumerate(records, start=1):
        row = BatchRow()
        for key in CSV_COLUMNS:
            value = record.get(key, "")
            if key in ("resolution", "generation_limit", "priority"):
                if value:
                    try:
                        setattr(row, key, int(float(value)))
                    except ValueError:
                        problems.append("row {}: {} is not a number ({})".format(index, key, value))
            else:
                setattr(row, key, value)
        if row.source_type not in SOURCE_TYPES:
            problems.append("row {}: source_type must be one of {} (got {!r})".format(index, ", ".join(SOURCE_TYPES), row.source_type))
            continue
        rows.append(row)
    return rows, problems


# ---------------------------------------------------------------- events
@dataclass
class BatchEvent:
    row_id: str
    status: str
    message: str
    done: int = 0
    total: int = 0


class _CountingGenerator:
    """Wraps the clip generator so the batch can stop at its own budget,
    whatever any one row's limit says."""

    def __init__(self, inner, budget: int, used: List[int]):
        self._inner, self._budget, self._used = inner, budget, used

    def submit(self, prompt, settings):
        if self._budget and self._used[0] >= self._budget:
            from .providers import ProviderError
            raise ProviderError("The batch's generation budget ({}) is spent.".format(self._budget), retryable=False, fatal=True)
        job = self._inner.submit(prompt, settings)
        self._used[0] += 1
        return job

    def __getattr__(self, name):
        return getattr(self._inner, name)


class BatchRunner:
    """Runs a batch's rows one after another on the calling thread."""

    def __init__(self, batch: Batch, credentials: Optional[Credentials], frameworks: Frameworks, config: Config,
                 on_event: Callable[[BatchEvent], None] = lambda e: None,
                 stop: Optional[threading.Event] = None, pause: Optional[threading.Event] = None,
                 providers: Optional[Providers] = None):
        self.batch = batch
        self.credentials = credentials
        self.frameworks = frameworks
        self.config = config
        self.on_event = on_event
        self.stop = stop or threading.Event()
        self.pause = pause or threading.Event()
        self._providers = providers
        self._used = [0]
        self._sheet_at = 0.0
        self.current: Optional[str] = None

    # -------------------------------------------------------------- queue
    def next_row(self, only: Optional[Set[str]] = None) -> Optional[BatchRow]:
        candidates = [r for r in self.batch.rows if r.status == QUEUED and (only is None or r.id in only)]
        if not candidates:
            return None
        order = {r.id: i for i, r in enumerate(self.batch.rows)}
        candidates.sort(key=lambda r: (r.priority, order[r.id]))
        return candidates[0]

    def run(self, only: Optional[Set[str]] = None) -> Dict[str, int]:
        """Work through the queue. Returns the counts at the end."""
        started = 0
        while not self.stop.is_set():
            if self.pause.is_set():
                self._emit("", PAUSED, "paused: no new episode is started until Resume")
                break
            row = self.next_row(only)
            if row is None:
                break
            started += 1
            self._run_row(row)
        counts = self.batch.counts()
        done, failed = counts.get(COMPLETED, 0), counts.get(FAILED, 0)
        waiting = counts.get(WAITING, 0)
        self._emit("", "summary", "{} completed, {} failed, {} waiting for approval, {} queued".format(
            done, failed, waiting, counts.get(QUEUED, 0)))
        return counts

    def _run_row(self, row: BatchRow) -> None:
        self.current = row.id
        row.attempts += 1
        self._set(row, VALIDATING, "checking the inputs")
        problems = validate_row(self.batch, row, self.credentials)
        if problems:
            self._set(row, BLOCKED, "; ".join(problems), error="; ".join(problems))
            return
        try:
            production = production_for(self.batch, row, self.frameworks)
        except Exception as exc:                            # noqa: BLE001 - the row fails, the batch goes on
            log.exception("Row %s could not be set up", row.id)
            self._set(row, FAILED, "could not be set up: {}".format(exc), error=str(exc))
            return
        spec = resolve(self.batch, row)
        providers = self._providers or make_providers(self.credentials, self.config, self.batch.mock)
        if providers.clip_generator is not None:
            providers = Providers(providers.script_writer, providers.prompt_writer,
                                  _CountingGenerator(providers.clip_generator, self.batch.max_generations, self._used))
        episode = production.episode(1)

        def on_event(event):
            row.stage = event.stage
            # The export reports in thousandths of the job (export_job.Reporter).
            row.progress = ("{}% ".format(event.done // 10) if event.total == 1000 else
                            "{}/{} ".format(event.done, event.total) if event.total else "")
            row.progress += event.message[:80]
            now_mono = time.monotonic()
            if now_mono - self._sheet_at >= SHEET_REFRESH_SECONDS:
                self._sheet_at = now_mono
                self.batch.write_status_sheet()           # the sheet only; batch.json waits for a status change
            self._emit(row.id, RUNNING, "{}: {}".format(stages.STAGE_NAMES.get(Stage(event.stage), event.stage),
                                                       event.message), event.done, event.total)
        runner = Runner(production, providers, self.frameworks, self.config, on_event=on_event, stop=self.stop,
                        max_generations=int(spec["generation_limit"]))
        self._set(row, RUNNING, "started at {}".format(stages.STAGE_NAMES[Stage(spec["start_stage"])]))
        try:
            stopped_at = runner.run(1, until=Stage(spec["end_stage"]))
        except Stopped:
            self._set(row, QUEUED, "stopped by the user; resumes from its checkpoints")
            return
        except Exception as exc:                            # noqa: BLE001
            log.exception("Row %s crashed", row.id)
            self._set(row, FAILED, "crashed: {}".format(exc), error=str(exc))
            return
        if self.stop.is_set() and stopped_at is not None:
            state = episode.stage(stopped_at)
            if state.status == Status.FAILED.value and "Stopped" in state.error:
                self._set(row, QUEUED, "stopped by the user; resumes from its checkpoints")
                return
        if stopped_at is None or episode.next_stage() is None or \
                stage_index(stopped_at) > stage_index(spec["end_stage"]):
            row.export_path = episode.exports[-1].path if episode.exports else ""
            self._set(row, COMPLETED, "finished: {}".format(Path(row.export_path).name if row.export_path else
                                                          stages.STAGE_NAMES[Stage(spec["end_stage"])] + " done"))
            return
        state = episode.stage(stopped_at)
        if state.status == Status.NEEDS_REVIEW.value:
            self._set(row, WAITING, "{} needs approval: {}".format(stages.STAGE_NAMES[stopped_at], state.next_action))
        elif state.status == Status.FAILED.value:
            self._set(row, FAILED, "{} failed: {}".format(stages.STAGE_NAMES[stopped_at], state.error), error=state.error)
        else:
            self._set(row, FAILED, "{} stopped ({})".format(stages.STAGE_NAMES[stopped_at], state.status),
                      error=state.next_action or state.status)

    # ------------------------------------------------------------ control
    def approve(self, row_id: str, by: str) -> bool:
        """Approve the stage a row is waiting on and put it back in the
        queue. Only the one row; never everything."""
        row = self.batch.row(row_id)
        if row.status != WAITING or not row.production_dir:
            return False
        production = Production.load(Path(row.production_dir))
        episode = production.episode(1)
        waiting = episode.waiting_for_person()
        if waiting is None:
            self._set(row, QUEUED, "nothing was waiting; queued again")
            return True
        Runner(production, Providers(), self.frameworks, self.config).approve(1, waiting, by)
        self._set(row, QUEUED, "{} approved by {}; queued to continue".format(stages.STAGE_NAMES[waiting], by))
        return True

    def retry(self, row_id: str) -> bool:
        row = self.batch.row(row_id)
        if row.status not in (FAILED, BLOCKED, CANCELLED):
            return False
        row.error = ""
        self._set(row, QUEUED, "queued again by hand; clips already made are reused")
        return True

    def cancel(self, row_id: str) -> bool:
        row = self.batch.row(row_id)
        if row.status not in (QUEUED, PAUSED, BLOCKED, WAITING):
            return False
        self._set(row, CANCELLED, "cancelled by hand")
        return True

    def pause_row(self, row_id: str) -> bool:
        row = self.batch.row(row_id)
        if row.status != QUEUED:
            return False
        self._set(row, PAUSED, "paused by hand")
        return True

    def resume_row(self, row_id: str) -> bool:
        row = self.batch.row(row_id)
        if row.status != PAUSED:
            return False
        self._set(row, QUEUED, "resumed by hand")
        return True

    def set_priority(self, row_id: str, priority: int) -> None:
        row = self.batch.row(row_id)
        row.priority = max(1, min(9, int(priority)))
        row.note("priority {}".format(row.priority))
        self.batch.save()

    # ------------------------------------------------------------ helpers
    def _set(self, row: BatchRow, status: str, message: str, error: str = "") -> None:
        row.status = status
        row.error = error if status in (FAILED, BLOCKED) else ""
        if status not in (RUNNING, VALIDATING):
            row.progress = ""
        row.note("{}: {}".format(STATUS_WORDS.get(status, status), message))
        try:
            self.batch.save()
        except OSError as exc:
            log.warning("batch.json could not be saved: %s", exc)
        self._emit(row.id, status, message)

    def _emit(self, row_id: str, status: str, message: str, done: int = 0, total: int = 0) -> None:
        log.info("batch %s row %s %s: %s", self.batch.id, row_id or "-", status, message)
        self.on_event(BatchEvent(row_id, status, message, done, total))
