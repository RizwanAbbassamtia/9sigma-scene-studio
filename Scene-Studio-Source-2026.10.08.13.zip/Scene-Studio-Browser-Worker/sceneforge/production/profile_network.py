"""Bounded connection checks using only a profile's configured network route."""
import time
from .profile_proxy import ProfileProxies

CHECK_URL = 'https://myaccount.google.com/'


def network_error_message(error):
    """Return fixed messages: proxy URLs, passwords and request headers stay private."""
    text = str(error).lower()
    if '407' in text or 'invalid_auth_credentials' in text or 'proxy authentication' in text:
        return 'The proxy rejected its saved username or password. Re-enter the proxy credentials and test again.'
    if 'certificate' in text or 'cert_' in text or 'ssl' in text:
        return 'The connection failed certificate verification. Check the proxy or network; HTTPS verification remains enabled.'
    if any(value in text for value in ('timeout', 'timed out', 'etimedout')):
        return 'Google did not respond through this profile connection in time. Check the proxy server, port and internet connection.'
    if any(value in text for value in ('proxy_connection', 'tunnel_connection', 'econnrefused', 'econnreset', 'enotfound', 'name_not_resolved')):
        return 'This profile connection could not reach Google. Check the proxy type, server, port and credentials.'
    return 'Google could not be reached through this profile connection. Check its proxy settings and internet connection.'


def check_profile_connection(root, profile):
    """No Google login, generation request, saved browser cookies or direct fallback."""
    from playwright.sync_api import sync_playwright
    started = time.monotonic()
    try:
        proxy = ProfileProxies(root).launch_options(profile)
    except ValueError:
        return {'ok': False, 'message': 'The saved proxy could not be opened. Re-save its password under the Windows login running the desktop app.', 'seconds': 0}
    try:
        with sync_playwright() as runtime:
            request = runtime.request.new_context(timeout=15000, ignore_https_errors=False,
                                                  **({'proxy': proxy} if proxy else {}))
            try:
                response = request.get(CHECK_URL, max_redirects=5)
                status = response.status
                if status == 407:
                    message = network_error_message('407')
                elif status in (200, 204):
                    message = 'Google is reachable through the saved profile connection. You can now try Sign in to Google.'
                else:
                    message = f'Google returned HTTP {status} through this connection. Check the proxy or try again later.'
                return {'ok': status in (200, 204), 'message': message,
                        'http_status': status, 'seconds': round(time.monotonic() - started, 1)}
            finally:
                request.dispose()
    except Exception as exc:
        return {'ok': False, 'message': network_error_message(exc),
                'seconds': round(time.monotonic() - started, 1)}
