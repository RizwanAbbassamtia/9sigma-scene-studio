"""Resolve app-owned saved profiles; identity labels are candidates, not live proof.

Chrome retains its own session data. This module reads only email labels and never
copies a profile or reads cookies, passwords, or authentication tokens.
"""
import json
import re
from pathlib import Path


def saved_folder(root, profile):
    if not isinstance(profile, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', profile):
        raise ValueError('Invalid saved profile')
    base = Path(root).resolve() / 'manual-browser-profiles'
    if base.resolve() != base:
        raise ValueError('Saved profile storage must remain inside the app data folder')
    folder = base / profile
    if folder.resolve() != folder or not (folder / 'Default').is_dir():
        raise ValueError('Saved Chrome profile was not found in the app data folder')
    return folder


def saved_emails(root, profile):
    try:
        folder = saved_folder(root, profile)
        for relative in ('Default/Preferences', 'Local State'):
            path = folder / relative
            if path.resolve() != path:
                continue
            try:
                with path.open('rb') as stream:
                    raw = stream.read(2 * 1024 * 1024 + 1)
                if len(raw) > 2 * 1024 * 1024:
                    continue
                data = json.loads(raw)
                if relative == 'Default/Preferences':
                    values = [row.get('email') for row in data.get('account_info', []) if isinstance(row, dict)]
                else:
                    values = [data.get('profile', {}).get('info_cache', {}).get('Default', {}).get('user_name')]
                emails = sorted({v.strip().casefold() for v in values if isinstance(v, str)
                                 and len(v) <= 254 and re.fullmatch(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}', v.strip())})
                if emails:
                    return emails
            except (OSError, ValueError, TypeError, AttributeError):
                continue
    except (OSError, ValueError):
        pass
    return []


def generation_account(root, account, connections):
    """Use the saved email as the expected identity, rechecked in Google's UI."""
    if any(c.get('state') == 'manual' for c in connections.values()):
        profile = account.get('managed_profile', account['id'])
        emails = saved_emails(root, profile)
        if len(emails) != 1:
            raise ValueError(f"{account['id']}: one saved Google email is required for generation preflight")
        return {**account, 'email': emails[0], 'profile_storage': 'saved', 'google_slot': 0}
    if not any(c.get('state') == 'connected' for c in connections.values()):
        raise ValueError(f"{account['id']}: no saved generation session is available")
    return account
