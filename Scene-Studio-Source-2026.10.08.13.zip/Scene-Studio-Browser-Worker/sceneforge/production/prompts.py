"""Scene prompts as text, and as items the pipeline can generate from.

The prompt writer produces the same numbered format the editor has always
read from an episode folder -- one scene per line, `N: <full prompt>`,
with `says:` dialogue inside it -- so the file it writes is also the script
the editor pairs clips with. Parsing reuses the editor's own parser; nothing
is reinterpreted, and the prompt text is carried whole.

A prompt may also run over several lines: the numbered line starts it and
every line up to the next number belongs to it. `N.M:` names clip M of
scene N when a scene is deliberately split; a bare number repeated is an
ambiguity that is reported, never silently merged or overwritten.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Tuple

from ..script_parser import parse_script
from .manifest import PromptItem

# `1: text`, `1. text`, `1.2: text` (scene 1, clip 2). A dot followed by a
# digit and no separator (`1.5 seconds`) is prose, not a header.
_HEADER = re.compile(r"^\s*(\d{1,4})(?:\.(\d{1,2}))?\s*(?::|\.(?!\d))\s*(.*?)\s*$")
_NUMBERED = _HEADER                        # the old name, for anything that imported it
MAX_PROMPT_CHARS = 4000                    # Omni Flash: 1 to 4000 characters


def parse_text(text: str, max_clip_seconds: float = 0.0) -> List[PromptItem]:
    """Numbered prompt blocks -> PromptItems in the order written.

    `max_clip_seconds` is the provider's clip length limit; it is recorded on
    the item as a setting, not used to split scenes -- splitting a scene into
    several clips is a decision for the prompt framework, not for a parser.
    """
    return parse_report(text, max_clip_seconds)[0]


def parse_report(text: str, max_clip_seconds: float = 0.0) -> Tuple[List[PromptItem], List[str]]:
    """The items, and what is wrong with the numbering, in plain words."""
    items: List[PromptItem] = []
    lines_of: Dict[int, int] = {}                     # index in items -> line number
    current = None
    for number, line in enumerate(text.replace("\r\n", "\n").split("\n"), start=1):
        match = _HEADER.match(line)
        if match:
            scene = int(match.group(1))
            clip = int(match.group(2)) if match.group(2) else 0      # 0: not stated
            current = PromptItem(scene=scene, clip=clip, sequence=len(items) + 1, prompt=match.group(3))
            if max_clip_seconds:
                current.settings["max_seconds"] = max_clip_seconds
            lines_of[len(items)] = number
            items.append(current)
        elif current is not None and line.strip():
            current.prompt = (current.prompt + "\n" + line.strip()) if current.prompt else line.strip()
    problems = _number_clips(items, lines_of)
    for item in items:
        item.dialogue = _dialogue_of(item.prompt)
    problems += validate_items(items)
    return items, problems


def _number_clips(items: List[PromptItem], lines_of: Dict[int, int]) -> List[str]:
    """Bare numbers become clip 1; a bare number used twice is ambiguous
    (a split scene, or a mistake?) and is said so, while both are kept as
    clip 1, 2, ... so neither overwrites the other."""
    problems: List[str] = []
    bare: Dict[int, List[int]] = {}
    for index, item in enumerate(items):
        if item.clip == 0:
            bare.setdefault(item.scene, []).append(index)
    for scene, indexes in bare.items():
        if len(indexes) > 1:
            problems.append("scene {} is numbered {} times (lines {}); number split scenes {}.1, {}.2 …".format(
                scene, len(indexes), ", ".join(str(lines_of[i]) for i in indexes), scene, scene))
        for clip, index in enumerate(indexes, start=1):
            items[index].clip = clip
    return problems


def validate_items(items: List[PromptItem]) -> List[str]:
    """What would stop these prompts being generated: no numbers, gaps,
    duplicate scene/clip numbers, empty or over-long prompts."""
    problems: List[str] = []
    if not items:
        return ["no numbered prompts were found (each prompt starts with its number, like `1: …`)"]
    seen: Dict[str, int] = {}
    for item in items:
        if item.key in seen:
            problems.append("scene {} clip {} appears more than once".format(item.scene, item.clip))
        seen[item.key] = item.sequence
    scenes = sorted({i.scene for i in items})
    if scenes[0] != 1:
        problems.append("numbering starts at {}, not 1".format(scenes[0]))
    gaps = [n for n in range(scenes[0], scenes[-1]) if n not in scenes]
    if gaps:
        problems.append("missing scene numbers: {}".format(", ".join(str(g) for g in gaps[:20])))
    empty = [i.scene for i in items if not i.prompt.strip()]
    if empty:
        problems.append("empty prompts for scenes: {}".format(", ".join(str(s) for s in empty[:20])))
    long = [i.scene for i in items if len(i.prompt.strip()) > MAX_PROMPT_CHARS]
    if long:
        problems.append("over {} characters for scenes: {}".format(MAX_PROMPT_CHARS, ", ".join(str(s) for s in long[:20])))
    return problems


def _dialogue_of(body: str) -> str:
    """The spoken lines inside a prompt, as the editor's parser reads them."""
    if not body.strip():
        return ""
    scenes = parse_script_text("1: " + body.replace("\n", " "))
    if not scenes:
        return ""
    scene = scenes[1] if 1 in scenes else next(iter(scenes.values()))
    return " / ".join("{}: {}".format(d.speaker, d.text) for d in scene.dialogue)


def parse_script_text(text: str):
    """parse_script works on a path; give it text through a temp file so the
    one parser stays the one parser."""
    import tempfile
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as handle:
        handle.write(text)
        path = Path(handle.name)
    try:
        return parse_script(path)
    finally:
        try:
            path.unlink()
        except OSError:
            pass


def parse_file(path: Path) -> List[PromptItem]:
    return parse_text(Path(path).read_text(encoding="utf-8", errors="replace"))


def write_for_editor(items: List[PromptItem], path: Path) -> Path:
    """The prompt set as the numbered script the editor reads, numbered by
    play order so each clip file's leading number finds its line. One line
    per clip: the editor's format has no continuation lines."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["{}: {}".format(item.sequence, " ".join(item.prompt.split()))
             for item in sorted(items, key=lambda i: i.sequence)]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def clip_filename(item: PromptItem) -> str:
    """Leading number is the play order, which the editor takes as the clip
    number; the rest says which scene and clip it is for people."""
    return "{:03d}_scene{}_clip{}.mp4".format(item.sequence, item.scene, item.clip)


def take_filename(item: PromptItem, take: int) -> str:
    """Where an earlier take of a clip is kept, out of the editor's way."""
    return "{:03d}_scene{}_clip{}_take{}.mp4".format(item.sequence, item.scene, item.clip, take)
