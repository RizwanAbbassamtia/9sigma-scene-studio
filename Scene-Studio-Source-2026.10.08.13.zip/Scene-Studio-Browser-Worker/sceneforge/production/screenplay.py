"""Read a screenplay the way the script-writing framework produces it.

Built on the real episode script the user supplied (samples/), not on a
guess. That script looks like this:

    Characters (Kirdar):
    - Ahsan: Ghareeb magar khuddar ...

    Complete Script:

    SCENE 1 – INT. SALMA KA BUNGALOW, DINING HALL – SUBAH
    DURATION: 0:00 - 2:35

    BEGUM SALMA
    Ahsan! Kitni dair ...

    AHSAN
    Ji ammi ...

Everything is kept in the language it was written in. Nothing is rewritten,
dropped or summarised: the parser only finds the boundaries so that later
stages can check every scene was carried through, and so the editor's
existing per-scene machinery has something to pair clips with.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

_SCENE = re.compile(r"^\s*SCENE\s+(\d+)\s*[–—\-:.]*\s*(.*?)\s*$", re.IGNORECASE)
_DURATION = re.compile(r"^\s*DURATION\s*:\s*(\d+:\d{2})\s*-\s*(\d+:\d{2})", re.IGNORECASE)
_CHAR_LINE = re.compile(r"^\s*-\s*([^:]+):\s*(.+?)\s*$")
_SPEAKER = re.compile(r"^[A-Z][A-Z .'\-]{1,40}(\s*\(.*\))?$")


@dataclass
class Line:
    speaker: str
    text: str


@dataclass
class ScriptScene:
    number: int
    heading: str
    start: str = ""
    end: str = ""
    lines: List[Line] = field(default_factory=list)
    action: List[str] = field(default_factory=list)

    @property
    def speakers(self) -> List[str]:
        seen: List[str] = []
        for line in self.lines:
            if line.speaker not in seen:
                seen.append(line.speaker)
        return seen

    @property
    def dialogue_text(self) -> str:
        return "\n".join("{}: {}".format(l.speaker, l.text) for l in self.lines)

    @property
    def seconds(self) -> float:
        return max(0.0, _seconds(self.end) - _seconds(self.start)) if self.start and self.end else 0.0


@dataclass
class Screenplay:
    characters: Dict[str, str] = field(default_factory=dict)
    scenes: List[ScriptScene] = field(default_factory=list)
    preamble: List[str] = field(default_factory=list)

    @property
    def words(self) -> int:
        return sum(len(l.text.split()) for s in self.scenes for l in s.lines) + \
            sum(len(a.split()) for s in self.scenes for a in s.action)

    def scene(self, number: int) -> Optional[ScriptScene]:
        return next((s for s in self.scenes if s.number == number), None)


def _seconds(stamp: str) -> float:
    try:
        minutes, seconds = stamp.split(":")
        return int(minutes) * 60 + int(seconds)
    except ValueError:
        return 0.0


def parse(text: str) -> Screenplay:
    play = Screenplay()
    current: Optional[ScriptScene] = None
    speaker: Optional[str] = None
    in_characters = False

    for raw in text.splitlines():
        line = raw.rstrip()
        stripped = line.strip()

        if not stripped:
            speaker = None
            continue

        match = _SCENE.match(stripped)
        if match:
            current = ScriptScene(number=int(match.group(1)), heading=match.group(2))
            play.scenes.append(current)
            speaker = None
            in_characters = False
            continue

        if current is None:
            if stripped.lower().startswith("characters"):
                in_characters = True
                continue
            if in_characters:
                match = _CHAR_LINE.match(stripped)
                if match:
                    play.characters[match.group(1).strip()] = match.group(2).strip()
                    continue
            play.preamble.append(stripped)
            continue

        match = _DURATION.match(stripped)
        if match:
            current.start, current.end = match.group(1), match.group(2)
            continue

        if _SPEAKER.match(stripped) and speaker is None:
            speaker = re.sub(r"\s*\(.*\)$", "", stripped).strip()
            continue

        if speaker is not None:
            current.lines.append(Line(speaker=speaker, text=stripped))
        else:
            current.action.append(stripped)

    return play


def validate(play: Screenplay, required_sections=("scenes", "characters")) -> List[str]:
    """What is wrong with a script, in plain words. Empty means nothing."""
    problems: List[str] = []
    if "characters" in required_sections and not play.characters:
        problems.append("No character list was found.")
    if not play.scenes:
        problems.append("No scenes were found (expected headings like 'SCENE 1 - ...').")
        return problems
    numbers = [s.number for s in play.scenes]
    expected = list(range(1, len(numbers) + 1))
    if numbers != expected:
        problems.append("Scene numbers are not 1..{} in order: {}".format(len(numbers), numbers[:20]))
    for scene in play.scenes:
        if not scene.lines and not scene.action:
            problems.append("Scene {} is empty.".format(scene.number))
    last = play.scenes[-1]
    if last.lines and len(last.lines[-1].text) > 40 and not last.lines[-1].text.rstrip().endswith(
            (".", "!", "?", "।", "۔", "\"", "”", "'")):
        problems.append("The script may be cut off: scene {} ends mid-sentence.".format(last.number))
    return problems


def coverage(play: Screenplay, prompt_scenes: List[int]) -> Dict[str, List[int]]:
    """Which script scenes the prompt set covers, misses, duplicates, or
    invents. Every list is scene numbers."""
    have = set(s.number for s in play.scenes)
    got = list(prompt_scenes)
    seen = set()
    duplicates = sorted({n for n in got if n in seen or seen.add(n)})
    return {
        "missing": sorted(have - set(got)),
        "extra": sorted(set(got) - have),
        "duplicated": duplicates,
        "out_of_order": [n for i, n in enumerate(got[1:], 1) if n < got[i - 1]],
    }
