"""Google's Gemini API as a clip generator, on a billed API key: the one
programmatic route Google documents for video. No Google account is signed
in, no browser is driven, no Flow credits are spent -- every clip is
billed per generated second to the Google Cloud account behind the key.

Two shapes, chosen by the model id:

  Veo (veo-3.1-generate-preview, -fast-, -lite-): a long-running operation
    submit    POST {base}/models/{model}:predictLongRunning  -> {"name": op}
    poll      GET  {base}/{op}                                -> {"done": true, "response": ...}
    download  GET  response.generateVideoResponse.generatedSamples[0].video.uri

  Gemini Omni Flash (gemini-omni-1.1-flash): an interaction
    submit    POST {base}/interactions                        -> {"id", "status", "steps": [...]}
    poll      GET  {base}/interactions/{id}   (INTERACTION_PATH; the path is assumed, see below)
    file      GET  {base}/files/{file}        until state ACTIVE
    download  GET  {base}/files/{file}:download?alt=media

The key travels in the x-goog-api-key header and nowhere else: never in a
URL, never to a host other than Google's API host (a download redirect to
storage goes without it), never into a message, a log line or a detail.
"""
from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import urlsplit

from ..logging_setup import get
from .providers import Job, ProviderError

log = get("production.gemini_video")

API_HOST = "generativelanguage.googleapis.com"
BASE = "https://" + API_HOST + "/v1beta"
VEO_MODELS = ("veo-3.1-generate-preview", "veo-3.1-fast-generate-preview", "veo-3.1-lite-generate-preview")
OMNI_FLASH_MODEL = "gemini-omni-1.1-flash"
MODELS = VEO_MODELS + (OMNI_FLASH_MODEL,)
MODEL_LABELS = {"veo-3.1-generate-preview": "Veo 3.1 (best)",
                "veo-3.1-fast-generate-preview": "Veo 3.1 Fast",
                "veo-3.1-lite-generate-preview": "Veo 3.1 Lite (cheapest)",
                OMNI_FLASH_MODEL: "Gemini Omni Flash"}
DEFAULT_MODEL = VEO_MODELS[0]
ASPECT_RATIOS = ("9:16", "16:9")
RESOLUTIONS = ("720p", "1080p")
DURATIONS = (4, 6, 8)
# ASSUMED: the interactions document shows the POST and the reply; the path
# a not-yet-completed interaction is read back from is taken to be the
# resource's own id under the same collection. Kept in one place so a
# correction is one line.
INTERACTION_PATH = "/interactions/{id}"
INTERACTIONS_PATH = "/interactions"
POLL_SECONDS = 10.0
SUBMIT_TIMEOUT = 120
STATUS_TIMEOUT = 60
DOWNLOAD_TIMEOUT = 600
MAX_PROMPT = 4000
MIN_CLIP_BYTES = 10_000
DOWNLOAD_ATTEMPTS = 3
MAX_REDIRECTS = 5
BILLING_NOTE = "Billing is on the Google Cloud account; the API reports no balance."

_FILE_ID = re.compile(r"files/([^/:?#]+)")


def _requests_transport(method: str, url: str, headers: Dict[str, str], body, timeout: float, stream: bool):
    """The one place the network is touched; tests hand in a stand-in.
    Redirects are not followed here: download() follows them itself so
    the key header goes only to the API host."""
    import requests
    return requests.request(method, url, headers=headers, json=body, timeout=timeout, stream=stream,
                            allow_redirects=False)


def _host(url: str) -> str:
    try:
        return (urlsplit(url).hostname or "").lower()
    except ValueError:
        return ""


def _error(response) -> Tuple[str, str, str]:
    """Google's error shape is {"error": {"message", "status", "details"}}:
    the message, the status word and the reason from the details."""
    try:
        data = response.json()
    except ValueError:
        return (getattr(response, "text", "") or "")[:300].strip(), "", ""
    if not isinstance(data, dict):
        return str(data)[:300], "", ""
    error = data.get("error")
    if not isinstance(error, dict):
        return str(data.get("message") or data)[:300], "", ""
    reason = ""
    for detail in error.get("details") or []:
        if isinstance(detail, dict) and detail.get("reason"):
            reason = str(detail["reason"])
            break
    return str(error.get("message") or "")[:300], str(error.get("status") or "").upper(), reason.upper()


class GeminiVideoGenerator:
    """submit / poll / download like the other clip generators, plus
    check() for the key dialog. One instance is one model and one set of
    video settings; poll() tells a Veo operation from an interaction by
    the job id itself, so a queue resumed under other settings still
    finds its jobs."""

    poll_seconds = POLL_SECONDS

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL, aspect_ratio: str = "9:16",
                 resolution: str = "720p", duration_seconds: int = 8, transport: Optional[Callable] = None,
                 base_url: str = BASE):
        self._api_key = (api_key or "").strip()
        self.model = (model or DEFAULT_MODEL).strip() or DEFAULT_MODEL
        self.aspect_ratio = aspect_ratio if aspect_ratio in ASPECT_RATIOS else ASPECT_RATIOS[0]
        self.resolution = resolution if resolution in RESOLUTIONS else RESOLUTIONS[0]
        try:
            self.duration_seconds = int(duration_seconds)
        except (TypeError, ValueError):
            self.duration_seconds = 8
        if self.duration_seconds not in DURATIONS:
            self.duration_seconds = 8
        self.transport = transport or _requests_transport
        self.base_url = (base_url or BASE).rstrip("/")
        self._files: Dict[str, str] = {}          # interaction id -> file id, once the video is named
        self._completed: Dict[str, dict] = {}     # interaction id -> the reply that already carried the video

    # ----------------------------------------------------------- plumbing
    @property
    def is_veo(self) -> bool:
        return self.model != OMNI_FLASH_MODEL

    def _ready(self) -> None:
        if not self._api_key:
            raise ProviderError("No Google Gemini key is saved. Enter it under Google Gemini key….", fatal=True)

    def _headers(self) -> Dict[str, str]:
        return {"x-goog-api-key": self._api_key, "Accept": "application/json"}

    def _scrub(self, text: str) -> str:
        """Defence in depth: whatever the reply says, the key is not repeated."""
        text = str(text or "")
        return text.replace(self._api_key, "[key]") if self._api_key else text

    def _request(self, method: str, path: str, body=None, timeout: float = STATUS_TIMEOUT, what: str = "request"):
        self._ready()
        url = self.base_url + path
        try:
            return self.transport(method, url, self._headers(), body, timeout, False)
        except ProviderError:
            raise
        except Exception as exc:                                       # noqa: BLE001 - any transport failure
            raise ProviderError("Could not reach Google's API for the {}: {}".format(what, type(exc).__name__),
                                retryable=True) from exc

    def _checked(self, response, what: str) -> Dict[str, object]:
        code = int(getattr(response, "status_code", 0) or 0)
        if code == 200:
            try:
                data = response.json()
            except ValueError as exc:
                raise ProviderError("Google's reply to the {} was not JSON".format(what), retryable=True,
                                    detail=self._scrub((getattr(response, "text", "") or "")[:300])) from exc
            if not isinstance(data, dict):
                raise ProviderError("Google's reply to the {} had an unexpected shape".format(what),
                                    retryable=False, detail=self._scrub(json.dumps(data)[:300]))
            return data
        message, status, reason = _error(response)
        self._refuse(code, self._scrub(message), status, reason, what)
        raise AssertionError("unreachable")

    def _refuse(self, code: int, message: str, status: str, reason: str, what: str) -> None:
        """HTTP codes and Google's status words, in the queue's terms. A key
        with no quota, a bad key and a key without billing stop the whole
        run: nothing further would succeed."""
        if code == 429 or status == "RESOURCE_EXHAUSTED":
            raise ProviderError("Google says this key has no quota left ({}): {}. Nothing more is submitted; "
                                "the clips already made are kept.".format(code, message or "resource exhausted"),
                                exhausted=True, detail=message)
        if code == 400 and (reason == "API_KEY_INVALID" or "api key" in message.lower()):
            raise ProviderError("Google did not accept the Gemini key (400 API_KEY_INVALID). Check it under "
                                "Google Gemini key….", fatal=True, detail=message)
        if code == 401 or status == "UNAUTHENTICATED":
            raise ProviderError("Google did not accept the Gemini key ({}). Check it under Google Gemini key…."
                                .format(code), fatal=True, detail=message)
        if code == 403 or status == "PERMISSION_DENIED":
            raise ProviderError("Google refused this key ({} PERMISSION_DENIED): {}. Billing must be on for the "
                                "project the key belongs to; see the Cloud console.".format(
                                    code, message or "permission denied"), fatal=True, detail=message)
        if code == 400:
            raise ProviderError("Google rejected the {}: {}".format(what, message or "invalid request (400)"),
                                retryable=False, detail=message)
        if code == 404:
            raise ProviderError("Google has no such resource for the {} (404): {}".format(
                what, message or "not found"), retryable=False, detail=message)
        if code >= 500:
            raise ProviderError("Google had a temporary failure ({}) on the {}; worth retrying".format(code, what),
                                retryable=True, detail=message)
        raise ProviderError("Google answered {} to the {}: {}".format(code, what, message or "no detail"),
                            retryable=False, detail=message)

    def _op_failed(self, job_id: str, error: dict) -> Job:
        """A finished job that carries an error: a quota or permission
        error stops the run like an HTTP one; anything else fails the clip."""
        message = self._scrub(str(error.get("message") or "generation failed"))[:300]
        status = str(error.get("status") or "").upper()
        if status in ("RESOURCE_EXHAUSTED", "PERMISSION_DENIED", "UNAUTHENTICATED"):
            self._refuse(429 if status == "RESOURCE_EXHAUSTED" else 403, message, status, "", "job")
        return Job(job_id=job_id, status="failed", error=message)

    # ---------------------------------------------------------- the API
    def submit(self, prompt: str, settings: Dict[str, object]) -> Job:
        self._ready()
        text = (prompt or "").strip()
        if not text:
            raise ProviderError("Gemini needs a prompt, and this clip's prompt is empty.", retryable=False)
        if len(text) > MAX_PROMPT:
            raise ProviderError("Gemini accepts prompts of 1 to {} characters; this one is {} characters. "
                                "Shorten it in the prompt file.".format(MAX_PROMPT, len(text)), retryable=False)
        if self.is_veo:
            return self._submit_veo(text)
        return self._submit_interaction(text)

    def _submit_veo(self, text: str) -> Job:
        body = {"instances": [{"prompt": text}],
                "parameters": {"aspectRatio": self.aspect_ratio, "resolution": self.resolution,
                               "durationSeconds": self.duration_seconds, "personGeneration": "allow_adult"}}
        response = self._request("POST", "/models/{}:predictLongRunning".format(self.model), body=body,
                                 timeout=SUBMIT_TIMEOUT, what="video request")
        data = self._checked(response, "video request")
        name = str(data.get("name") or "").strip()
        if not name:
            raise ProviderError("Google accepted the video request but returned no operation name",
                                retryable=False, detail=self._scrub(json.dumps(data)[:300]), unconfirmed=True)
        log.info("Gemini operation %s submitted (%s)", name, self.model)
        return Job(job_id=name, status="queued")

    def _submit_interaction(self, text: str) -> Job:
        body = {"model": self.model, "input": text,
                "response_format": {"type": "video", "aspect_ratio": self.aspect_ratio,
                                    "resolution": self.resolution, "delivery": "uri"},
                "generation_config": {"video_config": {"task": "text_to_video"}}}
        response = self._request("POST", INTERACTIONS_PATH, body=body, timeout=SUBMIT_TIMEOUT, what="video request")
        data = self._checked(response, "video request")
        job_id = str(data.get("id") or "").strip()
        if not job_id:
            raise ProviderError("Google accepted the video request but returned no interaction id",
                                retryable=False, detail=self._scrub(json.dumps(data)[:300]), unconfirmed=True)
        if str(data.get("status") or "").lower() == "completed":
            self._completed[job_id] = data          # no need to ask again for what the reply carried
        log.info("Gemini interaction %s submitted (%s)", job_id, self.model)
        return Job(job_id=job_id, status="queued")

    def poll(self, job_id: str) -> Job:
        job_id = str(job_id or "").strip()
        if "/operations/" in job_id:
            return self._poll_veo(job_id)
        return self._poll_interaction(job_id)

    def _poll_veo(self, name: str) -> Job:
        response = self._request("GET", "/" + name.lstrip("/"), timeout=STATUS_TIMEOUT, what="status request")
        data = self._checked(response, "status request")
        if not data.get("done"):
            return Job(job_id=name, status="running")
        error = data.get("error")
        if isinstance(error, dict):
            return self._op_failed(name, error)
        result = data.get("response") if isinstance(data.get("response"), dict) else {}
        video = result.get("generateVideoResponse") if isinstance(result.get("generateVideoResponse"), dict) else result
        samples = video.get("generatedSamples") or []
        uri = ""
        if samples and isinstance(samples[0], dict):
            uri = str(((samples[0].get("video") or {}).get("uri")) or "").strip()
        if not uri:
            reasons = video.get("raiMediaFilteredReasons") or []
            if reasons or video.get("raiMediaFilteredCount"):
                raise ProviderError("Google's safety filter blocked this clip: {}".format(
                    self._scrub("; ".join(str(r) for r in reasons)[:300] or "no reason given")), retryable=False)
            raise ProviderError("Google reported the operation done but gave no video", retryable=False,
                                detail=self._scrub(json.dumps(data)[:300]))
        return Job(job_id=name, status="done", url=uri)

    def _poll_interaction(self, job_id: str) -> Job:
        file_id = self._files.get(job_id)
        if not file_id:
            data = self._completed.pop(job_id, None)
            if data is None:
                response = self._request("GET", INTERACTION_PATH.format(id=job_id), timeout=STATUS_TIMEOUT,
                                         what="status request")
                data = self._checked(response, "status request")
            status = str(data.get("status") or "").lower()
            if status in ("failed", "cancelled", "canceled", "expired"):
                error = data.get("error") if isinstance(data.get("error"), dict) else {}
                reason = str(error.get("message") or data.get("finish_reason") or data.get("finishReason") or
                             "the interaction {}".format(status))
                return Job(job_id=job_id, status="failed", error=self._scrub(reason)[:300])
            if status != "completed":
                return Job(job_id=job_id, status="running")
            uri, finish = _interaction_video(data)
            if not uri:
                if finish and finish.upper() not in ("STOP", "COMPLETED"):
                    raise ProviderError("Google's safety filter blocked this clip: {}".format(
                        self._scrub(finish)[:300]), retryable=False)
                raise ProviderError("Google reported the interaction completed but gave no video", retryable=False,
                                    detail=self._scrub(json.dumps(data)[:300]))
            match = _FILE_ID.search(uri)
            if not match:
                raise ProviderError("Google's video link is not a files/ resource", retryable=False,
                                    detail=self._scrub(uri)[:300])
            file_id = match.group(1)
            self._files[job_id] = file_id
        # The file is served only once its state is ACTIVE.
        response = self._request("GET", "/files/" + file_id, timeout=STATUS_TIMEOUT, what="file request")
        data = self._checked(response, "file request")
        state = str(data.get("state") or "").upper()
        if state == "ACTIVE":
            return Job(job_id=job_id, status="done", url="{}/files/{}:download?alt=media".format(self.base_url, file_id))
        if state == "FAILED":
            error = data.get("error") if isinstance(data.get("error"), dict) else {}
            return Job(job_id=job_id, status="failed",
                       error=self._scrub(str(error.get("message") or "the video file failed"))[:300])
        return Job(job_id=job_id, status="running")

    def download(self, job: Job, dest: Path) -> Path:
        """The clip to `dest`, through a .part file, so a half-written
        download never carries a real name. The key header goes with the
        request only while the link is on Google's API host; a redirect to
        storage is followed without it."""
        url = (job.url or "").strip()
        if not url.lower().startswith("https://"):
            raise ProviderError("Job {} has no usable video link".format(job.job_id), retryable=True)
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        partial = dest.with_suffix(dest.suffix + ".part")
        last: Optional[ProviderError] = None
        for attempt in range(1, DOWNLOAD_ATTEMPTS + 1):
            try:
                response = self._fetch(url)
            except ProviderError as exc:
                if not exc.retryable:
                    raise
                last = exc
                time.sleep(min(10, 2 * attempt))
                continue
            kind = str((getattr(response, "headers", None) or {}).get("Content-Type", "") or "").lower()
            if "json" in kind or "html" in kind:
                raise ProviderError("The video link for job {} answered with {} instead of a video".format(
                    job.job_id, kind.split(";")[0]), retryable=True)
            written = self._write(response, partial)
            if written < MIN_CLIP_BYTES:
                partial.unlink(missing_ok=True)
                last = ProviderError("The download for job {} was only {} bytes".format(job.job_id, written),
                                     retryable=True)
                continue
            partial.replace(dest)                            # only a complete file gets the real name
            log.info("Gemini job %s downloaded: %s (%d bytes)", job.job_id, dest.name, written)
            return dest
        partial.unlink(missing_ok=True)
        raise last or ProviderError("Clip {} could not be downloaded".format(job.job_id), retryable=True)

    def _fetch(self, url: str):
        """One GET with redirects followed by hand: up to MAX_REDIRECTS
        hops, the key only to the API host."""
        self._ready()
        for _ in range(MAX_REDIRECTS + 1):
            headers = {"x-goog-api-key": self._api_key} if _host(url) == API_HOST else {}
            try:
                response = self.transport("GET", url, headers, None, DOWNLOAD_TIMEOUT, True)
            except Exception as exc:                                   # noqa: BLE001 - any transport failure
                raise ProviderError("Could not download the clip: {}".format(type(exc).__name__),
                                    retryable=True) from exc
            code = int(getattr(response, "status_code", 0) or 0)
            if code in (301, 302, 303, 307, 308):
                location = str((getattr(response, "headers", None) or {}).get("Location", "") or "").strip()
                if not location.lower().startswith("https://"):
                    raise ProviderError("The video link redirected somewhere that is not https", retryable=False)
                url = location
                continue
            if code == 200:
                return response
            if code >= 500:
                raise ProviderError("The video host answered {}".format(code), retryable=True)
            message, status, reason = _error(response)
            self._refuse(code, self._scrub(message), status, reason, "download")
        raise ProviderError("The video link redirected more than {} times".format(MAX_REDIRECTS), retryable=False)

    @staticmethod
    def _write(response, partial: Path) -> int:
        chunks = getattr(response, "iter_content", None)
        written = 0
        with open(partial, "wb") as out:
            if callable(chunks):
                for chunk in chunks(1024 * 256):
                    if chunk:
                        out.write(chunk)
                        written += len(chunk)
            else:
                body = getattr(response, "content", b"") or b""
                out.write(body)
                written = len(body)
        return written

    def check(self, timeout: float = 15) -> str:
        """One model lookup with the key: free, and enough to tell a bad key
        from a good one. Raises the mapped ProviderError otherwise."""
        response = self._request("GET", "/models/" + self.model, timeout=timeout, what="key check")
        self._checked(response, "key check")
        return "Google Gemini key accepted for {}. {}".format(self.model, BILLING_NOTE)


def _interaction_video(data: dict) -> Tuple[str, str]:
    """The first video uri in an interaction reply, wherever the reply
    keeps its content (steps[].content[] or outputs[]), and any finish
    reason it states."""
    finish = str(data.get("finish_reason") or data.get("finishReason") or "")
    parts: List[dict] = []
    for step in (data.get("steps") or []) + (data.get("outputs") or []):
        if not isinstance(step, dict):
            continue
        content = step.get("content")
        if isinstance(content, list):
            parts.extend(p for p in content if isinstance(p, dict))
        elif step.get("type"):
            parts.append(step)
        finish = finish or str(step.get("finish_reason") or step.get("finishReason") or "")
    for part in parts:
        if str(part.get("type") or "").lower() == "video":
            uri = str(part.get("uri") or (part.get("video") or {}).get("uri") or "").strip()
            if uri:
                return uri, finish
    return "", finish
