"""The framework library: the user's own instructions to the models, kept
as named, versioned documents.

A framework is a production input, like a script. Editing one must never
silently change a job that already used it, so every save is a new version
and a production records the exact version it ran with (name, version, sha).
Nothing here invents a framework: if none has been saved, the pipeline says
so and stops.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from ..product import PRODUCT
from .manifest import FrameworkRef, digest

KINDS = ("hook", "script", "prompt", "continuity")
_HOME = PRODUCT.data_dir / "frameworks"


class Frameworks:
    def __init__(self, home: Optional[Path] = None):
        self.home = Path(home) if home else _HOME
        self.index_path = self.home / "index.json"

    # -- storage --------------------------------------------------------------
    def _index(self) -> Dict[str, Dict[str, object]]:
        try:
            return json.loads(self.index_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _write_index(self, index: Dict[str, Dict[str, object]]) -> None:
        self.home.mkdir(parents=True, exist_ok=True)
        self.index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False), encoding="utf-8")

    def _path(self, name: str, version: int) -> Path:
        safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in name).strip() or "framework"
        return self.home / safe / "v{:03d}.txt".format(version)

    # -- API ------------------------------------------------------------------
    def save(self, name: str, kind: str, text: str) -> FrameworkRef:
        """A new version, unless the text is identical to the latest one."""
        if kind not in KINDS:
            raise KeyError(kind)
        text = text.replace("\r\n", "\n").strip() + "\n"
        index = self._index()
        entry = index.get(name, {"kind": kind, "versions": []})
        versions: List[Dict[str, object]] = entry["versions"]      # type: ignore[assignment]
        sha = digest(text)
        if versions and versions[-1]["sha"] == sha:
            last = versions[-1]
            return FrameworkRef(name=name, version=int(last["version"]), sha=sha)
        version = len(versions) + 1
        path = self._path(name, version)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        versions.append({"version": version, "sha": sha, "path": str(path),
                         "saved": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                         "words": len(text.split())})
        entry["kind"] = kind
        index[name] = entry
        self._write_index(index)
        return FrameworkRef(name=name, version=version, sha=sha)

    def import_file(self, name: str, kind: str, path: Path) -> FrameworkRef:
        return self.save(name, kind, Path(path).read_text(encoding="utf-8", errors="replace"))

    def text(self, ref: FrameworkRef) -> str:
        entry = self._index().get(ref.name)
        if not entry:
            raise KeyError("no framework named '{}'".format(ref.name))
        for record in entry["versions"]:                                # type: ignore[index]
            if int(record["version"]) == ref.version:
                body = Path(str(record["path"])).read_text(encoding="utf-8")
                if ref.sha and digest(body) != ref.sha:
                    raise ValueError("framework '{}' v{} on disk does not match the version this "
                                     "production recorded".format(ref.name, ref.version))
                return body
        raise KeyError("framework '{}' has no version {}".format(ref.name, ref.version))

    def latest(self, name: str) -> Optional[FrameworkRef]:
        entry = self._index().get(name)
        if not entry or not entry["versions"]:                          # type: ignore[index]
            return None
        last = entry["versions"][-1]                                    # type: ignore[index]
        return FrameworkRef(name=name, version=int(last["version"]), sha=str(last["sha"]))

    def names(self, kind: Optional[str] = None) -> List[str]:
        return sorted(n for n, e in self._index().items() if kind is None or e.get("kind") == kind)

    def versions(self, name: str) -> List[Dict[str, object]]:
        return list(self._index().get(name, {}).get("versions", []))     # type: ignore[union-attr]
