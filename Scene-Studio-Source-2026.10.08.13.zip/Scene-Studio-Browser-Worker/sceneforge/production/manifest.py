"""The production manifest: one JSON file that is the truth about a production.

Everything the pipeline does is recorded here before and after it does it --
which stage each episode is at, which version of the script the prompts came
from, which provider job produced which clip, what was reviewed by a person
and what was only validated by code. The runner reads it to decide the next
step and to resume after an interruption; the dashboard reads it to show
where things stand; nothing paid is ever started from anything else.

Versions are never overwritten. A regenerated script is a new ScriptVersion;
the old one stays, and everything built on it is marked OUTDATED rather than
deleted, so a changed document never quietly repeats paid generation.
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import uuid
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Dict, List, Optional

MANIFEST_NAME = "production.json"
FORMAT_VERSION = 2      # 2: start/end stage, aspect ratio, resolution, editing mode, source type


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class Stage(str, Enum):
    SCRIPT = "script"
    PROMPTS = "prompts"
    CLIPS = "clips"
    EDIT = "edit"
    EXPORT = "export"


ORDER = [Stage.SCRIPT, Stage.PROMPTS, Stage.CLIPS, Stage.EDIT, Stage.EXPORT]


class Status(str, Enum):
    PENDING = "pending"            # nothing done yet
    RUNNING = "running"            # the runner is on it
    NEEDS_REVIEW = "needs_review"  # done by code; waiting for a person
    APPROVED = "approved"          # a person said yes (or automatic mode did)
    DONE = "done"                  # finished and not waiting on anyone
    FAILED = "failed"              # stopped; error and next_action say why
    OUTDATED = "outdated"          # something upstream changed since
    SKIPPED = "skipped"            # the production started after this stage


class ReviewMode(str, Enum):
    EACH_STAGE = "each_stage"          # stop after every creative stage
    BEFORE_PAID = "before_paid"        # stop only before video generation
    AUTOMATIC = "automatic"            # run to the end while limits allow


class ErrorPolicy(str, Enum):
    STOP = "stop"                      # first failure stops the run
    SKIP = "skip"                      # retry, then skip the item and go on
    ASK = "ask"                        # retry, then wait for a person


class EditingMode(str, Enum):
    AUTOMATIC = "automatic"            # the edit is made and carried straight to export
    REVIEW = "review"                  # the edit is made, then the run pauses before export
    MANUAL = "manual"                  # the run pauses for a pass in the editor


# What the person already has when the production is set up. "Scenes" is
# ambiguous -- prompt text or video files -- so the type is named, never
# guessed from a folder.
SOURCE_TYPES = ("title", "script", "prompts", "script_prompts", "clips", "composition")
# The stage each source type lets the production start at.
SOURCE_START = {"title": Stage.SCRIPT, "script": Stage.PROMPTS, "prompts": Stage.CLIPS,
                "script_prompts": Stage.CLIPS, "clips": Stage.EDIT, "composition": Stage.EXPORT}
ASPECT_RATIOS = ("auto", "16:9", "9:16")     # auto: whatever the clips are
RESOLUTIONS = (720, 1080)


def stage_index(stage) -> int:
    return ORDER.index(Stage(stage))


def stages_between(start, end) -> List[Stage]:
    """The stages a production runs, first to last, inclusive."""
    a, b = stage_index(start), stage_index(end)
    if b < a:
        b = a
    return ORDER[a:b + 1]


@dataclass
class StageState:
    status: str = Status.PENDING.value
    version: int = 0                   # which artefact version this state is about
    started: str = ""
    finished: str = ""
    error: str = ""
    next_action: str = ""
    reviewed_by: str = ""              # a person's name; empty means code only

    def set(self, status: Status, **extra) -> None:
        self.status = status.value
        stamp = now()
        if status == Status.RUNNING:
            self.started = stamp
            self.error = ""
        elif status in (Status.DONE, Status.NEEDS_REVIEW, Status.APPROVED, Status.FAILED):
            self.finished = stamp
        for key, value in extra.items():
            setattr(self, key, value)


@dataclass
class FrameworkRef:
    """Which named framework, at which saved version, produced an artefact."""
    name: str = ""
    version: int = 0
    sha: str = ""


@dataclass
class ScriptVersion:
    version: int
    path: str                          # the readable document
    created: str
    sha: str
    model: str = ""
    framework: FrameworkRef = field(default_factory=FrameworkRef)
    # When a hook framework ran first, which one, and where its reply (the
    # five hooks and the recommendation the script was asked to open with)
    # was kept: a script is only reproducible with both.
    hook_framework: FrameworkRef = field(default_factory=FrameworkRef)
    hooks_path: str = ""
    source: str = "generated"          # generated | imported
    word_count: int = 0
    scenes: int = 0
    validation: List[str] = field(default_factory=list)   # what was wrong, if anything


@dataclass
class PromptItem:
    """One clip to generate: a scene, or one of several clips for a scene."""
    scene: int
    clip: int = 1                      # 1..n within the scene
    sequence: int = 0                  # play order across the episode
    prompt: str = ""                   # the full prompt, untouched
    dialogue: str = ""                 # in the script's language
    characters: List[str] = field(default_factory=list)
    settings: Dict[str, object] = field(default_factory=dict)
    # generation
    job_id: str = ""
    job_status: str = ""               # provider's word for it
    submitted: str = ""
    attempts: int = 0
    # the file
    path: str = ""
    downloaded: bool = False
    validated: bool = False
    validation_note: str = ""
    # editing
    analysed: bool = False
    review: str = ""                   # pending | approved | rejected
    error: str = ""
    # Earlier takes, oldest first: {take, path, job_id, submitted}. A new
    # take never deletes the file of the one before it.
    takes: List[Dict[str, object]] = field(default_factory=list)

    @property
    def key(self) -> str:
        return "{}.{}".format(self.scene, self.clip)

    def retire_take(self, moved_to: str = "") -> None:
        """The current clip becomes take history; the item is fresh for a
        new submission. `moved_to` is where the old file now lives."""
        if self.path or self.job_id:
            self.takes.append({"take": len(self.takes) + 1, "path": moved_to or self.path,
                               "job_id": self.job_id, "submitted": self.submitted})
        self.path = self.job_id = self.job_status = self.submitted = ""
        self.downloaded = self.validated = self.analysed = False
        self.validation_note = self.error = self.review = ""
        self.attempts = 0


@dataclass
class PromptSet:
    version: int
    script_version: int
    created: str
    path: str                          # the readable list, one line per item
    model: str = ""
    framework: FrameworkRef = field(default_factory=FrameworkRef)
    source: str = "generated"          # generated | imported
    items: List[PromptItem] = field(default_factory=list)
    validation: List[str] = field(default_factory=list)


@dataclass
class ExportRecord:
    version: int
    path: str
    created: str
    prompt_set: int
    clips_used: int
    seconds: float = 0.0


@dataclass
class EpisodeRecord:
    number: int
    name: str
    stages: Dict[str, StageState] = field(default_factory=lambda: {s.value: StageState() for s in ORDER})
    scripts: List[ScriptVersion] = field(default_factory=list)
    prompt_sets: List[PromptSet] = field(default_factory=list)
    exports: List[ExportRecord] = field(default_factory=list)
    clips_dir: str = ""

    # -- current artefacts --------------------------------------------------
    @property
    def script(self) -> Optional[ScriptVersion]:
        return self.scripts[-1] if self.scripts else None

    @property
    def prompt_set(self) -> Optional[PromptSet]:
        return self.prompt_sets[-1] if self.prompt_sets else None

    def stage(self, stage: Stage) -> StageState:
        return self.stages[stage.value]

    # -- what comes next ----------------------------------------------------
    def stage_words(self, start, end) -> Dict[str, str]:
        """How each stage reads on a dashboard for a run from `start` to
        `end`: SKIPPED before the range, the stage's own status inside it
        (with PENDING shown as READY for the next one and WAITING after),
        and 'not in range' past the end."""
        words = {}
        nxt = self.next_stage()
        a, b = stage_index(start), stage_index(end)
        for index, stage in enumerate(ORDER):
            status = self.stage(stage).status
            if index < a and status in (Status.PENDING.value, Status.SKIPPED.value):
                words[stage.value] = "skipped"
            elif index > b:
                words[stage.value] = "not in range"
            elif status == Status.PENDING.value:
                words[stage.value] = "ready" if stage == nxt else "waiting"
            else:
                words[stage.value] = status
        return words

    def next_stage(self) -> Optional[Stage]:
        """The first stage that is not finished, or None when exported."""
        for stage in ORDER:
            status = self.stage(stage).status
            if status in (Status.DONE.value, Status.APPROVED.value, Status.SKIPPED.value):
                continue
            return stage
        return None

    def waiting_for_person(self) -> Optional[Stage]:
        for stage in ORDER:
            if self.stage(stage).status == Status.NEEDS_REVIEW.value:
                return stage
        return None

    # -- versions -----------------------------------------------------------
    def add_script(self, path: Path, text: str, **meta) -> ScriptVersion:
        version = ScriptVersion(version=len(self.scripts) + 1, path=str(path), created=now(),
                                sha=digest(text), word_count=len(text.split()), **meta)
        self.scripts.append(version)
        self.stage(Stage.SCRIPT).version = version.version
        self.mark_outdated_after(Stage.SCRIPT)
        return version

    def add_prompt_set(self, path: Path, items: List[PromptItem], **meta) -> PromptSet:
        script_version = self.script.version if self.script else 0
        prompt_set = PromptSet(version=len(self.prompt_sets) + 1, script_version=script_version,
                               created=now(), path=str(path), items=items, **meta)
        self.prompt_sets.append(prompt_set)
        self.stage(Stage.PROMPTS).version = prompt_set.version
        self.mark_outdated_after(Stage.PROMPTS)
        return prompt_set

    def mark_outdated_after(self, changed: Stage) -> List[Stage]:
        """Everything downstream of a changed stage that has results is
        marked outdated -- never deleted, never regenerated on its own."""
        affected = []
        for stage in ORDER[ORDER.index(changed) + 1:]:
            state = self.stage(stage)
            if state.status not in (Status.PENDING.value, Status.SKIPPED.value):
                state.status = Status.OUTDATED.value
                state.next_action = "Upstream changed: regenerate, or keep the previous result."
                affected.append(stage)
        return affected

    def skip_through(self, stage: Stage) -> None:
        """The production starts after `stage`: everything up to it is skipped."""
        for earlier in ORDER[:ORDER.index(stage) + 1]:
            if self.stage(earlier).status == Status.PENDING.value:
                self.stage(earlier).set(Status.SKIPPED)

    def skip_before(self, stage: Stage) -> None:
        """The production starts at `stage`: everything before it is skipped."""
        index = ORDER.index(stage)
        if index > 0:
            self.skip_through(ORDER[index - 1])

    def progress_text(self) -> str:
        """One line for a list of productions: where it is and how far."""
        nxt = self.next_stage()
        if nxt is None:
            return "Exported" if self.exports else "Finished"
        state = self.stage(nxt)
        if nxt == Stage.CLIPS and self.prompt_set:
            total = len(self.prompt_set.items)
            ready = sum(1 for i in self.prompt_set.items if i.validated)
            if ready or state.status == Status.RUNNING.value:
                return "{}/{} generated".format(ready, total)
        return {Status.RUNNING.value: "Running", Status.NEEDS_REVIEW.value: "Waiting for review",
                Status.FAILED.value: "Failed", Status.OUTDATED.value: "Outdated"}.get(state.status, "Waiting")


@dataclass
class Production:
    id: str
    title: str
    name: str
    language: str = "Urdu"
    target_minutes: float = 20.0
    synopsis: str = ""
    characters: str = ""
    setting: str = ""
    notes: str = ""
    working_dir: str = ""
    clips_dir: str = ""
    export_dir: str = ""
    review_mode: str = ReviewMode.EACH_STAGE.value
    error_policy: str = ErrorPolicy.ASK.value
    # The automation range: the run begins at start_stage (everything before
    # it is SKIPPED and its material supplied) and ends after end_stage.
    start_stage: str = Stage.SCRIPT.value
    end_stage: str = Stage.EXPORT.value
    source_type: str = "title"         # one of SOURCE_TYPES
    editing_mode: str = EditingMode.AUTOMATIC.value
    aspect_ratio: str = "auto"         # auto (from the clips), 16:9 long form, or 9:16 vertical
    resolution: int = 1080             # height in pixels; width follows the ratio
    final_filename: str = ""           # export name without the version suffix; empty = episode name
    batch_id: str = ""                 # set when this production belongs to a batch
    spending_limit: float = 0.0        # in the provider's currency; 0 = no limit set
    spent_reported: float = 0.0        # what providers reported, never an estimate
    # Optional. When set, the script stage is two calls: the hook framework
    # first (five openings and a recommendation), then the script framework
    # told to open with the recommended one. Empty means one call, as before.
    hook_framework: FrameworkRef = field(default_factory=FrameworkRef)
    script_framework: FrameworkRef = field(default_factory=FrameworkRef)
    prompt_framework: FrameworkRef = field(default_factory=FrameworkRef)
    continuity: str = ""               # shared character / style guidance
    generation_settings: Dict[str, object] = field(default_factory=dict)
    editing_settings: Dict[str, object] = field(default_factory=dict)
    episodes: List[EpisodeRecord] = field(default_factory=list)
    created: str = field(default_factory=now)
    updated: str = ""
    format_version: int = FORMAT_VERSION

    # -- lifecycle ----------------------------------------------------------
    @classmethod
    def new(cls, title: str, name: str, working_dir: Path, episodes: int = 1, **fields_) -> "Production":
        production = cls(id=uuid.uuid4().hex[:12], title=title, name=name,
                         working_dir=str(working_dir), **fields_)
        for number in range(1, max(1, episodes) + 1):
            production.episodes.append(EpisodeRecord(
                number=number,
                name="{} - episode {}".format(name, number) if episodes > 1 else name,
                clips_dir=str((Path(production.clips_dir) if production.clips_dir
                               else Path(working_dir) / "clips") / "ep{:02d}".format(number))))
        return production

    @property
    def path(self) -> Path:
        return Path(self.working_dir) / MANIFEST_NAME

    def episode(self, number: int) -> EpisodeRecord:
        for episode in self.episodes:
            if episode.number == number:
                return episode
        raise KeyError(number)

    def save(self) -> Path:
        """Write atomically: the old manifest is replaced only once the new
        one is fully on disk, so a crash mid-write cannot lose the record."""
        self.updated = now()
        path = self.path
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(_to_dict(self), indent=2, ensure_ascii=False)
        fd, tmp = tempfile.mkstemp(prefix=".production-", suffix=".json", dir=str(path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        return path

    @classmethod
    def load(cls, working_dir: Path) -> "Production":
        raw = json.loads((Path(working_dir) / MANIFEST_NAME).read_text(encoding="utf-8"))
        production = _from_dict(cls, raw)
        if int(raw.get("format_version", 1) or 1) < 2:
            _migrate_v1(production, raw)
        return production

    # -- summary for the dashboard and the start-production confirmation ----
    @property
    def stages_in_range(self) -> List[Stage]:
        return stages_between(self.start_stage, self.end_stage)

    def summary(self) -> Dict[str, object]:
        return {
            "title": self.title, "name": self.name, "language": self.language,
            "start_stage": self.start_stage, "end_stage": self.end_stage,
            "aspect_ratio": self.aspect_ratio, "resolution": self.resolution,
            "editing_mode": self.editing_mode,
            "episodes": [{
                "number": e.number, "name": e.name,
                "stages": {s.value: e.stage(s).status for s in ORDER},
                "next": (e.next_stage().value if e.next_stage() else "finished"),
                "clips": len(e.prompt_set.items) if e.prompt_set else 0,
            } for e in self.episodes],
            "review_mode": self.review_mode, "error_policy": self.error_policy,
            "spending_limit": self.spending_limit, "spent_reported": self.spent_reported,
        }


# ------------------------------------------------------------ (de)serialise
def _to_dict(obj):
    if hasattr(obj, "__dataclass_fields__"):
        return {f.name: _to_dict(getattr(obj, f.name)) for f in fields(obj)}
    if isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_to_dict(v) for v in obj]
    if isinstance(obj, Enum):
        return obj.value
    return obj


def _from_dict(cls, raw):
    kwargs = {}
    for f in fields(cls):
        if f.name not in raw:
            continue
        value = raw[f.name]
        kwargs[f.name] = _coerce(f.type, value)
    return cls(**kwargs)


_NESTED = {
    "FrameworkRef": FrameworkRef, "ScriptVersion": ScriptVersion, "PromptItem": PromptItem,
    "PromptSet": PromptSet, "ExportRecord": ExportRecord, "EpisodeRecord": EpisodeRecord,
    "StageState": StageState,
}


def _coerce(type_name, value):
    name = type_name if isinstance(type_name, str) else getattr(type_name, "__name__", str(type_name))
    if name in _NESTED and isinstance(value, dict):
        return _from_dict(_NESTED[name], value)
    if name.startswith("List[") and isinstance(value, list):
        inner = name[5:-1]
        return [_coerce(inner, v) for v in value]
    if name.startswith("Dict[str, StageState]") and isinstance(value, dict):
        return {k: _from_dict(StageState, v) for k, v in value.items()}
    return value


def _migrate_v1(production: "Production", raw: dict) -> None:
    """A manifest from before the automation range: read the range off the
    stages that were skipped when it was set up, and the video settings off
    the old editing_settings. Nothing about the run itself changes; the
    file is rewritten in the new format the next time it is saved."""
    first = production.episodes[0] if production.episodes else None
    start = Stage.SCRIPT
    if first is not None:
        for stage in ORDER:
            if first.stage(stage).status == Status.SKIPPED.value:
                start = ORDER[min(ORDER.index(stage) + 1, len(ORDER) - 1)]
            else:
                break
    production.start_stage = start.value
    production.end_stage = Stage.EXPORT.value
    production.source_type = {Stage.SCRIPT: "title", Stage.PROMPTS: "script", Stage.CLIPS: "prompts",
                              Stage.EDIT: "clips", Stage.EXPORT: "composition"}[start]
    height = production.editing_settings.get("output_height") if isinstance(production.editing_settings, dict) else None
    try:
        production.resolution = int(height) if int(height or 0) in RESOLUTIONS else 1080
    except (TypeError, ValueError):
        production.resolution = 1080
    production.aspect_ratio = "auto"
    production.format_version = FORMAT_VERSION
