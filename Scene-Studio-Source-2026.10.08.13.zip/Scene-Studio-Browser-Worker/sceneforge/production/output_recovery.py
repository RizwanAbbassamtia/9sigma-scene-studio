"""Recover a saved provider result without placing another generation order."""
import json

from .flow_browser_run import BrowserSettings
from .gemini_browser import conversation_url


def recovery_record(queue, number):
    row = next((r for r in queue.rows() if r['number'] == number), None)
    if not row or row['status'] != 'review' or row['provider'] != 'gemini':
        raise ValueError('Only a Gemini scene needing review can recover its existing result.')
    try:
        receipt = json.loads(row['receipt'] or '')
    except (TypeError, ValueError):
        raise ValueError('No saved conversation receipt exists. Review the provider before retrying.') from None
    if not isinstance(receipt, dict) or not conversation_url(receipt.get('url', '')) or receipt.get('account') != row['account']:
        raise ValueError('The saved conversation does not match this scene and profile.')
    if row['file']:
        raise ValueError('A saved clip already needs review; do not download or generate another.')
    attempt = queue.db.execute(
        'SELECT id,receipt,provider,account FROM attempts WHERE scene=? ORDER BY id DESC LIMIT 1',
        (number,)).fetchone()
    if not attempt or attempt['receipt'] != row['receipt'] or attempt['provider'] != 'gemini' or attempt['account'] != row['account']:
        raise ValueError('The latest attempt does not match the saved result. Review it manually.')
    dest = queue.folder / f"{number:04d}_gemini_attempt{attempt['id']}.mp4"
    if dest.exists() or dest.with_suffix('.partial.mp4').exists():
        raise ValueError('An output already exists on disk; review that file before continuing.')
    return row, attempt['id'], dest


def recover_scene_output(queue, number, account, browser, emit=lambda message: None, stopped=lambda: False):
    row, attempt, dest = recovery_record(queue, number)
    if account['id'] != row['account']:
        raise ValueError('Recovery must use the original profile.')
    settings = BrowserSettings(**queue.get('settings'))
    queue.update(number, status='generating', note='Checking the existing Gemini result; no new request sent.')
    try:
        emit(f"Checking existing Gemini result for scene {number} / {account['id']}; no new prompt submitted")
        browser.recover_output(account, row['receipt'], settings, dest, stopped=stopped)
        if not dest.is_file():
            raise RuntimeError('The existing result has not produced a saved video.')
        queue.update(number, status='done', file=str(dest), note=None)
        queue.attempt(attempt, 'done')
        emit(f"Scene {number} recovered from the existing Gemini result")
    except Exception as exc:
        queue.update(number, status='review', file=str(dest) if dest.is_file() else None, note=str(exc))
        queue.attempt(attempt, 'review', note=str(exc))
        raise
    finally:
        try:
            browser.close()
        finally:
            queue.export()
