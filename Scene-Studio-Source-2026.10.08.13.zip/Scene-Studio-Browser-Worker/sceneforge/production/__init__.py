"""The optional production pipeline: title → script → scene prompts → clips
→ edit → export. Off unless a production is started by hand; the manual
editor never touches any of this."""
