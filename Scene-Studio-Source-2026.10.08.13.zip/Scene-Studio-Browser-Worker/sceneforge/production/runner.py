"""Runs a production, one stage at a time, recording everything as it goes.

    runner = Runner(production, providers, frameworks, config, on_event=print)
    runner.run(episode=1)          # runs until a checkpoint, a failure, or the end

Rules the runner keeps whatever the caller asks:
  - nothing paid starts unless run() is called; opening a manifest does nothing
  - a stage that needs a person stops the run with NEEDS_REVIEW; the next
    run() call continues only if that stage was APPROVED
  - every submission is written to the manifest before the request is sent,
    so a crash can never lose a job id; on resume, jobs are reconciled
    (polled) before anything is resubmitted
  - the generation limit is enforced here, in the application, not trusted
    to the provider; reported cost is recorded but never estimated
  - a truncated model reply is repaired by asking it to continue, a bounded
    number of times, and never passed on as complete
  - a submission that got no job id back stops the clips stage rather than
    being sent again; generate() makes clips by hand for chosen scenes, and
    a new take keeps the previous file as take history
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional

from ..config import Config
from ..logging_setup import get
from . import prompts as prompt_text
from .frameworks import Frameworks
from .manifest import (
    EditingMode, ErrorPolicy, Production, PromptItem, ReviewMode, Stage, Status,
)
from .providers import Job, ProviderError, validate_clip
from .screenplay import coverage, parse as parse_screenplay, validate as validate_screenplay

log = get("production.runner")

MAX_CONTINUATIONS = 3          # how many times a cut-off reply is asked to continue
MAX_ATTEMPTS = 3               # per clip, before the error policy decides
MAX_POLL_FAILURES = 6          # status checks that may fail in a row before the stage does
MAX_IN_FLIGHT = 8              # jobs in flight at once, whatever a provider says it allows
MAX_BUSY_WAITS = 180           # busy answers in a row (about 30 min at 10 s) before the stage stops
POLL_SECONDS = 5.0


@dataclass
class Event:
    episode: int
    stage: str
    status: str
    message: str
    done: int = 0
    total: int = 0


@dataclass
class Providers:
    script_writer: object = None
    prompt_writer: object = None
    clip_generator: object = None


def _lease_lost(stop) -> bool:
    """The worker's stop object carries a `lost` event when the job was
    taken over by another machine; a plain threading.Event never says so."""
    lost = getattr(stop, "lost", None)
    return bool(lost is not None and getattr(lost, "is_set", lambda: False)())


class Stopped(Exception):
    """The person pressed Stop. Not an error; the manifest is left consistent."""


class Runner:
    def __init__(self, production: Production, providers: Providers, frameworks: Frameworks,
                 config: Config, on_event: Callable[[Event], None] = lambda e: None,
                 stop: Optional[threading.Event] = None, max_generations: int = 0,
                 poll_seconds: float = POLL_SECONDS, in_flight: int = 3):
        self.production = production
        self.providers = providers
        self.frameworks = frameworks
        self.config = config
        self.on_event = on_event
        self.stop = stop or threading.Event()
        self.max_generations = max_generations        # 0 = no application-side cap
        self.poll_seconds = poll_seconds
        self.in_flight = in_flight

    # ------------------------------------------------------------------ run
    def run(self, episode: int, until: Optional[Stage] = None) -> Optional[Stage]:
        """Run the episode's next stages. Returns the stage it stopped at
        (waiting for a person, failed, or the first one past the range), or
        None when the episode is exported.

        `until` defaults to the production's end stage, so a production set
        up as Clips → Editing stops after the edit and leaves Export pending.
        """
        record = self.production.episode(episode)
        if until is None:
            try:
                until = Stage(self.production.end_stage)
            except ValueError:
                until = None
        while True:
            self._check_stop()
            stage = record.next_stage()
            if stage is None:
                return None
            state = record.stage(stage)
            if state.status == Status.NEEDS_REVIEW.value:
                return stage                                    # a person is needed
            if state.status == Status.OUTDATED.value:
                state.next_action = "Upstream changed. Choose: regenerate this stage, or keep the previous result."
                return stage
            if until is not None and ORDER_INDEX[stage] > ORDER_INDEX[until]:
                return stage
            if stage == Stage.CLIPS and self.production.review_mode == ReviewMode.BEFORE_PAID.value \
                    and state.status != Status.APPROVED.value and not state.reviewed_by:
                state.set(Status.NEEDS_REVIEW,
                          next_action="Review the script and prompts, then approve to start paid generation.")
                self._save(record.number, stage, "waiting for approval before paid generation")
                return stage
            if self._attempt(record, stage, lambda: self._run_stage(record, stage)):
                return stage
            if record.stage(stage).status == Status.NEEDS_REVIEW.value:
                return stage

    def generate(self, episode: int, keys, new_take: bool = False) -> Optional[Stage]:
        """The clips stage for the chosen items only ("scene.clip" keys), by
        hand from the dashboard. A new take retires each chosen clip's
        current file to take history first; otherwise a clip that is
        already valid is kept and nothing is asked for it. Returns the
        stage the episode is left at, like run()."""
        record = self.production.episode(episode)
        chosen = {str(k) for k in keys}
        if not chosen:
            return Stage.CLIPS
        state = record.stage(Stage.CLIPS)
        state.set(Status.RUNNING, next_action="Wait.")
        self._save(record.number, Stage.CLIPS, "started for {} chosen clip(s)".format(len(chosen)))
        self._attempt(record, Stage.CLIPS, lambda: self._clips(record, only=chosen, new_take=new_take))
        return Stage.CLIPS

    def plan(self, episode: int, keys=None, new_take: bool = False) -> Dict[str, object]:
        """What generating would do, for the confirmation before it does:
        submissions, clips kept, jobs still to poll, the cap, and the
        provider's quota when it has said (None when unknown)."""
        record = self.production.episode(episode)
        items = sorted(record.prompt_set.items if record.prompt_set else [], key=lambda i: i.sequence)
        chosen = [i for i in items if keys is None or i.key in {str(k) for k in keys}]
        present = [i for i in chosen if not new_take and i.validated and i.path and Path(i.path).exists()]
        wanted = [i for i in chosen if i not in present]
        polling = [i for i in wanted if i.job_id and not new_take]
        submit = [i for i in wanted if i not in polling]
        problems = _prompt_problems(submit)
        generator = self.providers.clip_generator
        return {"submit": len(submit), "reused": len(present), "polling": len(polling),
                "scenes": [i.scene for i in submit], "cap": self.max_generations,
                "cap_used": sum(1 for i in items if i.job_id), "problems": problems,
                "quota": getattr(generator, "remaining_today", None) if generator is not None else None,
                "quota_label": getattr(generator, "quota_label", "quota left today") if generator is not None else "quota left today",
                "price": getattr(generator, "video_price", None) if generator is not None else None}

    def _attempt(self, record, stage: Stage, work: Callable[[], None]) -> bool:
        """One stage's work, with a stop, a provider error or a crash
        recorded on the stage. True when it ended in one of those."""
        state = record.stage(stage)
        try:
            work()
        except Stopped:
            if _lease_lost(self.stop):
                # Another machine holds this production now: its
                # manifest is theirs, and this stale copy is not saved.
                log.warning("Episode %d %s: stopped because the job was taken over; nothing saved",
                            record.number, stage.value)
                return True
            state.set(Status.FAILED, error="Stopped by the user.",
                      next_action="Press Start production to continue from here.")
            self._save(record.number, stage, "stopped")
            return True
        except ProviderError as exc:
            state.set(Status.FAILED, error=str(exc),
                      next_action=("Try again later." if exc.retryable else
                                   "Fix the cause (see the error), then press Start production."))
            log.error("Episode %d %s failed: %s %s", record.number, stage.value, exc, exc.detail[:300])
            self._save(record.number, stage, "failed: " + str(exc))
            return True
        except Exception as exc:                                  # noqa: BLE001
            state.set(Status.FAILED, error="{}: {}".format(type(exc).__name__, exc),
                      next_action="Send the log; then press Start production to try again.")
            log.exception("Episode %d %s crashed", record.number, stage.value)
            self._save(record.number, stage, "crashed")
            return True
        return False

    def approve(self, episode: int, stage: Stage, by: str) -> None:
        """A person's approval of a stage that was waiting for it.

        For a creative stage that means "this result is good, move on". For
        the clips stage it means "you may now spend money": the stage has not
        run yet, so it goes back to pending with the approver's name on it,
        and the gate in run() lets it through.
        """
        record = self.production.episode(episode)
        state = record.stage(stage)
        generated = any(i.validated for i in (record.prompt_set.items if record.prompt_set else []))
        if stage == Stage.CLIPS and not generated and not state.error:
            state.set(Status.PENDING, reviewed_by=by, next_action="Approved; press Start production to generate.")
        else:
            state.set(Status.APPROVED, reviewed_by=by, next_action="")
        self._save(episode, stage, "approved by " + by)

    # --------------------------------------------------------------- stages
    def _run_stage(self, record, stage: Stage) -> None:
        handler = {Stage.SCRIPT: self._script, Stage.PROMPTS: self._prompts, Stage.CLIPS: self._clips,
                   Stage.EDIT: self._edit, Stage.EXPORT: self._export}[stage]
        record.stage(stage).set(Status.RUNNING, next_action="Wait.")
        self._save(record.number, stage, "started")
        handler(record)

    def _finish_creative(self, record, stage: Stage, message: str) -> None:
        """A creative stage ends waiting for a person, unless the production
        chose to run past it."""
        state = record.stage(stage)
        if self.production.review_mode == ReviewMode.EACH_STAGE.value:
            state.set(Status.NEEDS_REVIEW, next_action="Review, edit if needed, then approve or regenerate.")
        else:
            state.set(Status.DONE, next_action="")
        self._save(record.number, stage, message)

    # -- 1. script ----------------------------------------------------------
    def _script(self, record) -> None:
        writer = self.providers.script_writer
        if writer is None:
            raise ProviderError("No script writer is configured (an OpenAI key is needed for this stage).")
        framework = self._framework_text(self.production.script_framework, "script-writing")
        continuity = ("\n\nShared continuity:\n" + self.production.continuity if self.production.continuity else "")
        system = framework + continuity
        brief = self._brief(record)
        number = len(record.scripts) + 1
        user = brief
        hooks_path = ""
        hook_ref = self.production.hook_framework
        if hook_ref.name:
            # The hook framework is a two-turn instruction: "give me five
            # openings and your recommendation, then wait". Prepending it to
            # the script call would get the five hooks back and no script,
            # so it is its own call, and its reply is handed to the script
            # call as the opening to use. The reply is kept beside the
            # script: a script is only reproducible with both.
            hook_system = self._framework_text(hook_ref, "hook") + continuity
            hooks = self._complete_text(writer, hook_system, brief, record, Stage.SCRIPT)
            hooks_file = self._episode_dir(record) / "hooks-v{}.txt".format(number)
            hooks_file.write_text(hooks.text, encoding="utf-8")
            hooks_path = str(hooks_file)
            self._event(record.number, Stage.SCRIPT, "running", "hooks written; asking for the script")
            user = (brief + "\n\nUse the hook under MY RECOMMENDATION in the text below as the exact "
                    "opening of the script:\n\n" + hooks.text)
        result = self._complete_text(writer, system, user, record, Stage.SCRIPT)
        play = parse_screenplay(result.text)
        problems = validate_screenplay(play)
        path = self._episode_dir(record) / "script-v{}.txt".format(number)
        path.write_text(result.text, encoding="utf-8")
        version = record.add_script(path, result.text, model=result.model,
                                    framework=self.production.script_framework, hook_framework=hook_ref,
                                    hooks_path=hooks_path, scenes=len(play.scenes))
        version.validation = problems
        if problems:
            record.stage(Stage.SCRIPT).set(
                Status.NEEDS_REVIEW,
                next_action="The script did not pass validation: " + "; ".join(problems) +
                            " Edit it, or regenerate.")
            self._save(record.number, Stage.SCRIPT, "needs attention: " + problems[0])
            return
        self._finish_creative(record, Stage.SCRIPT,
                              "script v{}: {} scenes, {} words".format(version.version, len(play.scenes), version.word_count))

    def _brief(self, record) -> str:
        p = self.production
        parts = ["Title: {}".format(p.title), "Episode: {} of {}".format(record.number, len(p.episodes)),
                 "Language: {}".format(p.language),
                 "Target length: about {:.0f} minutes (an estimate until the video is timed)".format(p.target_minutes)]
        for label, value in (("Synopsis", p.synopsis), ("Characters", p.characters),
                             ("Setting", p.setting), ("Notes", p.notes)):
            if value.strip():
                parts.append("{}:\n{}".format(label, value.strip()))
        if record.number > 1:
            previous = self.production.episode(record.number - 1).script
            if previous:
                text = Path(previous.path).read_text(encoding="utf-8", errors="replace")
                parts.append("The previous episode's script, for continuity:\n" + text[-6000:])
        return "\n\n".join(parts)

    # -- 2. prompts ---------------------------------------------------------
    def _prompts(self, record) -> None:
        writer = self.providers.prompt_writer
        if writer is None:
            raise ProviderError("No prompt writer is configured (an Anthropic key is needed for this stage).")
        if record.script is None:
            raise ProviderError("There is no script to write prompts from.")
        framework = self._framework_text(self.production.prompt_framework, "scene-prompt")
        script_text = Path(record.script.path).read_text(encoding="utf-8", errors="replace")
        system = framework + ("\n\nShared continuity:\n" + self.production.continuity if self.production.continuity else "")
        user = ("Write the scene prompts for this script. Keep every scene, in order, numbered from 1. "
                "Keep the dialogue exactly as written and in its language ({}).\n\n{}".format(
                    self.production.language, script_text))
        result = self._complete_text(writer, system, user, record, Stage.PROMPTS)
        items = prompt_text.parse_text(result.text, float(self.production.generation_settings.get("max_seconds", 0) or 0))
        play = parse_screenplay(script_text)
        report = coverage(play, [i.scene for i in items]) if play.scenes else {}
        problems = []
        if not items:
            problems.append("No numbered prompts were found in the reply.")
        for key, label in (("missing", "missing scenes"), ("duplicated", "duplicated scenes"),
                           ("out_of_order", "scenes out of order"), ("extra", "scenes not in the script")):
            if report.get(key):
                problems.append("{}: {}".format(label, report[key][:20]))
        path = self._episode_dir(record) / "prompts-v{}.txt".format(len(record.prompt_sets) + 1)
        path.write_text(result.text, encoding="utf-8")
        prompt_set = record.add_prompt_set(path, items, model=result.model, framework=self.production.prompt_framework)
        prompt_set.validation = problems
        if problems:
            record.stage(Stage.PROMPTS).set(
                Status.NEEDS_REVIEW,
                next_action="The prompts did not cover the script: " + "; ".join(problems) + " Edit, or regenerate.")
            self._save(record.number, Stage.PROMPTS, "needs attention: " + problems[0])
            return
        self._finish_creative(record, Stage.PROMPTS, "prompt set v{}: {} clips".format(prompt_set.version, len(items)))

    # -- 3. clips -----------------------------------------------------------
    def _clips(self, record, only=None, new_take: bool = False) -> None:
        generator = self.providers.clip_generator
        if generator is None:
            raise ProviderError("No clip generator is configured (the Omni Flash connection is needed).")
        prompt_set = record.prompt_set
        if prompt_set is None or not prompt_set.items:
            raise ProviderError("There are no prompts to generate from.")
        clips_dir = Path(record.clips_dir)
        clips_dir.mkdir(parents=True, exist_ok=True)
        prompt_text.write_for_editor(prompt_set.items, clips_dir / "scenes.txt")
        items = sorted(prompt_set.items, key=lambda i: i.sequence)
        chosen = [i for i in items if only is None or i.key in only]
        total = len(items)
        state = record.stage(Stage.CLIPS)

        if new_take:
            for item in chosen:
                self._retire(item, clips_dir / "takes")
            self._save(record.number, Stage.CLIPS, "{} clip(s) retired to take history".format(len(chosen)))
        # Resume: anything already on disk and valid needs nothing.
        for item in items:
            if item.path and validate_clip(Path(item.path)) == "":
                item.downloaded = item.validated = True
        generated = sum(1 for i in items if i.validated)
        self._event(record.number, Stage.CLIPS, "running", "{} of {} clips already present".format(generated, total),
                    generated, total)

        # A submission that got no job id back is never resubmitted on its
        # own: choosing it by hand is the person saying "ask again".
        pending: List[PromptItem] = [i for i in chosen if not i.validated
                                     and (only is not None or i.job_status != UNCONFIRMED)]
        for item in pending:
            if item.job_status == UNCONFIRMED:
                item.job_status = item.error = ""
        unconfirmed = [i for i in items if i.job_status == UNCONFIRMED and not i.validated]
        problems = _prompt_problems(pending)
        if problems:
            raise ProviderError("Nothing was submitted: " + "; ".join(problems) +
                                ". Fix the scene prompts first.", retryable=False)
        active: Dict[str, PromptItem] = {}
        submissions = sum(1 for i in items if i.job_id)
        skipped: List[PromptItem] = []
        poll_failures = 0
        busy_waits = 0

        while pending or active:
            self._check_stop()
            # Reconcile jobs that were submitted before a restart.
            for item in list(pending):
                if item.job_id and item.job_id not in active and not item.validated:
                    active[item.job_id] = item
                    pending.remove(item)
            # Submit up to the in-flight limit, within the generation cap. A
            # provider that says how many jobs it runs at once sets the
            # ceiling; the runner's own figure applies when it does not.
            allowed = getattr(generator, "max_in_flight", None) or self.in_flight
            limit = max(1, min(int(allowed), MAX_IN_FLIGHT))
            while pending and len(active) < limit:
                self._check_stop()                # a takeover mid-submit must not buy the next clip
                if self.max_generations and submissions >= self.max_generations:
                    raise ProviderError(
                        "The generation limit ({}) for this production is reached with {} clips still to "
                        "make.".format(self.max_generations, len(pending)), retryable=False)
                item = pending.pop(0)
                item.attempts += 1
                item.submitted = _now()
                item.job_status = "submitting"
                self._save(record.number, Stage.CLIPS, "submitting clip {}".format(item.sequence))
                try:
                    job = generator.submit(item.prompt, {**self.production.generation_settings, **item.settings})
                except ProviderError as exc:
                    if getattr(exc, "busy", False):
                        # No free slot on the provider: this clip goes back
                        # to the front of the queue with no attempt spent,
                        # and no more are submitted until something in
                        # flight finishes or a poll interval has passed.
                        item.attempts -= 1
                        item.job_status = ""
                        item.submitted = ""
                        pending.insert(0, item)
                        busy_waits += 1
                        self._event(record.number, Stage.CLIPS, "running",
                                    "the provider is busy ({}); waiting for a free slot".format(str(exc)[:120]))
                        if busy_waits > MAX_BUSY_WAITS:
                            raise ProviderError("Omni Flash stayed busy for {} checks in a row ({}); stopping so "
                                                "this can be looked at. Retry continues from the clips already "
                                                "made.".format(busy_waits, str(exc)[:160]), retryable=True)
                        break
                    if getattr(exc, "fatal", False):
                        # A bad key or a spent daily limit: no scene will
                        # fare better, so the stage stops here, and this
                        # clip is not charged an attempt.
                        item.attempts -= 1
                        item.job_status = ""
                        raise
                    if getattr(exc, "unconfirmed", False) or "no job id" in str(exc).lower():
                        self._unconfirmed(item, str(exc))
                    if not self._tolerate(item, exc, skipped, pending):
                        raise
                    continue
                if not (job.job_id or "").strip():
                    self._unconfirmed(item, "the provider answered without a job id")
                item.job_id, item.job_status = job.job_id, job.status
                submissions += 1
                busy_waits = 0
                active[job.job_id] = item
                self._save(record.number, Stage.CLIPS, "clip {} submitted ({})".format(item.sequence, job.job_id))
            # Poll what is in flight.
            for job_id, item in list(active.items()):
                try:
                    job = generator.poll(job_id)
                except ProviderError as exc:
                    if getattr(exc, "fatal", False) or not exc.retryable or poll_failures >= MAX_POLL_FAILURES:
                        raise
                    poll_failures += 1
                    log.warning("Status check for job %s failed (%d in a row): %s", job_id, poll_failures, exc)
                    break
                poll_failures = 0
                item.job_status = job.status
                if job.status == "done":
                    del active[job_id]
                    self._fetch(generator, job, item, clips_dir)
                    if job.reported_cost is not None:
                        self.production.spent_reported += float(job.reported_cost)
                    generated = sum(1 for i in items if i.validated)
                    self._save(record.number, Stage.CLIPS, "clip {} ready".format(item.sequence), generated, total)
                elif job.status == "failed":
                    del active[job_id]
                    item.job_id = ""
                    error = ProviderError(job.error or "the provider reported a failure", retryable=True)
                    if not self._tolerate(item, error, skipped, pending):
                        raise error
            if active or (pending and busy_waits):
                # Never faster than the provider asks to be polled; a busy
                # provider with nothing of ours in flight is asked again
                # after the same interval.
                self._sleep(max(self.poll_seconds, float(getattr(generator, "poll_seconds", 0.0) or 0.0)))

        if new_take:
            record.mark_outdated_after(Stage.CLIPS)         # an edit or export made before this take is stale
        if skipped:
            state.set(Status.FAILED if self.production.error_policy == ErrorPolicy.ASK.value else Status.NEEDS_REVIEW,
                      error="{} clip(s) could not be generated: {}".format(
                          len(skipped), ", ".join(str(i.sequence) for i in skipped)),
                      next_action="Regenerate the failed clips, or approve to continue without them.")
            self._save(record.number, Stage.CLIPS, "finished with {} clips missing".format(len(skipped)))
            return
        missing = [i for i in items if not i.validated]
        generated = total - len(missing)
        if missing:
            note = (" Clip(s) {} were submitted but got no job id; choose them and Generate selected to ask "
                    "again.".format(", ".join(str(i.sequence) for i in unconfirmed)) if unconfirmed else "")
            state.set(Status.NEEDS_REVIEW,
                      next_action="{} of {} clips are ready.{} Generate the missing ones, or approve to edit "
                                  "with what is there.".format(generated, total, note))
            self._save(record.number, Stage.CLIPS, "{} of {} clips ready".format(generated, total), generated, total)
            return
        if self.production.review_mode == ReviewMode.EACH_STAGE.value:
            state.set(Status.NEEDS_REVIEW,
                      next_action="All {} clips are generated and checked. Look at them (Open the clips in the "
                                  "editor), regenerate any that are wrong, then approve to edit.".format(total))
        else:
            state.set(Status.DONE, next_action="")
        self._save(record.number, Stage.CLIPS, "all {} clips generated and checked".format(total), total, total)

    def _retire(self, item: PromptItem, takes_dir: Path) -> None:
        """The current clip file goes to the takes folder, out of the
        editor's way, and the item is ready for a new submission."""
        moved = ""
        if item.path and Path(item.path).exists():
            takes_dir.mkdir(parents=True, exist_ok=True)
            dest = takes_dir / prompt_text.take_filename(item, len(item.takes) + 1)
            Path(item.path).replace(dest)
            moved = str(dest)
        item.retire_take(moved)

    def _unconfirmed(self, item: PromptItem, why: str) -> None:
        """The request may have been accepted, but nothing came back to
        track it by. Resubmitting could pay twice, so the stage stops
        here and says so; the item is left out of automatic retries."""
        item.job_id = ""
        item.job_status = UNCONFIRMED
        item.error = why
        raise ProviderError(
            "Clip {} (scene {}) may have been accepted by the provider, but no job id came back ({}). It was "
            "not resubmitted. Check the provider's queue and quota; then choose the clip and press Generate "
            "selected to ask for it again, or Generate missing to carry on with the others.".format(
                item.sequence, item.scene, why), retryable=False)

    def _fetch(self, generator, job: Job, item: PromptItem, clips_dir: Path) -> None:
        dest = clips_dir / prompt_text.clip_filename(item)
        generator.download(job, dest)
        problem = validate_clip(dest)
        item.path = str(dest)
        item.downloaded = True
        item.validated = problem == ""
        item.validation_note = problem
        if problem:
            raise ProviderError("Clip {} downloaded but is not a usable video: {}".format(item.sequence, problem),
                                retryable=True)

    def _tolerate(self, item: PromptItem, error: ProviderError, skipped: List[PromptItem],
                  pending: List[PromptItem]) -> bool:
        """Decide what a failed clip means for the run. True: carry on."""
        item.error = str(error)
        log.warning("Clip %d attempt %d failed: %s", item.sequence, item.attempts, error)
        if item.attempts < MAX_ATTEMPTS and (error.retryable or item.attempts == 1):
            pending.append(item)
            return True
        policy = self.production.error_policy
        if policy == ErrorPolicy.STOP.value:
            return False
        skipped.append(item)
        return True

    # -- 4. edit ------------------------------------------------------------
    def _edit(self, record) -> None:
        from ..pipeline import analyse
        from ..state import save as save_state
        clips_dir = Path(record.clips_dir)
        if not clips_dir.is_dir() or not any(clips_dir.glob("*.mp4")):
            raise ProviderError("There are no clips in {} to edit.".format(clips_dir))
        state = record.stage(Stage.EDIT)
        config = self._export_config()
        episode = analyse(clips_dir, config,
                          progress=lambda d, t, label: self._event(record.number, Stage.EDIT, "running", label, d, t))
        save_state(episode, "automation")
        flagged = len(episode.flagged)
        if record.prompt_set:
            for item in record.prompt_set.items:
                item.analysed = True
        # The composition is written; whether the run pauses here is the
        # editing mode's call (and "review at each stage" always pauses).
        # "Review before paid generation" had its one checkpoint already.
        mode = self.production.editing_mode
        if mode == EditingMode.MANUAL.value:
            state.set(Status.NEEDS_REVIEW,
                      next_action="Manual editing: open the clips in the editor, make your cuts, then approve "
                                  "here to export ({} clips, {} flagged).".format(len(episode.clips), flagged))
        elif mode == EditingMode.REVIEW.value or self.production.review_mode == ReviewMode.EACH_STAGE.value:
            state.set(Status.NEEDS_REVIEW,
                      next_action="The edit is made: {} clips, {} flagged. Open the folder in the editor to check "
                                  "it, then approve here to export.".format(len(episode.clips), flagged))
        else:
            state.set(Status.DONE, next_action=(
                "{} clips were flagged; they were kept and exported as cut.".format(flagged) if flagged else ""))
        self._save(record.number, Stage.EDIT, "analysed {} clips, {} flagged".format(len(episode.clips), flagged))

    # -- 5. export ----------------------------------------------------------
    def _export(self, record) -> None:
        """Export encodes the composition Editing left beside the clips (or
        the editor saved there). It never analyses again: a person's cuts
        are what is exported, and an export-only production is refused
        rather than quietly re-editing."""
        from ..assemble import build, flag_joins
        from ..autocut import mark_scene_boundaries
        from ..ingest import scan
        from ..retakes import build as build_retakes, sheet_path_for, write as write_retakes
        from ..state import load_into
        clips_dir = Path(record.clips_dir)
        config = self._export_config()
        episode = scan(clips_dir, config)                   # files and their lengths; no analysis
        loaded = load_into(episode)
        if loaded.restored == 0:
            raise ProviderError(
                "No composition is saved for {}{}. Run Editing first, or open the folder in the editor "
                "and save it.".format(clips_dir, " (" + loaded.reason + ")" if loaded.reason else ""),
                retryable=False)
        mark_scene_boundaries(episode)
        flag_joins(episode)
        if not any(c.state.value != "rejected" for c in episode.clips):
            raise ProviderError("Every clip is rejected; there is nothing to export.")
        export_dir = Path(self.production.export_dir or self.production.working_dir)
        version = len(record.exports) + 1
        stem = (self.production.final_filename or "").strip() or record.name
        output = export_dir / "{} - v{}.mp4".format(_safe_name(stem), version)
        # The file lands under a temporary name and is renamed only once the
        # encode finished and was checked, so a half-written export is never
        # mistaken for a finished one.
        partial = output.with_name(output.stem + ".part.mp4")
        from ..export_job import ExportError
        try:
            path = build(episode, config, partial, include_pending=True,
                         progress=lambda d, t, label: self._event(record.number, Stage.EXPORT, "running", label, d, t))
        except ExportError as exc:
            # The export says what stopped it and that the finished segments
            # are kept: the next run of this stage continues from them.
            raise ProviderError(str(exc), retryable=True) from exc
        problem = validate_clip(path)
        if problem:
            raise ProviderError("The export did not decode cleanly: {}".format(problem), retryable=True)
        path.replace(output)
        path = output
        from .. import teamsheet
        teamsheet.report_export(episode, path, str(getattr(config, "editor_username", "") or ""),
                                str(getattr(config, "editor_name", "") or ""), "Automatic")
        rows = build_retakes(episode)
        if rows:
            write_retakes(rows, sheet_path_for(path))
        from .manifest import ExportRecord
        from ..assemble import planned_seconds
        record.exports.append(ExportRecord(version=version, path=str(path), created=_now(),
                                           prompt_set=record.prompt_set.version if record.prompt_set else 0,
                                           clips_used=sum(1 for c in episode.clips if c.state.value != "rejected"),
                                           seconds=planned_seconds(episode, config)))
        if record.prompt_set:
            for item in record.prompt_set.items:
                item.review = "exported"
        record.stage(Stage.EXPORT).set(Status.DONE, next_action="")
        self._save(record.number, Stage.EXPORT, "exported " + path.name)

    # -------------------------------------------------------------- helpers
    def _export_config(self) -> Config:
        """The editing config with this production's video settings laid
        over it. A copy: the app's own config is never changed by a run."""
        import copy
        config = copy.copy(self.config)
        p = self.production
        if p.aspect_ratio in ("auto", "16:9", "9:16"):
            config.aspect_ratio = p.aspect_ratio
        if p.resolution in (720, 1080):
            config.output_height = int(p.resolution)
        return config

    def _complete_text(self, writer, system: str, user: str, record, stage: Stage):
        """One reply, continued if it was cut short, a bounded number of times."""
        self._event(record.number, stage, "running", "asking the model")
        result = writer.write(system, user)
        text = result.text
        continuations = 0
        while result.truncated and continuations < MAX_CONTINUATIONS:
            continuations += 1
            self._check_stop()
            self._event(record.number, stage, "running", "the reply was cut short; asking it to continue ({})".format(continuations))
            tail = text[-1500:]
            more = writer.write(system, user + "\n\nYour previous reply was cut off. Continue exactly from "
                                              "where it stopped, without repeating anything. It ended with:\n" + tail)
            text += more.text
            result = more
        result.text = text
        if result.truncated:
            raise ProviderError("The model's reply was still cut short after {} continuations; the script "
                                "would be incomplete.".format(MAX_CONTINUATIONS), retryable=False)
        return result

    def _framework_text(self, ref, what: str) -> str:
        if not ref.name:
            raise ProviderError("No {} framework is selected for this production. Add yours in the "
                                "framework library and choose it; nothing is invented in its place.".format(what))
        try:
            return self.frameworks.text(ref)
        except (KeyError, ValueError, OSError) as exc:
            raise ProviderError("The {} framework could not be read: {}".format(what, exc)) from exc

    def _episode_dir(self, record) -> Path:
        path = Path(self.production.working_dir) / "ep{:02d}".format(record.number)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def _save(self, episode: int, stage: Stage, message: str, done: int = 0, total: int = 0) -> None:
        if _lease_lost(self.stop):
            # The job went to another machine while this step ran: the
            # manifest is theirs now, and every write from here would be stale.
            raise Stopped()
        self.production.save()
        self._event(episode, stage, self.production.episode(episode).stage(stage).status, message, done, total)

    def _event(self, episode: int, stage: Stage, status: str, message: str, done: int = 0, total: int = 0) -> None:
        log.info("ep%d %s %s: %s", episode, stage.value, status, message)
        self.on_event(Event(episode, stage.value, status, message, done, total))

    def _check_stop(self) -> None:
        if self.stop.is_set():
            raise Stopped()

    def _sleep(self, seconds: float) -> None:
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            self._check_stop()
            time.sleep(min(0.2, max(0.0, end - time.monotonic())))


ORDER_INDEX = {Stage.SCRIPT: 0, Stage.PROMPTS: 1, Stage.CLIPS: 2, Stage.EDIT: 3, Stage.EXPORT: 4}
UNCONFIRMED = "unconfirmed"    # job_status: submitted, but no job id came back to track it by


def _prompt_problems(items: List[PromptItem]) -> List[str]:
    """Every prompt checked against the provider's 1..4000 characters before
    one request is sent, named by scene."""
    empty = [i.scene for i in items if not i.prompt.strip()]
    long = [i.scene for i in items if len(i.prompt.strip()) > prompt_text.MAX_PROMPT_CHARS]
    problems = []
    if empty:
        problems.append("empty prompt for scene(s) {}".format(", ".join(str(s) for s in empty[:20])))
    if long:
        problems.append("prompt over {} characters for scene(s) {}".format(
            prompt_text.MAX_PROMPT_CHARS, ", ".join(str(s) for s in long[:20])))
    return problems


def _now() -> str:
    from .manifest import now
    return now()


def _safe_name(text: str) -> str:
    """A filename stem: the characters Windows refuses are replaced."""
    cleaned = "".join("-" if ch in '<>:"/\\|?*' or ord(ch) < 32 else ch for ch in text).strip(" .")
    return cleaned[:120] or "episode"
