"""App-owned Chrome profiles. Stores account mappings, never Google secrets."""
import csv
import io
import json
import re
import time
from pathlib import Path
from .master import _write_atomic

class ManagedPool:
    def __init__(self, root):
        self.path=Path(root)/'managed-pool'/'accounts.json'
        self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}

    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        _write_atomic(self.path,json.dumps(self.data,indent=2))

    def add(self, accounts):
        for a in accounts:
            self.data.setdefault(a.email.casefold(),dict(id=a.id,email=a.email,profile_id=a.id,google_slot=0,status='needs_login',checked_at=None))
        self.save()

    def map(self, raw):
        pending={}
        for row in csv.reader(io.StringIO(raw)):
            if not row:continue
            if len(row)!=3:raise ValueError('Use email,profile name,Google slot')
            email,profile,slot=[v.strip() for v in row];email=email.casefold()
            if email not in self.data:raise ValueError('Import this Gmail first: '+email)
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',profile):raise ValueError('Profile names use letters, numbers, underscores or hyphens')
            if not re.fullmatch(r'\d{1,3}',slot):raise ValueError('Google slot must be 0 through 999')
            if email in pending:raise ValueError('Duplicate Gmail')
            pending[email]={**self.data[email], 'profile_id':profile,'google_slot':int(slot),'status':'needs_login','checked_at':None}
        if not pending or len(pending)>1000:raise ValueError('Use 1 to 1,000 rows')
        merged={**self.data,**pending}
        keys=[(v['profile_id'].casefold(),v['google_slot']) for v in merged.values()]
        if len(keys)!=len(set(keys)):raise ValueError('A profile slot can belong to only one Gmail')
        self.data=merged;self.save()

    def account(self, a):
        row=self.data.get(a['email'].casefold())
        if not row:raise ValueError('Account is not in the managed pool')
        return {**a,'managed_profile':row['profile_id'],'google_slot':row['google_slot']}

    def record(self,email,status):
        if email.casefold() in self.data:
            self.data[email.casefold()].update(status=status,checked_at=time.time());self.save()
