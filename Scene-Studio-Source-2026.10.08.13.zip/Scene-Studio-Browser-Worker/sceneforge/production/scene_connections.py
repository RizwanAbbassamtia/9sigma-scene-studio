"""Local connection observations. No passwords, cookies, or Google tokens."""
import json
import time
from pathlib import Path

from .master import _write_atomic


class ConnectionBook:
    def __init__(self, root):
        self.path = Path(root) / 'scene-server' / 'connections.json'
        self.entries = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
        # A closed/crashed app cannot still be waiting for a user to sign in.
        for entry in self.entries.values():
            for value in entry.values():
                if value.get('state') == 'waiting':
                    value.update(state='needs_login', message='Sign-in was interrupted. Try again.')

    def get(self, account_id):
        return self.entries.get(account_id, {})

    def record(self, account_id, provider, state, message=''):
        if provider not in ('flow', 'gemini') or state not in ('waiting', 'connected', 'needs_login', 'manual'):
            raise ValueError('Invalid connection state')
        self.entries.setdefault(account_id, {})[provider] = dict(
            state=state, checked_at=time.time(), message=message[:500])
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _write_atomic(self.path, json.dumps(self.entries, ensure_ascii=False, indent=2))
