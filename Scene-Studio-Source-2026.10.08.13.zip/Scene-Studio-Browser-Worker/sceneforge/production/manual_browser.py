"""Open user-controlled Chrome profiles; never attach an automation driver."""
import subprocess
from pathlib import Path

from .chrome_runtime import resolve_chrome
from .profile_proxy import ProfileProxies
from .flow_browser import GOOGLE_SIGN_IN_URL


def open_manual_profile(root, account, services=False):
    root = Path(root).resolve()
    profile = account.get('managed_profile', account['id'])
    ProfileProxies.key(profile)
    # Manual sessions remain separate from the automation browser storage.
    folder = root / 'manual-browser-profiles' / profile
    proxy = ProfileProxies(root).summary(profile)
    args = [str(resolve_chrome(root)), '--user-data-dir=' + str(folder)]
    if proxy.get('enabled'):
        host = proxy['host']
        host = '[' + host + ']' if ':' in host else host
        args.append('--proxy-server={mode}://{host}:{port}'.format(host=host, **{k:proxy[k] for k in ('mode','port')}))
    else:
        args.append('--no-proxy-server')
    args.extend(['--new-window'] + (['https://flow.google.com/', 'https://gemini.google.com/app'] if services else [GOOGLE_SIGN_IN_URL]))
    folder.mkdir(parents=True, exist_ok=True)
    try:
        child = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, close_fds=True)
    except OSError:
        raise RuntimeError('Chrome could not open. Check the configured Chrome installation and retry.') from None
    # A process ID is an observation of launch only, never proof of Google login.
    return {'opened':True, 'mode':'manual', 'profile':profile, 'pid':child.pid,
            'proxy_authentication':bool(proxy.get('enabled') and proxy.get('username')),
            'message':'Chrome opened for manual sign-in. Login is not verified by the app.'}
