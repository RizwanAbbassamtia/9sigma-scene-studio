"""Sequential Flow work using fresh browser observations, never estimated balances.

The ledger is local SQLite, not a database placed on the shared master folder.
An interrupted submission is held for review instead of being submitted twice.
"""
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import sqlite3
import time


@dataclass(frozen=True)
class BrowserSettings:
    model: str = "Omni 1.1 Flash"
    aspect: str = "16:9"
    resolution: str = "720p"
    duration: str = "10s"

    def validate(self):
        if self.aspect not in ("16:9", "9:16"):
            raise ValueError("Choose 16:9 or 9:16")
        if self.model not in ("Omni 1.1 Flash", "Veo 3.1 - Lite", "Veo 3.1 - Fast", "Veo 3.1 - Quality"):
            raise ValueError("Choose a supported model")
        if self.resolution not in ("360p", "720p") or self.duration not in ("4s", "6s", "8s", "10s"):
            raise ValueError("Choose a listed resolution and duration")
        if self.model.startswith("Veo") and (self.duration == "10s" or self.resolution == "360p"):
            raise ValueError("Veo does not generate native 10-second or 360p clips. Choose Omni 1.1 Flash.")


@dataclass(frozen=True)
class LiveQuote:
    email: str
    balance: int
    cost: int
    observed: float

    def verify(self, expected_email):
        if self.email.casefold() != expected_email.casefold():
            raise RuntimeError("The browser is signed in to a different account; no generation submitted")
        if type(self.balance) is not int or type(self.cost) is not int or self.balance < 0 or self.cost <= 0:
            raise RuntimeError("Flow did not provide an unambiguous balance and positive cost")
        if not 0 <= time.time() - self.observed <= 30:
            raise RuntimeError("Credit reading is stale; refresh before generation")


class RunLedger:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.folder / "run.sqlite"), timeout=1)
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS scenes(
                number INTEGER PRIMARY KEY, prompt TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'todo',
                account TEXT, before_credit INTEGER, quoted INTEGER, after_credit INTEGER,
                receipt TEXT, file TEXT, note TEXT);
        ''')
        self.db.commit()

    def create(self, prompts, settings, budget=None):
        settings.validate()
        if not prompts or any(not p.strip() for p in prompts):
            raise ValueError("Enter at least one nonempty prompt")
        if self.db.execute("SELECT COUNT(*) FROM scenes").fetchone()[0]:
            raise ValueError("This run already exists; choose Resume")
        with self.db:
            self.db.execute("INSERT INTO config VALUES ('settings',?)", (json.dumps(asdict(settings)),))
            if budget is not None:
                if type(budget) is not int or budget <= 0:
                    raise ValueError('Enter a positive credit limit')
                self.db.execute("INSERT INTO config VALUES ('budget',?)", (str(budget),))
            self.db.executemany("INSERT INTO scenes(number,prompt) VALUES (?,?)", enumerate(prompts, 1))

    def settings(self):
        return BrowserSettings(**json.loads(self.db.execute("SELECT value FROM config WHERE key='settings'").fetchone()[0]))

    def rows(self):
        cursor = self.db.execute("SELECT * FROM scenes ORDER BY number")
        names = [c[0] for c in cursor.description]
        return [dict(zip(names, row)) for row in cursor]

    def update(self, number, **values):
        allowed = {'status', 'account', 'before_credit', 'quoted', 'after_credit', 'receipt', 'file', 'note'}
        if not values or not set(values) <= allowed:
            raise ValueError("Invalid ledger update")
        with self.db:
            self.db.execute("UPDATE scenes SET " + ','.join(k + '=?' for k in values) + ' WHERE number=?',
                            (*values.values(), number))

    def claim(self, number, account, quote):
        # Only one worker can transition this scene to submitting.
        with self.db:
            updated = self.db.execute('''UPDATE scenes SET status='submitting', account=?,
                before_credit=?, quoted=? WHERE number=? AND status='todo' ''',
                (account, quote.balance, quote.cost, number)).rowcount
        if updated != 1:
            raise RuntimeError("Another worker already claimed this scene")

    def close(self):
        self.db.close()


def execute(ledger, accounts, browser, emit=lambda s: None, stopped=lambda: False):
    """browser: open, quote, submit, finish, balance, close. One output per scene."""
    settings = ledger.settings()
    settings.validate()
    rows = ledger.rows()
    if any(r['status'] not in ('todo', 'done') for r in rows):
        raise RuntimeError("An earlier scene needs review. Do not retry an uncertain submission; check Flow first")
    account_index = 0
    active = None
    try:
        for row in rows:
            if row['status'] == 'done':
                continue
            if stopped():
                return "Stopped before the next scene"
            while account_index < len(accounts):
                account = accounts[account_index]
                if active != account['id']:
                    browser.open(account)
                    active = account['id']
                quote = browser.quote(settings, row['prompt'])
                quote.verify(account['email'])
                emit("Scene {}: {} has {} credits; Flow quotes {}".format(row['number'], account['id'], quote.balance, quote.cost))
                if quote.balance >= quote.cost:
                    break
                emit("{} cannot cover the next scene; switching accounts".format(account['id']))
                account_index += 1
            else:
                return "Waiting for credits: all selected accounts are insufficient; remaining scenes are saved"
            if stopped():
                return "Stopped before submission"
            cap = ledger.db.execute("SELECT value FROM config WHERE key='budget'").fetchone()
            used = sum((r['before_credit'] - r['after_credit']) for r in ledger.rows() if r['status'] == 'done')
            if cap and used + quote.cost > int(cap[0]):
                return 'Credit limit reached; remaining scenes are saved without submission'
            number = row['number']
            ledger.claim(number, account['id'], quote)
            try:
                # A durable intent exists BEFORE the browser submits anything.
                receipt = browser.submit(row['prompt'])
                ledger.update(number, status='generating', receipt=receipt)
                dest = ledger.folder / ('{:03d}_scene{}_clip1.mp4'.format(number, number))
                if dest.exists():
                    raise RuntimeError("Output already exists; refusing to overwrite it")
                browser.finish(receipt, dest)
                email, balance = browser.balance()
                if email.casefold() != account['email'].casefold() or type(balance) is not int or balance < 0:
                    raise RuntimeError("Could not confirm the same account's resulting balance")
                if quote.balance - balance != quote.cost:
                    ledger.update(number, status='review', after_credit=balance, file=str(dest),
                                  note='Actual deduction differs from quote; check Flow before continuing')
                    return "Stopped: the actual credit change differs from Google's quote"
                ledger.update(number, status='done', after_credit=balance, file=str(dest))
                emit("Scene {} saved; confirmed balance {}".format(number, balance))
            except Exception as exc:
                ledger.update(number, status='review', note=str(exc)[:500])
                raise
        return "All scenes saved in order"
    finally:
        browser.close()
