"""Google Flow accounts: an inventory of the accounts editors generate clips
in by hand, with the credits each one had when someone last looked, and a
manual production queue that says which clip goes to which account and
which person.

Everything here is bookkeeping for work done by a person in a browser.
Google offers no API for Flow accounts or their credits, so this module
never signs in to Google, never stores a Google password and never drives
flow.google.com: the credit figure is what a person typed after reading it
off the screen, and a clip is 'done' when the person drops the file into
the clips folder and Refresh finds it.

The inventory lives in the master folder (flow-accounts.json, written under
the master log's cross-machine lock like titles.json, with a read-only CSV
mirror for Excel); the queue lives next to the production it is for
(<working>/manual-queue.json, one list per episode). Text read from either
file was written by another machine, so it is cleaned with _one_line before
it reaches a screen, a CSV cell or a log line.
"""
from __future__ import annotations

import csv
import io
import json
import os
import re
from dataclasses import dataclass, field, fields
from datetime import date, datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

from ..logging_setup import get
from .manifest import PromptItem, now
from .master import (
    EMAIL, FLOW_ACCOUNTS_NAME, FLOW_STATUS_SHEET, MasterLog, _cell, _lines, _one_line, _raw, _read_json,
    _write_atomic, safe_name,
)
from .prompts import clip_filename
from .providers import validate_clip

log = get("production.flow_accounts")

ACCOUNT_STATUSES = ("active", "low", "exhausted", "paused")
ACCOUNT_ID = re.compile(r"^FA-(\d{3,})$")
LOW_CLIPS = 10                         # an account with fewer clips' worth of credits than this is 'low'
DEFAULT_COST_PER_CLIP = 20             # credits one clip costs, until the page says otherwise
LABEL_MAX = 80
NAME_MAX = 80
HISTORY_MAX = 200                      # entries kept per account; the oldest go first
RENEWAL_DAY_MAX = 28                   # a renewal day every month has
RENEWAL_BY = "renewal (assumed)"       # credits_checked_by when the tool assumed the monthly figure

QUEUE_NAME = "manual-queue.json"
FLOW_QUEUE_DIR = "flow-queue"           # under the shared folder: one queue and one clips folder per title
QUEUE_STATUSES = ("todo", "generating", "done", "failed")
VIDEO_SUFFIXES = (".mp4", ".mov", ".mkv", ".webm", ".m4v")
STATUS_COLUMNS = ("id", "label", "email", "credits", "checked", "checked_by", "cost_per_clip", "clips_left",
                  "status", "editor", "notes", "monthly_credits", "renews_on_day", "last_renewed")
# "12.mp4", "12 - anything.mp4", "scene12.mp4", "scene12_clip2 (1).mp4", "Scene 12 clip 2.mp4"
_LEADING_NUMBER = re.compile(r"^\s*(\d+)")
_SCENE_NUMBER = re.compile(r"^\s*scene\s*[_-]?\s*(\d+)(?:\s*[_-]?\s*clip\s*[_-]?\s*(\d+))?", re.IGNORECASE)


# ------------------------------------------------------------------ accounts
@dataclass
class FlowAccount:
    """One Google account someone generates in. The email is for people
    to tell accounts apart; nothing signs in with it."""
    id: str                            # FA-001, FA-002, ...: given once, never reused
    label: str = ""
    email: str = ""
    credits_last_seen: int = 0
    credits_checked_at: str = ""
    credits_checked_by: str = ""
    credit_cost_per_clip: int = DEFAULT_COST_PER_CLIP
    status: str = "active"             # active | low | exhausted | paused
    assigned_editor: str = ""
    notes: str = ""
    chrome_profile: str = ""           # the person's own Chrome profile directory ("Profile 2"); may be empty
    daily_credits: int = 0             # opt-in midnight Pacific planning estimate
    daily_remaining: int = 0
    daily_reset_date: str = ""
    monthly_credits: int = 0           # what the plan gives back each month (Plus 200, Pro 1,000...); 0 = none
    renews_on_day: int = 0             # day of the month the billing cycle starts, 1..28; 0 = not known
    last_renewed: str = ""             # ISO date of the last renewal the tool assumed (or saw entered)
    history: List[Dict[str, object]] = field(default_factory=list)
    created: str = field(default_factory=now)


def clips_left(account: FlowAccount) -> int:
    """How many clips the credits last seen pay for."""
    cost = max(1, int(account.credit_cost_per_clip or 0))
    return max(0, int(account.credits_last_seen or 0)) // cost


def status_for(account: FlowAccount) -> str:
    """The status the credits imply. A paused account stays paused: that
    is a person's decision, undone only by resume()."""
    if account.status == "paused":
        return "paused"
    cost = max(1, int(account.credit_cost_per_clip or 0))
    credits = int(account.credits_last_seen or 0)
    if credits < cost:
        return "exhausted"
    if credits < cost * LOW_CLIPS:
        return "low"
    return "active"


def renewal_date(today: date, day: int) -> date:
    """The most recent day-of-month `day` on or before `today`: this
    month's when it has passed (or is today), else last month's."""
    day = int(day)
    if today.day >= day:
        return today.replace(day=day)
    year, month = (today.year - 1, 12) if today.month == 1 else (today.year, today.month - 1)
    return date(year, month, day)


def _iso_date(text) -> str:
    """An ISO date ('2026-09-05') or nothing; a timestamp keeps its date."""
    text = _one_line(text).strip()[:10]
    try:
        return date.fromisoformat(text).isoformat()
    except ValueError:
        return ""


def pacific_day(at: Optional[datetime] = None) -> date:
    """Pacific date using US DST rules since 2007; no Windows tzdata dependency.

    Reset is the owner's estimate, not a reading of Google's balance.
    """
    at = at or datetime.now(timezone.utc)
    if at.tzinfo is None:
        raise ValueError("An aware timestamp is required")
    utc = at.astimezone(timezone.utc)
    march = datetime(utc.year, 3, 8, 10, tzinfo=timezone.utc)
    start = march + timedelta(days=(6 - march.weekday()) % 7)
    november = datetime(utc.year, 11, 1, 9, tzinfo=timezone.utc)
    end = november + timedelta(days=(6 - november.weekday()) % 7)
    return (utc - timedelta(hours=7 if start <= utc < end else 8)).date()


def apply_daily_renewals(accounts, at: Optional[datetime] = None):
    at = at or datetime.now(timezone.utc)
    day = pacific_day(at).isoformat()
    changed = []
    for account in accounts:
        if account.daily_credits <= 0 or account.daily_reset_date >= day:
            continue
        # Replace today's allowance; never accumulate unused daily credits.
        other = max(0, account.credits_last_seen - account.daily_remaining)
        account.daily_remaining = account.daily_credits
        account.credits_last_seen = other + account.daily_remaining
        account.daily_reset_date = day
        account.credits_checked_at = at.isoformat()
        account.credits_checked_by = RENEWAL_BY
        account.status = status_for(account)
        FlowAccountBook._note(account, RENEWAL_BY, "daily renewal",
                              "Midnight Pacific estimate; confirm the balance in Flow",
                              credits=account.credits_last_seen, at=at.isoformat())
        changed.append(account)
    return changed


def apply_renewals(accounts: Iterable[FlowAccount], today: Optional[date] = None,
                   at: str = "") -> List[FlowAccount]:
    """Google Flow gives a plan's credits back on the day the billing cycle
    starts. For every account with a monthly figure and a day, when that
    day has come round since the last renewal noted, the credits are set
    to the monthly figure and marked as assumed, until someone reads Flow
    and presses Set credits. A figure a person entered on or after the
    renewal date is the truth and is never lowered by the assumption: the
    renewal is only noted as seen. Returns the accounts changed; nothing
    is written here."""
    today = today or datetime.now(timezone.utc).date()
    at = at or now()
    changed = []
    for account in accounts:
        monthly = max(0, _int(account.monthly_credits))
        day = _int(account.renews_on_day)
        if monthly <= 0 or not 1 <= day <= RENEWAL_DAY_MAX:
            continue
        due = renewal_date(today, day)
        if _iso_date(account.last_renewed) >= due.isoformat():
            continue
        seen = _iso_date(account.credits_checked_at)
        by_person = account.credits_checked_by and account.credits_checked_by != RENEWAL_BY
        if by_person and seen >= due.isoformat():
            note = "renewed: day {} passed; {} credits kept as seen by {} on {}".format(
                day, account.credits_last_seen, account.credits_checked_by, seen)
            FlowAccountBook._note(account, RENEWAL_BY, "renewed", note, credits=account.credits_last_seen, at=at)
        else:
            account.credits_last_seen = monthly + account.daily_remaining
            account.credits_checked_at = at
            account.credits_checked_by = RENEWAL_BY
            account.status = status_for(account)
            FlowAccountBook._note(account, RENEWAL_BY, "renewed",
                                  "renewed: {} credits assumed on day {}; check Flow and press Set credits "
                                  "if different".format(monthly, day), credits=monthly, at=at)
        account.last_renewed = due.isoformat()
        changed.append(account)
    return changed


def next_account_id(accounts: Iterable[FlowAccount]) -> str:
    highest = 0
    for account in accounts:
        match = ACCOUNT_ID.match(str(getattr(account, "id", "") or "").strip())
        if match:
            highest = max(highest, int(match.group(1)))
    return "FA-{:03d}".format(highest + 1)


def clean_email(email) -> str:
    """One address or nothing; anything else is refused in words."""
    text = _one_line(email).strip()
    if text and not EMAIL.match(text):
        raise ValueError("The email must be one address like name@gmail.com, with no spaces, commas or "
                         "brackets.")
    return text[:200]


def clean_profile(profile) -> str:
    """A Chrome profile directory name ("Default", "Profile 3") or nothing.
    It goes on Chrome's command line, so it is one plain name: no path
    separators and never something that starts like a flag."""
    text = _one_line(profile).strip()[:NAME_MAX]
    if text.startswith("-") or "/" in text or "\\" in text:
        return ""
    return text


def _int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _account_from(entry) -> FlowAccount:
    if not isinstance(entry, dict):
        raise TypeError("not an account")
    known = {f.name for f in fields(FlowAccount)}
    account = FlowAccount(**{k: v for k, v in entry.items() if k in known})
    for name in ("id", "label", "email", "credits_checked_at", "credits_checked_by", "status",
                 "assigned_editor", "chrome_profile", "created"):
        value = getattr(account, name)
        setattr(account, name, _one_line("" if value is None else str(value)))
    account.label = account.label[:LABEL_MAX]
    account.assigned_editor = account.assigned_editor[:NAME_MAX]
    account.chrome_profile = clean_profile(account.chrome_profile)
    account.credits_checked_by = account.credits_checked_by[:NAME_MAX]
    account.notes = _lines("" if account.notes is None else str(account.notes))
    account.credits_last_seen = max(0, _int(account.credits_last_seen))
    account.credit_cost_per_clip = max(1, _int(account.credit_cost_per_clip, DEFAULT_COST_PER_CLIP))
    account.daily_credits = max(0, _int(account.daily_credits))
    account.daily_remaining = min(account.credits_last_seen, account.daily_credits, max(0, _int(account.daily_remaining)))
    account.daily_reset_date = _iso_date(account.daily_reset_date)
    account.monthly_credits = max(0, _int(account.monthly_credits))
    account.renews_on_day = min(RENEWAL_DAY_MAX, max(0, _int(account.renews_on_day)))
    account.last_renewed = _iso_date(account.last_renewed)
    if account.status not in ACCOUNT_STATUSES:
        account.status = "active"
    account.status = status_for(account)
    history = account.history if isinstance(account.history, list) else []
    account.history = [{"at": _one_line(h.get("at", "")), "by": _one_line(h.get("by", ""))[:NAME_MAX],
                        "event": _one_line(h.get("event", ""))[:40], "credits": _int(h.get("credits"), -1),
                        "note": _one_line(h.get("note", ""))[:400]}
                       for h in history if isinstance(h, dict)][-HISTORY_MAX:]
    return account


class FlowAccountBook:
    """The inventory, kept in the master folder and written under the
    master log's lock so two machines never lose each other's changes.
    Every change re-reads the file under the lock, applies itself and
    writes the whole file back; LockBroken from the log propagates, and
    nothing is written then."""

    def __init__(self, master: MasterLog):
        self.master = master
        self.path = master.flow_accounts_path
        self.sheet_path = master.flow_status_sheet

    # -- reads ----------------------------------------------------------------
    def accounts(self) -> List[FlowAccount]:
        with self.master._lock:
            return self._load()[1]

    def account(self, account_id: str) -> FlowAccount:
        return self._find(self.accounts(), account_id)

    def default_cost(self) -> int:
        with self.master._lock:
            return self._load()[0]

    def next_for(self, editor: str) -> Optional[FlowAccount]:
        """The active account with the most credits, assigned to this
        editor or to nobody. 'low' still generates, so it counts when no
        active one is left; exhausted and paused never do."""
        editor = _one_line(editor).strip().casefold()
        best = None
        for status in ("active", "low"):
            for account in self.accounts():
                if account.status != status:
                    continue
                owner = account.assigned_editor.strip().casefold()
                if owner and owner != editor:
                    continue
                if best is None or account.credits_last_seen > best.credits_last_seen:
                    best = account
            if best is not None:
                return best
        return None

    # -- writes ---------------------------------------------------------------
    def set_default_cost(self, cost: int, by: str = "") -> int:
        cost = self._check_cost(cost)

        def change(accounts, _cost):
            return cost
        self._change(change)
        return cost

    def add(self, label: str, email: str = "", credits: int = 0, cost: Optional[int] = None,
            editor: str = "", notes: str = "", by: str = "", chrome_profile: str = "",
            monthly_credits: int = 0, renews_on_day: int = 0, daily_credits: int = 0) -> FlowAccount:
        label = self._check_label(label)
        email = clean_email(email)
        credits = self._check_credits(credits)
        cost = None if cost is None else self._check_cost(cost)
        editor = _one_line(editor)[:NAME_MAX]
        notes = _lines(notes)
        by = _one_line(by)[:NAME_MAX]
        chrome_profile = clean_profile(chrome_profile)
        monthly_credits = self._check_monthly(monthly_credits)
        renews_on_day = self._check_day(renews_on_day)
        daily_credits = self._check_credits(daily_credits)
        made = {}

        def change(accounts, default_cost):
            stamp = now()
            account = FlowAccount(id=next_account_id(accounts), label=label, email=email,
                                  credits_last_seen=credits, credits_checked_at=stamp if credits else "",
                                  credits_checked_by=by if credits else "",
                                  credit_cost_per_clip=default_cost if cost is None else cost,
                                  assigned_editor=editor, notes=notes, chrome_profile=chrome_profile,
                                  monthly_credits=monthly_credits, renews_on_day=renews_on_day,
                                  daily_credits=daily_credits, daily_remaining=min(credits, daily_credits),
                                  daily_reset_date=pacific_day().isoformat() if daily_credits else "",
                                  created=stamp,
                                  history=[{"at": stamp, "by": by, "event": "added", "credits": credits,
                                            "note": "added by {}".format(by or "?")}])
            account.status = status_for(account)
            accounts.append(account)
            made["account"] = account
            return default_cost
        self._change(change)
        return made["account"]

    def update(self, account_id: str, label: Optional[str] = None, email: Optional[str] = None,
               cost: Optional[int] = None, notes: Optional[str] = None, by: str = "",
               chrome_profile: Optional[str] = None, monthly_credits: Optional[int] = None,
               renews_on_day: Optional[int] = None, daily_credits: Optional[int] = None) -> FlowAccount:
        account_id = self._check_id(account_id)
        label = None if label is None else self._check_label(label)
        email = None if email is None else clean_email(email)
        cost = None if cost is None else self._check_cost(cost)
        notes = None if notes is None else _lines(notes)
        by = _one_line(by)[:NAME_MAX]
        chrome_profile = None if chrome_profile is None else clean_profile(chrome_profile)
        monthly_credits = None if monthly_credits is None else self._check_monthly(monthly_credits)
        renews_on_day = None if renews_on_day is None else self._check_day(renews_on_day)
        daily_credits = None if daily_credits is None else self._check_credits(daily_credits)
        found = {}

        def change(accounts, default_cost):
            account = self._find(accounts, account_id)
            if label is not None:
                account.label = label
            if email is not None:
                account.email = email
            if cost is not None:
                account.credit_cost_per_clip = cost
            if notes is not None:
                account.notes = notes
            if chrome_profile is not None:
                account.chrome_profile = chrome_profile
            if daily_credits is not None and daily_credits != account.daily_credits:
                # Enabling daily tracking classifies existing credits; adds no money.
                account.daily_credits = daily_credits
                account.daily_remaining = min(account.credits_last_seen, daily_credits)
                account.daily_reset_date = pacific_day().isoformat()
            if monthly_credits is not None:
                account.monthly_credits = monthly_credits
            if renews_on_day is not None:
                account.renews_on_day = renews_on_day
            account.status = status_for(account)
            self._note(account, by, "edited", "details edited by {}".format(by or "?"))
            found["account"] = account
            return default_cost
        self._change(change)
        return found["account"]

    def set_credits(self, account_id: str, credits: int, by: str = "", note: str = "") -> FlowAccount:
        """The number a person reads in Flow now. Recorded with who and
        when; the status follows from it."""
        account_id = self._check_id(account_id)
        credits = self._check_credits(credits)
        by = _one_line(by)[:NAME_MAX]
        note = _one_line(note)[:400]
        found = {}

        def change(accounts, default_cost):
            account = self._find(accounts, account_id)
            before = account.credits_last_seen
            stamp = now()
            if account.daily_credits:
                spent = max(0, before - credits)
                account.daily_remaining = min(credits, max(0, account.daily_remaining - spent))
                account.daily_reset_date = pacific_day().isoformat()
            account.credits_last_seen = credits
            account.credits_checked_at = stamp
            account.credits_checked_by = by
            account.status = status_for(account)
            self._note(account, by, "credits", note or "credits {} -> {} seen by {}".format(
                before, credits, by or "?"), credits=credits, at=stamp)
            found["account"] = account
            return default_cost
        self._change(change)
        return found["account"]

    def set_balances(self, account_id, daily, other, by=""):
        daily, other = self._check_credits(daily), self._check_credits(other)
        found = {}
        def change(accounts, cost):
            account = self._find(accounts, account_id)
            if daily > account.daily_credits:
                raise ValueError("Daily remaining cannot exceed the daily allowance")
            account.daily_remaining = daily
            account.credits_last_seen = daily + other
            account.daily_reset_date = pacific_day().isoformat()
            account.credits_checked_at = now()
            account.credits_checked_by = _one_line(by)
            account.status = status_for(account)
            self._note(account, by, "credits", "Daily and other balances confirmed", credits=daily + other)
            found["account"] = account
            return cost
        self._change(change)
        return found["account"]

    def add_many(self, text, daily=50, cost=20, by="", profiles=None):
        """Validate everything first, then add nonduplicate addresses in one lock."""
        emails = list(dict.fromkeys(clean_email(x).casefold() for x in re.split(r"[\s,;]+", text.strip()) if x))
        if not emails:
            raise ValueError("Paste at least one email address")
        daily, cost = self._check_credits(daily), self._check_cost(cost)
        profiles = profiles or {}
        result = {"added": 0, "skipped": 0}
        def change(accounts, default_cost):
            known = {a.email.casefold() for a in accounts}
            next_id = int(next_account_id(accounts).split("-")[1])
            for email in emails:
                if email in known:
                    result["skipped"] += 1
                    continue
                account = FlowAccount(id="FA-{:03d}".format(next_id), label=email[:LABEL_MAX], email=email,
                                      daily_credits=daily, daily_remaining=daily, credits_last_seen=daily,
                                      daily_reset_date=pacific_day().isoformat(), credit_cost_per_clip=cost,
                                      chrome_profile=clean_profile(profiles.get(email, "")),
                                      credits_checked_at=now(), credits_checked_by=RENEWAL_BY)
                account.status = status_for(account)
                self._note(account, by, "added", "Bulk import; starting credits are assumed", credits=daily)
                accounts.append(account)
                next_id += 1
                result["added"] += 1
            return default_cost
        self._change(change)
        return result

    def assign(self, account_id: str, editor: str, by: str = "") -> FlowAccount:
        account_id = self._check_id(account_id)
        editor = _one_line(editor)[:NAME_MAX]
        by = _one_line(by)[:NAME_MAX]
        found = {}

        def change(accounts, default_cost):
            account = self._find(accounts, account_id)
            account.assigned_editor = editor
            self._note(account, by, "assigned", "assigned to {} by {}".format(editor or "nobody", by or "?"))
            found["account"] = account
            return default_cost
        self._change(change)
        return found["account"]

    def pause(self, account_id: str, by: str = "", note: str = "") -> FlowAccount:
        return self._set_paused(account_id, True, by, note)

    def resume(self, account_id: str, by: str = "", note: str = "") -> FlowAccount:
        return self._set_paused(account_id, False, by, note)

    def _set_paused(self, account_id: str, paused: bool, by: str, note: str) -> FlowAccount:
        account_id = self._check_id(account_id)
        by = _one_line(by)[:NAME_MAX]
        note = _one_line(note)[:400]
        found = {}

        def change(accounts, default_cost):
            account = self._find(accounts, account_id)
            if paused:
                account.status = "paused"
            elif account.status == "paused":
                account.status = "active"
                account.status = status_for(account)
            self._note(account, by, "paused" if paused else "resumed",
                       note or "{} by {}".format("paused" if paused else "resumed", by or "?"))
            found["account"] = account
            return default_cost
        self._change(change)
        return found["account"]

    def renew(self, today: Optional[date] = None) -> List[FlowAccount]:
        """apply_renewals on the file, under the lock; the file is written
        only when an account changed. Returns the accounts changed."""
        renewed = []
        with self.master._lock, self.master._file_lock():
            default_cost, accounts = self._load()
            # Monthly logic first so a daily assumption cannot mask a confirmed balance.
            renewed = apply_renewals(accounts, today)
            daily = apply_daily_renewals(accounts)
            renewed = list({a.id: a for a in renewed + daily}.values())
            if renewed:
                self._save(default_cost, accounts)
        if renewed:
            self.master._best_effort(lambda: self._write_sheet(accounts), "refresh " + FLOW_STATUS_SHEET)
        return renewed

    def export_status_csv(self) -> Path:
        with self.master._lock:
            _, accounts = self._load()
        return self._write_sheet(accounts)

    # -- internals ------------------------------------------------------------
    def _change(self, change) -> None:
        """One change: read under the lock, apply, write back, mirror."""
        with self.master._lock, self.master._file_lock():
            default_cost, accounts = self._load()
            default_cost = change(accounts, default_cost)
            self._save(default_cost, accounts)
        self.master._best_effort(lambda: self._write_sheet(accounts), "refresh " + FLOW_STATUS_SHEET)

    def _load(self):
        raw = _read_json(self.path)
        if raw is None and not self.master.folder.is_dir():
            raise OSError("The master log folder is not reachable: {}".format(self.master.folder))
        entries = raw.get("accounts") if isinstance(raw, dict) else raw
        default_cost = DEFAULT_COST_PER_CLIP
        if isinstance(raw, dict):
            default_cost = max(1, _int(raw.get("default_cost_per_clip"), DEFAULT_COST_PER_CLIP))
        accounts, seen = [], set()
        for entry in entries if isinstance(entries, list) else []:
            try:
                account = _account_from(entry)
            except (TypeError, ValueError, AttributeError):
                self.master._report("{} entry {!r}".format(FLOW_ACCOUNTS_NAME, entry)[:120] +
                                    " is not an account; skipped")
                continue
            if not ACCOUNT_ID.match(account.id):
                self.master._report("{} account with id {!r} skipped: an id looks like FA-001".format(
                    FLOW_ACCOUNTS_NAME, account.id[:40]))
                continue
            if account.id in seen:
                self.master._report("{} has account {} twice; the first one is kept".format(
                    FLOW_ACCOUNTS_NAME, account.id))
                continue
            seen.add(account.id)
            accounts.append(account)
        return default_cost, accounts

    def _save(self, default_cost: int, accounts: List[FlowAccount]) -> None:
        self.master._check_held()
        payload = {"format_version": 1, "updated": now(), "default_cost_per_clip": int(default_cost),
                   "accounts": [_raw(a) for a in accounts]}
        _write_atomic(self.path, json.dumps(payload, indent=2, ensure_ascii=False), check=self.master._check_held)

    def _write_sheet(self, accounts: List[FlowAccount]) -> Path:
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(STATUS_COLUMNS)
        for account in accounts:
            writer.writerow([_cell(v) for v in (
                account.id, account.label, account.email, account.credits_last_seen, account.credits_checked_at,
                account.credits_checked_by, account.credit_cost_per_clip, clips_left(account), account.status,
                account.assigned_editor, _one_line(account.notes), account.monthly_credits, account.renews_on_day,
                account.last_renewed)])
        _write_atomic(self.sheet_path, buffer.getvalue(), encoding="utf-8-sig")
        return self.sheet_path

    @staticmethod
    def _note(account: FlowAccount, by: str, event: str, note: str, credits: int = -1, at: str = "") -> None:
        account.history.append({"at": at or now(), "by": by, "event": event, "credits": credits,
                                "note": _one_line(note)[:400]})
        del account.history[:-HISTORY_MAX]

    @staticmethod
    def _find(accounts: List[FlowAccount], account_id: str) -> FlowAccount:
        for account in accounts:
            if account.id == account_id:
                return account
        raise KeyError("There is no Flow account {} in the inventory.".format(account_id))

    @staticmethod
    def _check_id(account_id) -> str:
        account_id = str(account_id or "").strip()
        if not ACCOUNT_ID.match(account_id):
            raise ValueError("'{}' is not a Flow account id (they look like FA-001).".format(account_id[:40]))
        return account_id

    @staticmethod
    def _check_label(label) -> str:
        text = _one_line(label).strip()
        if not text:
            raise ValueError("The account needs a label, like 'Flow 3 (Rizwan)'.")
        return text[:LABEL_MAX]

    @staticmethod
    def _check_credits(credits) -> int:
        try:
            value = int(credits)
        except (TypeError, ValueError):
            raise ValueError("Credits must be a whole number, the one Flow shows.")
        if value < 0:
            raise ValueError("Credits cannot be below zero.")
        return value

    @staticmethod
    def _check_cost(cost) -> int:
        try:
            value = int(cost)
        except (TypeError, ValueError):
            raise ValueError("The cost per clip must be a whole number of credits.")
        if value < 1:
            raise ValueError("The cost per clip must be at least 1 credit.")
        return value

    @staticmethod
    def _check_monthly(credits) -> int:
        try:
            value = int(credits)
        except (TypeError, ValueError):
            raise ValueError("Monthly credits must be a whole number (0 when the plan gives none).")
        if value < 0:
            raise ValueError("Monthly credits cannot be below zero.")
        return value

    @staticmethod
    def _check_day(day) -> int:
        try:
            value = int(day)
        except (TypeError, ValueError):
            raise ValueError("The renewal day must be a day of the month, 1 to {} (0 for none).".format(
                RENEWAL_DAY_MAX))
        if not 0 <= value <= RENEWAL_DAY_MAX:
            raise ValueError("The renewal day must be between 1 and {} (0 for none).".format(RENEWAL_DAY_MAX))
        return value


# --------------------------------------------------------------- the queue
@dataclass
class QueueRow:
    """One clip a person will generate: which prompt, in which account, by
    whom, and whether the file has arrived."""
    scene: int
    clip: int = 1
    sequence: int = 0
    prompt: str = ""
    account_id: str = ""
    editor: str = ""
    status: str = "todo"               # todo | generating | done | failed
    file: str = ""                     # the file name inside the clips folder
    note: str = ""
    updated: str = ""
    # Automatic generation (Gemini): the provider's job id is written the
    # moment it is known, so a run cut short is resumed by polling, never
    # by paying for the clip twice.
    job_id: str = ""
    job_status: str = ""               # queued | running | done | failed, as the provider last said
    job_model: str = ""

    @property
    def key(self) -> str:
        return "{}.{}".format(self.scene, self.clip)

    @property
    def filename(self) -> str:
        """The name the app gives this clip (prompts.clip_filename)."""
        return clip_filename(PromptItem(scene=self.scene, clip=self.clip, sequence=self.sequence))


def _row_from(entry) -> QueueRow:
    if not isinstance(entry, dict):
        raise TypeError("not a row")
    known = {f.name for f in fields(QueueRow)}
    row = QueueRow(**{k: v for k, v in entry.items() if k in known})
    row.scene = _int(row.scene)
    row.clip = max(1, _int(row.clip, 1))
    row.sequence = _int(row.sequence)
    row.prompt = _lines(row.prompt)
    for name in ("account_id", "editor", "status", "file", "note", "updated", "job_id", "job_status", "job_model"):
        setattr(row, name, _one_line(getattr(row, name))[:400])
    if not ACCOUNT_ID.match(row.account_id):
        row.account_id = ""
    if row.status not in QUEUE_STATUSES:
        row.status = "todo"
    # A file name from the JSON is only ever joined to the clips folder as
    # a bare name: no folder parts, whatever the file says.
    row.file = os.path.basename(row.file.replace("\\", "/")) if row.file else ""
    return row


class ManualClipQueue:
    """The clips of one episode as work for people, kept next to the
    production in manual-queue.json (one list per episode number). Rows come
    from the prompt set; sync() adds what is new and keeps what a person
    already set on the rows that are still there."""

    def __init__(self, working_dir: Path, episode: int = 1, path: Optional[Path] = None, title: str = ""):
        self.working_dir = Path(working_dir)
        # Next to a production by default; a queue made from a bare prompt
        # file (no production) lives where the caller says, under the
        # shared folder's flow-queue/.
        self.path = Path(path) if path is not None else self.working_dir / QUEUE_NAME
        self.episode = int(episode)
        self.title = _one_line(title)[:200]
        self.source = ""                       # the prompt file the rows came from, by name
        self.rows: List[QueueRow] = []
        self._others: Dict[str, object] = {}   # the other episodes' lists, kept as read

    @classmethod
    def load(cls, working_dir: Path, episode: int = 1, path: Optional[Path] = None,
             title: str = "") -> "ManualClipQueue":
        queue = cls(working_dir, episode, path, title)
        queue.reload()
        return queue

    def reload(self) -> None:
        raw = _read_json(self.path)
        if isinstance(raw, dict):
            self.title = _one_line(raw.get("title", ""))[:200] or self.title
            self.source = _one_line(raw.get("source", ""))[:200]
        episodes = raw.get("episodes") if isinstance(raw, dict) else None
        episodes = episodes if isinstance(episodes, dict) else {}
        mine = episodes.get(str(self.episode))
        rows, seen = [], set()
        for entry in (mine.get("rows") if isinstance(mine, dict) else []) or []:
            try:
                row = _row_from(entry)
            except (TypeError, ValueError, AttributeError):
                continue
            if row.key in seen:
                continue
            seen.add(row.key)
            rows.append(row)
        self.rows = rows
        self._others = {k: v for k, v in episodes.items() if k != str(self.episode)}

    def save(self) -> Path:
        episodes = dict(self._others)
        episodes[str(self.episode)] = {"rows": [_raw(r) for r in self.rows]}
        payload = {"format_version": 1, "updated": now(), "title": self.title, "source": self.source,
                   "episodes": episodes}
        _write_atomic(self.path, json.dumps(payload, indent=2, ensure_ascii=False))
        return self.path

    def sync(self, items: Sequence[PromptItem]) -> List[QueueRow]:
        """Rows for the prompt set: one per item, in play order. A row that
        is already there keeps its assignment, status and file; its prompt
        text follows the set. Returns the rows that were added."""
        by_key = {row.key: row for row in self.rows}
        added, rows = [], []
        for item in items:
            key = "{}.{}".format(int(item.scene), int(item.clip))
            row = by_key.get(key)
            if row is None:
                row = QueueRow(scene=int(item.scene), clip=int(item.clip), sequence=int(item.sequence),
                               prompt=_lines(item.prompt), updated=now())
                added.append(row)
            else:
                row.sequence = int(item.sequence)
                row.prompt = _lines(item.prompt)
                # A clip the app itself already fetched and checked is done.
            if item.validated and item.path and row.status != "done":
                row.status = "done"
                row.file = os.path.basename(str(item.path).replace("\\", "/"))
                row.updated = now()
            rows.append(row)
        self.rows = rows
        return added

    def row(self, key: str) -> QueueRow:
        for row in self.rows:
            if row.key == key:
                return row
        raise KeyError("There is no clip {} in the queue.".format(key))

    def assign(self, keys: Iterable[str], account_id: Optional[str] = None, editor: Optional[str] = None) -> int:
        """Sets the account and/or the editor on the rows named; None
        leaves that field alone, '' clears it."""
        if account_id:
            account_id = FlowAccountBook._check_id(account_id)
        editor = None if editor is None else _one_line(editor)[:NAME_MAX]
        changed = 0
        for key in keys:
            row = self.row(key)
            if account_id is not None:
                row.account_id = account_id
            if editor is not None:
                row.editor = editor
            row.updated = now()
            changed += 1
        return changed

    def set_status(self, key: str, status: str, note: str = "") -> QueueRow:
        if status not in QUEUE_STATUSES:
            raise ValueError("'{}' is not a queue status; one of {}.".format(status, ", ".join(QUEUE_STATUSES)))
        row = self.row(key)
        row.status = status
        row.note = _one_line(note)[:400]
        row.updated = now()
        return row

    def counts(self) -> Dict[str, int]:
        counts = {status: 0 for status in QUEUE_STATUSES}
        for row in self.rows:
            counts[row.status] = counts.get(row.status, 0) + 1
        return counts


def title_queue_path(folder: Path, title: str) -> Path:
    """Where a queue made from a prompt file (no production) lives: under
    the shared folder, named for the title the way safe_name allows."""
    return Path(folder) / FLOW_QUEUE_DIR / (safe_name(title) + ".json")


def title_clips_dir(folder: Path, title: str) -> Path:
    """The folder people drop that title's clips into, beside its queue."""
    return Path(folder) / FLOW_QUEUE_DIR / safe_name(title) / "clips"


# ----------------------------------------------------------- the watcher
def _match_row(name: str, rows: List[QueueRow]) -> Optional[QueueRow]:
    """The row a dropped file is for: the app's own name first, then
    'scene12[_clip2]...', then a bare leading number (the play order, or
    the scene when no row has that play order)."""
    lowered = name.casefold()
    for row in rows:
        if row.filename.casefold() == lowered:
            return row
    stem = Path(name).stem
    match = _SCENE_NUMBER.match(stem)
    if match:
        scene, clip = int(match.group(1)), int(match.group(2) or 1)
        return next((r for r in rows if r.scene == scene and r.clip == clip), None)
    match = _LEADING_NUMBER.match(stem)
    if match:
        number = int(match.group(1))
        row = next((r for r in rows if r.sequence == number), None)
        if row is None:
            row = next((r for r in rows if r.scene == number and r.clip == 1), None)
        return row
    return None


def _same_file(a: Path, b: Path) -> bool:
    try:
        return os.path.samefile(str(a), str(b))
    except OSError:
        return False


def reconcile(queue: ManualClipQueue, clips_dir: Path) -> List[str]:
    """Matches the files a person dropped into the clips folder to the
    queue's rows, renames each to the app's own name, checks it and marks
    the row done (or failed, with why). Returns one line per change, in
    words. A valid clip that is already there is never replaced: a second
    file for the same row is left where it is and said so.

    Only the folder's own files are looked at, by bare name; nothing here
    follows a path written in a file."""
    clips_dir = Path(clips_dir)
    changes: List[str] = []
    try:
        entries = sorted(p for p in clips_dir.iterdir() if p.is_file())
    except OSError as exc:
        return ["The clips folder could not be read: {}".format(exc)]
    for entry in entries:
        name = entry.name
        if entry.suffix.lower() not in VIDEO_SUFFIXES or name.startswith(".") or "_take" in name.casefold():
            continue
        row = _match_row(name, queue.rows)
        if row is None:
            continue
        target = clips_dir / row.filename
        if row.status == "done" and row.file and not _same_file(entry, target) and target.is_file() \
                and not validate_clip(target):
            changes.append("{}: kept {}; {} was left as it is".format(row.key, row.file, name))
            continue
        if not _same_file(entry, target):
            if target.exists():
                # Another file already has the name: not a valid clip (or
                # the row would be done above), but never overwritten.
                problem = validate_clip(target)
                if not problem:
                    changes.append("{}: kept {}; {} was left as it is".format(row.key, target.name, name))
                    continue
                changes.append("{}: {} is there but {}; {} was left as it is".format(
                    row.key, target.name, problem, name))
                continue
            try:
                os.replace(str(entry), str(target))
            except OSError as exc:
                changes.append("{}: {} could not be renamed: {}".format(row.key, name, exc))
                continue
            changes.append("{}: {} renamed to {}".format(row.key, name, target.name))
        problem = validate_clip(target)
        stamp = now()
        if problem:
            if row.status != "failed" or row.file != target.name:
                row.status, row.file, row.note, row.updated = "failed", target.name, _one_line(problem)[:400], stamp
                changes.append("{}: {} failed the check: {}".format(row.key, target.name, problem))
        elif row.status != "done" or row.file != target.name:
            row.status, row.file, row.note, row.updated = "done", target.name, "", stamp
            changes.append("{}: {} is done".format(row.key, target.name))
    return changes
