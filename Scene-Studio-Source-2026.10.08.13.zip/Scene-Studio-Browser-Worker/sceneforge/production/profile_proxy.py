"""Per-profile network settings; proxy passwords stay in Windows DPAPI storage."""
import base64
import ipaddress
import json
import re
from pathlib import Path

from .login_vault import protect
from .master import _write_atomic


def password_storage_available():
    try:
        check=b'Scene Studio proxy vault check'
        return protect(protect(check), True)==check
    except Exception:
        return False


class ProfileProxies:
    def __init__(self, root):
        self.path = Path(root) / 'managed-pool' / 'proxies.json'
        try:
            self.data = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
            if not isinstance(self.data, dict):
                raise ValueError()
        except (OSError, ValueError):
            raise ValueError('Proxy settings could not be read. Restore the settings before opening a browser.') from None

    @staticmethod
    def key(profile):
        if not isinstance(profile, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', profile):
            raise ValueError('Invalid browser profile.')
        return profile.casefold()

    def summary(self, profile):
        row = self.data.get(self.key(profile))
        if not row:
            return {'mode': 'direct', 'enabled': False, 'password_saved': False}
        return {k: row[k] for k in ('mode', 'host', 'port', 'username')} | {
            'enabled': True, 'password_saved': bool(row.get('password_blob'))}

    def save(self, profile, values):
        key = self.key(profile)
        mode = values.get('mode', 'direct')
        if mode == 'direct':
            updated = {k: v for k, v in self.data.items() if k != key}
        else:
            if mode not in ('http', 'https', 'socks5'):
                raise ValueError('Choose Direct, HTTP, HTTPS or SOCKS5.')
            host = values.get('host', '').strip()
            try:
                host = str(ipaddress.ip_address(host.strip('[]')))
            except ValueError:
                if len(host) > 253 or not all(re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', part) for part in host.split('.')):
                    raise ValueError('Enter a hostname or IP address only, without a URL, port or credentials.') from None
                host = host.lower()
            port_text = str(values.get('port', ''))
            if not re.fullmatch(r'[0-9]{1,5}', port_text) or not 1 <= int(port_text) <= 65535:
                raise ValueError('Proxy port must be between 1 and 65535.')
            username = values.get('username', '')
            password = values.get('password', '')
            if not isinstance(username, str) or not isinstance(password, str) or len(username) > 512 or len(password) > 4096 or any(c in username + password for c in '\r\n\x00'):
                raise ValueError('Invalid proxy credentials.')
            previous = self.data.get(key, {})
            row = dict(mode=mode, host=host, port=int(port_text), username=username)
            same_login = all(previous.get(k) == row[k] for k in row)
            blob = previous.get('password_blob', '') if same_login else ''
            if values.get('clear_auth') is True:
                row['username'] = ''; password = ''; blob = ''
            elif previous.get('password_blob') and not same_login and not password:
                raise ValueError('Enter the proxy password again after changing its server or username, or select Remove authentication.')
            if mode == 'socks5' and (row['username'] or password or blob):
                raise ValueError('Chrome supports SOCKS5 without username/password authentication. Use HTTP or HTTPS for an authenticated proxy.')
            if (password or blob) and not row['username']:
                raise ValueError('Enter the proxy username or select Remove authentication.')
            if password:
                try:
                    blob = base64.b64encode(protect(password.encode('utf-8'))).decode('ascii')
                except Exception:
                    raise ValueError('Windows could not protect the proxy password. Start the browser worker from your normal Windows login and retry. No changes were saved.') from None
            row['password_blob'] = blob
            updated = {**self.data, key: row}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        _write_atomic(self.path, json.dumps(updated, indent=2))
        self.data = updated

    def launch_options(self, profile):
        row = self.data.get(self.key(profile))
        if row is None:
            return None
        host = '[' + row['host'] + ']' if ':' in row['host'] else row['host']
        options = {'server': f"{row['mode']}://{host}:{row['port']}"}
        if row['username']:
            options['username'] = row['username']
            options['password'] = ''
        if row.get('password_blob'):
            try:
                options['password'] = protect(base64.b64decode(row['password_blob'], validate=True), True).decode('utf-8')
            except Exception:
                raise ValueError('Proxy password is locked. Save it again under the Windows user running this worker.') from None
        return options
