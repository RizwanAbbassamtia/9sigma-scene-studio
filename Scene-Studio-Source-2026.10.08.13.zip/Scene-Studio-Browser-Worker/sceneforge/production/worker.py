"""The master-log worker: queued titles through the pipeline, unattended.

    worker = MasterWorker(log, log.frameworks, config, make_providers_for)
    worker.run_forever()          # until stop is set, a budget is spent, or the
                                  # same failure comes back three times

An editor adds a title to the shared log; this loop claims it, builds (or
resumes) a production in the record's own job folder, runs the ordinary
Runner in fully automatic mode, and writes every step back to the log so
the sheet shows script_done, prompts_done, clips_done and finally
video_done or failed. A person is never asked anything; this is the one
place in the app where paid work starts without a click per title, which
is why the budgets here are strict and why nothing paid starts before the
record's own generation limit has been checked.

What the loop promises:
  - one job at a time, and only a job it could claim: a second worker on
    another machine cannot run the same production dir, because the claim
    file is created with O_CREAT|O_EXCL (atomic on a share) and the log's
    own claim step ran first;
  - a live worker never looks dead: a thread of its own beats the log's
    heartbeat and the claim file every minute for as long as the job runs,
    whatever the runner is doing, so a clip that takes a provider a
    quarter of an hour cannot hand the job to a second machine;
  - a Stop press sends the job back to `queued` with a note, never to
    `failed`, and sends no mail;
  - a worker that loses a job keeps its hands off it: when the log or the
    claim file says another machine has taken the job over (this one slept
    through its own heartbeat), the runner is stopped at its next check and
    this machine writes nothing more -- no status, no mail, no unlinking of
    the other machine's claim -- so two machines never pay for the same
    clips or overwrite each other's statuses;
  - a job whose worker died is picked up again by whoever restarts, from
    where the manifest says it was, with the clips already on disk reused
    -- on any machine, whatever letter or UNC name it opens the share
    under, because every path in the manifest is re-rooted onto this
    machine's job folder before the runner sees it, and a manifest whose
    paths lead outside that folder is refused rather than followed;
  - the record's *current* frameworks are used for stages that have not
    run yet, so a fixed framework fixes a re-queued job; stages already done
    keep the version they ran with;
  - live vs mock is decided by the caller (the Test mode box, the CLI
    flag), never by anything read from the share.
"""
from __future__ import annotations

import ctypes
import os
import re
import socket
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from ..config import Config
from ..logging_setup import get
from ..product import PRODUCT
from .frameworks import Frameworks
from .manifest import (
    MANIFEST_NAME, ErrorPolicy, FrameworkRef, Production, ReviewMode, Stage, Status, digest, now,
)
from .master import LockBroken, MasterLog, MasterRecord, TitleJob, safe_name
from .omniflash import MODEL as OMNI_MODEL, OmniFlashGenerator
from .providers import (
    AnthropicPromptWriter, MockClipGenerator, MockPromptWriter, MockScriptWriter,
    OpenAIScriptWriter,
)
from .runner import POLL_SECONDS, Event, Providers, Runner, Stopped

log = get("production.worker")

SAMPLES = Path(__file__).resolve().parent.parent.parent / "samples"
# The matched three-scene pair test mode runs on. The 158-prompt ep11 sample
# is for the parser tests only: it would take ten minutes of ffmpeg per title.
MOCK_SCRIPT = SAMPLES / "mock-script.txt"
MOCK_PROMPTS = SAMPLES / "mock-prompts.txt"
IN_PROGRESS = ("script_running", "script_done", "prompts_done", "clips_done")
FINAL = ("video_done", "failed")
# How far along a status is; a log status never moves backwards from an
# event (a resumed job at clips_done must not show script_done again).
RANK = {"queued": 0, "paused": 0, "failed": 0, "script_running": 1, "script_done": 2,
        "prompts_done": 3, "clips_done": 4, "video_done": 5}
# Which runner event means which log status. The export is handled when
# the run returns, because that is when the export path and the list of
# missing clips are both known.
STAGE_STATUS = {("script", "done"): "script_done", ("prompts", "done"): "prompts_done",
                ("clips", "done"): "clips_done", ("clips", "approved"): "clips_done"}
FINISHED = (Status.DONE.value, Status.APPROVED.value, Status.SKIPPED.value)
STOPPED_ERROR = "Stopped by the user."          # the runner's wording for a Stop press
SAME_FAILURE_LIMIT = 3
HEARTBEAT_SECONDS = 60.0
CLAIM_STALE_SECONDS = 600.0                     # a claim file nobody has touched for this long is an orphan's
# An idle worker asks the share this often at least: a config with no poll
# interval (0 or missing) must not become a loop on the share's .lock.
MIN_POLL_SECONDS = 30.0
NAME_CHARS = 40                                 # of the title, in the export file name
TITLE_CHARS = 200
NO_CAP = ("The record has no generation limit (max_generations) so its titles cannot run in live mode: "
          "set one on the record first.")
NO_BUDGET = ("A live run needs a clip budget and a title budget above 0 (config.json: worker_max_generations "
             "and worker_max_titles). 0 means no limit, which is only allowed in test mode.")


def budget_text(count) -> str:
    """How a budget reads to the person confirming a run: '0' looks like
    'nothing will be spent' and means the opposite."""
    return "no limit" if int(count or 0) <= 0 else str(int(count))


def live_budget_problem(clips, titles) -> str:
    """Why a live run may not start with these budgets, or '' when it may.
    Test mode spends nothing, so it may run without a budget."""
    if int(clips or 0) <= 0 or int(titles or 0) <= 0:
        return NO_BUDGET
    return ""


def poll_interval(seconds) -> float:
    """How long an idle worker waits between looks at the log. None, 0 or
    less (a config with no interval) means the floor, never no wait at all;
    a positive value is taken as given, so a test can poll fast."""
    try:
        seconds = float(seconds or 0)
    except (TypeError, ValueError):
        seconds = 0.0
    return seconds if seconds > 0 else MIN_POLL_SECONDS


class WorkerError(Exception):
    """Something the worker checked before spending anything, worded for the
    editor who reads it in the sheet and the mail."""


@dataclass
class WorkerEvent:
    """One line per status change, for the page's status line and the CLI."""
    job_id: str
    title: str
    status: str
    note: str = ""
    at: str = ""

    def line(self) -> str:
        """'<time> <job id> <status> <title>' for a terminal, in local time."""
        try:
            when = datetime.fromisoformat(self.at).astimezone().strftime("%H:%M:%S")
        except ValueError:
            when = self.at
        return "{} {} {} {}".format(when, self.job_id, self.status, self.title[:60])


def make_providers(credentials, record, live: bool, config=None) -> Providers:
    """Real adapters from the sealed keys, or the mocks on the small matched
    sample pair (three scenes, three prompts: a test-mode title finishes in
    under a minute instead of generating 158 clips). `record` is accepted so
    a caller can vary models by record later; nothing in it decides live
    versus mock."""
    if not live:
        return Providers(MockScriptWriter(MOCK_SCRIPT), MockPromptWriter(MOCK_PROMPTS),
                         MockClipGenerator(seconds=2.0))
    openai = credentials.get("openai")
    anthropic = credentials.get("anthropic")
    omni = credentials.get("omniflash")
    address = str(getattr(config, "omniflash_base_url", "") or "")
    model = str(getattr(config, "omniflash_model", "") or "") or OMNI_MODEL
    return Providers(OpenAIScriptWriter(openai) if openai else None,
                     AnthropicPromptWriter(anthropic) if anthropic else None,
                     OmniFlashGenerator(omni, base_url=address, model=model) if omni else None)


def missing_mock_samples() -> List[Path]:
    """The sample files test mode cannot run without. Checked before the
    worker starts, so a missing file is one message rather than a failed
    job per title."""
    return [p for p in (MOCK_SCRIPT, MOCK_PROMPTS) if not p.is_file()]


class MasterWorker:
    def __init__(self, log: MasterLog, frameworks: Frameworks, config: Config,
                 providers_factory: Callable[[MasterRecord, bool], Providers], notifier=None,
                 on_event: Callable[[object], None] = lambda e: None,
                 stop: Optional[threading.Event] = None, poll_seconds: float = 60.0,
                 max_generations: int = 0, max_jobs: int = 0, live: bool = False,
                 worker_id: str = "", runner_poll_seconds: float = POLL_SECONDS,
                 heartbeat_seconds: float = HEARTBEAT_SECONDS):
        self.log = log
        # The share's own library by default: every machine resolves a
        # record's refs against the same files.
        self.frameworks = frameworks or log.frameworks
        self.config = config
        self.providers_factory = providers_factory
        self.notifier = notifier
        self.on_event = on_event
        self.stop = stop or threading.Event()
        self.poll_seconds = poll_interval(poll_seconds)
        self.runner_poll_seconds = runner_poll_seconds
        self.heartbeat_seconds = float(heartbeat_seconds)
        self.live = bool(live)
        # Run-wide budgets: clips submitted and titles processed since this
        # worker was started. 0 in the argument means "the config's value";
        # 0 in the config means no budget, which the callers refuse for a
        # live run (live_budget_problem) and the guide explains.
        self.max_generations = int(max_generations or getattr(config, "worker_max_generations", 0) or 0)
        self.max_jobs = int(max_jobs or getattr(config, "worker_max_titles", 0) or 0)
        self.worker_id = worker_id or default_worker_id()
        self.folder = Path(log.folder)
        self.clips_submitted = 0
        self.jobs_processed = 0
        self.stopped_reason = ""
        self.current: Optional[TitleJob] = None
        self._same_failure = ""
        self._same_count = 0

    # ---------------------------------------------------------------- loop
    def run_forever(self, once: bool = False) -> None:
        """Claim and process jobs until stop is set, a budget is spent, or the
        same failure repeats. `once` works through what is queued now and
        returns instead of polling, for the CLI's --once."""
        self._emit("worker {} started on {} ({})".format(
            self.worker_id, self.folder, "live: real keys, every clip is paid for" if self.live else "test mode"))
        try:
            # A job that carries this machine's name in an in-progress status
            # was ours when the process died: finish it before taking new work.
            for job in self._orphans_of_mine():
                if self._halt_reason():
                    break
                self._process_safely(job)
            while True:
                reason = self._halt_reason()
                if reason:
                    self._emit(reason)
                    return
                job = self._claim_next()
                if job is None:
                    if once:
                        self._emit("nothing queued; done")
                        return
                    self._wait(self.poll_seconds)
                    continue
                self._process_safely(job)
        finally:
            self.current = None

    def _halt_reason(self) -> str:
        if self.stop.is_set():
            return "stopped"
        if self.stopped_reason:
            return self.stopped_reason
        if self.max_jobs and self.jobs_processed >= self.max_jobs:
            return "stopped: the title budget for this run ({}) is spent".format(self.max_jobs)
        if self.max_generations and self.clips_submitted >= self.max_generations:
            return "stopped: the clip budget for this run ({}) is spent".format(self.max_generations)
        return ""

    def _claim_next(self) -> Optional[TitleJob]:
        """The log's claim, not a peek: the job comes back already marked as
        this worker's, so a second machine polling the same share cannot
        take it too."""
        try:
            return self.log.claim_next(self.worker_id)
        except OSError as exc:
            log.warning("The master log at %s is not reachable: %s", self.folder, exc)
            self._emit("the master log is not reachable: {}".format(exc))
            self._wait(self.poll_seconds)
            return None

    def _orphans_of_mine(self) -> List[TitleJob]:
        try:
            jobs = [j for j in self.log.jobs() if j.status in IN_PROGRESS
                    and getattr(j, "worker", "") == self.worker_id]
        except OSError as exc:
            log.warning("The master log at %s is not reachable: %s", self.folder, exc)
            return []
        return sorted(jobs, key=lambda j: j.updated or j.added)

    def _process_safely(self, job: TitleJob) -> None:
        try:
            self.process(job)
        except Exception as exc:                                       # noqa: BLE001 - the loop must survive
            log.exception("Job %s crashed in the worker", job.id)
            text = "{}: {}".format(type(exc).__name__, exc)
            self._emit("crashed on {} ({}): {}".format(job.id, job.title[:60], text))
            self._fail_crashed(job, text)

    def _fail_crashed(self, job: TitleJob, text: str) -> None:
        """A crash outside the runner must still end in the sheet: a job
        left in progress with a live-looking heartbeat would be reclaimed
        in ten minutes and crash again, with no failed status, no history
        entry and no mail. Only a job that is still this worker's is
        failed; one another machine has taken over is left to it."""
        try:
            fresh = self._reread(job)
            if fresh.status in IN_PROGRESS and (getattr(fresh, "worker", "") or "") in ("", self.worker_id):
                self._finish(fresh, self._record(fresh.framework_id), "failed",
                             error="The worker crashed on this title: {}".format(text))
                return
        except Exception:                                              # noqa: BLE001 - the share may be gone too
            log.exception("Job %s: the crash could not be written to the log", job.id)
        self._count_failure(text)

    def _wait(self, seconds: float) -> None:
        end = time.monotonic() + max(0.0, seconds)
        while time.monotonic() < end and not self.stop.is_set():
            time.sleep(min(0.5, max(0.0, end - time.monotonic())))

    # ------------------------------------------------------------- one job
    def process(self, job: TitleJob) -> TitleJob:
        """Take one job as far as it will go. Returns the job as the log last
        saw it; a job that could not be claimed comes back untouched."""
        record = self._record(job.framework_id)
        if record is None:
            return self._finish(job, None, "failed", error="No framework record '{}' exists in the master log "
                                                            "for this title.".format(job.framework_id))
        if not record.enabled:
            log.info("Job %s skipped: record %s is disabled", job.id, record.framework_id)
            return job
        fresh = self._reread(job)
        if not self._claimable(fresh):
            log.info("Job %s skipped: %s, worker %s", fresh.id, fresh.status, getattr(fresh, "worker", ""))
            return fresh
        job_dir = self.job_dir(record.framework_id, fresh.id)
        try:
            job_dir.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return self._finish(fresh, record, "failed", error="The job folder could not be created: {}".format(exc))
        if not self._claim(job_dir):
            self._emit("skipped {} ({}): another worker holds it".format(fresh.id, fresh.title[:60]))
            return fresh
        self.jobs_processed += 1
        self.current = fresh
        # The lease: the runner's stop flag for this job, set by a Stop
        # press or by losing the job to another machine. Liveness is a
        # matter of time, not of events: the runner can sit in one quiet
        # provider poll for longer than the stale limits, so a thread beats
        # the log and the claim file, and watches both for a takeover.
        lease = _Lease(self.stop, self.worker_id)
        beat = _Heartbeat(self, fresh.id, job_dir, lease)
        beat.start()
        try:
            return self._run_job(fresh, record, job_dir, lease)
        finally:
            beat.stop()
            self.current = None
            self._release(job_dir)

    def _run_job(self, job: TitleJob, record: MasterRecord, job_dir: Path, lease: "_Lease") -> TitleJob:
        rel_dir = self._relative(job_dir)
        cap = _record_cap(record)
        if self.live and cap <= 0:
            return self._finish(job, record, "failed", error=NO_CAP, production_dir=rel_dir)
        # Anything at all can come out of a file on the share that a person
        # edited by hand, not only the errors a clean file can raise; every
        # one of them must end as a failed status the sheet shows, never as
        # a crash that leaves the job in progress until it is reclaimed.
        try:
            refs = self._frameworks_for(record)
        except WorkerError as exc:
            return self._finish(job, record, "failed", error=str(exc), production_dir=rel_dir)
        except Exception as exc:                                       # noqa: BLE001 - see above
            return self._finish(job, record, "failed", production_dir=rel_dir,
                                error="The record's frameworks could not be read: {}: {}".format(
                                    type(exc).__name__, exc))
        try:
            production, notes = self._production_for(job, record, job_dir, refs)
        except WorkerError as exc:
            return self._finish(job, record, "failed", error=str(exc), production_dir=rel_dir)
        except Exception as exc:                                       # noqa: BLE001 - see above
            return self._finish(job, record, "failed", production_dir=rel_dir,
                                error="The saved production ({} in {}) could not be read: {}: {}".format(
                                    MANIFEST_NAME, job_dir, type(exc).__name__, exc))
        status = _status_of(production)
        note = "; ".join(notes) if notes else ("resumed on " + self.worker_id if status != "script_running"
                                                else "started on " + self.worker_id)
        # A status this title reached before (a resume after a Stop, a Retry,
        # another machine picking it up) was already mailed if the editor
        # asked for it; only a first arrival is.
        seen_before = any(row.get("status") == status for row in (job.history or []))
        job = self._set(job, record, status, note=note, notify=not seen_before, production_dir=rel_dir,
                        error="", stage=_stage_of(production), progress="")
        providers = self._counted(self.providers_factory(record, self.live), lease)
        tracker = _Tracker(self, job, record, production, lease)
        runner = Runner(production, providers, self.frameworks, self.config, on_event=tracker.on_event,
                        stop=lease, max_generations=self._runner_cap(cap, production),
                        poll_seconds=self.runner_poll_seconds)
        return self._drive(runner, tracker, lease)

    def _drive(self, runner: Runner, tracker: "_Tracker", lease: "_Lease") -> TitleJob:
        """Run to the end, deciding alone what a person would be asked in the
        dashboard: a script or prompt set that failed validation is written
        once more; clips that could not be made after their retries are
        accepted as missing and named in the note and the mail; anything
        else fails the job with the runner's own words. Every last word
        goes through _end, which says nothing when the job is no longer
        this machine's."""
        production, record = tracker.production, tracker.record
        episode = production.episode(1)
        retried = set()
        missing: List[str] = []
        while True:
            try:
                stopped = runner.run(1)
            except Stopped:
                return self._end(tracker, lease, "queued")
            except Exception as exc:                                   # noqa: BLE001 - the job fails, the loop lives
                log.exception("Job %s: the runner crashed", tracker.job.id)
                return self._end(tracker, lease, "failed", error="{}: {}".format(type(exc).__name__, exc))
            if stopped is None:
                export = episode.exports[-1].path if episode.exports else ""
                # Only a file inside the master folder is reported: the
                # manifest is on the share, and the page opens this path.
                if export and not _inside(Path(export), self.folder):
                    export = ""
                note = ("{} clip(s) missing: {}".format(len(missing), ", ".join(missing)) if missing
                        else "exported")
                return self._end(tracker, lease, "video_done", note=note, error="",
                                 export_path=self._relative(Path(export)) if export else "",
                                 stage="export", progress="done")
            state = episode.stage(stopped)
            if state.status == Status.FAILED.value:
                if state.error == STOPPED_ERROR or lease.is_set():
                    return self._end(tracker, lease, "queued")
                return self._end(tracker, lease, "failed", stage=stopped.value,
                                 error=state.error or "The {} stage failed.".format(stopped.value))
            if state.status == Status.NEEDS_REVIEW.value:
                if lease.is_set():
                    # Stopped, or taken over, between two stages: the next
                    # save or approval would be this machine's stale word.
                    return self._end(tracker, lease, "queued")
                if stopped in (Stage.SCRIPT, Stage.PROMPTS) and stopped not in retried:
                    retried.add(stopped)
                    self._emit("{}: {} — asking once more".format(tracker.job.id, state.next_action[:120]))
                    state.set(Status.PENDING, error="", next_action="")
                    production.save()
                    continue
                if stopped == Stage.CLIPS and episode.prompt_set and any(i.validated for i in episode.prompt_set.items):
                    missing = [str(i.sequence) for i in sorted(episode.prompt_set.items, key=lambda i: i.sequence)
                               if not i.validated]
                    runner.approve(1, Stage.CLIPS, by="worker: {} clips missing".format(len(missing)))
                    continue
                if stopped == Stage.EDIT:
                    runner.approve(1, Stage.EDIT, by="worker")
                    continue
                return self._end(tracker, lease, "failed", stage=stopped.value,
                                 error=state.next_action or state.error or
                                 "The {} stage needs a person.".format(stopped.value))
            if state.status == Status.OUTDATED.value:
                return self._end(tracker, lease, "failed", stage=stopped.value,
                                 error="The {} stage is outdated: something upstream changed. Open the "
                                       "production in the dashboard to regenerate it or keep the previous "
                                       "result.".format(stopped.value))
            return self._end(tracker, lease, "failed", stage=stopped.value,
                             error="The {} stage stopped with status '{}'.".format(stopped.value, state.status))

    def _end(self, tracker: "_Tracker", lease: "_Lease", status: str, note: str = "", **fields) -> TitleJob:
        """The job's last word from this run -- unless the job is no longer
        this machine's. The log is read once more here, because a takeover
        during a step with no event and no heartbeat (the export, say) is
        only visible in the log; and after a takeover nothing is written:
        the other machine's status, claim and clips are its own now."""
        job = tracker.job
        fresh = self._reread(job)
        if lease.check(fresh) or lease.lost.is_set():
            who = lease.taken_by
            self._emit("{} ({}) was taken over by {}: this machine stopped and wrote nothing".format(
                job.id, job.title[:60], who) if who else
                "{} ({}) is now {} on the log: this machine stopped and wrote nothing".format(
                    job.id, job.title[:60], fresh.status))
            return fresh
        if status == "queued":
            return self._requeue(job, tracker.record)
        return self._finish(job, tracker.record, status, note=note, **fields)

    # ------------------------------------------------------------ claiming
    def _reread(self, job: TitleJob) -> TitleJob:
        try:
            fresh = self.log.job(job.id)
        except (KeyError, OSError):
            fresh = None
        return fresh or job

    def _claimable(self, job: TitleJob) -> bool:
        """Queued, or in progress and ours (or nobody's, or a dead worker's:
        the log's claim step hands those over with a stale heartbeat)."""
        if job.status == "queued":
            return True
        if job.status not in IN_PROGRESS:
            return False
        owner = getattr(job, "worker", "") or ""
        return owner in ("", self.worker_id) or _older_than(getattr(job, "heartbeat", ""), CLAIM_STALE_SECONDS)

    def _claim(self, job_dir: Path) -> bool:
        """The cross-machine claim: a file only one creator can make. A file
        nobody has touched for ten minutes belongs to a worker that died and
        is taken over; a fresh one means the job is running elsewhere --
        unless it names this machine and a process that is no longer
        running, which is what a crash here leaves behind, and the restarted
        worker must finish that job now, not in ten minutes."""
        path = job_dir / ".claimed"
        for _ in range(3):
            try:
                fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                if not self._claim_is_dead(path):
                    return False
                # Two workers can find the same dead claim at once. Each
                # renames it to a name of its own first -- one rename wins,
                # the other finds nothing to rename -- so only the winner
                # goes on to make the new claim; the loser competes again
                # for that new claim and finds it fresh.
                broken = path.with_name(".claimed-broken-{}".format(uuid.uuid4().hex[:8]))
                try:
                    os.replace(str(path), str(broken))
                except OSError:
                    continue
                log.warning("Breaking a dead claim on %s", job_dir)
                try:
                    broken.unlink()
                except OSError as exc:
                    log.warning("The broken claim %s could not be removed: %s", broken, exc)
                continue
            except OSError as exc:
                log.warning("Could not claim %s: %s", job_dir, exc)
                return False
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write("{}\n{}\n{}\n".format(self.worker_id, os.getpid(), now()))
            return True
        return False

    def _claim_is_dead(self, path: Path) -> bool:
        """A live worker touches its claim every minute, so one older than
        the stale limit is dead whoever wrote it -- even when its pid is in
        use here: after a reboot the number belongs to some other program.
        A fresh claim that names this machine is checked by pid too, so a
        crash here is picked up at once, not in ten minutes."""
        try:
            age = time.time() - path.stat().st_mtime
        except OSError:
            return False
        if age >= CLAIM_STALE_SECONDS:
            return True
        holder, pid = _read_claim(path)
        if holder == self.worker_id and pid is not None:
            return pid == os.getpid() or not _pid_alive(pid)
        return False

    def _claim_is_mine(self, job_dir: Path) -> bool:
        """Whether the claim file still names this process. After a takeover
        it names the other machine, and that file is theirs to remove."""
        holder, pid = _read_claim(job_dir / ".claimed")
        return holder == self.worker_id and pid == os.getpid()

    def _release(self, job_dir: Path) -> None:
        if not self._claim_is_mine(job_dir):
            return
        try:
            (job_dir / ".claimed").unlink()
        except OSError:
            pass

    def _touch_claim(self, job_dir: Path) -> None:
        try:
            os.utime(str(job_dir / ".claimed"), None)
        except OSError:
            pass

    # ------------------------------------------------- the production
    def job_dir(self, framework_id: str, job_id: str) -> Path:
        """Always derived here, never taken from the log: production_dir in a
        shared JSON is informational, and a hand-edited one must not send
        clips and manifests anywhere else."""
        return self.folder / framework_id / "jobs" / job_id

    def exports_dir(self, framework_id: str) -> Path:
        return self.folder / framework_id / "exports"

    def _production_for(self, job: TitleJob, record: MasterRecord, job_dir: Path, refs: Dict[str, FrameworkRef]):
        notes: List[str] = []
        exports = str(self.exports_dir(record.framework_id))
        title = " ".join(str(job.title or "").split())[:TITLE_CHARS]
        name = "{} {}".format(job.id, safe_name(title, job.id)[:NAME_CHARS].rstrip(" .")).strip()
        if (job_dir / MANIFEST_NAME).exists():
            production = Production.load(job_dir)
            self._reroot(production, job, job_dir, title, name, exports)
            episode = production.episode(1)
            for stage, pairs in ((Stage.SCRIPT, (("hook", "hook_framework"), ("script", "script_framework"))),
                                 (Stage.PROMPTS, (("prompt", "prompt_framework"),))):
                if episode.stage(stage).status in FINISHED:
                    continue                                   # done with the version it ran with; keep it
                for kind, attr in pairs:
                    current, old = refs[kind], getattr(production, attr)
                    if (current.name, current.version, current.sha) != (old.name, old.version, old.sha):
                        setattr(production, attr, current)
                        notes.append("{} framework updated to {} v{} before resuming".format(kind, current.name, current.version)
                                     if current.name else "{} framework removed before resuming".format(kind))
            production.review_mode = ReviewMode.AUTOMATIC.value
            production.error_policy = ErrorPolicy.SKIP.value
            production.language = record.language or production.language
            production.target_minutes = float(record.target_minutes or production.target_minutes)
            production.generation_settings = _generation_settings(record)
            # Only a job that came back through the queue -- a Retry, a
            # re-add from the sheet; still `queued`, or `script_running`
            # once claimed -- gets its skipped clips generated again: that
            # press is the deliberate action paid work needs. A takeover
            # of a stale job further along keeps the stage as it is.
            if job.status in ("queued", "script_running"):
                reset = _reset_skipped_clips(production)
                if reset:
                    notes.append(reset)
            production.save()
            return production, notes
        production = Production.new(
            title, name, job_dir, episodes=1, language=record.language or "Urdu",
            target_minutes=float(record.target_minutes or 20.0), clips_dir=str(job_dir / "clips"),
            export_dir=exports, review_mode=ReviewMode.AUTOMATIC.value, error_policy=ErrorPolicy.SKIP.value,
            hook_framework=refs["hook"], script_framework=refs["script"], prompt_framework=refs["prompt"],
            generation_settings=_generation_settings(record))
        production.save()
        return production, notes

    def _reroot(self, production: Production, job: TitleJob, job_dir: Path, title: str, name: str,
                exports: str) -> None:
        """A saved manifest, made fit to run here.

        The manifest was written by whichever machine ran the job last,
        under whatever letter or UNC name that machine gave the share, and
        anyone with the share can edit it. So nothing in it is taken as a
        place on this machine: the folders and names are derived again from
        the checked ids, exactly as for a new production, and every artefact
        path is moved by its tail from the old working dir to this job
        folder. A path that does not lead inside the job folder is refused
        -- the job fails with a message -- rather than read or written."""
        head = str(production.name or "").split(" ", 1)[0]
        if head != job.id:
            raise WorkerError("The saved production in this job folder is named for '{}', not for this title "
                              "({}); it was not resumed.".format(str(production.name or "")[:60], job.id))
        old_root = Path(str(production.working_dir or "") or job_dir)
        production.working_dir = str(job_dir)
        production.clips_dir = str(job_dir / "clips")
        production.export_dir = exports
        production.title = title
        production.name = name
        many = len(production.episodes) > 1
        for episode in production.episodes:
            episode.name = "{} - episode {}".format(name, episode.number) if many else name
            episode.clips_dir = str(job_dir / "clips" / "ep{:02d}".format(episode.number))
            for script in episode.scripts:
                script.path = self._moved(script.path, old_root, job_dir, "script")
                if script.hooks_path:
                    script.hooks_path = self._moved(script.hooks_path, old_root, job_dir, "hooks")
            for prompt_set in episode.prompt_sets:
                prompt_set.path = self._moved(prompt_set.path, old_root, job_dir, "prompt list")
                for item in prompt_set.items:
                    if item.path:
                        item.path = self._moved(item.path, old_root, job_dir, "clip")
            for export in episode.exports:
                # Informational: the runner never reads an old export, and
                # the page checks the path again before opening it.
                moved = _rebase(export.path, old_root.parent.parent.parent, self.folder)
                if moved is not None and _inside(Path(moved), self.folder):
                    export.path = moved

    @staticmethod
    def _moved(text: str, old_root: Path, job_dir: Path, what: str) -> str:
        moved = _rebase(text, old_root, job_dir)
        if moved is None or not _inside(Path(moved), job_dir):
            raise WorkerError("The saved production's {} path '{}' does not lead inside the job folder, so it "
                              "was not resumed. Fix or delete {} in {} to run the title again.".format(
                                  what, str(text)[:120], MANIFEST_NAME, job_dir))
        return moved

    def _frameworks_for(self, record: MasterRecord) -> Dict[str, FrameworkRef]:
        refs = {}
        for kind, attr in (("hook", "hook_framework"), ("script", "script_framework"), ("prompt", "prompt_framework")):
            ref = getattr(record, attr, None) or FrameworkRef()
            refs[kind] = self._usable_ref(ref, record, kind) if ref.name else FrameworkRef()
        return refs

    def _usable_ref(self, ref: FrameworkRef, record: MasterRecord, kind: str) -> FrameworkRef:
        """The record's ref, checked before anything is spent. A ref this
        library does not know is imported from the record's copy on the
        share, but only when that copy still has the sha the record was
        saved with: the record's sha stays the authority, so a rewritten
        share file cannot become the system prompt of every future job."""
        try:
            self.frameworks.text(ref)
            return ref
        except ValueError:
            raise WorkerError("The {} framework '{}' v{} was changed on disk after the record was saved; "
                              "upload it again from the record.".format(kind, ref.name, ref.version))
        except KeyError:
            pass
        except OSError as exc:
            raise WorkerError("The {} framework '{}' could not be read: {}".format(kind, ref.name, exc))
        folder = self.folder / record.framework_id / "frameworks"
        try:
            copies = sorted(folder.glob("{}-v*.txt".format(kind))) if folder.is_dir() else []
        except OSError:
            copies = []
        for path in reversed(copies):
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if digest(text.replace("\r\n", "\n").strip() + "\n") != ref.sha:
                continue
            try:
                imported = self.frameworks.save(ref.name, kind, text)
            except (KeyError, OSError) as exc:
                raise WorkerError("The {} framework could not be imported from the share: {}".format(kind, exc))
            if imported.sha == ref.sha:
                return imported
        raise WorkerError("The {} framework '{}' v{} is not in this machine's library, and the copy on the "
                          "share does not match the record; upload it again from the record.".format(
                              kind, ref.name, ref.version))

    def _runner_cap(self, record_cap: int, production: Production) -> int:
        """The record's per-production limit, lowered by what is left of this
        run's clip budget. Clips already submitted in an earlier run of the
        same production count against the record's cap (the runner counts
        them) but not against this run's budget."""
        episode = production.episode(1)
        already = sum(1 for i in (episode.prompt_set.items if episode.prompt_set else []) if i.job_id)
        caps = [c for c in (record_cap,) if c > 0]
        if self.max_generations:
            caps.append(already + max(0, self.max_generations - self.clips_submitted))
        return min(caps) if caps else 0

    def _counted(self, providers: Providers, lease: Optional["_Lease"] = None) -> Providers:
        if providers.clip_generator is not None:
            providers.clip_generator = _CountingGenerator(providers.clip_generator, self, lease)
        return providers

    # ------------------------------------------------------- the log side
    def _record(self, framework_id: str) -> Optional[MasterRecord]:
        try:
            return self.log.record(framework_id)
        except (KeyError, ValueError):
            return None

    def _set(self, job: TitleJob, record: Optional[MasterRecord], status: str, note: str = "",
             notify: bool = True, **fields) -> TitleJob:
        """One status change: written to the log, announced, and mailed when
        the settings ask for it. A mail that could not go out is written
        into the job's history so the editor sees why in the sheet."""
        stamp = now()
        fields.setdefault("heartbeat", "" if status in FINAL + ("queued", "paused") else stamp)
        if status == "queued":
            fields.setdefault("worker", "")
        elif status in IN_PROGRESS:
            fields.setdefault("worker", self.worker_id)
        job = self._write_status(job, status, note, fields)
        self._emit(WorkerEvent(job.id, job.title, status, note, stamp))
        if notify and self.notifier is not None and record is not None:
            job = self._notify(job, record, status, note)
        return job

    def _write_status(self, job: TitleJob, status: str, note: str, fields: Dict[str, object]) -> TitleJob:
        """set_status, tried again when the log refused it because another
        machine broke this one's lock mid-change: the lock is taken afresh
        and the job re-read first, and the write is dropped -- LockBroken
        raised -- when the re-read shows the job is another machine's now,
        which is what breaking a lock usually means."""
        last: Optional[LockBroken] = None
        for attempt in range(3):
            try:
                return self.log.set_status(job.id, status, note=note, **fields)
            except LockBroken as exc:
                last = exc
                log.warning("Job %s: %s (attempt %d)", job.id, exc, attempt + 1)
                time.sleep(0.3 * (attempt + 1))
                fresh = self._reread(job)
                owner = getattr(fresh, "worker", "") or ""
                if fresh is not job and owner not in ("", self.worker_id):
                    raise LockBroken("'{}' is {} on {} now; this machine's '{}' was not written".format(
                        fresh.title[:60], fresh.status, owner, status)) from exc
        raise last                                                     # type: ignore[misc]

    def _notify(self, job: TitleJob, record: MasterRecord, status: str, note: str) -> TitleJob:
        export = ""
        if job.export_path:
            try:
                export = str(self._resolve(job.export_path))
            except (OSError, ValueError):
                export = str(job.export_path)
        try:
            sent = self.notifier.notify(job, record, status, note=note, export_path=export)
        except Exception:                                              # noqa: BLE001 - mail never fails a job
            log.exception("Job %s: the notifier crashed", job.id)
            sent = False
        problem = "" if sent else str(getattr(self.notifier, "last_error", "") or "")
        if problem:
            try:
                job = self.log.set_status(job.id, status, note=problem)
            except OSError as exc:
                log.warning("Job %s: could not record the mail failure: %s", job.id, exc)
        return job

    def _finish(self, job: TitleJob, record: Optional[MasterRecord], status: str, note: str = "", **fields) -> TitleJob:
        if status == "failed":
            error = str(fields.get("error", "") or "")
            log.error("Job %s failed: %s", job.id, error)
            fields.setdefault("progress", "")
            job = self._set(job, record, status, note=note or error[:200], **fields)
            self._count_failure(error)
            return job
        job = self._set(job, record, status, note=note, **fields)
        self._same_failure, self._same_count = "", 0
        return job

    def _requeue(self, job: TitleJob, record: MasterRecord) -> TitleJob:
        """A Stop press: back to the queue with a note, no mail, the
        production dir kept so the next worker resumes it."""
        who = str(getattr(self.config, "editor_name", "") or "").strip() or self.worker_id
        return self._set(job, record, "queued", note="stopped by {}".format(who), notify=False,
                         error="", progress="")

    def _count_failure(self, error: str) -> None:
        if error and error == self._same_failure:
            self._same_count += 1
        else:
            self._same_failure, self._same_count = error, 1
        if self._same_count >= SAME_FAILURE_LIMIT:
            self.stopped_reason = "stopped: same failure three times: {}".format(error)

    def _relative(self, path: Path) -> str:
        try:
            return Path(os.path.relpath(str(path), str(self.folder))).as_posix()
        except ValueError:                                     # another drive: keep it absolute
            return str(path)

    def _resolve(self, rel: str) -> Path:
        return Path(self.log.resolve(rel))

    def _emit(self, event) -> None:
        if isinstance(event, WorkerEvent):
            log.info("job %s -> %s (%s) %s", event.job_id, event.status, event.title[:60], event.note)
        elif isinstance(event, str):
            log.info("worker: %s", event)
        try:
            self.on_event(event)
        except Exception:                                              # noqa: BLE001 - a listener must not stop the loop
            log.exception("an event listener crashed")


_ID_FILE = PRODUCT.data_dir / "worker-id"


def default_worker_id(id_file: Optional[Path] = None) -> str:
    """This machine's name on the log: the hostname plus a short token
    made once per installation, because two laptops set up from the same
    image share a hostname, and a name alone would let one take the
    other's live job as its own orphan. The token lives beside the app's
    data; when it cannot be kept, a fresh one is used for this process."""
    path = Path(id_file) if id_file else _ID_FILE
    host = socket.gethostname()
    try:
        token = path.read_text(encoding="utf-8").strip()
    except OSError:
        token = ""
    if not re.fullmatch(r"[0-9a-f]{6}", token or ""):
        token = uuid.uuid4().hex[:6]
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(token, encoding="utf-8")
        except OSError:
            pass
    return "{}-{}".format(host, token)


class _Lease:
    """This machine's hold on one job, in the shape the runner's stop flag
    takes (is_set and wait): set by a Stop press, or by losing the job to
    another machine. The heartbeat thread and the tracker hand every job
    the log returns to check(); the first one that names another worker,
    or a status nobody is running, marks the lease lost, the runner stops
    at its next check, and _end writes nothing."""

    def __init__(self, stop: threading.Event, worker_id: str):
        self.stop = stop
        self.worker_id = worker_id
        self.lost = threading.Event()
        self.taken_by = ""

    def is_set(self) -> bool:
        return self.stop.is_set() or self.lost.is_set()

    def wait(self, timeout=None) -> bool:
        end = None if timeout is None else time.monotonic() + max(0.0, float(timeout))
        while not self.is_set():
            left = None if end is None else end - time.monotonic()
            if left is not None and left <= 0:
                return False
            self.stop.wait(0.2 if left is None else min(0.2, left))
        return True

    def check(self, job: Optional[TitleJob]) -> bool:
        """True when `job`, as the log just returned it, is no longer this
        worker's: another machine's name on it, or a status no worker holds
        (a person paused or re-queued it). Marks the lease lost."""
        if job is None:
            return self.lost.is_set()
        owner = getattr(job, "worker", "") or ""
        if owner == self.worker_id and job.status in IN_PROGRESS:
            return False
        self.taken_by = owner
        self.lost.set()
        return True

    def lose_to(self, holder: str) -> None:
        """The claim file names another worker: the same loss, seen in the
        job folder rather than in the log."""
        self.taken_by = holder
        self.lost.set()


class _Heartbeat(threading.Thread):
    """Beats the log's heartbeat and the claim file every interval for as
    long as one job runs, on a thread of its own, so a worker inside a
    quiet step -- three clips in flight at a slow provider, ffmpeg over a
    long episode -- still looks alive to every other machine. A beat that
    cannot be written is logged and tried again next time. The beat is
    also where a takeover is noticed first: the job the log hands back,
    and the claim file, must still be this worker's."""

    def __init__(self, worker: MasterWorker, job_id: str, job_dir: Path, lease: _Lease):
        super().__init__(name="master-heartbeat-" + job_id, daemon=True)
        self.worker = worker
        self.job_id = job_id
        self.job_dir = job_dir
        self.lease = lease
        self.done = threading.Event()

    def run(self) -> None:
        while not self.done.wait(self.worker.heartbeat_seconds):
            if self.done.is_set() or self.lease.lost.is_set():
                return
            holder, pid = _read_claim(self.job_dir / ".claimed")
            if holder and (holder != self.worker.worker_id or (pid is not None and pid != os.getpid())):
                log.warning("Job %s: the claim file now names %s; stopping", self.job_id, holder)
                self.lease.lose_to(holder)
                return
            try:
                job = self.worker.log.touch(self.job_id)
            except (OSError, KeyError, ValueError) as exc:
                log.warning("Job %s: the heartbeat could not be written: %s", self.job_id, exc)
                continue
            if self.done.is_set():
                return                                     # the job ended between the beat and its reply
            if self.lease.check(job):
                log.warning("Job %s is now %s (worker %s); stopping", self.job_id, job.status, job.worker or "none")
                return
            self.worker._touch_claim(self.job_dir)

    def stop(self) -> None:
        self.done.set()
        self.join(timeout=5.0)


class _Tracker:
    """Turns the runner's events into log updates for one job: a stage that
    finished becomes the matching status at once; running events refresh
    stage and progress, at most once a minute. Liveness is the heartbeat
    thread's job, not this one's: an event may be an hour away. Nothing is
    written once the lease is lost, and a status change reads the job
    first: a machine that slept through its heartbeat must not put its own
    name back on a job another machine took."""

    def __init__(self, worker: MasterWorker, job: TitleJob, record: MasterRecord, production: Production,
                 lease: _Lease):
        self.worker = worker
        self.job = job
        self.record = record
        self.production = production
        self.lease = lease
        self.job_dir = Path(production.working_dir)
        self.last_written = time.monotonic()
        self.last_stage = job.stage or ""

    def on_event(self, event: Event) -> None:
        self.worker._emit(event)
        if self.lease.lost.is_set():
            return
        progress = ("{} {}%".format(event.stage, event.done // 10) if event.total == 1000
                    else "{} {}/{}".format(event.stage, event.done, event.total) if event.total
                    else "{}: {}".format(event.stage, event.message)[:80])
        status = STAGE_STATUS.get((event.stage, event.status))
        try:
            if status and RANK.get(status, 0) > RANK.get(self.job.status, 0):
                if self.lease.check(self.worker._reread(self.job)):
                    return
                self.job = self.worker._set(self.job, self.record, status, note=event.message[:200],
                                            stage=event.stage, progress=progress)
            elif event.stage != self.last_stage or time.monotonic() - self.last_written >= HEARTBEAT_SECONDS:
                self.job = self._touch(stage=event.stage, progress=progress)
                if self.lease.check(self.job):
                    return
            else:
                return
        except OSError as exc:                                 # a share hiccup must not fail the job
            log.warning("Job %s: the log could not be updated: %s", self.job.id, exc)
            return
        self.last_written = time.monotonic()
        self.last_stage = event.stage
        self.worker._touch_claim(self.job_dir)

    def _touch(self, **fields) -> TitleJob:
        """A sign of life without a history entry: the sheet shows the stage
        and progress, the history stays one row per status."""
        return self.worker.log.touch(self.job.id, **fields)


class _CountingGenerator:
    """The clip generator with the run-wide budget counter in front of it,
    and the last gate before money is spent: a lease lost while the runner
    was between two submits stops the next one here."""

    def __init__(self, inner, worker: MasterWorker, lease: Optional[_Lease] = None):
        self.inner = inner
        self.worker = worker
        self.lease = lease

    def submit(self, prompt, settings):
        if self.lease is not None and self.lease.is_set():
            raise Stopped()
        job = self.inner.submit(prompt, settings)
        self.worker.clips_submitted += 1
        return job

    def __getattr__(self, name):
        return getattr(self.inner, name)


# ------------------------------------------------------------------ helpers
def _record_cap(record: MasterRecord) -> int:
    settings = getattr(record, "generation_settings", None) or {}
    cap = settings.get("max_generations")
    if isinstance(cap, bool) or not isinstance(cap, int):
        return 0
    return cap if cap > 0 else 0


def _generation_settings(record: MasterRecord) -> Dict[str, object]:
    """What the clip provider needs, plus the record's generation limit, so
    the manifest carries the cap: the same production opened in the
    production dashboard reads its cap from this dict and would otherwise
    run without one. 'mock' is never forwarded (live vs mock is the
    caller's choice). The worker's own runner takes the cap from the
    record directly, lowered by the run's budget."""
    settings = getattr(record, "generation_settings", None) or {}
    out: Dict[str, object] = {}
    try:
        seconds = float(settings.get("max_seconds") or 0)
    except (TypeError, ValueError):
        seconds = 0.0
    if seconds > 0:
        out["max_seconds"] = seconds
    cap = _record_cap(record)
    if cap > 0:
        out["max_generations"] = cap
    return out


def _reset_skipped_clips(production: Production) -> str:
    """A clips stage that ended with every clip skipped is waiting for a
    person, and the runner will not enter it again: a Retry would fail
    with the same words each time. Give those clips back their attempts
    and set the stage pending, so the retry generates them. A clip that
    was made is never touched, and a stage with any such clip is left to
    _drive, which accepts the rest as missing. Returns a note, or ''."""
    episode = production.episode(1)
    state = episode.stage(Stage.CLIPS)
    items = episode.prompt_set.items if episode.prompt_set else []
    if state.status != Status.NEEDS_REVIEW.value or not items or any(i.validated for i in items):
        return ""
    for item in items:
        item.attempts = 0
        item.error = ""
        item.job_id = ""
        item.job_status = ""
    state.set(Status.PENDING, error="", next_action="")
    return "none of the {} clips was made last time; the clips stage is generating them again".format(len(items))


def _status_of(production: Production) -> str:
    """Where a saved production already is, in the log's words."""
    episode = production.episode(1)
    for stage, status in ((Stage.CLIPS, "clips_done"), (Stage.PROMPTS, "prompts_done"), (Stage.SCRIPT, "script_done")):
        if episode.stage(stage).status in FINISHED:
            return status
    return "script_running"


def _stage_of(production: Production) -> str:
    stage = production.episode(1).next_stage()
    return stage.value if stage else "export"


def _rebase(text, old_root: Path, new_root: Path) -> Optional[str]:
    """`text` moved from under old_root to under new_root by its tail;
    a relative path is taken as relative to the new root; None when the
    path was not under old_root at all. Case and separators are compared
    the way this machine's file system does."""
    if not text:
        return ""
    path = Path(os.path.normpath(str(text)))
    if not path.is_absolute():
        return str(new_root / path)
    parts = path.parts
    base = Path(os.path.normpath(str(old_root))).parts
    if len(parts) < len(base):
        return None
    if [os.path.normcase(p) for p in parts[:len(base)]] != [os.path.normcase(p) for p in base]:
        return None
    return str(new_root.joinpath(*parts[len(base):])) if len(parts) > len(base) else str(new_root)


def _inside(path: Path, root: Path) -> bool:
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
    except (OSError, ValueError):
        return False
    return True


def _read_claim(path: Path) -> Tuple[str, Optional[int]]:
    """(worker id, pid) from a claim file; ('', None) when it cannot be read."""
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return "", None
    holder = lines[0].strip() if lines else ""
    try:
        pid = int(lines[1].strip()) if len(lines) > 1 else None
    except ValueError:
        pid = None
    return holder, pid


def _pid_alive(pid: int) -> bool:
    """Whether a process with this id is running on this machine. Windows
    is asked through OpenProcess: os.kill(pid, 0) there does not probe, it
    terminates."""
    if not pid or pid <= 0:
        return False
    if os.name == "nt":
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        query_limited, access_denied, still_active = 0x1000, 5, 259
        handle = kernel32.OpenProcess(query_limited, False, int(pid))
        if not handle:
            return ctypes.get_last_error() == access_denied
        try:
            code = ctypes.c_ulong()
            if kernel32.GetExitCodeProcess(handle, ctypes.byref(code)):
                return code.value == still_active
            return True
        finally:
            kernel32.CloseHandle(handle)
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _older_than(stamp: str, seconds: float) -> bool:
    """True when an ISO timestamp is older than `seconds`, or unreadable."""
    if not stamp:
        return True
    try:
        when = datetime.fromisoformat(str(stamp))
    except ValueError:
        return True
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - when).total_seconds() > seconds
