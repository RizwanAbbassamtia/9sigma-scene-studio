"""Omni Flash, the video generator: the Generation API v2 exactly as its
document describes it (docs/omniflash-v2-api.md), and nothing more.

    submit     POST {base}/api/v2/videos/generate      -> a job id, at once
    poll       GET  {base}/api/v2/videos/status/{id}   -> pending | processing | done | failed
    download   GET  the video link (signed, ~24 hours) -> the clip, complete or not at all
    usage      GET  {base}/api/v2/usage                -> today's quota

The document leaves the base URL blank, so it is a setting (config.json
``omniflash_base_url``, or the API keys screen). The key goes with every
API request as a bearer token and nowhere else: not to a video link on
another host (the link carries its own token), and never into a log, an
error or a dialog.

A daily-limit key reports no cost and a 429 that says "no more today"
stops the whole clips stage, with the reset time, rather than failing
scene after scene; the same goes for a rejected or disabled key. The live
service turned out to answer 429 for a second reason too -- every parallel
video slot on the key is busy -- and that one is a wait, not a stop (see
_refuse). A pay-as-you-go key (billing_mode "payg" from /usage) has a
balance and a price per video instead of a limit; the price is recorded
per clip because the provider states it.
"""
from __future__ import annotations

import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, Optional
from urllib.parse import urlsplit

from ..logging_setup import get
from .providers import Job, ProviderError

log = get("production.omniflash")

MODEL = "omniflash-10s"
POLL_SECONDS = 10.0            # the document: "poll every 10 seconds"
SUBMIT_TIMEOUT = 360           # the document: "a timeout of at least 360 seconds"
STATUS_TIMEOUT = 60
DOWNLOAD_TIMEOUT = 600
MAX_PROMPT = 4000              # the document: 1 to 4000 characters
MIN_CLIP_BYTES = 10_000
DOWNLOAD_ATTEMPTS = 3
GENERATE_PATH = "/api/v2/videos/generate"
STATUS_PATH = "/api/v2/videos/status/"
USAGE_PATH = "/api/v2/usage"
NO_ADDRESS = ("The Omni Flash address is not set. Enter the address where the Generation API runs "
              "under Automate > API keys (its document leaves the base URL blank).")

_STATUS = {"pending": "queued", "queued": "queued", "processing": "running", "running": "running",
           "done": "done", "failed": "failed"}


def _requests_transport(method: str, url: str, headers: Dict[str, str], body, timeout: float, stream: bool):
    """The one place the network is touched; tests hand in a stand-in."""
    import requests
    return requests.request(method, url, headers=headers, json=body, timeout=timeout, stream=stream)


def _detail(response) -> str:
    """The document's error shape is {"detail": "..."}; anything else is
    shown as text, shortened."""
    try:
        data = response.json()
    except ValueError:
        return (getattr(response, "text", "") or "")[:300].strip()
    if isinstance(data, dict):
        return str(data.get("detail") or data.get("error") or data.get("message") or "")[:300]
    return str(data)[:300]


def _host(url: str) -> str:
    try:
        return (urlsplit(url).hostname or "").lower()
    except ValueError:
        return ""


def _local_time(iso: str) -> str:
    """"2026-07-13T00:00:00Z" as the machine's own clock says it."""
    try:
        when = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        return when.astimezone().strftime("%d %b %H:%M")
    except (ValueError, OverflowError, OSError):
        return iso


class OmniFlashGenerator:
    """The ClipGenerator the runner drives: submit / poll / download, plus
    usage() for the API keys screen."""

    poll_seconds = POLL_SECONDS

    def __init__(self, api_key: str, base_url: str = "", model: str = MODEL,
                 transport: Optional[Callable] = None, **settings):
        self._api_key = (api_key or "").strip()
        self.base_url = normalise_address(base_url)
        self.model = (model or MODEL).strip() or MODEL
        self.transport = transport or _requests_transport
        self.settings = settings
        self.remaining_today: Optional[int] = None   # as the last reply reported it
        # What the live service turned out to say that the document does not:
        # a pay-as-you-go key has no daily limit but a balance and a price per
        # video, and a number of video jobs it will run at once. All three are
        # read off /api/v2/usage and only ever repeated, never estimated.
        self.billing_mode: str = ""
        self.video_price: Optional[float] = None
        self.balance: Optional[float] = None
        self.max_in_flight: Optional[int] = None
        self.quota_label: str = "quota left today"

    # ----------------------------------------------------------- plumbing
    def _ready(self) -> None:
        if not self.base_url or not self.base_url.lower().startswith(("http://", "https://")):
            raise ProviderError(NO_ADDRESS, fatal=True)
        if not self._api_key:
            raise ProviderError("No Omni Flash API key is saved. Enter it under Automate > API keys.", fatal=True)

    def _headers(self) -> Dict[str, str]:
        return {"Authorization": "Bearer " + self._api_key, "Accept": "application/json"}

    def _request(self, method: str, path: str, body=None, timeout: float = STATUS_TIMEOUT, what: str = "request"):
        self._ready()
        url = self.base_url + path
        try:
            return self.transport(method, url, self._headers(), body, timeout, False)
        except ProviderError:
            raise
        except Exception as exc:                                       # noqa: BLE001 - any transport failure
            raise ProviderError("Could not reach Omni Flash at {} for the {}: {}".format(
                _host(url) or self.base_url, what, type(exc).__name__), retryable=True) from exc

    def _checked(self, response, what: str) -> Dict[str, object]:
        code = int(getattr(response, "status_code", 0) or 0)
        if code == 200:
            try:
                data = response.json()
            except ValueError as exc:
                raise ProviderError("Omni Flash's reply to the {} was not JSON".format(what), retryable=True,
                                    detail=(getattr(response, "text", "") or "")[:300]) from exc
            if not isinstance(data, dict):
                raise ProviderError("Omni Flash's reply to the {} had an unexpected shape".format(what),
                                    retryable=False, detail=json.dumps(data)[:300])
            return data
        self._refuse(code, _detail(response), what)
        raise AssertionError("unreachable")

    def _refuse(self, code: int, detail: str, what: str) -> None:
        """The document's error table, in the pipeline's terms. 401, 403
        and 429 stop the whole stage: retrying them scene by scene would
        only fail 150 more times."""
        if code == 400:
            raise ProviderError("Omni Flash rejected the {}: {}".format(what, detail or "invalid request (400)"),
                                retryable=False, detail=detail)
        if code == 401:
            raise ProviderError("Omni Flash did not accept the API key (401: missing or invalid). Check it "
                                "under Automate > API keys.", fatal=True, detail=detail)
        if code == 403:
            raise ProviderError("The Omni Flash API key has been disabled (403). Ask the administrator who "
                                "issued it.", fatal=True, detail=detail)
        if code == 429:
            # The live service (omniflows.tech, 11 Sep 2026) also answers 429
            # when every parallel video slot on the key is taken -- by us or
            # by anyone else sharing the key: "Concurrency limit reached: 5
            # of 5 video threads are busy. Please wait for a running job to
            # complete before submitting more." That is a wait, not a stop.
            lowered = (detail or "").lower()
            if any(word in lowered for word in ("concurrency", "threads are busy", "wait for a running job", "busy")):
                raise ProviderError("Omni Flash is busy: {}".format(detail.strip() or "every parallel job slot is taken"),
                                    retryable=True, busy=True, detail=detail)
            raise ProviderError("Omni Flash's daily limit for this key is reached (429){}. Nothing more can "
                                "be generated until then; the clips already made are kept, and Retry "
                                "continues from them.".format(self._reset_note()), fatal=True, detail=detail)
        if code == 404 and what != "status request":
            raise ProviderError("Omni Flash has no such endpoint at {} (404): check the address under "
                                "Automate > API keys.".format(self.base_url), fatal=True, detail=detail)
        if code >= 500:
            raise ProviderError("Omni Flash had a temporary failure ({}) on the {}; worth retrying".format(code, what),
                                retryable=True, detail=detail)
        raise ProviderError("Omni Flash answered {} to the {}: {}".format(code, what, detail or "no detail"),
                            retryable=False, detail=detail)

    def _reset_note(self) -> str:
        """"; it resets at 13 Jul 05:00 (your clock)" when usage can be
        read, "; it resets at midnight UTC" when it cannot. Never raises."""
        try:
            data = self.usage()
        except ProviderError:
            return "; it resets at midnight UTC"
        reset_at = str(data.get("reset_at") or "")
        if reset_at:
            return "; it resets at {} (your clock)".format(_local_time(reset_at))
        seconds = data.get("reset_in_seconds")
        if isinstance(seconds, (int, float)) and seconds > 0:
            return "; it resets in about {} h {:02d} min".format(int(seconds // 3600), int(seconds % 3600 // 60))
        return "; it resets at midnight UTC"

    # ---------------------------------------------------------- the API
    def submit(self, prompt: str, settings: Dict[str, object]) -> Job:
        self._ready()
        text = (prompt or "").strip()
        if not text:
            raise ProviderError("Omni Flash needs a prompt, and this scene's prompt is empty.", retryable=False)
        if len(text) > MAX_PROMPT:
            raise ProviderError("Omni Flash accepts prompts of 1 to {} characters; this one is {} characters. "
                                "Shorten it in the scene prompts.".format(MAX_PROMPT, len(text)), retryable=False)
        start_frame = settings.get("start_frame") if isinstance(settings, dict) else None
        body = {"prompt": text, "model": self.model,
                "start_frame": start_frame if isinstance(start_frame, str) and start_frame else None}
        response = self._request("POST", GENERATE_PATH, body=body, timeout=SUBMIT_TIMEOUT, what="video request")
        data = self._checked(response, "video request")
        job_id = str(data.get("job_id") or "").strip()
        if not job_id:
            raise ProviderError("Omni Flash accepted the video request but returned no job id", retryable=False,
                                detail=json.dumps(data)[:300], unconfirmed=True)
        status = _STATUS.get(str(data.get("status") or "pending").lower(), "queued")
        if status in ("done", "failed"):
            status = "queued"                       # a fresh job is polled at least once
        log.info("Omni Flash job %s submitted (%s)", job_id, self.model)
        return Job(job_id=job_id, status=status)

    def poll(self, job_id: str) -> Job:
        response = self._request("GET", STATUS_PATH + str(job_id), timeout=STATUS_TIMEOUT, what="status request")
        if int(getattr(response, "status_code", 0) or 0) == 404:
            # Finished jobs are kept for two hours; a production resumed
            # after that has to ask again. Nothing already on disk is lost.
            return Job(job_id=job_id, status="failed",
                       error="Omni Flash no longer has job {} (finished jobs are kept for two hours); "
                             "the clip will be requested again".format(job_id))
        data = self._checked(response, "status request")
        status = str(data.get("status") or "").lower()
        if status in ("pending", "queued"):
            return Job(job_id=job_id, status="queued")
        if status in ("processing", "running"):
            return Job(job_id=job_id, status="running")
        if status == "done":
            url = clean_video_url(str(data.get("video_url") or "").strip())
            if not url:
                raise ProviderError("Omni Flash reported job {} done but gave no video link".format(job_id),
                                    retryable=True, detail=json.dumps(data)[:300])
            remaining = data.get("remaining_today")
            if isinstance(remaining, int) and not isinstance(remaining, bool):
                self.remaining_today = remaining
            # The cost is what the provider says and nothing else. The live
            # service puts "cost" and "balance_remaining" on the done reply
            # of a pay-as-you-go key; failing that, the price its usage
            # endpoint stated; a daily-limit key reports None.
            cost = _number(data.get("cost"))
            if cost is None and self.billing_mode == "payg":
                cost = self.video_price
            balance = _number(data.get("balance_remaining"))
            if balance is not None:
                self.balance = balance
            elif cost is not None and self.balance is not None:
                self.balance = max(0.0, self.balance - cost)
            if self.balance is not None and cost:
                self.remaining_today = int(self.balance // cost)
            return Job(job_id=job_id, status="done", url=url, reported_cost=cost)
        if status == "failed":
            return Job(job_id=job_id, status="failed", error=str(data.get("error") or "Generation failed."))
        raise ProviderError("Omni Flash answered with an unknown job status '{}'".format(status[:40]),
                            retryable=False, detail=json.dumps(data)[:300])

    def download(self, job: Job, dest: Path) -> Path:
        """The clip to `dest`, through a .part file, so a half-written
        download never carries a real name. Bounded retries on the network
        and on the server; an expired link is reported, not retried."""
        url = (job.url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise ProviderError("Job {} has no usable video link".format(job.job_id), retryable=True)
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        partial = dest.with_suffix(dest.suffix + ".part")
        # The link carries its own token. The key is sent only when the
        # link lives on the API's own host, never to a third party.
        headers = self._headers() if _host(url) == _host(self.base_url) else {}
        last: Optional[ProviderError] = None
        for attempt in range(1, DOWNLOAD_ATTEMPTS + 1):
            try:
                response = self.transport("GET", url, headers, None, DOWNLOAD_TIMEOUT, True)
            except Exception as exc:                                   # noqa: BLE001 - any transport failure
                last = ProviderError("Could not download clip {}: {}".format(job.job_id, type(exc).__name__),
                                     retryable=True)
                time.sleep(min(10, 2 * attempt))
                continue
            code = int(getattr(response, "status_code", 0) or 0)
            if code >= 500:
                last = ProviderError("The video host answered {} for job {}".format(code, job.job_id), retryable=True)
                time.sleep(min(10, 2 * attempt))
                continue
            if code in (401, 403, 404, 410):
                raise ProviderError("The video link for job {} was refused ({}); links expire about 24 hours "
                                    "after generation. The clip will be requested again.".format(job.job_id, code),
                                    retryable=True)
            if code != 200:
                raise ProviderError("The video link for job {} answered {}".format(job.job_id, code), retryable=False)
            kind = str((getattr(response, "headers", None) or {}).get("Content-Type", "") or "").lower()
            if "json" in kind or "html" in kind:
                raise ProviderError("The video link for job {} answered with {} instead of a video".format(
                    job.job_id, kind.split(";")[0]), retryable=True, detail=_detail(response))
            written = self._write(response, partial)
            if written < MIN_CLIP_BYTES:
                partial.unlink(missing_ok=True)
                last = ProviderError("The download for job {} was only {} bytes".format(job.job_id, written),
                                     retryable=True)
                continue
            partial.replace(dest)                            # only a complete file gets the real name
            log.info("Omni Flash job %s downloaded: %s (%d bytes)", job.job_id, dest.name, written)
            return dest
        partial.unlink(missing_ok=True)
        raise last or ProviderError("Clip {} could not be downloaded".format(job.job_id), retryable=True)

    @staticmethod
    def _write(response, partial: Path) -> int:
        chunks = getattr(response, "iter_content", None)
        written = 0
        with open(partial, "wb") as out:
            if callable(chunks):
                for chunk in chunks(1024 * 256):
                    if chunk:
                        out.write(chunk)
                        written += len(chunk)
            else:
                body = getattr(response, "content", b"") or b""
                out.write(body)
                written = len(body)
        return written

    def usage(self, timeout: float = STATUS_TIMEOUT) -> Dict[str, object]:
        """Today's quota, as the key's administrator set it. Free: it
        generates nothing. What the reply says about billing and parallel
        jobs is kept on the generator for the runner and the screens."""
        response = self._request("GET", USAGE_PATH, timeout=timeout, what="usage request")
        data = self._checked(response, "usage request")
        self._learn(data)
        return data

    def _learn(self, data: Dict[str, object]) -> None:
        mode = str(data.get("billing_mode") or "").strip().lower()
        self.billing_mode = mode
        threads = data.get("max_video_threads")
        if isinstance(threads, int) and not isinstance(threads, bool) and threads > 0:
            self.max_in_flight = threads
        if mode == "payg":
            price = _number(data.get("payg_video_price"))
            balance = _number(data.get("balance"))
            self.video_price, self.balance = price, balance
            self.quota_label = "videos the balance covers"
            if price and balance is not None:
                self.remaining_today = int(balance // price) if price > 0 else None
        else:
            self.quota_label = "quota left today"
            left = data.get("omniflash_remaining_today")
            if left is None:
                left = data.get("image_remaining_today")
            if isinstance(left, int) and not isinstance(left, bool):
                self.remaining_today = left

    def quota_text(self, timeout: float = STATUS_TIMEOUT) -> str:
        """One line for the API keys screen."""
        data = self.usage(timeout)
        label = str(data.get("label") or "").strip()
        if self.billing_mode == "payg":
            price, balance = self.video_price, self.balance
            parts = ["pay-as-you-go"]
            if balance is not None:
                parts.append("balance {:g}".format(balance))
            if price is not None:
                parts.append("{:g} per video".format(price))
                if balance is not None and price > 0:
                    parts.append("about {} videos".format(int(balance // price)))
            if self.max_in_flight:
                parts.append("up to {} video jobs at a time".format(self.max_in_flight))
            made = data.get("total_videos_generated")
            if isinstance(made, int) and not isinstance(made, bool):
                parts.append("{} videos made on this key so far".format(made))
            if data.get("video_gen_enabled") is False:
                parts.append("VIDEO GENERATION IS DISABLED on this key")
            text = "; ".join(parts)
            if label:
                text = "Key '{}': ".format(label[:40]) + text
            return "Omni Flash reachable. " + text
        limit = data.get("omniflash_daily_limit")
        used = data.get("omniflash_used_today")
        left = data.get("omniflash_remaining_today")
        if limit is None:
            limit, used, left = data.get("image_daily_limit"), data.get("image_used_today"), data.get("image_remaining_today")
            pool = "videos share the image pool: "
        else:
            pool = "videos today: "
        reset = str(data.get("reset_at") or "")
        text = "{}{} used of {}, {} left".format(pool, used if used is not None else "?", limit if limit is not None else "?",
                                                left if left is not None else "?")
        if reset:
            text += "; resets at {} (your clock)".format(_local_time(reset))
        if label:
            text = "Key '{}': ".format(label[:40]) + text
        return "Omni Flash reachable. " + text


def _number(value) -> Optional[float]:
    """A float from a JSON number, or None for anything else (bools included)."""
    if isinstance(value, bool) or value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


_TOKEN = re.compile(r"[?&]token=([^?&]+)")


def clean_video_url(url: str) -> str:
    """The video link with one signed token.

    Seen live (omniflows.tech, 11 Sep 2026): every status poll re-signs the
    stored link and APPENDS another "?token=…", so after the second poll
    the link reads "…mp4?token=A?token=B" and the server refuses its own
    link ("Invalid or expired token"). Only the first token verifies. The
    path is kept and the first token alone is put back on it. A link with
    one token, or none, is returned unchanged.
    """
    if not url:
        return url
    tokens = _TOKEN.findall(url)
    if len(tokens) <= 1:
        return url
    return url.split("?", 1)[0] + "?token=" + tokens[0]


_SCHEME = re.compile(r"^[a-z][a-z0-9+.\-]*://", re.I)
_API_PREFIX = re.compile(r"/api/v2(?:/.*)?$", re.I)


def normalise_address(text: str) -> str:
    """The service address the way the adapter needs it.

    "omniflows.tech", "omniflows.tech/", "HTTPS://Omniflows.tech/" and
    "https://omniflows.tech/api/v2" (the document's path, typed along) all
    become "https://omniflows.tech". Seen on Rizwan's laptop on 11 Sep:
    the address typed as "omniflows.tech" under Automate > API keys was
    saved as typed, and every request then stopped with NO_ADDRESS, which
    reads as if nothing had been entered. Anything that is not http(s) is
    returned trimmed and left for _ready() to refuse by name.
    """
    text = (text or "").strip().strip("'\"").strip()
    if not text:
        return ""
    if not _SCHEME.match(text):
        text = "https://" + text
    scheme, _, rest = text.partition("://")
    scheme = scheme.lower()
    if scheme not in ("http", "https"):
        return text.rstrip("/")
    host, slash, path = rest.partition("/")
    path = _API_PREFIX.sub("", "/" + path if slash else "")
    return "{}://{}{}".format(scheme, host.lower(), path).rstrip("/")
