"""Selected-account passwords, protected for the current Windows user by DPAPI."""
import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path


def protect(value, decrypt=False):
    if os.name != 'nt':
        raise ValueError('Local password storage requires Windows')
    class Blob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]
    buffer = ctypes.create_string_buffer(value)
    source = Blob(len(value), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    function = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    function.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                         ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
    function.restype = wintypes.BOOL
    if not function(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise ValueError('Windows could not unlock this password vault')
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        free = ctypes.WinDLL('kernel32').LocalFree
        free.argtypes = [ctypes.c_void_p]
        free.restype = ctypes.c_void_p
        free(result.data)


class LoginVault:
    def __init__(self, root):
        self.path = Path(root) / 'scene-server' / 'login-passwords.dpapi'

    def read(self):
        return json.loads(protect(self.path.read_bytes(), True)) if self.path.exists() else {}

    def get(self, email):
        return self.read().get(email.casefold(), '')

    def save_many(self, entries):
        saved = self.read()
        for email, password in entries.items():
            if not isinstance(password, str) or len(password) > 4096:
                raise ValueError('Invalid password')
            if password:
                saved[email.casefold()] = password
            else:
                saved.pop(email.casefold(), None)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix('.tmp')
        temporary.write_bytes(protect(json.dumps(saved).encode('utf-8')))
        temporary.replace(self.path)
