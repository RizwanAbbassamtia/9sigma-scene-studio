"""The two things every way of starting a production shares: seeding it
from what the person already has, and building its providers.

The wizard, the dashboard and the batch screen all call these, so a
production started from a folder of clips is the same object whichever
screen made it, and "test mode" means the same mock providers everywhere.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from ..config import Config
from . import prompts as prompt_text
from .credentials import Credentials
from .manifest import EpisodeRecord, Production, SOURCE_START, Stage
from .providers import MockClipGenerator, MockPromptWriter, MockScriptWriter
from .runner import Providers
from .screenplay import parse as parse_screenplay

SAMPLES = Path(__file__).resolve().parent.parent.parent / "samples"


def seed_production(production: Production, episode: EpisodeRecord, source_type: str,
                    existing: Optional[Path] = None, script_text: str = "", prompts_text: str = "") -> None:
    """Record what the person already has on one episode, and skip the
    stages before it.

    source_type is one of manifest.SOURCE_TYPES. Text may come from a file
    (`existing`, for "script" and "prompts") or be given directly; imported
    text is copied into the episode folder as version 1 and never
    rewritten. For "clips" and "composition" `existing` is the folder.
    """
    work = Path(production.working_dir) / "ep{:02d}".format(episode.number)
    work.mkdir(parents=True, exist_ok=True)
    if existing is not None and source_type in ("script", "prompts"):
        text = Path(existing).read_text(encoding="utf-8", errors="replace")
        script_text, prompts_text = (text, "") if source_type == "script" else ("", text)
    if source_type in ("script", "script_prompts") and script_text.strip():
        copy = work / "script-v{}.txt".format(len(episode.scripts) + 1)
        copy.write_text(script_text, encoding="utf-8")
        play = parse_screenplay(script_text)
        episode.add_script(copy, script_text, source="imported", scenes=len(play.scenes))
        episode.skip_through(Stage.SCRIPT)
    if source_type in ("prompts", "script_prompts"):
        copy = work / "prompts-v{}.txt".format(len(episode.prompt_sets) + 1)
        copy.write_text(prompts_text, encoding="utf-8")
        items, problems = prompt_text.parse_report(
            prompts_text, float(production.generation_settings.get("max_seconds", 0) or 0))
        prompt_set = episode.add_prompt_set(copy, items, source="imported")
        prompt_set.validation = problems
        episode.skip_through(Stage.PROMPTS)
    if source_type == "clips" and existing is not None:
        episode.clips_dir = str(existing)
        episode.skip_through(Stage.CLIPS)
    if source_type == "composition" and existing is not None:
        episode.clips_dir = str(existing)
        episode.skip_through(Stage.EDIT)
    # The range recorded on the production is what the dashboard shows.
    if production.start_stage == Stage.SCRIPT.value and source_type != "title":
        production.start_stage = SOURCE_START[source_type].value
        production.source_type = source_type


def make_providers(credentials: Optional[Credentials], config: Config, mock: bool) -> Providers:
    """Mock providers for test mode, otherwise whatever keys are sealed on
    this machine; a stage whose provider is None is refused by the runner
    with a message naming the key."""
    if mock:
        return Providers(MockScriptWriter(SAMPLES / "script-example-ghareeb-ghar-damaad.txt"),
                         MockPromptWriter(SAMPLES / "scene-prompts-example-ep11.txt"),
                         MockClipGenerator(seconds=3.0))
    from .omniflash import MODEL as OMNI_MODEL, OmniFlashGenerator
    from .providers import AnthropicPromptWriter, OpenAIScriptWriter
    if credentials is None:
        return Providers()
    openai = credentials.get("openai")
    anthropic = credentials.get("anthropic")
    omni = credentials.get("omniflash")
    address = str(getattr(config, "omniflash_base_url", "") or "")
    model = str(getattr(config, "omniflash_model", "") or "") or OMNI_MODEL
    return Providers(OpenAIScriptWriter(openai) if openai else None,
                     AnthropicPromptWriter(anthropic) if anthropic else None,
                     OmniFlashGenerator(omni, base_url=address, model=model) if omni else None)
