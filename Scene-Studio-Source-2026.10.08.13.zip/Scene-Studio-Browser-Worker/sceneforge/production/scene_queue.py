"""Durable Flow -> Gemini scene queue. Browser adapters perform all live checks."""
from contextlib import contextmanager
from dataclasses import asdict, replace
from pathlib import Path
import json
import os
import sqlite3
import time

from .flow_browser_run import BrowserSettings
from .master import _write_atomic


class AccountUnavailable(RuntimeError):
    """Confirmed unavailable before submission; another account may be used."""


class GenerationRejected(RuntimeError):
    """The service explicitly reported failure; no completed result is assumed."""


class QuotaReached(GenerationRejected):
    """Google explicitly rejected the attempt because the account hit its limit."""


@contextmanager
def browser_lock(root):
    """OS-owned lock released on crash, shared by desktop and web workers."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    stream = (root / 'worker.lock').open('a+b')
    try:
        try:
            stream.seek(0)
            if not stream.read(1):
                stream.write(b'0')
                stream.flush()
            stream.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError('Another browser worker is using these accounts. Stop it first.') from exc
        yield
    finally:
        stream.close()


class GeminiUsage:
    """Conservative rolling 24-hour reservation, shared across all local runs.

    This is a local cap, not a claim about Google's reset schedule. Attempts
    remain counted after crashes/failures because a remote charge is uncertain.
    """
    def __init__(self, path, clock=time.time):
        self.clock = clock
        self.db = sqlite3.connect(str(path), timeout=10)
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('CREATE TABLE IF NOT EXISTS usage(email TEXT, at REAL, run TEXT, scene INTEGER)')
        self.db.commit()

    def remaining(self, email, limit=3):
        used = self.db.execute('SELECT COUNT(*) FROM usage WHERE email=? AND at>?',
                               (email.casefold(), self.clock() - 86400)).fetchone()[0]
        return max(0, limit - used)

    def snapshot(self, email, limit=3):
        times = [r[0] for r in self.db.execute(
            'SELECT at FROM usage WHERE email=? AND at>? ORDER BY at',
            (email.casefold(), self.clock() - 86400))]
        # If a run used a lower cap, enough old reservations must expire first.
        next_slot = times[len(times) - limit] + 86400 if limit > 0 and len(times) >= limit else None
        return dict(remaining=max(0, limit-len(times)), used=len(times), limit=limit,
                    next_slot_at=next_slot, window='rolling_24h', source='local_attempt_cap')

    def reserve(self, email, run, scene, limit=3):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            if self.remaining(email, limit) <= 0:
                raise AccountUnavailable('Local Gemini allowance is exhausted for this account')
            self.db.execute('INSERT INTO usage VALUES(?,?,?,?)',
                            (email.casefold(), self.clock(), str(run), scene))
            self.db.commit()
        except Exception:
            self.db.rollback()
            raise

    def close(self):
        self.db.close()

    def exhaust(self, email, run, scene, limit=3):
        for _ in range(self.remaining(email, limit)):
            self.reserve(email, run, scene, limit)


class SceneQueue:
    def __init__(self, folder):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.folder / 'queue.sqlite'), timeout=10)
        self.db.row_factory = sqlite3.Row
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS scenes(number INTEGER PRIMARY KEY, prompt TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'todo', provider TEXT, account TEXT, receipt TEXT,
                file TEXT, note TEXT, charged INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY, scene INTEGER,
                provider TEXT, account TEXT, at REAL, status TEXT, receipt TEXT, note TEXT);
        ''')
        self.db.commit()

    def get(self, key, default=None):
        row = self.db.execute('SELECT value FROM config WHERE key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def put(self, key, value):
        with self.db:
            self.db.execute('INSERT OR REPLACE INTO config VALUES(?,?)', (key, json.dumps(value)))

    def create(self, prompts, accounts, settings, budget=None, gemini_limit=3):
        settings.validate()
        if not prompts or len(prompts) > 10000 or any(not isinstance(p, str) or not p.strip() or len(p) > 30000 for p in prompts):
            raise ValueError('Enter 1–10000 nonempty scene prompts, at most 30000 characters each')
        if not accounts or len(accounts) != len(set(accounts)):
            raise ValueError('Choose unique accounts in the desired order')
        if budget is not None and (type(budget) is not int or budget <= 0):
            raise ValueError('Flow credit cap must be positive or blank for all available credits')
        if type(gemini_limit) is not int or not 0 <= gemini_limit <= 3:
            raise ValueError('Gemini cap must be between zero and three')
        if self.rows():
            raise ValueError('Run already exists')
        with self.db:
            values = dict(accounts=accounts, settings=asdict(settings), budget=budget,
                          gemini_limit=gemini_limit, stage='flow', created=time.time())
            self.db.executemany('INSERT INTO config VALUES(?,?)', [(k, json.dumps(v)) for k, v in values.items()])
            self.db.executemany('INSERT INTO scenes(number,prompt) VALUES(?,?)', enumerate(prompts, 1))
        self.export()

    def rows(self):
        return [dict(r) for r in self.db.execute('SELECT * FROM scenes ORDER BY number')]

    def update(self, number, **values):
        if not values or not set(values) <= {'status', 'provider', 'account', 'receipt', 'file', 'note', 'charged'}:
            raise ValueError('Invalid scene update')
        with self.db:
            self.db.execute('UPDATE scenes SET ' + ','.join(k + '=?' for k in values) + ' WHERE number=?',
                            (*values.values(), number))

    def begin(self, number, provider, account):
        with self.db:
            count = self.db.execute("UPDATE scenes SET status='submitting', provider=?, account=?, note=NULL WHERE number=? AND status='todo'",
                                    (provider, account, number)).rowcount
            if count != 1:
                raise RuntimeError('Scene was already claimed')
            cursor = self.db.execute('INSERT INTO attempts(scene,provider,account,at,status) VALUES(?,?,?,?,?)',
                                     (number, provider, account, time.time(), 'submitting'))
        return cursor.lastrowid

    def attempt(self, attempt, status, receipt=None, note=None):
        with self.db:
            self.db.execute('UPDATE attempts SET status=?, receipt=COALESCE(?,receipt), note=? WHERE id=?',
                            (status, receipt, note, attempt))

    def recover(self):
        with self.db:
            self.db.execute("UPDATE scenes SET status='review', note='Interrupted submission. Check the provider before retrying.' WHERE status IN ('submitting','generating')")

    def retry(self, numbers, reviewed=False):
        if not numbers:
            raise ValueError('Select unfinished scenes to retry')
        rows = {r['number']: r for r in self.rows()}
        for number in numbers:
            if number not in rows or rows[number]['status'] == 'done':
                raise ValueError('Completed or unknown scenes cannot be retried')
            if rows[number]['status'] in ('review', 'submitting', 'generating') and not reviewed:
                raise ValueError('Check the provider first and confirm that no usable video exists')
            if rows[number]['file'] and Path(rows[number]['file']).exists():
                raise ValueError('This scene already has a local video. Inspect and accept it instead of regenerating.')
        with self.db:
            self.db.executemany("UPDATE scenes SET status='todo', note=NULL, receipt=NULL WHERE number=?", [(n,) for n in numbers])
        self.put('stage', 'flow')
        self.export()

    def export(self):
        rows = self.rows()
        pending = [r for r in rows if r['status'] != 'done']
        safe = [r for r in pending if r['status'] in ('todo', 'failed')]
        review = [r for r in pending if r['status'] not in ('todo', 'failed')]
        _write_atomic(self.folder / 'unfinished-prompts.json', json.dumps(pending, ensure_ascii=False, indent=2))
        _write_atomic(self.folder / 'retry-prompts.txt', '\n\n'.join(f"{r['number']}: {r['prompt']}" for r in safe))
        _write_atomic(self.folder / 'review-prompts.txt', '\n\n'.join(f"{r['number']}: {r['prompt']}\nReason: {r['note'] or r['status']}" for r in review))

    def close(self):
        self.db.close()


def execute_queue(queue, accounts, flow, gemini, usage, emit=lambda s: None, stopped=lambda: False):
    queue.recover()
    settings = BrowserSettings(**queue.get('settings'))
    selected = {a['id']: a for a in accounts}
    ordered = [selected[i] for i in queue.get('accounts') if i in selected]
    try:
        for account in ordered:
            for provider, browser in [('flow', flow), ('gemini', gemini)]:
                queue.put('stage', provider)
                if stopped():
                    return 'Stopped; unfinished prompts saved'
                pending = [r for r in queue.rows() if r['status'] == 'todo']
                if not pending:
                    break
                if provider == 'gemini' and usage.remaining(account['email'], queue.get('gemini_limit')) == 0:
                    continue
                try:
                    try:
                        emit(f"Checking {provider} / {account['id']} saved session before submission")
                        browser.open(account)
                    except RuntimeError as exc:
                        raise AccountUnavailable('Profile login or connection needs admin attention: ' + str(exc)) from exc
                    for row in pending:
                        if stopped():
                            return 'Stopped; unfinished prompts saved'
                        quote = None
                        if provider == 'flow':
                            try:
                                quote = browser.quote(settings, row['prompt'])
                            except Exception as exc:
                                raise AccountUnavailable('Flow generation controls could not be verified before submission: ' + str(exc)) from exc
                            quote.verify(account['email'])
                            if quote.balance < quote.cost:
                                emit(f"{account['id']}: Flow balance {quote.balance} cannot cover {quote.cost}; next account")
                                break
                            cap = queue.get('budget')
                            spent = sum(r['charged'] for r in queue.rows())
                            if cap is not None and spent + quote.cost > cap:
                                emit('Flow credit cap reached; moving to Gemini')
                                break
                        else:
                            if usage.remaining(account['email'], queue.get('gemini_limit')) == 0:
                                break
                            # Draft 360p is a Flow setting, not a Gemini app setting.
                            try:
                                browser.prepare(replace(settings, resolution='720p'), row['prompt'])
                            except Exception as exc:
                                raise AccountUnavailable('Gemini generation controls could not be verified before submission: ' + str(exc)) from exc
                        if stopped():
                            return 'Stopped before submission'
                        # The destination is chosen and checked before any remote submission.
                        next_attempt = queue.db.execute('SELECT COALESCE(MAX(id),0)+1 FROM attempts').fetchone()[0]
                        dest = queue.folder / f"{row['number']:04d}_{provider}_attempt{next_attempt}.mp4"
                        if dest.exists():
                            queue.update(row['number'], status='review', file=str(dest), note='Existing local video needs review')
                            continue
                        attempt = queue.begin(row['number'], provider, account['id'])
                        prior_charge = row['charged']
                        if quote:
                            queue.update(row['number'], charged=prior_charge + quote.cost)
                        try:
                            if provider == 'gemini':
                                usage.reserve(account['email'], queue.folder, row['number'], queue.get('gemini_limit'))
                            receipt = browser.submit(row['prompt'])
                            queue.update(row['number'], status='generating', receipt=receipt)
                            queue.attempt(attempt, 'generating', receipt)
                            browser.finish(receipt, dest)
                            queue.update(row['number'], file=str(dest))
                            if provider == 'flow':
                                email, balance = browser.balance()
                                if email.casefold() != account['email'].casefold() or type(balance) is not int or balance < 0:
                                    raise RuntimeError('Cannot confirm resulting Flow balance')
                                charge = quote.balance - balance
                                queue.update(row['number'], charged=prior_charge + max(quote.cost, charge))
                                if charge != quote.cost:
                                    raise RuntimeError('Flow charge differs from quote; inspect the saved video and balance')
                            queue.update(row['number'], status='done', note=None)
                            queue.attempt(attempt, 'done')
                            emit(f"Scene {row['number']} saved via {provider} / {account['id']}")
                        except QuotaReached as exc:
                            queue.update(row['number'], status='todo', note=str(exc))
                            queue.attempt(attempt, 'quota_rejected', note=str(exc))
                            if provider == 'gemini':
                                usage.exhaust(account['email'], queue.folder, row['number'], queue.get('gemini_limit'))
                            emit(f"{provider} / {account['id']}: quota reached; next account")
                            break
                        except GenerationRejected as exc:
                            queue.update(row['number'], status='failed', note=str(exc))
                            queue.attempt(attempt, 'failed', note=str(exc))
                            emit(f"Scene {row['number']} failed: {exc}")
                        except Exception as exc:
                            # Reserve the quote against the cap even when billing cannot be confirmed.
                            current = next(r for r in queue.rows() if r['number'] == row['number'])
                            queue.update(row['number'], status='review', note=str(exc),
                                         file=str(dest) if dest.exists() else current['file'],
                                         charged=max(current['charged'], quote.cost if quote else 0))
                            queue.attempt(attempt, 'review', note=str(exc))
                            raise
                        finally:
                            queue.export()
                except AccountUnavailable as exc:
                    emit(f"{provider} / {account['id']}: {exc}; next account")
                finally:
                    browser.close()
            # Each account uses Flow then Gemini; the budget applies across all accounts.
        queue.put('stage', 'complete')
        unfinished = sum(r['status'] != 'done' for r in queue.rows())
        return f'Run finished: {unfinished} unfinished scene(s) exported' if unfinished else 'All scenes saved locally'
    finally:
        flow.close()
        gemini.close()
        queue.export()
