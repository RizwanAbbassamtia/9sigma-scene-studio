"""Locate Chrome, including a running portable copy, without reading its profile."""
import json
import os
from pathlib import Path
import shutil
import subprocess

from .master import _write_atomic


def _valid_path(value):
    if not isinstance(value, str) or not value.strip():
        return None
    value = os.path.expandvars(value.strip().strip('"'))
    if value.startswith(('\\\\', '//')):
        return None
    path = Path(value)
    if not path.is_absolute() or path.name.casefold() != 'chrome.exe':
        return None
    try:
        return path.resolve() if path.is_file() else None
    except OSError:
        return None


def _registry_paths():
    if os.name != 'nt':
        return []
    import winreg
    paths = []
    key = r'Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'
    for hive in (winreg.HKEY_CURRENT_USER, winreg.HKEY_LOCAL_MACHINE):
        for view in (winreg.KEY_WOW64_64KEY, winreg.KEY_WOW64_32KEY):
            try:
                with winreg.OpenKey(hive, key, 0, winreg.KEY_READ | view) as opened:
                    paths.append(winreg.QueryValueEx(opened, '')[0])
            except OSError:
                continue
    return paths


def _installed_paths():
    paths = [str(Path(os.environ[name]) / 'Google' / 'Chrome' / 'Application' / 'chrome.exe')
             for name in ('PROGRAMFILES', 'PROGRAMFILES(X86)', 'ProgramW6432', 'LOCALAPPDATA')
             if os.environ.get(name)]
    paths.extend(_registry_paths())
    found = shutil.which('chrome.exe')
    if found:
        paths.append(found)
    return paths


def _running_paths():
    """Read executable paths only; never inspect command lines, cookies or sessions."""
    if os.name != 'nt':
        return []
    powershell = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'WindowsPowerShell' / 'v1.0' / 'powershell.exe'
    command = ('[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new(); '
               'Get-Process -Name chrome -ErrorAction SilentlyContinue | '
               'ForEach-Object { $_.Path } | Sort-Object -Unique')
    try:
        result = subprocess.run([str(powershell), '-NoProfile', '-NonInteractive', '-Command', command],
                                capture_output=True, text=True, encoding='utf-8', errors='replace',
                                timeout=8, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        return result.stdout.splitlines() if result.returncode == 0 else []
    except (OSError, subprocess.TimeoutExpired):
        return []


def resolve_chrome(root=None, *, override=None, remember=False):
    """Use one executable for startup checks and both provider browser launches."""
    explicit = override or os.environ.get('SCENE_CHROME_PATH')
    settings = Path(root) / 'browser-runtime.json' if root is not None else None
    if explicit:
        selected = _valid_path(explicit)
        if selected is None:
            raise RuntimeError('The selected Chrome path is invalid. Choose the full path to chrome.exe, not the portable launcher.')
    else:
        selected = None
        if settings and settings.exists():
            try:
                saved = json.loads(settings.read_text(encoding='utf-8'))
                selected = _valid_path(saved.get('chrome_executable')) if isinstance(saved, dict) else None
            except (OSError, ValueError):
                raise RuntimeError('Saved browser location could not be read. Set SCENE_CHROME_PATH to your chrome.exe to repair it.') from None
        if selected is None:
            selected = next((path for value in _installed_paths() if (path := _valid_path(value))), None)
        if selected is None:
            portable = {str(path).casefold(): path for value in _running_paths() if (path := _valid_path(value))}
            if len(portable) > 1:
                raise RuntimeError('Several Chrome installations are running. Set SCENE_CHROME_PATH to the chrome.exe you want this worker to use.')
            selected = next(iter(portable.values()), None)
    if selected is None:
        raise RuntimeError('Chrome was not found. Open your portable Chrome once and retry, or set SCENE_CHROME_PATH to its chrome.exe. You can also install Google Chrome.')
    if remember and settings:
        settings.parent.mkdir(parents=True, exist_ok=True)
        content = json.dumps({'chrome_executable': str(selected)}, indent=2)
        if not settings.exists() or settings.read_text(encoding='utf-8') != content:
            _write_atomic(settings, content)
    return selected
