"""Google Flow integration with visible setup and optional headless generation.

Controls were inspected in Flow on 2026-09-30. Missing controls, wrong accounts,
login challenges and ambiguous results stop the run; there are no stealth flags.
Each account uses an app-managed Chrome profile, signed in by its owner once.
"""
import json
import re
import time
from pathlib import Path
from urllib.parse import urlparse

from .flow_browser_run import LiveQuote
from .master import _write_atomic
from .providers import validate_clip
from .profile_proxy import ProfileProxies
from .chrome_runtime import resolve_chrome
from .profile_network import network_error_message
from .saved_profiles import saved_folder
from ..ffmpeg_tools import find_tool, run as run_tool


EMAIL = re.compile(r'[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}')
CREDIT = re.compile(r'^([\d,]+) Google Flow credits$')
COST = re.compile(r'^([\d,]+) credits?$')
PROJECT_PATH = re.compile(r'/(?:u/\d+/)?project/[a-f0-9-]+')
GOOGLE_SIGN_IN_URL = 'https://accounts.google.com/signin?continue=https%3A%2F%2Fmyaccount.google.com%2F&hl=en'


class FlowAccessRestricted(RuntimeError):
    """Flow explicitly reports that this account cannot use the service."""


class FlowBrowser:
    def __init__(self, profile_root, run_folder, emit=lambda message: None, observe=None, *, headless=False):
        self.profile_root = Path(profile_root)
        self.run_folder = Path(run_folder)
        self.emit = emit
        self.observe = observe
        self.headless = bool(headless)
        self.runtime = None
        self.context = None
        self.page = None
        self.project_url = ''
        self.pending_prompt = ''

    def _start(self, account):
        self.close()
        if not re.fullmatch(r'FA-\d{3,}', account['id']):
            raise ValueError('Invalid account identifier')
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise RuntimeError('Browser component is missing. Install the updated Omni Flow package.') from exc
        profile_name=account.get('managed_profile',account['id'])
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',profile_name):
            raise ValueError('Invalid managed profile')
        profile=(saved_folder(self.profile_root.parent, profile_name)
                 if account.get('profile_storage') == 'saved' else self.profile_root / profile_name)
        if not profile.resolve().is_relative_to(self.profile_root.parent.resolve()):
            raise ValueError('Browser profile must remain inside the app data folder')
        proxy = ProfileProxies(self.profile_root.parent).launch_options(profile_name)
        executable = resolve_chrome(self.profile_root.parent)
        profile.mkdir(parents=True,exist_ok=True)
        self.runtime = sync_playwright().start()
        try:
            self.context=self.runtime.chromium.launch_persistent_context(
                str(profile),executable_path=str(executable),headless=self.headless,accept_downloads=True,
                chromium_sandbox=True,locale='en-US',viewport={'width':1280,'height':900},timeout=30000,
                **({'proxy': proxy} if proxy else {'args': ['--no-proxy-server']}))
        except Exception as exc:
            self.close()
            if re.search(r'ProcessSingleton|profile.*in use|exitCode=21|singleton', str(exc), re.I):
                raise RuntimeError(f"{account['id']}: close this profile's visible Chrome window so the background worker can use its saved session.") from None
            raise RuntimeError(f"{account['id']}: Chrome could not open the saved profile. Check Chrome, the profile lock and proxy settings. No direct-connection retry was attempted.") from None
        self.page=self.context.pages[0] if self.context.pages else self.context.new_page()
        self.page.set_default_timeout(30000)
        self.account = dict(account)

    def preflight_failure(self, service):
        """Retain a local page diagnostic; never inspect browser session storage."""
        location = urlparse(self.page.url)
        page_name = self.page.title()[:160]
        self.run_folder.mkdir(parents=True, exist_ok=True)
        name = 'preflight_{}_{}'.format(self.account['id'], service)
        try:
            self.page.screenshot(path=str(self.run_folder / (name + '.png')))
        except Exception:
            pass
        detail = {'service': service, 'profile': self.account['id'], 'title': page_name,
                  'page': location.scheme + '://' + location.netloc + location.path}
        detail['controls'] = self.page.locator('button, a, [role="button"]').evaluate_all(
            "els => els.filter(e => e.getClientRects().length).slice(0,60).map(e => ({role:e.getAttribute('role')||e.tagName,label:e.getAttribute('aria-label')||'',text:(e.innerText||'').slice(0,100)}))")
        _write_atomic(self.run_folder / (name + '.json'), json.dumps(detail))
        return f"{service.title()} did not expose a signed-in account on {detail['page']} ({page_name}). No prompt submitted."

    def connect(self, account, stopped=lambda: False):
        return self._connect_service(account, 'flow', stopped)

    def _wait_for_account(self, service, stopped, timeout=600):
        """Verify the visible account on the expected Google site, never cookies."""
        host = {'google': 'myaccount.google.com', 'flow': 'flow.google.com',
                'gemini': 'gemini.google.com'}[service]
        deadline = time.monotonic() + timeout
        entered_flow = False
        entered_google = False
        while time.monotonic() < deadline:
            if stopped():
                raise RuntimeError('Sign-in cancelled. Saved browser data is kept.')
            if self.page.is_closed():
                raise RuntimeError('The sign-in window was closed. Select Sign in to Google to resume.')
            location = urlparse(self.page.url)
            if location.scheme == 'https' and location.netloc == host:
                # Flow can still show its public entry page after Google sign-in.
                # Only follow its observed entry control, once; onboarding stays manual.
                landing = service == 'flow' and location.path.rstrip('/') == '/about'
                if landing and not entered_flow:
                    entry = self.page.get_by_role('button', name='Create with Google Flow', exact=True)
                    if entry.count() and entry.first.is_visible():
                        entry.first.click()
                        entered_flow = True
                        self.page.wait_for_timeout(1000)
                        continue
                if not landing:
                    button = self.page.get_by_role('button', name=re.compile(r'^Google Account:'))
                    if button.count() == 1 and button.is_visible():
                        emails = {x.casefold() for x in EMAIL.findall(button.get_attribute('aria-label') or '')}
                        if emails == {self.account['email'].casefold()}:
                            return
                        if emails:
                            raise RuntimeError('A different Google account is signed in. Reconnect the email selected in the account pool.')
                    if service == 'google' and not entered_google:
                        # Some signed-out accounts first see the My Account intro.
                        for role in ('link', 'button'):
                            sign_in = self.page.get_by_role(role, name='Sign in', exact=True)
                            if sign_in.count() and sign_in.first.is_visible():
                                sign_in.first.click()
                                entered_google = True
                                break
            self.page.wait_for_timeout(1000)
        raise RuntimeError(f'{service.title()} sign-in was not confirmed. Complete Google verification or any service setup, then retry.')

    def _connect_service(self, account, service, stopped):
        """Sign in with Google first, then open the service in the same saved profile."""
        generation_mode = self.headless
        self.headless = False  # Account verification always needs a visible window.
        try:
            self._start(account)
            self.emit('Google sign-in: {}. Enter your password and verification directly in Chrome; keep this window open.'.format(account['email']))
            # Open Google's public sign-in form directly, avoiding the My Account
            # introduction. Google returns to My Account for visible email verification.
            self._open_signin_page(GOOGLE_SIGN_IN_URL)
            self._wait_for_account('google', stopped)
            if stopped():
                raise RuntimeError('Sign-in cancelled. Saved browser data is kept.')
            self.emit('Google login verified. Opening {} for this saved profile.'.format(service.title()))
            self._open_signin_page(self.service_url(service))
            self._wait_for_account(service, stopped)
            return '{} account connected: {}'.format(service.title(), account['email'])
        finally:
            self.close()
            self.headless = generation_mode

    def _open_signin_page(self, url):
        # A slow page must not close the user's authentication window after 30s.
        # The normal identity loop keeps it open for verification or cancellation.
        from playwright.sync_api import Error
        try:
            self.page.goto(url, wait_until='commit', timeout=20000)
        except Error as exc:
            self.emit(network_error_message(exc) + ' Chrome remains open so you can inspect the page or reload it. Use Cancel sign-in in the admin page to stop.')

    def open(self, account):
        self._start(account)
        try:
            self._open_flow(account)
        except Exception as exc:
            diagnostic = self.preflight_failure('flow')
            if isinstance(exc, FlowAccessRestricted):
                raise
            # A redirect can finish while an editor control is being awaited.
            # Keep the provider's reason instead of reporting a missing login.
            self._check_flow_access()
            raise RuntimeError(diagnostic) from exc

    def _check_flow_access(self):
        location = urlparse(self.page.url)
        if (location.hostname == 'flow.google.com'
                and location.path.rstrip('/').endswith('/age-restricted')):
            raise FlowAccessRestricted(
                'Google Flow says this account does not meet its age requirement. No prompt submitted.')

    def _open_flow(self, account):
        self.run_folder.mkdir(parents=True, exist_ok=True)
        self.projects_path = self.run_folder / 'browser-projects.json'
        projects = json.loads(self.projects_path.read_text(encoding='utf-8')) if self.projects_path.exists() else {}
        url = projects.get(account['id'], '')
        if url:
            parsed = urlparse(url)
            if parsed.scheme != 'https' or parsed.netloc != 'flow.google.com' or not PROJECT_PATH.fullmatch(parsed.path):
                raise RuntimeError('Invalid saved project address')
        self.page.goto(url or self.service_url('flow'), wait_until='domcontentloaded')
        self._check_flow_access()
        if urlparse(self.page.url).path.rstrip('/') == '/about':
            entry = self.page.get_by_role('button', name='Create with Google Flow', exact=True)
            if entry.count() == 1 and entry.is_visible():
                entry.press('Space')
        self.page.get_by_role('button', name='Account details', exact=True).wait_for(timeout=90000)
        self._check_flow_access()
        email, _ = self.balance()
        if email.casefold() != account['email'].casefold():
            raise RuntimeError('Wrong Google account in this browser profile; reconnect the selected account')
        if not url:
            self.page.get_by_role('button', name='New project', exact=True).press('Space')
            self.page.wait_for_url(re.compile(r'https://flow\.google\.com/(?:u/\d+/)?project/[a-f0-9-]+$'), timeout=90000)
            projects[account['id']] = self.page.url
            _write_atomic(self.projects_path, json.dumps(projects))
            self._settings_button()
        self.project_url = self.page.url
        self.page.locator('div.ProseMirror[contenteditable="true"]').wait_for(timeout=90000)

    def balance(self):
        p = self.page
        dialog = p.get_by_role('dialog', name='Account settings', exact=True)
        if not dialog.is_visible():
            p.get_by_role('button', name='Account details', exact=True).press('Space')
        dialog.wait_for()
        try:
            emails = set(EMAIL.findall(dialog.inner_text()))
            links = dialog.get_by_role('link', name=CREDIT)
            if len(emails) != 1 or links.count() != 1:
                raise RuntimeError('Flow did not display one account and an unambiguous balance')
            match = CREDIT.fullmatch(links.inner_text().strip())
            if not match:
                raise RuntimeError('Unrecognized credit display; no credits assumed')
            email, balance = emails.pop(), int(match.group(1).replace(',', ''))
            if self.observe and email.casefold() == self.account['email'].casefold():
                self.observe(self.account['id'], balance, None)
            return email, balance
        finally:
            dialog.get_by_role('button', name='Close account panel', exact=True).press('Space')
            dialog.wait_for(state='hidden')

    def _radio(self, name):
        control = self.page.get_by_role('radio', name=name, exact=True)
        if control.count() != 1 or not control.is_visible() or not control.is_enabled():
            raise RuntimeError('Flow does not offer the requested setting: ' + name)
        if not control.is_checked():
            control.press('Space')
        if not control.is_checked():
            raise RuntimeError('Flow did not accept the requested setting: ' + name)

    def _settings_button(self):
        """Resolve either observed Flow label without choosing an ambiguous control."""
        buttons = self.page.get_by_role(
            'button', name=re.compile(r'^(?:Settings trigger|Settings)$')).filter(visible=True)
        if not buttons.count():
            buttons.first.wait_for(state='visible', timeout=30000)
        candidates = [button for button in buttons.all() if button.is_enabled()]
        if len(candidates) != 1:
            raise RuntimeError('Flow did not expose one enabled generation Settings button')
        return candidates[0]

    def quote(self, settings, prompt):
        try:
            return self._quote(settings, prompt)
        except Exception:
            try:
                self.preflight_failure('flow')
            except Exception:
                pass  # A closed page must not replace the original preparation error.
            raise

    def _quote(self, settings, prompt):
        settings.validate()
        self.settings = settings
        p = self.page
        self.pending_prompt = prompt
        p.locator('div.ProseMirror[contenteditable="true"]').fill(prompt)
        if not p.get_by_role('radio', name='Video', exact=True).is_visible():
            self._settings_button().press('Space')
        self._radio('Video')
        model = p.get_by_role('button', name='Select model family', exact=True)
        if settings.model not in model.inner_text():
            model.press('Space')
            p.get_by_role('menuitem', name=settings.model, exact=True).press('Enter')
        if settings.model not in model.inner_text():
            raise RuntimeError('Flow did not accept the selected model')
        for value in (settings.aspect, settings.resolution, settings.duration, 'x1'):
            self._radio(value)
        prices = p.get_by_role('link', name=COST)
        if prices.count() != 1:
            raise RuntimeError('Flow does not display one generation price; no guessed cost will be used')
        cost = int(COST.fullmatch(prices.inner_text().strip()).group(1).replace(',', ''))
        email, balance = self.balance()
        self.quote_value = LiveQuote(email, balance, cost, time.time())
        if self.observe and email.casefold() == self.account['email'].casefold():
            self.observe(self.account['id'], balance, cost)
        return self.quote_value

    def submit(self, prompt):
        if prompt != self.pending_prompt:
            raise RuntimeError('Prompt changed after the credit check')
        self.quote_value.verify(self.account['email'])
        p = self.page
        prior = [tile.get_attribute('aria-label') or '' for tile in p.locator('flow-grid-tile-container').all()]
        if p.get_by_role('radio', name='Video', exact=True).is_visible():
            self._settings_button().press('Space')
        button = p.get_by_role('button', name='Start generation', exact=True)
        if not button.is_enabled():
            raise RuntimeError('Flow has disabled generation; check the browser')
        button.press('Space')  # never automatically repeated on a timeout
        deadline = time.monotonic() + 120
        while time.monotonic() < deadline:
            tiles = p.locator('flow-grid-tile-container')
            if tiles.count() == len(prior) + 1:
                # Flow replaces the pending prompt label with a generated title.
                # Correlate against the pre-submit tile set, not the old label.
                return json.dumps({'project': self.project_url, 'previous_labels': prior})
            if tiles.count() > len(prior) + 1:
                raise RuntimeError('Multiple new Flow results appeared. Review this submission before retrying.')
            p.wait_for_timeout(1000)
        raise RuntimeError('Submission result is uncertain. Inspect Flow; do not resubmit this scene')

    def finish(self, receipt, dest):
        data = json.loads(receipt)
        p = self.page
        deadline = time.monotonic() + 1200
        while time.monotonic() < deadline:
            candidates = []
            previous = data.get('previous_labels')
            if previous is None:
                candidates = p.locator('flow-grid-tile-container').filter(has=p.get_by_role('button', name=data['label'], exact=True)).all()
            else:
                tiles = p.locator('flow-grid-tile-container').all()
                if len(tiles) != len(previous) + 1:
                    raise RuntimeError('Flow results changed unexpectedly; inspect the saved project before retrying.')
                labels = [candidate.get_attribute('aria-label') or '' for candidate in tiles]
                candidates = [candidate for candidate,label in zip(tiles,labels) if label and label not in previous]
            if len(candidates) == 1:
                tile = candidates[0]
                if tile.get_by_role('img', name='Generated video thumbnail', exact=True).count() == 1:
                    break
            p.wait_for_timeout(3000)
        else:
            raise RuntimeError('Video not confirmed complete within 20 minutes; check Flow before retrying')
        tile.dblclick()
        video = p.locator('video[aria-label="Generated video"]')
        video.wait_for(timeout=60000)
        src = video.get_attribute('src') or ''
        parsed = urlparse(src)
        if parsed.scheme != 'https' or parsed.hostname != 'flow-content.google' or not parsed.path.startswith('/video/'):
            raise RuntimeError('Unrecognized completed-video address; download manually')
        # Fetch only the media URL visibly attached to this completed video.
        response = self.context.request.get(src, timeout=120000, max_redirects=0)
        if response.status != 200:
            raise RuntimeError('Video download failed; the scene will not be generated again')
        partial = Path(str(dest) + '.partial.mp4')
        if Path(dest).exists() or partial.exists():
            raise RuntimeError('Output exists; refusing to overwrite a previous download')
        try:
            partial.write_bytes(response.body())
            error = validate_clip(partial)
            if error:
                raise RuntimeError('Downloaded clip failed validation: ' + error)
            probe = find_tool('ffprobe')
            if not probe:
                raise RuntimeError('Video validator is missing; restore the app installation')
            checked = run_tool([probe, '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                                'stream=width,height:format=duration', '-of', 'json', str(partial)])
            if checked.returncode:
                raise RuntimeError('Could not verify the downloaded video format')
            info = json.loads(checked.stdout.decode('utf-8'))
            stream = info['streams'][0]
            ratio = stream['width'] / stream['height']
            expected = 16 / 9 if self.settings.aspect == '16:9' else 9 / 16
            duration = float(info['format']['duration'])
            if abs(ratio - expected) > 0.02 or abs(duration - int(self.settings.duration[:-1])) > 0.5:
                raise RuntimeError('The downloaded clip has a different aspect ratio or duration; review it before continuing')
            partial.rename(dest)
        finally:
            response.dispose()
        p.goto(self.project_url, wait_until='domcontentloaded')
        p.get_by_role('button', name='Account details', exact=True).wait_for(timeout=90000)

    def service_url(self, provider):
        slot = self.account.get('google_slot')
        if slot is not None:
            slot = int(slot)
            if not 0 <= slot <= 999:
                raise ValueError('Invalid Google slot')
        if provider == 'flow':
            return f'https://flow.google.com/u/{slot}/' if slot is not None else 'https://flow.google.com/'
        return f'https://gemini.google.com/u/{slot}/app' if slot is not None else 'https://gemini.google.com/app'

    def close(self):
        try:
            if self.context is not None:self.context.close()
        finally:
            self.context=self.page=None
            if self.runtime is not None:
                self.runtime.stop()
                self.runtime=None
