"""Gemini website adapter using the same local Chrome profiles as Flow.

English semantic controls follow Google's documented Create video / Submit /
Download video workflow. An eligible account must be used for live validation;
missing controls stop or skip the account rather than guessing a private API.
"""
import json
import re
import time
from pathlib import Path
from urllib.parse import urlparse

from .flow_browser import FlowBrowser, EMAIL
from .master import _write_atomic
from .providers import validate_clip
from .scene_queue import AccountUnavailable, GenerationRejected, QuotaReached
from ..ffmpeg_tools import find_tool, run as run_tool


def conversation_url(url):
    parsed = urlparse(url)
    return (parsed.scheme == 'https' and parsed.netloc == 'gemini.google.com'
            and re.fullmatch(r'/(?:u/\d+/)?app/[a-zA-Z0-9_-]+', parsed.path) is not None)


def video_prompt(settings, prompt):
    return (f'Generate the actual video using your video-generation tool: one native '
            f'{int(settings.duration[:-1])}-second video, aspect ratio {settings.aspect}, '
            f'resolution {settings.resolution}, with audio. Return the generated video, '
            'not a shot breakdown or a rewritten prompt. Preserve the scene and any '
            'dialogue below.\n\n' + prompt)


def visible_media_url(url):
    """Allow only the HTTPS download attached to the visible Google video player."""
    parsed = urlparse(url)
    return (parsed.scheme == 'https' and parsed.netloc == 'contribution.usercontent.google.com'
            and parsed.path == '/download')


class GeminiBrowser(FlowBrowser):
    def identity(self):
        # Gemini moved its account control from a header button to a sidebar
        # link. Both expose the visible Google Account email accessibly.
        button = self.page.get_by_role('button', name=re.compile(r'^Google Account:')).or_(
            self.page.get_by_role('link', name=re.compile(r'^Google Account:')))
        if not button.count() or not button.first.is_visible():
            menu = self.page.get_by_role('button', name='Main menu', exact=True)
            if menu.count() == 1 and menu.is_visible():
                menu.press('Space')
        button = button.filter(visible=True)
        button.wait_for(timeout=30000)
        if button.count() != 1:
            raise RuntimeError('Gemini exposes more than one active account; review this profile.')
        emails = set(EMAIL.findall(button.get_attribute('aria-label') or ''))
        if emails != {self.account['email']} and {e.casefold() for e in emails} != {self.account['email'].casefold()}:
            raise RuntimeError('Gemini is signed in to a different account. Reconnect this account.')

    def connect(self, account, stopped=lambda: False):
        return self._connect_service(account, 'gemini', stopped)

    def _open_app(self):
        """Enter the observed public landing page once, then verify the account."""
        self.page.goto(self.service_url('gemini'), wait_until='domcontentloaded')
        editor = self.page.get_by_role('textbox', name='Enter a prompt for Gemini', exact=True).or_(
            self.page.get_by_label('Enter a prompt for Gemini', exact=True)).filter(visible=True)
        entered = False
        until = time.monotonic() + 30
        while time.monotonic() < until:
            location = urlparse(self.page.url)
            if location.scheme != 'https' or location.netloc != 'gemini.google.com':
                raise RuntimeError('Gemini needs Google sign-in or verification. Open this profile to complete it.')
            if editor.count() == 1 and editor.is_enabled():
                self.identity()
                return
            public_landing = re.fullmatch(r'/(?:u/\d+/)?', location.path) is not None
            if public_landing and not entered:
                entry = self._unique(('Chat with Gemini',))
                if entry is not None and entry.is_enabled():
                    # This only enters Gemini; it never fills or submits Google sign-in.
                    entered = True
                    entry.press('Enter')
                    until = time.monotonic() + 30
            self.page.wait_for_timeout(250)
        raise RuntimeError('Gemini did not expose its prompt editor after opening the app. No prompt submitted.')

    def open(self, account):
        self._start(account)
        try:
            self._open_app()
        except Exception as exc:
            raise RuntimeError(self.preflight_failure('gemini')) from exc

    def _unique(self, names, roles=('button', 'link')):
        for role in roles:
            for name in names:
                locator = self.page.get_by_role(role, name=name, exact=True)
                if locator.count() == 1 and locator.is_visible():
                    return locator
        return None

    def prepare(self, settings, prompt):
        settings.validate()
        # Start a fresh conversation for each scene; never attach an older video.
        self._open_app()
        self.settings = settings
        # Owner's live trial on 2026-10-07 confirmed direct explicit generation.
        # Merely pasting a scene can return a text breakdown instead of a video.
        self.emit('Preparing one explicit Gemini video request in a fresh conversation.')
        editor = self.page.get_by_role('textbox', name='Enter a prompt for Gemini', exact=True)
        if editor.count() != 1:
            # Some versions expose a labelled contenteditable without textbox role.
            editor = self.page.get_by_label('Enter a prompt for Gemini', exact=True)
        editor.wait_for(timeout=30000)
        if self.page.locator('video').count():
            raise RuntimeError('Gemini already displays video content. A fresh empty video conversation is required.')
        self.pending_prompt = prompt
        editor.fill(video_prompt(settings, prompt))
        self.editor = editor
        self.identity()
        submit = self._unique(('Submit', 'Send message', 'Send'))
        if submit is None or not submit.is_enabled():
            raise AccountUnavailable('Gemini video submission is unavailable; check allowance and account access')

    def submit(self, prompt):
        if prompt != self.pending_prompt:
            raise RuntimeError('Prompt changed after Gemini preflight')
        self.identity()
        button = self._unique(('Submit', 'Send message', 'Send'))
        if button is None:
            raise RuntimeError('Gemini submit control disappeared')
        self.editor.press('Enter')  # exactly once; any timeout requires review
        # Persist a real conversation address, never the empty /app landing page.
        self.page.wait_for_url(lambda url: conversation_url(str(url)), timeout=60000)
        return json.dumps({'url': self.page.url, 'account': self.account['id'], 'submitted': time.time()})

    def _wait_diagnostic(self, reason, elapsed):
        """Save only the rendered Gemini page, never login forms or session data."""
        profile = self.account['id']
        if not re.fullmatch(r'FA-\d{3,}', profile):
            return
        location = urlparse(self.page.url)
        detail = {'service': 'gemini', 'profile': profile, 'reason': reason,
                  'elapsed_seconds': int(elapsed),
                  'page': location.scheme + '://' + (location.hostname or '') + location.path}
        name = self.run_folder / f'wait_{profile}_gemini'
        try:
            self.run_folder.mkdir(parents=True, exist_ok=True)
            # Never capture a Google sign-in/challenge or a foreign page.
            if not conversation_url(self.page.url):
                detail['capture'] = 'Skipped: not a Gemini conversation.'
            else:
                try:
                    self.page.screenshot(path=str(name.with_suffix('.png')), timeout=10000)
                    detail['screenshot'] = name.with_suffix('.png').name
                except Exception:
                    detail['screenshot'] = 'Unavailable'
                try:
                    visible = self.page.locator('body').evaluate("""body => {
                        const shown = e => e && e.getClientRects().length &&
                            getComputedStyle(e).visibility !== 'hidden' && getComputedStyle(e).display !== 'none';
                        const area = body.querySelector('main, [role="main"]') || body;
                        const walker = document.createTreeWalker(area, NodeFilter.SHOW_TEXT);
                        let text = '', node, scanned = 0;
                        while ((node = walker.nextNode()) && text.length < 12000 && scanned++ < 5000) {
                            const e = node.parentElement;
                            if (shown(e) && !e.closest('script, style, input, textarea, [contenteditable="true"]'))
                                text += node.textContent.trim() + '\\n';
                        }
                        const controls = Array.from(body.querySelectorAll('button, a, [role="button"], [role="menuitem"]'))
                            .filter(shown).slice(0, 60).map(e => ({
                                role: e.getAttribute('role') || e.tagName,
                                label: (e.getAttribute('aria-label') || '').slice(0, 200),
                                text: (e.innerText || '').slice(0, 160)
                            }));
                        return {response_text: text.slice(0, 12000), controls};
                    }""", timeout=5000)
                    detail['response_text'] = str(visible.get('response_text', ''))[:12000]
                    detail['controls'] = [
                        {'role': str(c.get('role', ''))[:40], 'label': str(c.get('label', ''))[:200],
                         'text': str(c.get('text', ''))[:160]} for c in visible.get('controls', [])[:60]]
                except Exception:
                    detail['capture'] = 'Visible page text unavailable.'
            _write_atomic(name.with_suffix('.json'), json.dumps(detail, ensure_ascii=False))
        except Exception:
            # Diagnostics must not turn a valid submitted job into a new failure.
            self.emit('Gemini wait diagnostic could not be saved; the existing request is still being checked.')

    @staticmethod
    def _check_output_stop(stopped):
        if stopped():
            raise RuntimeError('Gemini output check stopped. The saved conversation receipt is retained; no new request was submitted.')

    def _completed_assistant_rejection(self):
        """Match the observed completed refusal only inside Gemini's reply."""
        label = self.page.locator('h6').filter(has_text=re.compile(r'^\s*Gemini said\s*$'))
        responses = self.page.locator('div.response-content').filter(has=label).filter(visible=True)
        if responses.count() != 1:
            return False
        content = responses.locator('message-content').filter(visible=True)
        if content.count() != 1:
            return False
        if self.page.locator('video').count():
            return False
        # These observed feedback controls mark the sole assistant reply complete.
        # They live outside response-content, so require them to be globally unique.
        for name in ('Good response', 'Bad response'):
            feedback = self.page.get_by_role('button', name=name, exact=True).filter(visible=True)
            if feedback.count() != 1:
                return False
        text = ' '.join(content.inner_text(timeout=5000).split()).replace('\u2019', "'").casefold()
        observed = ("I can't make videos that seem to show minors in dangerous or compromising situations. "
                    'Can I help you with something else?').casefold()
        return text == observed

    def recover_output(self, account, receipt, settings, dest, *, stopped=lambda: False):
        """Reopen one saved conversation and download it without another request."""
        data = json.loads(receipt)
        if data.get('account') != account['id']:
            raise RuntimeError('Gemini receipt account mismatch')
        if not conversation_url(data.get('url', '')):
            raise RuntimeError('Gemini receipt has no valid conversation address; inspect the browser')
        settings.validate()
        dest = Path(dest)
        if dest.exists() or dest.with_suffix('.partial.mp4').exists():
            raise RuntimeError('A local output already exists; inspect it before retrying download')
        self._check_output_stop(stopped)
        self._start(account)
        self._check_output_stop(stopped)
        self.page.goto(data['url'], wait_until='domcontentloaded')
        self._check_output_stop(stopped)
        self.identity()
        if not conversation_url(self.page.url) or urlparse(self.page.url).path != urlparse(data['url']).path:
            raise RuntimeError('Gemini did not reopen the saved conversation; no new request was submitted.')
        self.settings = settings
        self.emit('Checking the saved Gemini conversation for its existing video. No new generation request.')
        self.finish(receipt, dest, stopped=stopped)

    def finish(self, receipt, dest, *, stopped=lambda: False):
        data = json.loads(receipt)
        if data['account'] != self.account['id']:
            raise RuntimeError('Gemini receipt account mismatch')
        if not conversation_url(data.get('url', '')):
            raise RuntimeError('Gemini receipt has no valid conversation address; inspect the browser')
        started = time.monotonic()
        until = started + 1200
        refresh_at = started + 180
        report_at = started + 60
        refreshed = False
        download = None
        self._check_output_stop(stopped)
        self._wait_diagnostic('waiting', 0)
        while time.monotonic() < until:
            self._check_output_stop(stopped)
            if self._completed_assistant_rejection():
                self._wait_diagnostic('provider_rejected', time.monotonic() - started)
                raise GenerationRejected('Gemini declined this video request because it identified minors in a dangerous or compromising situation. No video was generated.')
            # Other failure classifications still require explicit service alerts.
            alerts = self.page.get_by_role('alert').all_text_contents()
            if any(re.search(r'(could not|couldn.t|unable to|failed to) generate', text, re.I) for text in alerts):
                raise GenerationRejected('Gemini explicitly reported generation failure')
            if any(re.search(r'(limit reached|reached.*limit|no.*video.*left)', text, re.I) for text in alerts):
                raise QuotaReached('Gemini reported a video limit; retry after its allowance refreshes')
            videos = self.page.locator('video')
            if videos.count() == 1 and videos.is_visible():
                download = self._unique(('Download video',))
                if download is None:
                    share = self._unique(('Share',))
                    if share is not None:
                        share.press('Space')
                        download = self._unique(('Download video',), ('button', 'menuitem', 'link'))
                if download is not None:
                    break
            now = time.monotonic()
            if now >= report_at:
                elapsed = int(now - started)
                self.emit(f'Waiting for Gemini video / {self.account["id"]}: {elapsed}s; checking the same saved request.')
                self._wait_diagnostic('waiting', elapsed)
                report_at = now + 60
            if not refreshed and time.monotonic() >= refresh_at:
                # Read the same saved job. Never create another prompt on a stale UI.
                if self.page.url != data['url']:
                    raise RuntimeError('Gemini conversation changed while waiting; review the saved job')
                self.emit('Refreshing the same Gemini conversation to check its completed video.')
                self.page.reload(wait_until='domcontentloaded')
                self.identity()
                refreshed = True
            self.page.wait_for_timeout(3000)
        if download is None:
            self._wait_diagnostic('timeout', time.monotonic() - started)
            raise RuntimeError('Gemini video/download not confirmed within 20 minutes; inspect the conversation')
        dest = Path(dest)
        partial = dest.with_suffix('.partial.mp4')
        if dest.exists() or partial.exists():
            raise RuntimeError('A local output already exists; inspect it before retrying')
        self._check_output_stop(stopped)
        self.identity()
        self._check_output_stop(stopped)
        src = self.page.locator('video').get_attribute('src') or ''
        if visible_media_url(src):
            # Public media URL exposed by the player, not a generation endpoint.
            # This avoids a download-button overlay issue observed in the trial.
            response = self.context.request.get(src, timeout=120000, max_redirects=0)
            try:
                if response.status != 200:
                    raise RuntimeError('Gemini video download failed; retry download, not generation')
                partial.write_bytes(response.body())
            finally:
                response.dispose()
        else:
            with self.page.expect_download(timeout=120000) as result:
                download.press('Enter')
            result.value.save_as(str(partial))
        error = validate_clip(partial)
        if error:
            raise RuntimeError('Gemini download is not a valid video: ' + error)
        probe = find_tool('ffprobe')
        if not probe:
            raise RuntimeError('ffprobe is required to verify the Gemini video')
        checked = run_tool([probe, '-v', 'error', '-select_streams', 'v:0', '-show_entries',
                            'stream=width,height:format=duration', '-of', 'json', str(partial)])
        if checked.returncode:
            raise RuntimeError('Cannot verify Gemini video format')
        info = json.loads(checked.stdout.decode('utf-8'))
        stream = info['streams'][0]
        expected = 16 / 9 if self.settings.aspect == '16:9' else 9 / 16
        # Preserve a valid clip even if Gemini ignored the requested format.
        partial.rename(dest)
        if abs(stream['width'] / stream['height'] - expected) > .02 or abs(float(info['format']['duration']) - int(self.settings.duration[:-1])) > .5:
            raise RuntimeError('Gemini returned a different aspect ratio or duration. Review the saved clip before accepting it.')
