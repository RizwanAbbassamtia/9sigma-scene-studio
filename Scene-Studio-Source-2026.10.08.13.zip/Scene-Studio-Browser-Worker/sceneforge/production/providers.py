"""The three providers the pipeline talks to, behind one small interface
each, with a mock of every one so the whole chain runs without a key or a
bill.

    ScriptWriter    title + framework -> a script          (OpenAI)
    PromptWriter    script + framework -> scene prompts    (Anthropic)
    ClipGenerator   prompt -> a video file                 (Omni Flash)

Only official HTTP APIs are used; nothing drives a website. The OpenAI and
Anthropic adapters use the documented endpoints (chat completions, messages)
with the model name as a setting, because model names change faster than
this file will. The Omni Flash adapter lives in omniflash.py and follows its
Generation API v2 document, kept at docs/omniflash-v2-api.md.

Every text result says whether it was cut short (the provider's own finish
reason), so the runner can repair rather than pass a truncated script on.
Usage is reported as the provider reported it; nothing here estimates cost.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from ..ffmpeg_tools import find_tool, run as run_tool
from ..logging_setup import get

log = get("production.providers")

OPENAI_URL = "https://api.openai.com/v1/chat/completions"
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2023-06-01"
TIMEOUT = 300


class ProviderError(Exception):
    """retryable: the same request may succeed later. fatal: nothing from
    this provider will succeed until a person acts (a bad or disabled key,
    a daily limit reached), so the whole stage stops at once."""

    def __init__(self, message: str, retryable: bool = False, detail: str = "", fatal: bool = False,
                 unconfirmed: bool = False, busy: bool = False, exhausted: bool = False):
        super().__init__(message)
        self.retryable = retryable
        self.detail = detail
        self.fatal = fatal
        # The key has no quota (or balance) left: the run stops like a
        # fatal error, but the key itself is fine and works again once
        # the quota returns or the bill is paid.
        self.exhausted = exhausted
        # The provider has no free slot right now (every parallel job it
        # allows is running, ours or another user's on the same key). Not a
        # failure of this clip: the runner waits and asks again, without
        # spending an attempt.
        self.busy = busy
        # The request may have gone through but no job id came back: the
        # caller must reconcile rather than submit again.
        self.unconfirmed = unconfirmed


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    reported_cost: Optional[float] = None      # only if the provider says so


@dataclass
class TextResult:
    text: str
    model: str
    finish_reason: str = ""
    truncated: bool = False
    usage: Usage = field(default_factory=Usage)
    raw: Dict[str, object] = field(default_factory=dict)


@dataclass
class Job:
    job_id: str
    status: str                 # queued | running | done | failed
    url: str = ""               # where the clip can be fetched, when done
    error: str = ""
    reported_cost: Optional[float] = None


# ------------------------------------------------------------------ helpers
def _post(url: str, headers: Dict[str, str], body: Dict[str, object]) -> Dict[str, object]:
    import requests
    try:
        response = requests.post(url, headers=headers, json=body, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise ProviderError("Could not reach {}: {}".format(url.split("/")[2], exc), retryable=True) from exc
    if response.status_code == 429 or response.status_code >= 500:
        raise ProviderError("{} answered {} (busy or down); worth retrying".format(
            url.split("/")[2], response.status_code), retryable=True, detail=response.text[:500])
    if response.status_code >= 400:
        raise ProviderError("{} refused the request ({})".format(url.split("/")[2], response.status_code),
                            retryable=False, detail=response.text[:500])
    try:
        return response.json()
    except ValueError as exc:
        raise ProviderError("The reply was not JSON", detail=response.text[:300]) from exc


# ------------------------------------------------------------ script writer
class OpenAIScriptWriter:
    def __init__(self, api_key: str, model: str = "gpt-4.1", max_tokens: int = 8000,
                 temperature: float = 0.8):
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def write(self, system: str, user: str) -> TextResult:
        body = {"model": self.model, "temperature": self.temperature, "max_tokens": self.max_tokens,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
        raw = _post(OPENAI_URL, {"Authorization": "Bearer " + self.api_key,
                                 "Content-Type": "application/json"}, body)
        try:
            choice = raw["choices"][0]
            text = choice["message"]["content"] or ""
            finish = choice.get("finish_reason", "")
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderError("OpenAI's reply had no text in it", detail=json.dumps(raw)[:500]) from exc
        usage = raw.get("usage", {}) or {}
        return TextResult(text=text, model=raw.get("model", self.model), finish_reason=finish,
                          truncated=(finish == "length"),
                          usage=Usage(int(usage.get("prompt_tokens", 0)), int(usage.get("completion_tokens", 0))),
                          raw=raw)


class MockScriptWriter:
    """Returns the supplied sample script, in sections if asked, so the rest
    of the chain can be exercised with no key and no bill."""

    def __init__(self, sample: Path):
        self.sample = Path(sample)
        self.calls: List[Dict[str, str]] = []

    def write(self, system: str, user: str) -> TextResult:
        self.calls.append({"system": system, "user": user})
        text = self.sample.read_text(encoding="utf-8", errors="replace")
        return TextResult(text=text, model="mock-script", finish_reason="stop",
                          usage=Usage(len(system.split()) + len(user.split()), len(text.split())))


# ------------------------------------------------------------ prompt writer
class AnthropicPromptWriter:
    def __init__(self, api_key: str, model: str = "claude-sonnet-5", max_tokens: int = 16000,
                 temperature: float = 0.5):
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def write(self, system: str, user: str) -> TextResult:
        body = {"model": self.model, "max_tokens": self.max_tokens, "temperature": self.temperature,
                "system": system, "messages": [{"role": "user", "content": user}]}
        raw = _post(ANTHROPIC_URL, {"x-api-key": self.api_key, "anthropic-version": ANTHROPIC_VERSION,
                                    "content-type": "application/json"}, body)
        try:
            text = "".join(block.get("text", "") for block in raw["content"] if block.get("type") == "text")
            stop = raw.get("stop_reason", "")
        except (KeyError, TypeError) as exc:
            raise ProviderError("Anthropic's reply had no text in it", detail=json.dumps(raw)[:500]) from exc
        usage = raw.get("usage", {}) or {}
        return TextResult(text=text, model=raw.get("model", self.model), finish_reason=stop,
                          truncated=(stop == "max_tokens"),
                          usage=Usage(int(usage.get("input_tokens", 0)), int(usage.get("output_tokens", 0))),
                          raw=raw)


class MockPromptWriter:
    def __init__(self, sample: Path):
        self.sample = Path(sample)
        self.calls: List[Dict[str, str]] = []

    def write(self, system: str, user: str) -> TextResult:
        self.calls.append({"system": system, "user": user})
        text = self.sample.read_text(encoding="utf-8", errors="replace")
        return TextResult(text=text, model="mock-prompts", finish_reason="end_turn",
                          usage=Usage(len(user.split()), len(text.split())))


# ------------------------------------------------------------ clip generator
class MockClipGenerator:
    """Makes real, playable clips with ffmpeg -- a colour card with the scene
    number, a tone under it -- and finishes jobs out of submission order, so
    the runner's ordering and reconciliation are exercised for real."""

    def __init__(self, seconds: float = 3.0, out_of_order: bool = True, fail_every: int = 0):
        self.seconds = seconds
        self.out_of_order = out_of_order
        self.fail_every = fail_every
        self._jobs: Dict[str, Dict[str, object]] = {}
        self._count = 0

    def submit(self, prompt: str, settings: Dict[str, object]) -> Job:
        self._count += 1
        job_id = "mock-{}".format(uuid.uuid4().hex[:8])
        polls_needed = (3 - (self._count % 3)) if self.out_of_order else 1
        fails = self.fail_every and self._count % self.fail_every == 0
        self._jobs[job_id] = {"prompt": prompt, "polls": polls_needed, "fail": fails, "n": self._count}
        return Job(job_id=job_id, status="queued")

    def poll(self, job_id: str) -> Job:
        record = self._jobs.get(job_id)
        if record is None:
            return Job(job_id=job_id, status="failed", error="unknown job")
        record["polls"] -= 1
        if record["polls"] > 0:
            return Job(job_id=job_id, status="running")
        if record["fail"]:
            record["fail"] = False                       # succeeds on resubmission
            return Job(job_id=job_id, status="failed", error="simulated provider failure")
        return Job(job_id=job_id, status="done", url="mock://" + job_id, reported_cost=0.0)

    def download(self, job: Job, dest: Path) -> Path:
        record = self._jobs[job.job_id]
        ffmpeg = find_tool("ffmpeg")
        if not ffmpeg:
            raise ProviderError("ffmpeg is needed to make mock clips")
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        partial = dest.with_suffix(dest.suffix + ".part")
        # A test pattern and a tone that rises with the scene number, so a
        # mis-ordered assembly is audible. No text overlay: drawtext needs a
        # font path that differs from machine to machine.
        result = run_tool([ffmpeg, "-nostdin", "-loglevel", "error", "-y",
                           "-f", "lavfi", "-i", "testsrc2=s=1280x720:r=24:d={:.2f}".format(self.seconds),
                           "-f", "lavfi", "-i", "sine=frequency={}:duration={:.2f}".format(330 + 20 * record["n"], self.seconds),
                           "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
                           "-c:a", "aac", "-shortest", "-f", "mp4", str(partial)])
        if result.returncode != 0 or not partial.exists():
            raise ProviderError("mock clip could not be written", detail=result.stderr.decode("utf-8", "replace")[-300:])
        partial.replace(dest)                            # only a complete file gets the real name
        return dest


# ---------------------------------------------------------------- validation
def validate_clip(path: Path) -> str:
    """Empty string if the file is a complete, decodable video; otherwise why not."""
    path = Path(path)
    if not path.exists():
        return "file missing"
    if path.suffix == ".part" or path.stat().st_size < 10_000:
        return "file incomplete"
    ffprobe = find_tool("ffprobe")
    if not ffprobe:
        return ""                                        # cannot check; do not block
    result = run_tool([ffprobe, "-v", "error", "-show_entries", "format=duration:stream=codec_type",
                       "-of", "json", str(path)])
    if result.returncode != 0:
        return "not a readable video: " + result.stderr.decode("utf-8", "replace")[-200:].strip()
    try:
        info = json.loads(result.stdout.decode("utf-8", "replace"))
        duration = float(info.get("format", {}).get("duration", 0) or 0)
        kinds = {s.get("codec_type") for s in info.get("streams", [])}
    except (ValueError, TypeError):
        return "could not read the video's details"
    if duration <= 0.2:
        return "video is empty"
    if "video" not in kinds:
        return "no video stream"
    return ""

