"""The master log: the shared queue editors add titles to and the worker
takes them from, kept as plain files in one folder on a local, mapped or
UNC drive.

Why files and not a service: the business has a NAS and a handful of
laptops, and the log must keep working when the person who set it up is
away. Two JSON files are the truth -- master.json for the framework records,
titles.json for every title ever queued -- and two CSVs per record are what
editors open in Excel. Anyone with the folder can read the state; only this
module writes it.

Three facts shape every method here:

  - Other machines write the same files. Every change re-reads the file
    under a cross-machine lock (a file created with O_EXCL, which SMB serves
    atomically), applies the change and writes the whole file back through
    a temp file and os.replace, so two machines never lose each other's
    writes and a claim is never taken twice. Reads retry a few times,
    because a reader can land inside another machine's replace.
  - Excel holds a sheet open all day. The editors' sheet (add-titles.csv)
    is theirs: the app fills in ids only after a title is safely in the
    JSON, and honours exactly two status edits from it (queued <-> paused,
    failed -> queued; the cell is consumed and cleared so it is never
    applied twice). The status sheet (titles-status.csv) is the app's
    mirror of the JSON, rewritten best-effort: a locked sheet delays a
    status, it never fails a job.
  - The folder is shared, so nothing read from it is trusted as a path.
    Ids are checked against a strict pattern on every load, folders are
    only ever derived from ids that passed, and an id is never taken from
    a sheet or made from a title. Job ids carry a letter and a hyphen
    (t-3f9a2c7b) so Excel never reads one as a number.

The framework library lives in <folder>/library so every machine resolves a
record's refs against the same files; nothing resolves the human-readable
copies under <fid>/frameworks/.

Status words, for the editor reading the sheet: queued (waiting for the
worker), script_running, script_done, prompts_done, clips_done (the worker
is on it; `stage` and `progress` say where), video_done, failed (a person
must look; Retry re-queues it with its clips), paused (held by a person;
the worker skips it until someone queues it again). A Stop press sends a
job back to queued, never to failed.
"""
from __future__ import annotations

import codecs
import csv
import io
import json
import locale
import os
import re
import socket
import tempfile
import threading
import time
import unicodedata
import uuid
from dataclasses import dataclass, field, fields
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from ..logging_setup import get
from .frameworks import Frameworks
from .manifest import FrameworkRef, digest, now

log = get("production.master")

STATUSES = ["queued", "script_running", "script_done", "prompts_done", "clips_done",
            "video_done", "failed", "paused"]
IN_PROGRESS = ("script_running", "script_done", "prompts_done", "clips_done")
FRAMEWORK_KINDS = ("hook", "script", "prompt")
FRAMEWORK_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
# A job id is 't-' plus eight hex digits (see the module docstring); a bare
# 8-12 character id from an older file is accepted too. Neither form can
# hold a dot, a slash or a backslash, so an id can never leave its folder.
JOB_ID = re.compile(r"^[a-z0-9][a-z0-9-]{7,11}$")
EMAIL = re.compile(r"^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$")
TITLE_MAX = 200
SAFE_NAME_MAX = 60

MASTER_NAME = "master.json"
TITLES_NAME = "titles.json"
LOCK_NAME = ".lock"
LIBRARY_DIR = "library"
ADD_SHEET = "add-titles.csv"
STATUS_SHEET = "titles-status.csv"
# The Google Flow account inventory (flow_accounts.py) lives in the same
# folder and is written under the same lock; its mirror is Excel's copy.
FLOW_ACCOUNTS_NAME = "flow-accounts.json"
FLOW_STATUS_SHEET = "flow-accounts-status.csv"
ADD_COLUMNS = ("id", "title", "added_by", "status")
STATUS_COLUMNS = ("id", "title", "status", "stage", "progress", "added_by", "added", "updated",
                  "export_path", "error")
SHEET_TRANSITIONS = {("queued", "paused"), ("paused", "queued"), ("failed", "queued")}

LOCK_STALE_SECONDS = 60.0          # a lock older than this was left by a dead process
# A writer waits at least as long as a lock takes to go stale: one that
# arrived just after a crash would otherwise give up seconds before the
# dead lock could be broken.
LOCK_WAIT_SECONDS = 75.0
LOCK_CHECK_SECONDS = 1.0           # how often a waiter asks the share whether the lock is stale
HEARTBEAT_STALE_SECONDS = 600.0    # an in-progress job quieter than this has lost its worker
SHEET_SETTLE_SECONDS = 10.0        # Excel saves in place; a sheet this fresh may be half written
TEMP_YOUNG_SECONDS = 30.0          # a temp file this young means a write is in flight
RETRY_DELAYS = (0.1, 0.3, 0.7, 1.5, 3.0)
_SETTABLE = ("production_dir", "export_path", "error", "worker", "heartbeat", "stage", "progress")


# ------------------------------------------------------------------ records
@dataclass
class MasterRecord:
    """One framework the business produces under: who edits it, which
    frameworks write for it, and the settings every one of its titles runs
    with. framework_id is also the folder name, hence the strict pattern."""
    framework_id: str
    serial: str = ""                   # FW-001, FW-002, ...: given once, on the first save, never reused
    niche: str = ""
    editor_name: str = ""
    email: str = ""
    hook_framework: FrameworkRef = field(default_factory=FrameworkRef)
    script_framework: FrameworkRef = field(default_factory=FrameworkRef)
    prompt_framework: FrameworkRef = field(default_factory=FrameworkRef)
    language: str = "Urdu"
    target_minutes: float = 20.0
    enabled: bool = True
    generation_settings: Dict[str, object] = field(default_factory=dict)
    notes: str = ""
    created: str = field(default_factory=now)


@dataclass
class TitleJob:
    """One title's trip through the pipeline. production_dir and export_path
    are kept relative to the master folder because the next machine sees
    the share under another letter; they are informational -- the worker
    derives the job folder from the ids, never from these."""
    id: str
    framework_id: str
    title: str
    added_by: str = ""
    added: str = field(default_factory=now)
    status: str = "queued"
    updated: str = ""
    production_dir: str = ""
    export_path: str = ""
    error: str = ""
    worker: str = ""                   # hostname of the machine on it
    heartbeat: str = ""                # last sign of life from that worker
    stage: str = ""                    # script | prompts | clips | edit | export
    progress: str = ""                 # e.g. "clips 12/40"
    history: List[Dict[str, str]] = field(default_factory=list)


# ------------------------------------------------------------------ helpers
_LINE_CATEGORIES = ("Cc", "Zl", "Zp", "Cs", "Co", "Cn")


def _one_line(text) -> str:
    """Control characters and line breaks become spaces, runs collapse: a
    title or a name from a sheet must never carry a line into a CSV cell,
    a mail header or a log line. Format characters stay: the zero-width
    joiners and direction marks inside Urdu and Persian words are not
    printable by str.isprintable's rule, but replacing one splits the word."""
    out = []
    for ch in str(text or ""):
        out.append(" " if ch.isspace() or unicodedata.category(ch) in _LINE_CATEGORIES else ch)
    return " ".join("".join(out).split())


def _lines(text) -> str:
    """_one_line for a field that runs to several lines by design (a
    record's notes, a job's error): line breaks stay, every other control
    character becomes a space, and nothing is collapsed, so a traceback
    keeps its indentation."""
    out = []
    for ch in str(text or "").replace("\r\n", "\n"):
        if ch == "\n":
            out.append(ch)
        elif ch.isspace() or unicodedata.category(ch) in _LINE_CATEGORIES:
            out.append(" ")
        else:
            out.append(ch)
    return "".join(out)


def clean_title(title) -> str:
    """The title as it will be stored, or a ValueError saying what is wrong
    with it in words an editor can act on."""
    text = _one_line(title).strip()
    # Only the apostrophe _cell puts in front of = + - @ for Excel is undone;
    # a title that opens with a quotation mark keeps it.
    if len(text) > 1 and text[0] == "'" and text[1] in "=+-@":
        text = text[1:].strip()
    if not text:
        raise ValueError("The title is empty.")
    if not text.replace("?", "").strip():
        raise ValueError("The title is only question marks, which is what Excel writes for Urdu when a "
                         "sheet is saved as plain CSV. Save it again as 'CSV UTF-8'.")
    if not any(ch.isalnum() for ch in text):
        raise ValueError("The title has no letters or digits in it.")
    if len(text) > TITLE_MAX:
        raise ValueError("The title is {} characters long; a title may be at most {}.".format(len(text), TITLE_MAX))
    return text


def title_key(title) -> str:
    """Two spellings of one title compare equal: case, spacing, punctuation,
    dashes and diacritics are all dropped. A duplicate is a second paid
    production, so the comparison errs on the side of matching."""
    text = unicodedata.normalize("NFKC", str(title or "")).casefold()
    return "".join(ch for ch in text
                   if not ch.isspace() and not unicodedata.category(ch).startswith(("P", "S", "C", "M")))


def safe_name(title, fallback="") -> str:
    """A title as a file or folder name: letters and digits in any script,
    spaces, '-' and '_', at most SAFE_NAME_MAX characters. Everything NTFS
    refuses, and everything a path could be built from, is dropped."""
    kept = []
    for ch in str(title or ""):
        if ch.isalnum() or ch in "-_":
            kept.append(ch)
        elif ch.isspace():
            kept.append(" ")
    text = " ".join("".join(kept).split())[:SAFE_NAME_MAX].rstrip(" .")
    return text or str(fallback or "").strip() or "untitled"


def _cell(value) -> str:
    """A CSV cell Excel will show as text. A leading = + - @ (or a tab or
    CR) would be run as a formula; a quote in front stops that."""
    text = str(value if value is not None else "")
    if text and text[0] in "=+-@\t\r":
        return "'" + text
    return text


def _decode(raw: bytes) -> str:
    """Excel's own CSV saves are ANSI unless 'CSV UTF-8' was chosen, and a
    framework from Word can be UTF-16. Every one of those opens."""
    if raw.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return raw.decode("utf-16")
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        encoding = "mbcs" if os.name == "nt" else (locale.getpreferredencoding(False) or "cp1252")
        return raw.decode(encoding, errors="replace")


def _age_seconds(stamp) -> float:
    try:
        moment = datetime.fromisoformat(str(stamp))
    except (TypeError, ValueError):
        return float("inf")
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return (datetime.now(timezone.utc) - moment).total_seconds()


def _share_now(folder: Path) -> float:
    """The time by the clock that stamps files in `folder`: the file
    server's for a share, this machine's for a local disk.

    A file's age must be measured against the clock that wrote its mtime.
    A NAS a minute behind the laptops makes every fresh lock look stale by
    this machine's clock, and one a few seconds ahead makes every saved
    sheet look half-written; a probe file made and removed here gives the
    same clock's idea of now. When no probe can be made (a read-only
    folder, a full share) this machine's clock is the best there is."""
    try:
        fd, tmp = tempfile.mkstemp(prefix=".clock-", dir=str(folder))
    except OSError:
        return time.time()
    try:
        os.close(fd)
        return os.stat(tmp).st_mtime
    except OSError:
        return time.time()
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def _retry(action: Callable[[], object], what: str):
    """PermissionError is what Windows says for 'someone else has this file
    open' -- Excel on a sheet, a virus scan of the share, another machine's
    replace mid-flight. It clears in a moment, so wait and try again before
    giving up. RETRY_DELAYS is read at call time so a test can shorten it."""
    delays = tuple(RETRY_DELAYS) + (None,)
    for delay in delays:
        try:
            return action()
        except PermissionError as exc:
            if delay is None:
                raise
            log.warning("Could not %s (%s); trying again in %.1f s", what, exc, delay)
            time.sleep(delay)
    return None


def _write_atomic(path: Path, text: str, encoding: str = "utf-8", check: Optional[Callable[[], None]] = None) -> None:
    """The whole file lands under a temp name and is swapped in, so a reader
    on any machine sees the old file or the new one, never a half one.
    `check` runs right before the swap, after the slow part (writing the
    temp file to the share): the lock check belongs as close to the
    moment of writing as it can be."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".{}-".format(path.stem), suffix=path.suffix, dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding=encoding, newline="") as handle:
            handle.write(text)
        if check is not None:
            check()
        _retry(lambda: os.replace(tmp, str(path)), "replace " + path.name)
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def _write_in_progress(path: Path) -> bool:
    """A young temp file beside `path` means another writer is mid-replace,
    so a missing or half-read file is worth another look. An old temp file
    is what a crash leaves behind and must not block reads forever."""
    prefix = ".{}-".format(path.stem)
    try:
        for entry in path.parent.iterdir():
            if entry.name.startswith(prefix) and entry.suffix == path.suffix:
                if time.time() - entry.stat().st_mtime < TEMP_YOUNG_SECONDS:
                    return True
    except OSError:
        return False
    return False


def _read_json(path: Path):
    """None when the file is not there. A read that lands inside another
    machine's replace (briefly missing, locked, or half there) is retried
    a few times; only then is it an error."""
    last = None
    for delay in (0.0,) + tuple(RETRY_DELAYS):
        if delay:
            time.sleep(delay)
        try:
            return json.loads(Path(path).read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            if not _write_in_progress(Path(path)):
                return None
            last = exc
        except (OSError, ValueError) as exc:
            last = exc
    raise OSError("{} could not be read: {}".format(path, last))


def _raw(obj):
    if hasattr(obj, "__dataclass_fields__"):
        return {f.name: _raw(getattr(obj, f.name)) for f in fields(obj)}
    if isinstance(obj, dict):
        return {str(k): _raw(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_raw(v) for v in obj]
    return obj


def _ref_from(value) -> FrameworkRef:
    if isinstance(value, FrameworkRef):
        return value
    if not isinstance(value, dict):
        return FrameworkRef()
    try:
        return FrameworkRef(name=_one_line(str(value.get("name", "") or ""))[:200],
                            version=int(value.get("version", 0) or 0),
                            sha=_one_line(str(value.get("sha", "") or ""))[:80])
    except (TypeError, ValueError):
        return FrameworkRef()


SERIAL = re.compile(r"^FW-(\d{3,})$")


def next_serial(records) -> str:
    """FW-001 for the first record; otherwise one past the highest number
    ever given, whatever the records' order."""
    highest = 0
    for record in records:
        match = SERIAL.match(str(getattr(record, "serial", "") or "").strip())
        if match:
            highest = max(highest, int(match.group(1)))
    return "FW-{:03d}".format(highest + 1)


def _record_from(entry) -> MasterRecord:
    if not isinstance(entry, dict):
        raise TypeError("not a record")
    known = {f.name for f in fields(MasterRecord)}
    record = MasterRecord(**{k: v for k, v in entry.items() if k in known})
    # The file is another machine's word, so its text is cleaned the way
    # this app cleans what it adds: an ESC sequence in a niche or a line
    # break in a name must not reach the console, the log, a CSV cell or a
    # mail header just because it came in through a load. Notes run to
    # several lines by design, so only their control characters go.
    for name in ("framework_id", "serial", "niche", "editor_name", "email", "language", "created"):
        value = getattr(record, name)
        setattr(record, name, _one_line("" if value is None else str(value)))
    record.notes = _lines("" if record.notes is None else str(record.notes))
    for name in ("hook_framework", "script_framework", "prompt_framework"):
        setattr(record, name, _ref_from(getattr(record, name)))
    record.target_minutes = float(record.target_minutes or 0)
    record.enabled = bool(record.enabled)
    if not isinstance(record.generation_settings, dict):
        record.generation_settings = {}
    return record


def _job_from(entry) -> TitleJob:
    if not isinstance(entry, dict):
        raise TypeError("not a job")
    known = {f.name for f in fields(TitleJob)}
    job = TitleJob(**{k: v for k, v in entry.items() if k in known})
    # Cleaned like _record_from's fields, and to the lengths add_title
    # allows. The two paths are kept as written: they are informational
    # (the worker derives folders from the ids) and a doubled space in one
    # is real. The error may run to several lines, like a traceback.
    for f in fields(TitleJob):
        if f.name == "history":
            continue
        value = getattr(job, f.name)
        text = "" if value is None else str(value)
        if f.name == "error":
            text = _lines(text)
        elif f.name not in ("production_dir", "export_path"):
            text = _one_line(text)
        setattr(job, f.name, text)
    job.title = job.title[:TITLE_MAX]
    job.added_by = job.added_by[:80]
    history = job.history if isinstance(job.history, list) else []
    job.history = [{"status": _one_line(h.get("status", "")), "at": _one_line(h.get("at", "")),
                    "note": _one_line(h.get("note", ""))} for h in history if isinstance(h, dict)]
    return job


# ---------------------------------------------------------- shared library
class SharedFrameworks(Frameworks):
    """The framework library kept inside the master folder, so every machine
    resolves a record's refs against the same files.

    The index is written atomically with the same retry as the log, since
    two machines write it, and a read that lands in another machine's
    replace is retried rather than taken for an empty library -- which
    save() would then overwrite. Versions are read from where the library
    keeps them, not from the absolute path the uploading machine recorded,
    because the next machine sees the share under another drive letter.
    """

    def __init__(self, home: Optional[Path] = None, before_write: Optional[Callable[[], None]] = None):
        super().__init__(home)
        self.before_write = before_write

    def _index(self) -> Dict[str, Dict[str, object]]:
        raw = _read_json(self.index_path)
        return raw if isinstance(raw, dict) else {}

    def save(self, name: str, kind: str, text: str) -> FrameworkRef:
        # The version file and then the index: both under the log's lock,
        # both refused once another machine has broken that lock.
        if self.before_write is not None:
            self.before_write()
        return super().save(name, kind, text)

    def _write_index(self, index: Dict[str, Dict[str, object]]) -> None:
        _write_atomic(self.index_path, json.dumps(index, indent=2, ensure_ascii=False), check=self.before_write)

    def text(self, ref: FrameworkRef) -> str:
        entry = self._index().get(ref.name)
        if not entry:
            raise KeyError("no framework named '{}'".format(ref.name))
        for record in entry.get("versions", []):                        # type: ignore[union-attr]
            if int(record["version"]) == int(ref.version):
                body = self._path(ref.name, int(ref.version)).read_text(encoding="utf-8")
                if ref.sha and digest(body) != ref.sha:
                    raise ValueError("the framework file '{}' v{} was changed on disk; upload it again from "
                                     "the record".format(ref.name, ref.version))
                return body
        raise KeyError("framework '{}' has no version {}".format(ref.name, ref.version))


# ----------------------------------------------------------------- the lock
class LockBroken(OSError):
    """Raised instead of writing when another machine broke this one's
    lock (it stalled past LOCK_STALE_SECONDS: a share that hung, a laptop
    that slept). What it read under the lock is stale, so the caller must
    read the log again and redo the change; nothing was written."""


class _FileLock:
    """One lock for every machine that opens the folder: a file created with
    O_EXCL, which SMB serves atomically. It records who took it and when,
    so a lock left by a crashed process is broken once it is older than
    the stale limit instead of blocking everyone until someone notices.
    Each acquisition also writes a token of its own, so a holder that
    stalled past that limit can tell its lock was broken -- and then
    neither writes over the machine that broke it nor removes its lock."""

    def __init__(self, path: Path, owner: str, stale: float, wait: float):
        self.path = Path(path)
        self.owner = owner
        self.stale = stale
        self.wait = wait
        self.token = None                  # this acquisition's, from acquire until release

    def __enter__(self) -> "_FileLock":
        self.acquire()
        return self

    def __exit__(self, *exc) -> None:
        self.release()

    def acquire(self) -> None:
        deadline = time.monotonic() + self.wait
        checked = None                      # when the share was last asked whether the lock is stale
        while True:
            try:
                fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                # The staleness probe touches the share, so it runs about
                # once a second rather than on every tick of the wait.
                if checked is None or time.monotonic() - checked >= LOCK_CHECK_SECONDS:
                    checked = time.monotonic()
                    if self._stale() and self._break():
                        continue
                if time.monotonic() >= deadline:
                    raise OSError("The master log is locked by {}. If that machine is not running the app any "
                                  "more, delete {}".format(self._holder(), self.path))
                time.sleep(0.1)
                continue
            except FileNotFoundError:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                continue
            # Line one is for the person who reads a stuck lock, line two
            # for held().
            token = uuid.uuid4().hex
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write("{} {}\ntoken {}\n".format(self.owner, now(), token))
            self.token = token
            return

    def release(self) -> None:
        """Removes the lock only while it is still this acquisition's. One
        another machine broke and took is that machine's to remove."""
        if self.token is None:
            return
        try:
            if not self.held():
                log.warning("The master-log lock %s was broken while this process held it (%s has it now); "
                            "it is left alone", self.path, self._holder("nobody"))
                return
            _retry(lambda: os.unlink(str(self.path)), "release the master-log lock")
        except FileNotFoundError:
            pass
        except OSError as exc:
            log.warning("The master-log lock %s could not be removed: %s", self.path, exc)
        finally:
            self.token = None

    def held(self) -> bool:
        """Whether the lock file is still the one this acquisition wrote.
        A read that fails counts as no: a wrong no costs one refused
        write, a wrong yes could cost another machine's changes."""
        if self.token is None:
            return False
        try:
            text = _retry(lambda: self.path.read_text(encoding="utf-8", errors="replace"),
                          "read the master-log lock")
        except OSError:
            return False
        return "token {}".format(self.token) in str(text).splitlines()

    def _stale(self) -> bool:
        """Older than the stale limit by the share's own clock, never by
        this machine's: the lock's mtime was stamped over there."""
        try:
            mtime = os.stat(str(self.path)).st_mtime
        except OSError:
            return False
        return _share_now(self.path.parent) - mtime > self.stale

    def _break(self) -> bool:
        """Two waiters can find the same dead lock stale in the same second.
        Each renames it to a name of its own first -- one rename wins, the
        other finds nothing to rename -- so exactly one breaker removes it
        and the rest go back to competing for a new lock."""
        holder = self._holder()
        mine = self.path.with_name("{}-broken-{}".format(self.path.name, uuid.uuid4().hex[:8]))
        try:
            os.replace(str(self.path), str(mine))
        except OSError:
            return False
        log.warning("Breaking a master-log lock older than %.0f s held by %s", self.stale, holder)
        try:
            os.unlink(str(mine))
        except OSError as exc:
            log.warning("The broken lock %s could not be removed: %s", mine, exc)
        return True

    def _holder(self, missing: str = "an unknown process") -> str:
        """The first line of the lock: who took it and when."""
        try:
            lines = self.path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return missing
        return (lines[0].strip() if lines else "") or "an unknown process"


# ------------------------------------------------------------------- the log
class MasterLog:
    def __init__(self, folder: Path):
        self.folder = Path(folder)
        self.master_path = self.folder / MASTER_NAME
        self.titles_path = self.folder / TITLES_NAME
        self.lock_path = self.folder / LOCK_NAME
        self.frameworks = SharedFrameworks(self.folder / LIBRARY_DIR, before_write=self._check_held_if_locked)
        self.hostname = socket.gethostname()
        # The GUI thread reads while the worker thread writes; the file lock
        # is for other machines, this one is for this process.
        self._lock = threading.RLock()
        self._held = None                  # the file lock of the change in progress, for the write paths
        self._reported = set()             # bad entries already written to the log once
        self._sheets_written = {}          # fid -> mtime of the add sheet as this process last wrote it

    # -- paths ----------------------------------------------------------------
    def resolve(self, rel) -> Path:
        """A stored (relative) path as a real one on this machine."""
        path = Path(str(rel or ""))
        return path if path.is_absolute() else self.folder / path

    def relative(self, path) -> str:
        """A path under the master folder as the log stores it: relative,
        forward slashes, the same on every machine. Anything else is kept
        as given."""
        text = str(path or "")
        if not text:
            return ""
        try:
            return Path(text).resolve().relative_to(self.folder.resolve()).as_posix()
        except (OSError, ValueError):
            return text

    def record_dir(self, fid: str) -> Path:
        return self.folder / self._check_fid(fid)

    def job_dir(self, job: TitleJob) -> Path:
        """Where a job's production lives, from ids that passed the checks."""
        return self.record_dir(job.framework_id) / "jobs" / self._check_job_id(job.id)

    def export_dir(self, fid: str) -> Path:
        return self.record_dir(fid) / "exports"

    @property
    def flow_accounts_path(self) -> Path:
        """The Google Flow account inventory, beside titles.json."""
        return self.folder / FLOW_ACCOUNTS_NAME

    @property
    def flow_status_sheet(self) -> Path:
        return self.folder / FLOW_STATUS_SHEET

    def add_sheet(self, fid: str) -> Path:
        return self.record_dir(fid) / ADD_SHEET

    def status_sheet(self, fid: str) -> Path:
        return self.record_dir(fid) / STATUS_SHEET

    # -- records --------------------------------------------------------------
    def records(self) -> List[MasterRecord]:
        with self._lock:
            return self._load_records()

    def record(self, fid: str) -> MasterRecord:
        fid = self._check_fid(fid)
        return self._find_record(self.records(), fid)

    def save_record(self, record: MasterRecord) -> MasterRecord:
        fid = self._check_fid(record.framework_id)
        record.framework_id = fid
        record.email = (record.email or "").strip()
        if record.email and not EMAIL.match(record.email):
            raise ValueError("The email must be one address like name@example.com, with no spaces, commas "
                             "or brackets.")
        with self._lock, self._file_lock():
            records = self._load_records()
            for index, existing in enumerate(records):
                if existing.framework_id == fid:
                    if not (record.serial or "").strip():
                        record.serial = existing.serial or next_serial(records)
                    records[index] = record
                    break
            else:
                # The number is for people: it is given here, under the
                # lock, so two machines adding records at once never share
                # one, and a deleted record's number is never handed out again.
                if not (record.serial or "").strip():
                    record.serial = next_serial(records)
                records.append(record)
            self._save_records(records)
        self._best_effort(lambda: self._ensure_add_sheet(fid), "create the add-titles sheet for " + fid)
        return record

    def upload_framework(self, fid: str, kind: str, path: Path) -> FrameworkRef:
        """The file goes into the shared library as '<fid> <kind>' -- that is
        the ref the record keeps and the worker resolves -- and a readable
        copy lands under <fid>/frameworks/ for people. The kind is checked
        before any path is built from it."""
        if kind not in FRAMEWORK_KINDS:
            raise KeyError(kind)
        fid = self._check_fid(fid)
        text = _decode(Path(path).read_bytes())
        with self._lock, self._file_lock():
            ref = self.frameworks.save("{} {}".format(fid, kind), kind, text)
            copy = self.record_dir(fid) / "frameworks" / "{}-v{}.txt".format(kind, ref.version)
            if not copy.exists():
                self._best_effort(lambda: _write_atomic(copy, self.frameworks.text(ref)),
                                  "write the readable copy " + copy.name)
        return ref

    # -- titles ---------------------------------------------------------------
    def add_title(self, fid: str, title: str, added_by: str, force: bool = False) -> TitleJob:
        """A new queued job, unless the record already has this title. A
        live twin is refused outright (force=True makes a second, paid,
        production); a failed twin is refused with 'use Retry' so its clips
        are reused rather than bought again."""
        fid = self._check_fid(fid)
        title = clean_title(title)
        added_by = _one_line(added_by)[:80]
        with self._lock, self._file_lock():
            self._find_record(self._load_records(), fid)
            jobs = self._load_jobs()
            live, failed = self._twins(jobs, fid, title)
            if not force:
                if live is not None:
                    raise ValueError("'{}' is already in the log for {} as {} ({}).".format(
                        title, fid, live.id, live.status))
                if failed is not None:
                    raise ValueError("'{}' failed earlier as {}: use Retry, so its production folder and the "
                                     "clips already paid for are reused.".format(title, failed.id))
            job = self._new_job(jobs, fid, title, added_by, "added by {}".format(added_by or "?"))
            jobs.append(job)
            self._save_jobs(jobs)
        self._mirror(fid, jobs)
        return job

    def jobs(self, fid: Optional[str] = None, status: Optional[str] = None) -> List[TitleJob]:
        with self._lock:
            jobs = self._load_jobs()
        return [j for j in jobs if (fid is None or j.framework_id == fid) and (status is None or j.status == status)]

    def job(self, job_id: str) -> TitleJob:
        job_id = self._check_job_id(job_id)
        return self._find_job(self.jobs(), job_id)

    def set_status(self, job_id: str, status: str, note: str = "", expect: Optional[str] = None,
                   **changes) -> TitleJob:
        """The one way a job moves. Appends to its history, stamps `updated`,
        writes the JSON, then refreshes the status sheet best-effort.
        `expect` is the status the caller last saw: when the job has moved
        on since (another machine took it), nothing is written and the
        error says so, because a screen that has not refreshed must not
        pause or re-queue a job a worker is paying for."""
        job_id = self._check_job_id(job_id)
        self._check_status(status)
        self._check_changes(changes)
        with self._lock, self._file_lock():
            jobs = self._load_jobs()
            job = self._find_job(jobs, job_id)
            if expect is not None and job.status != expect:
                raise ValueError("'{}' is now {} ({}), not {}: the list was out of date. It has been "
                                 "refreshed; look again.".format(job.title[:60], job.status,
                                                                  job.worker or "no worker", expect))
            self._apply_status(job, status, note, changes)
            self._save_jobs(jobs)
        self._mirror(job.framework_id, jobs)
        return job

    def touch(self, job_id: str, **changes) -> TitleJob:
        """A sign of life from the worker: heartbeat, stage and progress
        without a history entry, meant for at most once a minute. A job
        that is not in progress is left alone: a beat that lands just after
        the job finished or went back to the queue must not make it look as
        if a worker were still on it."""
        job_id = self._check_job_id(job_id)
        self._check_changes(changes)
        with self._lock, self._file_lock():
            jobs = self._load_jobs()
            job = self._find_job(jobs, job_id)
            if job.status not in IN_PROGRESS:
                return job
            stamp = now()
            job.heartbeat = stamp
            job.updated = stamp
            self._set_changes(job, changes)
            self._save_jobs(jobs)
        self._mirror(job.framework_id, jobs)
        return job

    def retry(self, job_id: str) -> TitleJob:
        """A failed title back in the queue with the same id, so the worker
        resumes its production folder and reuses the clips on disk."""
        job_id = self._check_job_id(job_id)
        with self._lock, self._file_lock():
            jobs = self._load_jobs()
            job = self._find_job(jobs, job_id)
            if job.status != "failed":
                raise ValueError("Only a failed title can be retried; '{}' is {}.".format(job.title, job.status))
            self._apply_status(job, "queued", "retried; the production folder is kept", {})
            self._save_jobs(jobs)
        self._mirror(job.framework_id, jobs)
        return job

    def next_queued(self) -> Optional[TitleJob]:
        """A look at what the worker would take next, without taking it.
        The worker itself must use claim_next()."""
        with self._lock:
            records = self._load_records()
            jobs = self._load_jobs()
        return self._pick(records, jobs, include_stale=False)

    def claim_next(self, worker_id: str) -> Optional[TitleJob]:
        """The oldest queued job of an enabled record -- or an in-progress
        job whose worker has gone quiet -- marked as this worker's, inside
        the lock, so two machines can never take the same one."""
        worker_id = _one_line(worker_id) or self.hostname
        with self._lock, self._file_lock():
            records = self._load_records()
            jobs = self._load_jobs()
            job = self._pick(records, jobs, include_stale=True)
            if job is None:
                return None
            changes = {"worker": worker_id, "heartbeat": now()}
            if job.status == "queued":
                self._apply_status(job, "script_running", "claimed by {}".format(worker_id), changes)
            else:
                self._apply_status(job, job.status, "resumed after a stopped worker: claimed by {}".format(worker_id),
                                   changes)
            self._save_jobs(jobs)
        self._mirror(job.framework_id, jobs)
        return job

    # -- sheets ---------------------------------------------------------------
    def import_titles_from_csv(self, fid: str, settle_seconds: Optional[float] = None) -> List[TitleJob]:
        """Rows an editor typed into add-titles.csv become queued jobs; rows
        the log already knows (by id, or by the same title) get their id
        written back. Returns the jobs it queued: new ones, and failed ones
        the sheet re-added. Only the page's Refresh button calls this; the
        worker never does."""
        fid = self._check_fid(fid)
        settle = SHEET_SETTLE_SECONDS if settle_seconds is None else float(settle_seconds)
        sheet = self.add_sheet(fid)
        with self._lock:
            try:
                stat = sheet.stat()
            except FileNotFoundError:
                self._ensure_add_sheet(fid)
                return []
            # Measured by the clock that stamped the sheet: a share running
            # a few seconds ahead of this machine would otherwise make every
            # save look as if it were still in progress, forever.
            age = _share_now(sheet.parent) - stat.st_mtime
            ours = abs(stat.st_mtime - self._sheets_written.get(fid, -1.0)) < 0.001
            if age < settle and not ours:
                raise ValueError("{} was saved {:.0f} s ago and may still be being written; refresh again in a "
                                 "moment.".format(sheet.name, max(age, 0.0)))
            raw = sheet.read_bytes()
            if not raw.strip():
                return []
            if not raw.endswith(b"\n"):
                raise ValueError("{} does not end with a line break, so it may still be being saved. If it is "
                                 "not, press Enter after the last row and save it again.".format(sheet.name))
            columns, rows = _parse_sheet(_decode(raw))
            if "title" not in columns:
                raise ValueError("{} needs a 'title' column; its columns are {}.".format(
                    sheet.name, ", ".join(ADD_COLUMNS)))
            with self._file_lock():
                self._find_record(self._load_records(), fid)
                jobs = self._load_jobs()
                queued, changed, sheet_changed = self._absorb_rows(jobs, fid, rows)
                if changed:
                    self._save_jobs(jobs)
            if sheet_changed:
                self._best_effort(lambda: self._write_add_sheet(fid, columns, rows),
                                  "write the ids back into " + sheet.name)
        self._mirror(fid, jobs)
        return queued

    def export_titles_csv(self, fid: str) -> Path:
        """The status sheet for one record, written now; raises when it
        cannot be (the callers that must not fail wrap it)."""
        fid = self._check_fid(fid)
        with self._lock:
            jobs = self._load_jobs()
        return self._write_status_sheet(fid, jobs)

    # -- internals: state ------------------------------------------------------
    def _file_lock(self) -> _FileLock:
        """The cross-machine lock for one change. The log keeps it (every
        change runs under self._lock, so there is one at a time) for the
        write paths to ask whether it is still theirs."""
        self._held = _FileLock(self.lock_path, "{} pid {}".format(self.hostname, os.getpid()),
                               LOCK_STALE_SECONDS, LOCK_WAIT_SECONDS)
        return self._held

    def _check_held_if_locked(self) -> None:
        """For the shared library, whose writes happen under this log's lock
        when they come through upload_framework and unguarded otherwise."""
        if self._held is not None:
            self._check_held()

    def _check_held(self) -> None:
        """Nothing is written over a lock another machine broke: what this
        change read under it may be minutes old by now, and writing it
        back would undo everything that machine did, claims included."""
        lock = self._held
        if lock is None or not lock.held():
            raise LockBroken("The master log's lock was broken by another machine while this one was busy "
                             "({} holds it now); nothing was written. Read the log again and retry.".format(
                                 lock._holder("nobody") if lock is not None else "nobody"))

    def _read(self, path: Path):
        raw = _read_json(path)
        if raw is None and not self.folder.is_dir():
            raise OSError("The master log folder is not reachable: {}".format(self.folder))
        return raw

    def _load_records(self) -> List[MasterRecord]:
        raw = self._read(self.master_path)
        entries = raw.get("records") if isinstance(raw, dict) else raw
        records, seen = [], set()
        for entry in entries if isinstance(entries, list) else []:
            try:
                record = _record_from(entry)
            except (TypeError, ValueError, AttributeError):
                self._report("master.json entry {!r}".format(entry)[:120] + " is not a record; skipped")
                continue
            if not FRAMEWORK_ID.match(record.framework_id):
                self._report("master.json record with id {!r} skipped: a framework id is lower-case letters, "
                             "digits and hyphens".format(record.framework_id[:80]))
                continue
            if record.framework_id in seen:
                self._report("master.json has record '{}' twice; the first one is kept".format(record.framework_id))
                continue
            seen.add(record.framework_id)
            records.append(record)
        return records

    def _load_jobs(self) -> List[TitleJob]:
        raw = self._read(self.titles_path)
        entries = raw.get("jobs") if isinstance(raw, dict) else raw
        jobs, seen = [], set()
        for entry in entries if isinstance(entries, list) else []:
            try:
                job = _job_from(entry)
            except (TypeError, ValueError, AttributeError):
                self._report("titles.json entry {!r}".format(entry)[:120] + " is not a job; skipped")
                continue
            if not JOB_ID.match(job.id) or not FRAMEWORK_ID.match(job.framework_id):
                self._report("titles.json job with id {!r} for {!r} skipped: ids may hold only letters, digits "
                             "and hyphens".format(job.id[:40], job.framework_id[:40]))
                continue
            if job.id in seen:
                self._report("titles.json has job {} twice; the first one is kept".format(job.id))
                continue
            seen.add(job.id)
            jobs.append(job)
        return jobs

    def _save_records(self, records: List[MasterRecord]) -> None:
        self._check_held()
        payload = {"format_version": 1, "updated": now(), "records": [_raw(r) for r in records]}
        _write_atomic(self.master_path, json.dumps(payload, indent=2, ensure_ascii=False), check=self._check_held)

    def _save_jobs(self, jobs: List[TitleJob]) -> None:
        self._check_held()
        payload = {"format_version": 1, "updated": now(), "jobs": [_raw(j) for j in jobs]}
        _write_atomic(self.titles_path, json.dumps(payload, indent=2, ensure_ascii=False), check=self._check_held)

    def _report(self, message: str) -> None:
        if message not in self._reported:
            self._reported.add(message)
            log.warning("%s: %s", self.folder, message)

    @staticmethod
    def _best_effort(action: Callable[[], object], what: str) -> None:
        try:
            action()
        except OSError as exc:
            log.warning("Could not %s: %s (the log itself is saved)", what, exc)

    # -- internals: checks -----------------------------------------------------
    @staticmethod
    def _check_fid(fid) -> str:
        fid = str(fid or "").strip()
        if not FRAMEWORK_ID.match(fid):
            raise ValueError("A framework id is lower-case letters, digits and hyphens, like family-drama; "
                             "'{}' is not.".format(fid[:80]))
        return fid

    @staticmethod
    def _check_job_id(job_id) -> str:
        job_id = str(job_id or "").strip()
        if not JOB_ID.match(job_id):
            raise ValueError("'{}' is not a job id.".format(job_id[:80]))
        return job_id

    @staticmethod
    def _check_status(status) -> None:
        if status not in STATUSES:
            raise ValueError("'{}' is not a master-log status; one of {}.".format(status, ", ".join(STATUSES)))

    @staticmethod
    def _check_changes(changes: Dict[str, object]) -> None:
        unknown = sorted(set(changes) - set(_SETTABLE))
        if unknown:
            raise ValueError("A job's {} cannot be set this way; only {}.".format(
                ", ".join(unknown), ", ".join(_SETTABLE)))

    @staticmethod
    def _find_record(records: List[MasterRecord], fid: str) -> MasterRecord:
        for record in records:
            if record.framework_id == fid:
                return record
        raise KeyError("There is no framework record '{}' in the master log.".format(fid))

    @staticmethod
    def _find_job(jobs: List[TitleJob], job_id: str) -> TitleJob:
        for job in jobs:
            if job.id == job_id:
                return job
        raise KeyError("There is no job {} in the master log.".format(job_id))

    # -- internals: jobs -------------------------------------------------------
    @staticmethod
    def _twins(jobs: List[TitleJob], fid: str, title: str) -> Tuple[Optional[TitleJob], Optional[TitleJob]]:
        """(the latest live job with this title, the latest failed one)."""
        key = title_key(title)
        live = failed = None
        for job in jobs:
            if job.framework_id != fid or title_key(job.title) != key:
                continue
            if job.status == "failed":
                failed = job
            else:
                live = job
        return live, failed

    @staticmethod
    def _new_job(jobs: List[TitleJob], fid: str, title: str, added_by: str, note: str) -> TitleJob:
        taken = {j.id for j in jobs}
        while True:
            job_id = "t-" + uuid.uuid4().hex[:8]
            if job_id not in taken:
                break
        stamp = now()
        return TitleJob(id=job_id, framework_id=fid, title=title, added_by=added_by, added=stamp, updated=stamp,
                        history=[{"status": "queued", "at": stamp, "note": note}])

    def _apply_status(self, job: TitleJob, status: str, note: str, changes: Dict[str, object]) -> None:
        self._check_status(status)
        stamp = now()
        self._set_changes(job, changes)
        # A job nobody is on carries no sign of a worker, whatever the caller
        # passed: the reclaim rule reads the heartbeat as "someone is on it".
        if status == "queued":
            job.error = job.worker = job.heartbeat = job.stage = job.progress = ""
        elif status == "paused":
            job.worker = job.heartbeat = ""
        elif status in ("video_done", "failed"):
            job.heartbeat = ""
        job.status = status
        job.updated = stamp
        job.history.append({"status": status, "at": stamp, "note": _one_line(note)})

    def _set_changes(self, job: TitleJob, changes: Dict[str, object]) -> None:
        for key, value in changes.items():
            text = "" if value is None else str(value)
            if key in ("production_dir", "export_path"):
                text = self.relative(text)
            elif key == "error":
                text = _lines(text)
            else:
                text = _one_line(text)
            setattr(job, key, text)

    @staticmethod
    def _stale(job: TitleJob) -> bool:
        return job.status in IN_PROGRESS and \
            _age_seconds(job.heartbeat or job.updated or job.added) > HEARTBEAT_STALE_SECONDS

    def _pick(self, records: List[MasterRecord], jobs: List[TitleJob], include_stale: bool) -> Optional[TitleJob]:
        """Oldest first. `added` has one-second resolution and a sheet import
        queues its rows within one second, so ties fall to the order the
        jobs were written in -- the sheet's order -- never to the random id."""
        enabled = {r.framework_id for r in records if r.enabled}
        candidates = [(index, j) for index, j in enumerate(jobs) if j.framework_id in enabled
                      and (j.status == "queued" or (include_stale and self._stale(j)))]
        if not candidates:
            return None
        return min(candidates, key=lambda pair: (pair[1].added, pair[0]))[1]

    # -- internals: sheets -----------------------------------------------------
    def _absorb_rows(self, jobs: List[TitleJob], fid: str, rows: List[Dict[str, str]]):
        mine = [j for j in jobs if j.framework_id == fid]
        by_id = {j.id: j for j in mine}
        live, failed = {}, {}
        for job in mine:                                   # later jobs win, like _twins
            (failed if job.status == "failed" else live)[title_key(job.title)] = job
        queued, changed, sheet_changed = [], False, False
        for row in rows:
            raw_title = row.get("title", "") or ""
            sheet_id = (row.get("id") or "").strip()
            wanted = (row.get("status") or "").strip().lower()
            who = _one_line(row.get("added_by") or "")[:80] or "sheet"
            job = by_id.get(sheet_id)
            if job is None:
                try:
                    title = clean_title(raw_title)
                except ValueError as exc:
                    if raw_title.strip():
                        log.warning("A row in %s's sheet was skipped: %s", fid, exc)
                    continue
                key = title_key(title)
                job = live.get(key)
                if job is None and key in failed:
                    job = failed.pop(key)
                    self._apply_status(job, "queued", "re-added from the sheet by {}".format(who), {})
                    live[key] = job
                    queued.append(job)
                    changed = True
                if job is None:
                    job = self._new_job(jobs, fid, title, who, "added from the sheet by {}".format(who))
                    jobs.append(job)
                    by_id[job.id] = job
                    live[key] = job
                    queued.append(job)
                    changed = True
                if sheet_id != job.id:
                    row["id"] = job.id
                    sheet_changed = True
            if wanted:
                if (job.status, wanted) in SHEET_TRANSITIONS:
                    self._apply_status(job, wanted, "{} from the sheet by {}".format(
                        "held" if wanted == "paused" else "queued", who), {})
                    changed = True
                row["status"] = ""
                sheet_changed = True
        return queued, changed, sheet_changed

    def _ensure_add_sheet(self, fid: str) -> None:
        sheet = self.add_sheet(fid)
        if sheet.exists():
            return
        buffer = io.StringIO()
        csv.writer(buffer).writerow(ADD_COLUMNS)
        _write_atomic(sheet, buffer.getvalue(), encoding="utf-8-sig")
        self._remember_sheet(fid, sheet)

    def _write_add_sheet(self, fid: str, columns: List[str], rows: List[Dict[str, str]]) -> None:
        sheet = self.add_sheet(fid)
        columns = list(columns)
        if "id" not in columns:
            columns.insert(0, "id")
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(columns)
        for row in rows:
            writer.writerow([_cell(row.get(column, "")) for column in columns])
        _write_atomic(sheet, buffer.getvalue(), encoding="utf-8-sig")
        self._remember_sheet(fid, sheet)

    def _remember_sheet(self, fid: str, sheet: Path) -> None:
        """Our own write must not look like an editor's fresh save."""
        try:
            self._sheets_written[fid] = sheet.stat().st_mtime
        except OSError:
            pass

    def _write_status_sheet(self, fid: str, jobs: List[TitleJob]) -> Path:
        path = self.status_sheet(fid)
        buffer = io.StringIO()
        writer = csv.writer(buffer)
        writer.writerow(STATUS_COLUMNS)
        for job in jobs:
            if job.framework_id == fid:
                writer.writerow([_cell(getattr(job, column)) for column in STATUS_COLUMNS])
        _write_atomic(path, buffer.getvalue(), encoding="utf-8-sig")
        self._ensure_add_sheet(fid)
        return path

    def _mirror(self, fid: str, jobs: List[TitleJob]) -> None:
        """Best effort by design: Excel may hold the sheet all day, and a
        finished video must not be marked failed because of it."""
        self._best_effort(lambda: self._write_status_sheet(fid, jobs), "refresh the status sheet for " + fid)


def _parse_sheet(text: str) -> Tuple[List[str], List[Dict[str, str]]]:
    """Header names lower-cased and trimmed; every row a dict over them.
    Cells past the header are dropped, short rows are padded."""
    lines = list(csv.reader(io.StringIO(text, newline="")))
    if not lines:
        return [], []
    columns = [(name or "").strip().lstrip("﻿").strip().lower() for name in lines[0]]
    rows = []
    for line in lines[1:]:
        if not any(cell.strip() for cell in line):
            rows.append({column: "" for column in columns})
            continue
        rows.append({column: (line[index] if index < len(line) else "") for index, column in enumerate(columns)})
    return columns, rows
