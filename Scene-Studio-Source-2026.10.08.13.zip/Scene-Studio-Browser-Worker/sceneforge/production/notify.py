"""Email to the editor when a master-log title finishes or fails.

The worker runs unattended, often overnight, on a machine the editor is not
sitting at. The sheet shows the status, but nobody watches a sheet: a mail
saying "your video is ready" or "this title failed, here is why" is what
lets an editor go home. Everything here is best effort by design -- a mail
that cannot be sent is logged and reported back to the worker, and never
stops or fails the job it was about.

Two things this file is careful about, because the addresses and titles it
handles come from a shared sheet that any editor can type into:

  - a message is built with email.message.EmailMessage, which refuses a
    header containing a line break, and sent with exactly one envelope
    recipient, so a title or address cannot smuggle in a Bcc; and
  - the SMTP password is read from the sealed credential store at send
    time, never kept on the settings object, never logged, and never put in
    an error message (errors are worded from the exception's class, the
    host and the port only).
"""
from __future__ import annotations

import json
import os
import re
import smtplib
import socket
import ssl
import tempfile
import unicodedata
from dataclasses import asdict, dataclass, field, fields
from email.message import EmailMessage
from email.policy import SMTP as SMTP_POLICY
from email.utils import formatdate, make_msgid
from pathlib import Path
from typing import List, Optional, Tuple

from ..logging_setup import get
from ..product import PRODUCT

log = get("production.notify")

SETTINGS_PATH = PRODUCT.data_dir / "email.json"
SECURITY = ("starttls", "ssl", "none")
TIMEOUT = 30                # seconds; a dead or firewalled host must not hold the worker thread
SSL_PORT = 465              # the one port that needs a TLS handshake before any SMTP talk
# One address, no separators, no angle brackets: the envelope must have
# exactly the recipient the record names and nothing an editor typed after it.
ADDRESS = re.compile(r"^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$")
SUBJECT_TITLE_CHARS = 80

# What each master-log status means to the person reading the mail. Kept
# here rather than imported from master.py so that this module has no
# dependency on the log itself and can be tested on its own.
STATUS_WORDS = {
    "queued": ("Queued", "is queued and waiting for the worker."),
    "script_running": ("Script being written", "is being worked on: the worker has asked for the script."),
    "script_done": ("Script written", "has its script. The scene prompts are next."),
    "prompts_done": ("Scene prompts written", "has its scene prompts. The clips are being generated next."),
    "clips_done": ("Clips generated", "has all its clips. Editing and export are next."),
    "video_done": ("Video ready", "is finished and the video has been exported."),
    "failed": ("Failed", "stopped with an error and needs a person to look at it."),
    "paused": ("Paused", "is on hold: a person paused it, and the worker skips it until it is queued again."),
}


class NotifyError(Exception):
    """A mail could not be sent. The message is written for the person who
    fills in the email settings, not for a log parser."""


# ------------------------------------------------------------------ settings
@dataclass
class EmailSettings:
    enabled: bool = False
    host: str = ""
    port: int = 587
    username: str = ""
    sender: str = ""
    use_tls: bool = True
    # starttls | ssl | none. Gmail's 465 needs SSL from the first byte and
    # hangs under STARTTLS, so the port breaks ties; see mode().
    security: str = "starttls"
    notify_on: List[str] = field(default_factory=lambda: ["video_done", "failed"])

    def mode(self) -> str:
        """How the connection is secured. An explicit 'ssl' or 'none' wins;
        otherwise port 465 means SSL (the only thing that works there) and
        use_tls decides between STARTTLS and plain, which keeps a settings
        file written before `security` existed behaving as it did."""
        if self.security in ("ssl", "none"):
            return self.security
        if int(self.port) == SSL_PORT:
            return "ssl"
        return "starttls" if self.use_tls else "none"

    def wants(self, status: str) -> bool:
        return bool(self.enabled) and status in (self.notify_on or [])

    @classmethod
    def load(cls, path: Optional[Path] = None) -> "EmailSettings":
        """A missing or unreadable file means 'not set up', never an error:
        notifications are optional and must not stop the worker."""
        target = Path(path) if path else SETTINGS_PATH
        try:
            raw = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return cls()
        if not isinstance(raw, dict):
            return cls()
        known = {f.name for f in fields(cls)}
        settings = cls(**{k: v for k, v in raw.items() if k in known})
        return settings._clean()

    def save(self, path: Optional[Path] = None) -> Path:
        """Written whole and then swapped in, so a crash mid-write cannot
        leave a half file that load() would then read as 'not set up'."""
        target = Path(path) if path else SETTINGS_PATH
        target.parent.mkdir(parents=True, exist_ok=True)
        payload = json.dumps(asdict(self._clean()), indent=2, ensure_ascii=False)
        fd, tmp = tempfile.mkstemp(prefix=".email-", suffix=".json", dir=str(target.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(payload)
            os.replace(tmp, target)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
        return target

    def _clean(self) -> "EmailSettings":
        """Coerce what a hand-edited or older file may hold into the shapes
        send() relies on, in place."""
        self.enabled = bool(self.enabled)
        self.use_tls = bool(self.use_tls)
        self.host = str(self.host or "").strip()
        self.username = str(self.username or "").strip()
        self.sender = str(self.sender or "").strip()
        try:
            self.port = int(self.port)
        except (TypeError, ValueError):
            self.port = 587
        if self.security not in SECURITY:
            self.security = "starttls"
        if isinstance(self.notify_on, str):
            self.notify_on = [self.notify_on]
        elif not isinstance(self.notify_on, (list, tuple)):
            self.notify_on = []
        self.notify_on = [str(s).strip() for s in self.notify_on if str(s).strip()]
        return self


# ------------------------------------------------------------------- sending
def send(settings: EmailSettings, password: str, to: str, subject: str, body: str) -> None:
    """One plain-text mail to one address. Raises NotifyError, in plain
    English, for anything that stops it; nothing here retries."""
    to = (to or "").strip()
    if not ADDRESS.fullmatch(to):
        raise NotifyError("The editor's email address is not valid: it must be one address, like "
                          "name@example.com, with no spaces, commas or brackets.")
    if not ADDRESS.fullmatch((settings.sender or "").strip()):
        raise NotifyError("The sender address under Email settings is not valid: it must be one address, "
                          "like name@example.com.")
    if not settings.host:
        raise NotifyError("No mail server is set. Fill in the host and port under Email settings.")
    if settings.username and not password:
        raise NotifyError("A username is set under Email settings but no password is saved. Enter the "
                          "password there; it is sealed to this Windows account like the API keys.")
    message = _build(settings.sender.strip(), to, subject, body)

    mode = settings.mode()
    host, port = settings.host, int(settings.port)
    try:
        if mode == "ssl":
            smtp = smtplib.SMTP_SSL(host, port, timeout=TIMEOUT, context=ssl.create_default_context())
        else:
            smtp = smtplib.SMTP(host, port, timeout=TIMEOUT)
    except OSError as exc:                      # every smtplib/socket/ssl error is an OSError
        raise NotifyError(_explain(exc, host, port)) from exc
    try:
        if mode == "starttls":
            smtp.starttls(context=ssl.create_default_context())
        if settings.username or password:
            smtp.login(settings.username or settings.sender, password)
        # One envelope recipient, whatever the headers say: the To header
        # was built from the same single address, and nothing else can be
        # added to it after the fact.
        smtp.sendmail(settings.sender.strip(), [to], message.as_bytes())
    except OSError as exc:
        raise NotifyError(_explain(exc, host, port)) from exc
    finally:
        try:
            smtp.quit()
        except OSError:
            pass


def _build(sender: str, to: str, subject: str, body: str) -> EmailMessage:
    """The subject goes in exactly as given. EmailMessage refuses a header
    holding any line boundary (CR, LF, and the rarer ones splitlines() knows),
    and that refusal -- not a quiet clean-up here -- is what keeps a
    sheet-typed title from adding a Bcc: job_message() collapses a title to
    one line first, so the refusal only fires for a caller that skipped it.
    The 7-bit policy encodes an Urdu body as base64 or quoted-printable with
    CRLF line ends, which every server accepts."""
    message = EmailMessage(policy=SMTP_POLICY.clone(cte_type="7bit"))
    try:
        message["From"] = sender
        message["To"] = to
        message["Subject"] = "" if subject is None else str(subject)
        message["Date"] = formatdate(localtime=True)
        # The sender's own domain rather than make_msgid's default, which
        # asks DNS for this machine's full name and can stall the worker
        # thread for seconds where the lookup is slow.
        message["Message-ID"] = make_msgid(domain=sender.rpartition("@")[2] or None)
    except ValueError as exc:
        raise NotifyError("The mail could not be built: the subject contained a line break.") from exc
    message.set_content(body or "")
    return message


def _explain(exc: BaseException, host: str, port: int) -> str:
    """Plain English from the exception's class, the host and the port only.
    Never the exception text: a server's reply to a failed login can echo
    what it was sent."""
    where = "{}:{}".format(host, port)
    kind = type(exc).__name__
    if isinstance(exc, smtplib.SMTPAuthenticationError):
        text = "The mail server at {} rejected the username or password. Check both under Email settings.".format(where)
    elif isinstance(exc, smtplib.SMTPNotSupportedError):
        text = "The mail server at {} does not support the chosen security or sign-in method.".format(where)
    elif isinstance(exc, smtplib.SMTPRecipientsRefused):
        text = "The mail server at {} refused the editor's address.".format(where)
    elif isinstance(exc, smtplib.SMTPSenderRefused):
        text = "The mail server at {} refused the sender address.".format(where)
    elif isinstance(exc, smtplib.SMTPServerDisconnected):
        text = "The mail server at {} closed the connection before the mail was accepted.".format(where)
    elif isinstance(exc, smtplib.SMTPException):
        text = "The mail server at {} refused the request.".format(where)
    elif isinstance(exc, (socket.timeout, TimeoutError)):
        text = "The mail server at {} did not answer within {} seconds.".format(where, TIMEOUT)
    elif isinstance(exc, ssl.SSLError):
        text = ("The mail server at {} did not accept a secure connection. Try the other security setting: "
                "SSL for port 465, STARTTLS for 587.".format(where))
    elif isinstance(exc, ConnectionRefusedError):
        text = "Nothing is listening at {}. Check the host and port.".format(where)
    elif isinstance(exc, socket.gaierror):
        text = "The mail server '{}' could not be found. Check the host name.".format(host)
    else:
        text = "Could not reach the mail server at {}.".format(where)
    return "{} ({})".format(text, kind)


# ------------------------------------------------------------------- wording
def job_message(job, record, status: str, note: str = "", export_path: str = "") -> Tuple[str, str]:
    """Subject and body for a title reaching `status`. Written from the job's
    own record -- its timestamps, its error -- so a mail sent late still says
    what happened and when. `note` and `export_path` let the worker pass
    what the stored job does not carry (missing clips; the share's UNC path
    when the log was opened through a drive letter)."""
    title = _one_line(str(getattr(job, "title", "") or ""))
    label, phrase = STATUS_WORDS.get(status, (status.replace("_", " ").capitalize(), "is now '{}'.".format(status)))
    subject = "{}: {} - {}".format(PRODUCT.name, label, _shorten(title, SUBJECT_TITLE_CHARS) or "(untitled)")

    editor = str(getattr(record, "editor_name", "") or "").strip()
    framework = str(getattr(record, "framework_id", "") or getattr(job, "framework_id", "") or "")
    niche = str(getattr(record, "niche", "") or "")
    export = export_path or str(getattr(job, "export_path", "") or "")
    error = str(getattr(job, "error", "") or "")
    note = note or _latest_note(job, status)

    lines = ["Hello{},".format(" " + editor if editor else ""), "",
             '"{}" {}'.format(title, phrase), ""]
    serial = str(getattr(record, "serial", "") or "").strip()
    rows = [("Framework", (serial + "  " if serial else "") + framework + (" ({})".format(niche) if niche else "")),
            ("Status", "{} ({})".format(status, label)),
            ("Stage", _progress_of(job)),
            ("Video", export if status == "video_done" or (export and status != "failed") else ""),
            ("Error", error if status == "failed" or error else ""),
            ("Note", note),
            ("Added", _when(getattr(job, "added", ""), getattr(job, "added_by", ""))),
            ("Updated", str(getattr(job, "updated", "") or "")),
            ("Job id", str(getattr(job, "id", "") or ""))]
    width = max(len(k) for k, _ in rows) + 2
    for key, value in rows:
        if value:
            lines.append("{}{}".format((key + ":").ljust(width), value))
    lines += ["", "Sent automatically by the {} master-log worker. "
                  "The sheet in the master log folder shows every title's current status.".format(PRODUCT.name)]
    return subject, "\n".join(lines)


def _progress_of(job) -> str:
    stage = str(getattr(job, "stage", "") or "")
    progress = str(getattr(job, "progress", "") or "")
    if stage and progress and not progress.startswith(stage):
        return "{} ({})".format(stage, progress)
    return progress or stage


def _when(stamp, who) -> str:
    stamp = str(stamp or "")
    who = str(who or "").strip()
    if stamp and who:
        return "{} by {}".format(stamp, who)
    return stamp or (("by " + who) if who else "")


def _latest_note(job, status: str) -> str:
    """The most recent history note written for this status, if the log
    keeps one: the worker puts 'N clips missing' and the like there."""
    history = getattr(job, "history", None) or []
    for entry in reversed(list(history)):
        if isinstance(entry, dict):
            if entry.get("status") == status:
                return str(entry.get("note", "") or "")
        elif getattr(entry, "status", None) == status:
            return str(getattr(entry, "note", "") or "")
    return ""


_LINE_CATEGORIES = ("Cc", "Zl", "Zp", "Cs", "Co", "Cn")


def _one_line(text: str) -> str:
    """Whitespace, line breaks and control characters collapsed to single
    spaces: a header may not contain them and a mail subject reads better
    without them. Format characters (the zero-width joiners and direction
    marks inside Urdu words) are kept, or the subject would split words."""
    out = []
    for ch in str(text or ""):
        out.append(" " if ch.isspace() or unicodedata.category(ch) in _LINE_CATEGORIES else ch)
    return " ".join("".join(out).split())


def _shorten(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[:limit - 1].rstrip() + "…"


# ------------------------------------------------------------------ notifier
class Notifier:
    """The worker's one call per status change. Decides whether a mail is
    wanted, fetches the sealed password, sends, and swallows every failure
    into the log and `last_error`. The worker writes `last_error` into the
    job's history note after a False, so the editor sees 'email failed: ...'
    in the sheet; an email problem is never allowed to fail the job."""

    def __init__(self, settings: EmailSettings, credentials=None):
        self.settings = settings
        self.credentials = credentials
        self.last_error = ""            # plain English for the job's history note; empty after a success

    def wants(self, status: str) -> bool:
        return self.settings.wants(status)

    def notify(self, job, record, status: str, note: str = "", export_path: str = "") -> bool:
        """True when a mail went out. Never raises."""
        self.last_error = ""
        try:
            if not self.wants(status):
                return False
            to = str(getattr(record, "email", "") or "").strip()
            if not to:
                return False
            if not ADDRESS.fullmatch(to):
                self.last_error = "email not sent: the record's address is not a valid single email address"
                log.warning("Job %s: %s", getattr(job, "id", "?"), self.last_error)
                return False
            password = self.credentials.get("smtp") if self.credentials is not None else ""
            subject, body = job_message(job, record, status, note=note, export_path=export_path)
            send(self.settings, password or "", to, subject, body)
        except NotifyError as exc:
            self.last_error = "email failed: {}".format(exc)
            log.warning("Job %s: %s", getattr(job, "id", "?"), self.last_error)
            return False
        except Exception as exc:                                       # noqa: BLE001 - never raises
            self.last_error = "email failed: {}".format(type(exc).__name__)
            log.exception("Job %s: sending the %s mail crashed", getattr(job, "id", "?"), status)
            return False
        log.info("Job %s: %s mail sent", getattr(job, "id", "?"), status)
        return True
