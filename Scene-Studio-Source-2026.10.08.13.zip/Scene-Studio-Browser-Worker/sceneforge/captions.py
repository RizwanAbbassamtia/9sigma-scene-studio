"""Build subtitles from the script, timed to the speech the VAD heard.

Nothing is transcribed. The exact Urdu is already in the episode script, and
voice detection already knows when someone is speaking, so the two are combined:
each scripted line is given a share of its clip's speech time proportional to
how long it is to say.

That is more accurate than automatic transcription for this footage and costs
nothing extra, but it does assume the render says what the script says. A clip
flagged `cut off` is missing words, so its captions will run short too.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, NamedTuple, Optional

from .config import Config
from .logging_setup import get
from .models import Clip, Episode, ReviewState, SpeechSpan

log = get("captions")

MIN_CUE_SECONDS = 0.7
MAX_CUE_SECONDS = 7.0


class Cue(NamedTuple):
    start: float          # seconds into the finished video
    end: float
    speaker: str
    text: str

    def as_srt_block(self, index: int, with_speaker: bool) -> str:
        body = "{}: {}".format(self.speaker, self.text) if with_speaker else self.text
        return "{}\n{} --> {}\n{}\n".format(
            index, _timestamp(self.start), _timestamp(self.end), body)


def _timestamp(seconds: float) -> str:
    seconds = max(0.0, seconds)
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    whole = int(secs)
    millis = int(round((secs - whole) * 1000))
    if millis == 1000:                       # rounding can push it over
        whole, millis = whole + 1, 0
    return "{:02d}:{:02d}:{:02d},{:03d}".format(
        int(hours), int(minutes), whole, millis)


def _kept_speech(clip: Clip) -> List[SpeechSpan]:
    """Speech spans clipped to the part of the clip that survives the edit."""
    spans: List[SpeechSpan] = []
    for keep in clip.keep:
        for span in clip.speech:
            start = max(span.start, keep.start)
            end = min(span.end, keep.end)
            if end - start > 0.05:
                spans.append(SpeechSpan(start, end))
    return spans


def cues_for_clip(clip: Clip, offset: float) -> List[Cue]:
    """Lay this clip's scripted dialogue over its detected speech.

    `offset` is where the clip starts in the finished video.
    """
    if not clip.scene or not clip.scene.has_dialogue or not clip.scene.dialogue:
        return []

    spans = _kept_speech(clip)
    if not spans:
        return []

    lines = [line for line in clip.scene.dialogue if line.text.strip()]
    if not lines:
        return []

    total_chars = sum(max(1, line.char_count) for line in lines)
    total_speech = sum(s.duration for s in spans)
    if total_speech <= 0:
        return []

    # Time is allocated along the speech spans as one continuous ribbon, then
    # mapped back to real positions, so a line never lands in a silent gap.
    cues: List[Cue] = []
    consumed = 0.0
    for line in lines:
        share = total_speech * (max(1, line.char_count) / total_chars)
        start_local = _position_on_ribbon(spans, consumed)
        consumed += share
        end_local = _position_on_ribbon(spans, consumed)

        if end_local - start_local < MIN_CUE_SECONDS:
            end_local = min(spans[-1].end, start_local + MIN_CUE_SECONDS)
        if end_local - start_local > MAX_CUE_SECONDS:
            end_local = start_local + MAX_CUE_SECONDS

        # convert clip-local time to a position in the finished video
        start = offset + _played_before(clip, start_local)
        end = offset + _played_before(clip, end_local)
        if end > start:
            cues.append(Cue(start, end, line.speaker, line.text.strip()))
    return cues


def _played_before(clip: Clip, local: float) -> float:
    """How much of this clip has played by source time `local`.

    The export drops whatever lies between two kept segments, so a source
    time in the second segment lands earlier in the finished video than its
    distance from the first cut suggests. Time in a dropped gap maps to the
    end of the segment before it.
    """
    played = 0.0
    for span in clip.keep:
        if local <= span.start:
            break
        played += min(local, span.end) - span.start
    return played


def _position_on_ribbon(spans: List[SpeechSpan], travelled: float) -> float:
    """Where `travelled` seconds of speech lands, skipping the silent gaps."""
    remaining = travelled
    for span in spans:
        if remaining <= span.duration:
            return span.start + remaining
        remaining -= span.duration
    return spans[-1].end


def build(episode: Episode, config: Config,
          actual_durations: Optional[dict] = None) -> List[Cue]:
    """Every cue in the finished video, in order and never overlapping.

    `actual_durations` maps a clip number to how long its encoded segment really
    turned out. ffmpeg can only cut on a frame, so a segment lands up to a frame
    longer than planned -- around 0.03s each, invisible on one clip but roughly
    five seconds of drift by the end of a 167-clip episode. Passing the measured
    values keeps the captions locked to the picture; without them the planned
    durations are used, which is close but drifts late.
    """
    cues: List[Cue] = []
    offset = 0.0
    for clip in sorted(episode.clips, key=lambda c: c.number):
        if clip.state == ReviewState.REJECTED:
            continue
        cues.extend(cues_for_clip(clip, offset))
        if actual_durations and clip.number in actual_durations:
            offset += actual_durations[clip.number]
        else:
            offset += clip.cut_duration
    return _resolve_overlaps(cues)


def _resolve_overlaps(cues: List[Cue]) -> List[Cue]:
    """Stop a cue running into the next one.

    Padding a very short line up to MIN_CUE_SECONDS can push its end past where
    the following line starts, and two subtitles on screen at once reads as a
    bug. The earlier cue yields.
    """
    fixed: List[Cue] = []
    for index, cue in enumerate(cues):
        end = cue.end
        if index + 1 < len(cues):
            end = min(end, cues[index + 1].start - 0.02)
        if end <= cue.start:
            end = cue.start + 0.25          # keep it visible, however briefly
        fixed.append(Cue(cue.start, end, cue.speaker, cue.text))
    return fixed


def write_srt(cues: List[Cue], path: Path, with_speaker: bool = True) -> Optional[Path]:
    if not cues:
        return None
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    blocks = [cue.as_srt_block(index, with_speaker)
              for index, cue in enumerate(cues, start=1)]
    # UTF-8 with BOM: Windows players guess the encoding otherwise and Urdu
    # comes out as mojibake.
    path.write_text("\n".join(blocks), encoding="utf-8-sig")
    log.info("Wrote %d captions to %s", len(cues), path)
    return path
