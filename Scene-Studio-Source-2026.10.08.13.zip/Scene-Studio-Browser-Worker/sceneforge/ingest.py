"""Scan a folder of generated clips and pair each one with its script scene."""
from __future__ import annotations

import re
from pathlib import Path
from typing import List

from .config import Config
from .logging_setup import get
from .models import Clip, Episode, Flag, MediaInfo
from .probe import probe
from .script_parser import find_script, parse_script

log = get("ingest")

VIDEO_SUFFIXES = {".mp4", ".mov", ".mkv", ".webm", ".m4v"}

# A repeated download lands as "name (1).mp4"; that suffix is not part of the name
_TAKE = re.compile(r"\s*\((\d+)\)\s*$")
# Preferred: the number leads the filename -- "12._slug", "12_slug", "12 - slug"
_LEADING = re.compile(r"^(\d{1,4})\s*[._\-\s]+\s*(.*)$")
# Fallback: the number is embedded -- "CLIP_003", "scene-07-take2"
_EMBEDDED = re.compile(r"^\D*?(\d{1,4})\D*(.*)$")


def _parse_name(stem: str):
    """Pull (scene number, take, slug) out of a filename.

    Naming is not consistent between batches, let alone between generators. A
    leading number is taken as authoritative; failing that the first number
    anywhere is used, which is what makes "CLIP_003.mp4" land in the right
    place instead of being dumped at the end of the episode.
    """
    take = 0
    match = _TAKE.search(stem)
    if match:
        take = int(match.group(1))
        stem = stem[: match.start()]

    match = _LEADING.match(stem)
    if match:
        return int(match.group(1)), take, match.group(2).strip()

    match = _EMBEDDED.match(stem)
    if match:
        # Deliberately not falling back to the whole stem here. For "76" or
        # "CLIP_003" there is no description, and pretending the filename is one
        # gives every clip a unique "setting" -- which would make every single
        # cut look like a scene change when no script is available.
        return int(match.group(1)), take, match.group(2).strip(" ._-")

    return None, take, stem.strip()


def _flag_duplicate_numbers(clips: List[Clip]) -> None:
    """Mark every clip whose number another file also claims.

    Nothing is dropped: a repeated download is usually a re-generation, and
    which take is the good one is a judgement for the editor, not the importer.
    """
    seen: dict = {}
    for clip in clips:
        seen.setdefault(clip.number, []).append(clip)
    for group in seen.values():
        if len(group) > 1:
            for clip in group:
                clip.flags.add(Flag.DUPLICATE_NUMBER)


SCRIPT_COVERAGE = 0.5      # a script must name at least this share of the numbered clips


def _is_this_episodes_script(clips: List[Clip]) -> bool:
    """True when the script's scene numbers cover most of the numbered clips.
    A real script names nearly every clip; a stray numbered list names a
    few or none."""
    numbered = [c for c in clips if c.number < 10_000]
    if not numbered:
        return True
    matched = sum(1 for c in numbered if c.scene is not None)
    return matched >= max(1, int(SCRIPT_COVERAGE * len(numbered) + 0.999))


def scan(source_dir: Path, config: Config | None = None, do_probe: bool = True) -> Episode:
    """Build an Episode from a folder of clips plus its script file."""
    config = config or Config()
    source_dir = Path(source_dir)
    if not source_dir.is_dir():
        raise NotADirectoryError(str(source_dir))

    script_path = find_script(source_dir)
    scenes = parse_script(script_path) if script_path else {}
    if script_path is not None and not scenes:
        script_path = None                  # a text file, not a script: plan from the audio

    files = [p for p in source_dir.iterdir() if p.suffix.lower() in VIDEO_SUFFIXES]

    clips: List[Clip] = []
    unnumbered = 0
    for path in sorted(files):
        number, take, slug = _parse_name(path.stem)
        if number is None:
            unnumbered += 1
            number = 10_000 + unnumbered
        clip = Clip(number=number, path=path, slug=slug, take=take)

        if do_probe:
            clip.media = probe(path) or MediaInfo()
            if clip.media.duration <= 0:
                clip.flags.add(Flag.UNREADABLE)
            elif not clip.media.has_audio:
                clip.flags.add(Flag.NO_AUDIO_TRACK)

        scene = scenes.get(number)
        # A clip the script does not mention is worth a look. A folder with no
        # script at all is a different situation, and one flag on every clip
        # would only bury the flags that matter.
        if scene is None and script_path is not None:
            clip.flags.add(Flag.NO_SCENE_MATCH)
        clip.scene = scene

        clips.append(clip)

    clips.sort(key=lambda c: (c.number, c.take))
    if script_path is not None and not _is_this_episodes_script(clips):
        # Numbered entries, but not this episode's: a prompt list, a failed-
        # prompts list, another episode's script. Planning from it would
        # call every clip unscripted and keep it whole. The audio is the
        # script instead; nothing is flagged for a file that was never one.
        log.info("Ignoring %s as the script: its numbers match %d of %d clips",
                 script_path.name, sum(1 for c in clips if c.scene is not None), len(clips))
        script_path = None
        for clip in clips:
            clip.scene = None
            clip.flags.discard(Flag.NO_SCENE_MATCH)
    _flag_duplicate_numbers(clips)

    episode = Episode(
        name=source_dir.name,
        source_dir=source_dir,
        clips=clips,
        script_path=script_path,
    )
    _flag_duration_outliers(episode)
    return episode


def _flag_duration_outliers(episode: Episode) -> None:
    """Generated clips are normally a fixed length; anything off that is suspect."""
    durations = [c.media.duration for c in episode.clips if c.media and c.media.duration > 0]
    if len(durations) < 5:
        return
    ordered = sorted(durations)
    median = ordered[len(ordered) // 2]
    if median <= 0:
        return
    for clip in episode.clips:
        if not clip.media or clip.media.duration <= 0:
            continue
        if abs(clip.media.duration - median) / median > 0.10:
            clip.flags.add(Flag.DURATION_OUTLIER)


def missing_scene_numbers(episode: Episode) -> List[int]:
    """Scene numbers present in the script but with no matching clip file."""
    if not episode.script_path:
        return []
    scenes = parse_script(episode.script_path)
    have = {c.number for c in episode.clips}
    return sorted(n for n in scenes if n not in have)


def missing_clip_numbers(episode: Episode) -> List[int]:
    """Numbers absent from the run of clip files, whatever the script says.

    A folder numbered 1..160 with no 57 is a clip that never arrived from the
    generator, and the episode will simply skip it. The importer cannot know
    whether that is deliberate, so it is reported rather than flagged.
    """
    numbers = sorted({c.number for c in episode.clips if c.number < 10_000})
    if len(numbers) < 2:
        return []
    have = set(numbers)
    return [n for n in range(numbers[0], numbers[-1] + 1) if n not in have]
