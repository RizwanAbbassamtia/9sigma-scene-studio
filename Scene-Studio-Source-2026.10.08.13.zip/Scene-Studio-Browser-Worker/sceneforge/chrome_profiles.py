"""The person's own Chrome profiles, so an account can be opened in the
profile that is already signed in to it.

This module does exactly two things: it lists the profiles Chrome keeps
under the person's Local State file (read-only: the directory name, the
display name and the account address Chrome shows for each), and it starts
Chrome with one of them at a URL. It never reads cookies, passwords or any
other Chrome data, never signs in, and never touches the page once Chrome
is open; the person signs in to each profile once themselves, in Chrome.
The command line Chrome is started with carries the profile directory, a
new-window flag and the URL, and nothing else.
"""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple

from .logging_setup import get

log = get("chrome_profiles")

FLOW_URL = "https://flow.google.com"
CHROME_EXE = "chrome.exe"
APP_PATHS_KEY = r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"
NAME_MAX = 80


def _user_data_dir() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", "")) / "Google" / "Chrome" / "User Data"


def _candidate_paths() -> List[Path]:
    roots = [os.environ.get("PROGRAMFILES", r"C:\Program Files"),
             os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"),
             str(Path(os.environ.get("LOCALAPPDATA", "")))]
    return [Path(root) / "Google" / "Chrome" / "Application" / CHROME_EXE for root in roots if root]


def _registry_path() -> Optional[Path]:
    try:
        import winreg
    except ImportError:
        return None
    for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        try:
            with winreg.OpenKey(hive, APP_PATHS_KEY) as key:
                value, _ = winreg.QueryValueEx(key, "")
        except OSError:
            continue
        path = Path(str(value).strip().strip('"'))
        if path.is_file():
            return path
    return None


def find_chrome() -> Optional[str]:
    """Where chrome.exe is, or None when Chrome is not installed."""
    for path in _candidate_paths():
        if path.is_file():
            return str(path)
    found = _registry_path()
    return str(found) if found is not None else None


def _clean(text) -> str:
    return " ".join(str(text if text is not None else "").split())[:NAME_MAX]


def list_profiles() -> List[Tuple[str, str, str]]:
    """(directory, display name, account email) for every profile in
    Local State; an empty list when Chrome or the file is absent. The email
    is only what Chrome shows for the profile, and may be empty."""
    path = _user_data_dir() / "Local State"
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    cache = raw.get("profile", {}).get("info_cache", {}) if isinstance(raw, dict) else {}
    profiles = []
    for directory, info in (cache.items() if isinstance(cache, dict) else []):
        if not isinstance(info, dict):
            continue
        directory = _clean(directory)
        if not directory or "/" in directory or "\\" in directory or directory.startswith("-"):
            continue
        profiles.append((directory, _clean(info.get("name")) or directory, _clean(info.get("user_name"))))
    profiles.sort(key=lambda p: (p[0] != "Default", p[0].casefold()))
    return profiles


def profile_for_email(email: str, profiles=None) -> str:
    """The directory of the profile Chrome shows for this address, or ''."""
    wanted = _clean(email).casefold()
    if not wanted:
        return ""
    for directory, _, user_name in (list_profiles() if profiles is None else profiles):
        if user_name.casefold() == wanted:
            return directory
    return ""


def launch(profile_dir: str, url: str = FLOW_URL) -> Tuple[bool, str]:
    """Start Chrome with that profile at the URL, detached. (True, '') when
    it started; (False, reason) otherwise. Nothing is raised."""
    profile_dir = _clean(profile_dir)
    if not profile_dir:
        return False, "No Chrome profile is set for this account."
    if profile_dir.startswith("-") or "/" in profile_dir or "\\" in profile_dir:
        return False, "The Chrome profile name is not one Chrome would accept."
    chrome = find_chrome()
    if chrome is None:
        return False, "Chrome was not found on this PC."
    argv = [chrome, "--profile-directory={}".format(profile_dir), "--new-window", url]
    try:
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen(argv, close_fds=True, creationflags=flags)
    except OSError as exc:
        log.warning("Chrome did not start: %s", exc)
        return False, "Chrome did not start: {}".format(exc)
    return True, ""
