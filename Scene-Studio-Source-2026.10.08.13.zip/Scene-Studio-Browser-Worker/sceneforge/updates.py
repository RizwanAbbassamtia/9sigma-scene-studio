"""Update check and one-click install.

A small JSON file published at a fixed URL says what the newest build is:

    {
      "version": "9.02",
      "url": "https://.../Install-9SigmaAutomation.exe",
      "notes": "What changed, one or two lines.",
      "sha256": "…",            optional: the installer's digest
      "size": 346120957,        optional: its size in bytes
      "min_version": "9.00",    optional: oldest build that may take this update
      "built": "2026-09-09T11:07:00"
    }

The app fetches it after sign-in, compares the version with its own, and if
newer shows a banner. "Update now" downloads the installer to the user's temp
folder, checks its size and sha256 against the manifest when the manifest
carries them, launches it and quits, so the installer can replace the program
files. The installer is started in its automatic mode (--auto --open): it
waits for this app to finish closing, installs without a click and opens the
app again on the new version. The installer keeps exported videos and
settings and refreshes the shared logins, exactly as a manual reinstall does.

What "Update now" started is written to update-state.json (the version, the
manifest's checksum, where the installer is). At the next sign-in the app
reads it back: if it now IS that version the notice "Updated to …" is shown
once with what is new; if it is still the older build -- the installer was
closed, or the app was reopened while it waited -- the downloaded installer
is offered again and, when it still matches the checksum, not downloaded a
second time.

Everything network-bound runs off the GUI thread. A machine with no internet
simply sees no banner; the check never blocks sign-in or shows an error
unless the person asked for the check by hand.
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from PySide6.QtCore import QObject, QThread, Signal

from .logging_setup import get
from .product import PRODUCT
from .version import is_newer

log = get("updates")

VERSION = PRODUCT.version           # the running product's version, not always version.VERSION
INSTALLER_NAME = PRODUCT.installer_name
INSTALLER_ARGS = ["--auto", "--open"]   # no clicks; the app reopens when the installer is done
INSTALLER_MUTEX = PRODUCT.mutex     # held by a running installer (installer/setup_app.py)
STATE_NAME = "update-state.json"     # next to config.json: Later, and the update last started
CHECK_TIMEOUT = 8        # seconds; a slow check is a silent one
DOWNLOAD_TIMEOUT = 60


def _requests():
    """Imported late so a machine without the package still opens the app;
    tests replace this with a fake."""
    import requests
    return requests


@dataclass
class Release:
    version: str
    url: str
    notes: str = ""
    sha256: str = ""
    size: int = 0
    min_version: str = ""
    built: str = ""

    @property
    def is_newer(self) -> bool:
        return is_newer(self.version, VERSION)

    @property
    def is_compatible(self) -> bool:
        """False when the manifest says this build is too old to take the update."""
        return not self.min_version or not is_newer(self.min_version, VERSION)

    @property
    def is_offerable(self) -> bool:
        return self.is_newer and self.is_compatible


def parse_manifest(raw: dict) -> Release:
    size = raw.get("size") or 0
    try:
        size = int(size)
    except (TypeError, ValueError):
        size = 0
    return Release(version=str(raw["version"]),
                   url=str(raw["url"]),
                   notes=str(raw.get("notes", "")),
                   sha256=str(raw.get("sha256", "")).strip().lower(),
                   size=size,
                   min_version=str(raw.get("min_version", "")).strip(),
                   built=str(raw.get("built", "")))


_GITHUB_RAW = re.compile(r"^https://raw\.githubusercontent\.com/([^/]+)/([^/]+)/[^/]+/latest\.json$")


def manifest_sources(manifest_url: str) -> List[str]:
    """Every address the manifest can be read from, most direct first.

    The installed apps' logs showed why editors saw no notice: the raw
    GitHub file answered "503 Backend.max_conn reached" and, on some
    connections, did not resolve at all, and the check was made once. When
    the manifest lives in a GitHub repo two more copies are reachable on
    different hosts -- the same file attached to the latest release, and
    the releases API, which can describe the release on its own. Any one of
    them answering is enough.
    """
    sources = [manifest_url]
    match = _GITHUB_RAW.match(manifest_url or "")
    if match:
        owner, repo = match.groups()
        sources.append("https://github.com/{}/{}/releases/latest/download/latest.json".format(owner, repo))
        sources.append("https://api.github.com/repos/{}/{}/releases/latest".format(owner, repo))
    return sources


def _release_from_api(raw: dict) -> Release:
    """A Release read off the GitHub releases API when no manifest could be
    fetched: the tag is the version, the installer asset the url, the body
    the notes. Size comes from the asset; there is no sha256 to check
    against, and verify_download says so in the log."""
    tag = str(raw.get("tag_name", "")).lstrip("vV")
    assets = raw.get("assets") or []
    installer = next((a for a in assets if str(a.get("name", "")) == INSTALLER_NAME), None)
    if not tag or installer is None:
        raise ValueError("the latest release has no {}".format(INSTALLER_NAME))
    return Release(version=tag, url=str(installer.get("browser_download_url", "")),
                   notes=str(raw.get("body", "") or "").strip().splitlines()[0] if raw.get("body") else "",
                   size=int(installer.get("size") or 0), built=str(raw.get("published_at", "")))


def fetch_release_or_error(manifest_url: str, attempts: int = 2) -> Tuple[Optional[Release], str]:
    """Read the newest release from every reachable source. Returns
    (release, "") or (None, why), never raises.

    Every source is asked, and the newest version among the answers wins:
    right after a publish the raw file's CDN copy lags a few minutes
    behind the release asset, and an editor opening the app in that window
    would otherwise be told there is nothing new. Each source is tried up
    to `attempts` times, so a single 503 or a dropped packet is not a
    missed update. A manifest (with its sha256) is preferred over the
    releases API's description of the same version."""
    if not manifest_url:
        return None, "no update address is configured"
    reasons = []
    found: List[Tuple[Release, str]] = []

    def ask(source: str) -> None:
        for attempt in range(1, attempts + 1):
            try:
                response = _requests().get(source, timeout=CHECK_TIMEOUT,
                                           headers={"Cache-Control": "no-cache", "Accept": "application/json",
                                                    "User-Agent": PRODUCT.user_agent})
                response.raise_for_status()
                body = response.json()
                release = _release_from_api(body) if "tag_name" in body and "version" not in body else parse_manifest(body)
                found.append((release, source))
                return
            except Exception as exc:                   # noqa: BLE001 - deliberately broad
                reason = str(exc) or exc.__class__.__name__
                log.info("Update check: %s did not answer (try %d): %s", source.split("/")[2], attempt, reason[:160])
                reasons.append(reason)
                if _is_final(exc) or attempt >= attempts:
                    return
                time.sleep(1.0)

    # The two copies of the manifest are always read (the raw file's CDN
    # copy can lag the attached one for a few minutes). The releases API
    # is asked only when neither answered: it carries no checksum, and
    # unauthenticated calls to it are rationed per address -- every editor
    # asking it hourly is how "403 rate limit exceeded" got into the logs.
    sources = manifest_sources(manifest_url)
    for source in sources:
        if not _is_api(source):
            ask(source)
    if not found:
        for source in sources:
            if _is_api(source):
                ask(source)
    if not found:
        return None, reasons[0] if reasons else "no source answered"
    best, where = found[0]
    for release, source in found[1:]:
        if is_newer(release.version, best.version) or (release.version == best.version and release.sha256 and not best.sha256):
            best, where = release, source
    log.info("Update check: running %s, published %s%s (from %s; %d source(s) answered)", VERSION, best.version,
             "" if best.is_compatible else " (needs {} or newer first)".format(best.min_version),
             where.split("/")[2], len(found))
    return best, ""


def _is_api(source: str) -> bool:
    return source.startswith("https://api.github.com/")


def _is_final(exc: BaseException) -> bool:
    """True for an answer that will not change in a second: a release
    without the file (404) or a rationed address (403). Everything else --
    a 5xx, a timeout, a reset -- is worth one more try."""
    status = getattr(getattr(exc, "response", None), "status_code", None)
    if status is None:
        match = re.match(r"^(?:HTTP )?(\d{3})\b", str(exc))
        status = int(match.group(1)) if match else None
    return status in (403, 404)


def fetch_release(manifest_url: str) -> Optional[Release]:
    """Read latest.json. Returns None on any failure, logged but never raised."""
    return fetch_release_or_error(manifest_url)[0]


def download_dir() -> Path:
    path = Path(tempfile.gettempdir()) / (PRODUCT.folder + "-update")
    path.mkdir(parents=True, exist_ok=True)
    return path


# ------------------------------------------------------------ "Later" memory
def state_path(directory: Optional[Path] = None) -> Path:
    return Path(directory or Path.cwd()) / STATE_NAME


def _read_state(directory: Optional[Path] = None) -> dict:
    try:
        raw = json.loads(state_path(directory).read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_state(state: dict, directory: Optional[Path] = None, what: str = "the update state") -> None:
    try:
        state_path(directory).write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    except OSError as exc:
        log.warning("Could not write %s: %s", what, exc)


def read_deferred(directory: Optional[Path] = None) -> str:
    """The version the person pressed Later on, or "" if none was recorded."""
    try:
        return str(_read_state(directory).get("later_version", "")).strip()
    except AttributeError:
        return ""


def write_deferred(version: str, directory: Optional[Path] = None) -> None:
    state = _read_state(directory)
    state.update(later_version=version, later_at=datetime.now().isoformat(timespec="seconds"))
    _write_state(state, directory, "the deferred update")


def write_pending(release: Release, installer: str, directory: Optional[Path] = None) -> None:
    """Remember the update "Update now" just started, so the next launch
    can tell whether it happened."""
    state = _read_state(directory)
    state["pending"] = {"version": release.version, "url": release.url, "notes": release.notes,
                        "sha256": release.sha256, "size": release.size, "min_version": release.min_version,
                        "built": release.built, "installer": str(installer),
                        "started_at": datetime.now().isoformat(timespec="seconds")}
    _write_state(state, directory, "the pending update")


def read_pending(directory: Optional[Path] = None) -> Optional[Tuple[Release, str]]:
    """(release, installer path) of the update last started, or None."""
    raw = _read_state(directory).get("pending")
    if not isinstance(raw, dict) or not raw.get("version"):
        return None
    try:
        return parse_manifest(raw), str(raw.get("installer", ""))
    except (KeyError, TypeError, ValueError):
        return None


def clear_pending(directory: Optional[Path] = None) -> None:
    state = _read_state(directory)
    if state.pop("pending", None) is not None:
        _write_state(state, directory, "the pending update")


# ----------------------------------------------------------------- threads
class UpdateCheck(QThread):
    """Fetch the manifest in the background.

    `checked` always fires with the Release read (or None if the check could
    not be made); `found` fires only when that release is newer than this one
    and this build is allowed to take it; `unreachable` fires with the reason
    when the manifest could not be read.
    """
    checked = Signal(object)        # Release or None
    found = Signal(object)          # Release
    unreachable = Signal(str)       # why the manifest could not be read

    def __init__(self, manifest_url: str, parent: Optional[QObject] = None):
        super().__init__(parent)
        self.manifest_url = manifest_url

    def run(self):
        release, error = fetch_release_or_error(self.manifest_url)
        self.checked.emit(release)
        if release is None:
            self.unreachable.emit(error)
        elif release.is_offerable:
            self.found.emit(release)


def verify_download(path: Path, release: Release) -> str:
    """"" when the file matches what the manifest promised, else what is wrong.

    A manifest without sha256 cannot be checked; that is logged as "not
    verified" rather than refused, so older manifests keep working.
    """
    actual_size = path.stat().st_size
    if release.size and actual_size != release.size:
        return "the downloaded file is {} bytes but the update should be {}".format(actual_size, release.size)
    if not release.sha256:
        log.warning("Update %s not verified: the manifest carries no sha256", release.version)
        return ""
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != release.sha256:
        return "the downloaded file does not match the published checksum"
    log.info("Update %s verified: %d bytes, sha256 matches", release.version, actual_size)
    return ""


class Downloader(QThread):
    """Stream the installer to disk, reporting progress in bytes, then verify it."""
    progress = Signal(int, int)     # done, total (total may be 0 if unknown)
    finished_ok = Signal(str)       # path of the downloaded installer
    failed = Signal(str)

    def __init__(self, release: Release, parent: Optional[QObject] = None,
                 target_dir: Optional[Path] = None):
        super().__init__(parent)
        self.release = release
        self.target_dir = target_dir

    def run(self):
        target = (self.target_dir or download_dir()) / INSTALLER_NAME
        partial = target.with_suffix(".part")
        try:
            if self.reusable(target):
                # The same installer was fetched and checked before (the
                # app was reopened while it waited); 346 MB are not asked
                # for twice. A file that no longer matches is replaced.
                size = target.stat().st_size
                log.info("Update %s: the verified installer is already at %s; not downloading it again",
                         self.release.version, target)
                self.progress.emit(size, size)
                self.finished_ok.emit(str(target))
                return
            with _requests().get(self.release.url, stream=True,
                                 timeout=DOWNLOAD_TIMEOUT) as response:
                response.raise_for_status()
                # Google Drive answers a big-file link with an HTML "cannot
                # scan for viruses" page unless the URL carries confirm=t.
                # Catch that here rather than saving a web page as an exe.
                kind = response.headers.get("Content-Type", "")
                if "text/html" in kind:
                    raise IOError("the update link returned a web page, not the "
                                  "installer; check the url in latest.json")
                total = int(response.headers.get("Content-Length") or 0) or self.release.size
                done = 0
                with open(partial, "wb") as handle:
                    for chunk in response.iter_content(chunk_size=256 * 1024):
                        if not chunk:
                            continue
                        handle.write(chunk)
                        done += len(chunk)
                        self.progress.emit(done, total)
            if total and done < total:
                raise IOError("download ended early ({} of {} bytes)".format(done, total))
            if done < 1_000_000 and not self.release.size:
                raise IOError("downloaded file is far too small to be the installer")
            problem = verify_download(partial, self.release)
            if problem:
                raise IOError(problem)
            if target.exists():
                target.unlink()
            partial.rename(target)
            log.info("Downloaded update %s to %s", self.release.version, target)
            self.finished_ok.emit(str(target))
        except Exception as exc:                   # noqa: BLE001
            log.warning("Update download failed: %s", exc)
            try:
                if partial.exists():
                    partial.unlink()
            except OSError:
                pass
            self.failed.emit(str(exc))


    def reusable(self, target: Path) -> bool:
        """True when `target` is the installer the manifest describes: the
        manifest carries a sha256 and the file matches it. Without a
        checksum nothing is reused -- size alone does not say enough."""
        if not self.release.sha256 or not target.is_file():
            return False
        try:
            return verify_download(target, self.release) == ""
        except OSError:
            return False


def installer_running() -> bool:
    """True while an installer holds its single-instance name. Seen today:
    the app was reopened while the installer waited for it to close, and
    would have offered the same update again -- a second installer against
    the same folders. Windows only; False whenever it cannot be told."""
    if not sys.platform.startswith("win"):
        return False
    try:
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.OpenMutexW.restype = ctypes.c_void_p
        handle = kernel32.OpenMutexW(0x00100000, False, INSTALLER_MUTEX)      # SYNCHRONIZE
        if not handle:
            return False
        kernel32.CloseHandle(ctypes.c_void_p(handle))
        return True
    except Exception:                                   # noqa: BLE001
        return False


def launch_installer(path: str) -> bool:
    """Start the downloaded installer detached from this process, in its
    automatic mode: it waits for this app to close, installs without a
    click and opens the app again (`INSTALLER_ARGS`).

    Until 9.13 the installer was started plain: it opened on its
    requirements page and waited for a click on Install. Editors who
    reopened the app in the meantime found the old version with the notice
    again (that is how one editor downloaded 9.13 twice in eight minutes),
    and a closed installer window meant no update at all."""
    try:
        creation = 0
        if sys.platform.startswith("win"):
            creation = (getattr(subprocess, "DETACHED_PROCESS", 0)
                        | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        subprocess.Popen([path] + INSTALLER_ARGS, close_fds=True, creationflags=creation)
        log.info("Launched installer %s %s", path, " ".join(INSTALLER_ARGS))
        return True
    except OSError as exc:
        log.error("Could not launch installer: %s", exc)
        return False
