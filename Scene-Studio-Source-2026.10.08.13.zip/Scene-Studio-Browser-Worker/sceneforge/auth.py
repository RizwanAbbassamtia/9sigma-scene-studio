"""Local user accounts for the tool (either product; each install has its own users.json).

What this is, plainly: a gate on who opens the application. The account file
sits on the same machine as the clips, so somebody with the laptop and the will
could get past it. It is worth having for controlling access, stamping work
with who did it, and putting the company's name in front of the editor -- it is
not a defence against a determined person holding the hardware.

What it does do properly: passwords are never stored, only PBKDF2-HMAC-SHA256
hashes with a per-user salt, so the file cannot be read back into a usable
password even if it is copied.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import string
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from .logging_setup import get

log = get("auth")

USERS_FILE = "users.json"
REMEMBER_FILE = "remembered.json"          # "keep me signed in": the session
SAVED_LOGIN_FILE = "saved-login.json"      # "remember my login details": the fields
FORMAT_VERSION = 1

# PBKDF2 cost. High enough that guessing the file offline is slow, low enough
# that a login on a modest laptop still feels instant.
ITERATIONS = 240_000
SALT_BYTES = 16
KEY_BYTES = 32

# Password characters an editor has to read off a note and type correctly, so
# no 0/O or 1/l/I. Length carries the strength instead of exotic symbols.
_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
GENERATED_LENGTH = 14

MAX_ATTEMPTS = 5


class AuthError(RuntimeError):
    pass


@dataclass
class User:
    username: str
    display_name: str
    salt: str                    # base64
    hash: str                    # base64
    iterations: int = ITERATIONS
    created: str = ""
    last_login: str = ""
    role: str = "editor"

    def to_dict(self) -> dict:
        return {
            "username": self.username,
            "display_name": self.display_name,
            "salt": self.salt,
            "hash": self.hash,
            "iterations": self.iterations,
            "created": self.created,
            "last_login": self.last_login,
            "role": self.role,
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "User":
        return cls(
            username=raw["username"],
            display_name=raw.get("display_name", raw["username"]),
            salt=raw["salt"],
            hash=raw["hash"],
            iterations=int(raw.get("iterations", ITERATIONS)),
            created=raw.get("created", ""),
            last_login=raw.get("last_login", ""),
            role=raw.get("role", "editor"),
        )


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _derive(password: str, salt: bytes, iterations: int) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt,
                               iterations, dklen=KEY_BYTES)


def generate_password(length: int = GENERATED_LENGTH) -> str:
    """A password strong enough to be worth using and plain enough to type."""
    return "".join(secrets.choice(_ALPHABET) for _ in range(length))


class UserStore:
    """The accounts on this machine, held in one JSON file."""

    def __init__(self, directory: Path):
        self.path = Path(directory) / USERS_FILE
        self.users: Dict[str, User] = {}
        self.load()

    # ------------------------------------------------------------ persistence
    def load(self) -> None:
        self.users = {}
        if not self.path.exists():
            return
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            log.error("Could not read %s: %s", self.path, exc)
            return
        for entry in raw.get("users", []):
            try:
                user = User.from_dict(entry)
            except KeyError:
                continue
            self.users[user.username.lower()] = user

    def save(self) -> None:
        payload = {
            "version": FORMAT_VERSION,
            "updated": _now(),
            "users": [u.to_dict() for u in self.users.values()],
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # ------------------------------------------------------------- management
    @property
    def is_empty(self) -> bool:
        return not self.users

    def get(self, username: str) -> Optional[User]:
        return self.users.get(username.strip().lower())

    def list_users(self) -> List[User]:
        return sorted(self.users.values(), key=lambda u: u.username.lower())

    def add(self, username: str, password: Optional[str] = None,
            display_name: str = "", role: str = "editor") -> tuple:
        """Create a user. Returns (User, password) so it can be handed over once."""
        username = username.strip()
        if not username:
            raise AuthError("A username is required.")
        if self.get(username):
            raise AuthError("That username already exists: {}".format(username))

        password = password or generate_password()
        salt = os.urandom(SALT_BYTES)
        user = User(
            username=username,
            display_name=display_name.strip() or username,
            salt=base64.b64encode(salt).decode("ascii"),
            hash=base64.b64encode(_derive(password, salt, ITERATIONS)).decode("ascii"),
            iterations=ITERATIONS,
            created=_now(),
            role=role,
        )
        self.users[username.lower()] = user
        self.save()
        log.info("Created user %s (%s)", username, role)
        return user, password

    def remove(self, username: str) -> bool:
        key = username.strip().lower()
        if key not in self.users:
            return False
        del self.users[key]
        self.save()
        log.info("Removed user %s", username)
        return True

    def set_password(self, username: str, password: str) -> None:
        user = self.get(username)
        if user is None:
            raise AuthError("No such user: {}".format(username))
        salt = os.urandom(SALT_BYTES)
        user.salt = base64.b64encode(salt).decode("ascii")
        user.hash = base64.b64encode(_derive(password, salt, ITERATIONS)).decode("ascii")
        user.iterations = ITERATIONS
        self.save()
        log.info("Password changed for %s", username)

    # ----------------------------------------------------------------- verify
    def verify(self, username: str, password: str) -> Optional[User]:
        """Return the user on a correct password, otherwise None.

        Compared with compare_digest so the time taken does not leak how much
        of the hash matched.
        """
        user = self.get(username)
        if user is None:
            # Spend the same effort as a real check so a missing username is
            # not distinguishable from a wrong password by timing alone.
            _derive(password, b"\x00" * SALT_BYTES, ITERATIONS)
            return None
        try:
            salt = base64.b64decode(user.salt)
            expected = base64.b64decode(user.hash)
        except (ValueError, TypeError):
            return None
        candidate = _derive(password, salt, user.iterations)
        if not hmac.compare_digest(candidate, expected):
            return None
        user.last_login = _now()
        self.save()
        return user

    # -------------------------------------------------------- stay signed in
    # "Keep me signed in" writes a small file beside users.json naming the
    # account and a random token. Its presence is the proof, the way a browser
    # cookie is: whoever can read this folder can already read users.json, so
    # there is nothing stronger to protect it with. Signing out deletes it.
    @property
    def remember_path(self) -> Path:
        return self.path.parent / REMEMBER_FILE

    def remember(self, user: User) -> None:
        payload = {"username": user.username, "token": secrets.token_urlsafe(24),
                   "since": _now()}
        self.remember_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        log.info("Staying signed in as %s on this machine", user.username)

    def forget(self) -> None:
        try:
            self.remember_path.unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            log.warning("Could not clear the remembered sign-in: %s", exc)

    def remembered(self) -> Optional[User]:
        """The account to sign in as without asking, if one was kept."""
        path = self.remember_path
        if not path.exists():
            return None
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        user = self.get(str(raw.get("username", "")))
        if user is None or not raw.get("token"):
            self.forget()                    # account gone: the file is stale
            return None
        return user

    # ------------------------------------------------- remembered details
    # Two different things, kept apart on purpose:
    #   remember()/forget()      keep me signed in -- an authenticated session
    #                            that survives a restart; signing out ends it
    #   save_login()/forget_login()  remember my login details -- the username
    #                            and, sealed to this Windows account, the
    #                            password, so the fields are filled in next
    #                            time; signing out leaves it alone
    # The password is stored only through DPAPI (sceneforge.seal); where
    # that is unavailable only the username is kept and saved_login() says so.
    @property
    def saved_login_path(self) -> Path:
        return self.path.parent / SAVED_LOGIN_FILE

    def save_login(self, username: str, password: str = "") -> bool:
        """Keep the details for next time. Returns True when the password
        could be sealed; False means only the username was kept."""
        from . import seal
        payload = {"username": username.strip(), "password": "", "since": _now()}
        sealed_ok = False
        if password and seal.available():
            try:
                payload["password"] = seal.seal(password)
                sealed_ok = True
            except OSError as exc:
                log.warning("The password could not be sealed; only the username is kept (%s)", exc)
        try:
            self.saved_login_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except OSError as exc:
            log.warning("Could not save the login details: %s", exc)
            return False
        log.info("Login details saved for %s (%s)", payload["username"],
                 "username and password" if sealed_ok else "username only")
        return sealed_ok

    def forget_login(self) -> None:
        try:
            self.saved_login_path.unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            log.warning("Could not remove the saved login details: %s", exc)

    def saved_login(self) -> Optional[dict]:
        """{"username", "password"} kept on this machine, or None. The
        password is "" when none was sealed or it will no longer open."""
        from . import seal
        path = self.saved_login_path
        if not path.exists():
            return None
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        username = str(raw.get("username", "")).strip()
        if not username or self.get(username) is None:
            self.forget_login()              # the account is gone
            return None
        return {"username": username, "password": seal.unseal(str(raw.get("password", "")))}
