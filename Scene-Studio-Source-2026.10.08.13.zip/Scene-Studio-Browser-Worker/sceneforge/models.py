"""Core data model for SceneForge."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import List, Optional, Set


class ReviewState(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    RETAKE = "retake"


class Flag(str, Enum):
    """Reasons a clip is worth a human look, most severe first."""

    SCRIPTED_BUT_SILENT = "scripted_but_silent"      # says: in script, no speech heard
    SPEECH_NOT_SCRIPTED = "speech_not_scripted"      # no says in script, speech heard
    NO_AUDIO_TRACK = "no_audio_track"
    SPEECH_TRUNCATED = "speech_truncated"            # speech runs to the very end of the clip
    SPEECH_MUCH_SHORTER = "speech_much_shorter"      # far less speech than the script implies
    MOTION_ANOMALY = "motion_anomaly"                # optical-flow reversal / jump
    DURATION_OUTLIER = "duration_outlier"
    NO_SCENE_MATCH = "no_scene_match"                # clip number missing from the script
    DUPLICATE_NUMBER = "duplicate_number"            # more than one file claims this number
    UNREADABLE = "unreadable"
    JOIN_RISK = "join_risk"                          # the cut into this clip may jump or clip a word
    REPEATED_SPEECH = "repeated_speech"              # a word may be said twice by mistake; a person decides


# The join the editor can force before a clip, overriding the join style's
# own rule at that one point. None means "let the rule decide".
JOIN_CHOICES = ("cut", "dissolve", "dip")


@dataclass(frozen=True)
class DialogueLine:
    speaker: str
    text: str

    @property
    def char_count(self) -> int:
        return len(self.text.strip())


@dataclass
class Scene:
    """One numbered entry parsed out of the episode script .txt."""

    number: int
    setting: str
    has_dialogue: bool
    dialogue: List[DialogueLine] = field(default_factory=list)
    ambient: str = ""
    music: str = ""
    raw: str = ""

    @property
    def dialogue_chars(self) -> int:
        return sum(d.char_count for d in self.dialogue)

    @property
    def speakers(self) -> List[str]:
        seen: List[str] = []
        for d in self.dialogue:
            if d.speaker not in seen:
                seen.append(d.speaker)
        return seen

    def expected_speech_seconds(self, chars_per_second: float = 12.0) -> float:
        """Rough estimate of how long the scripted dialogue should take to speak.

        Only a heuristic for flagging outliers -- never used to make a cut.
        """
        if not self.has_dialogue or chars_per_second <= 0:
            return 0.0
        return self.dialogue_chars / chars_per_second


@dataclass
class MediaInfo:
    duration: float = 0.0
    width: int = 0
    height: int = 0
    fps: float = 0.0
    frame_count: int = 0
    video_codec: str = ""
    has_audio: bool = False
    audio_channels: int = 0
    audio_sample_rate: int = 0

    @property
    def resolution(self) -> str:
        return "{}x{}".format(self.width, self.height)


@dataclass(frozen=True)
class SpeechSpan:
    """A stretch of detected speech, in seconds from the clip start."""

    start: float
    end: float

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


@dataclass
class Clip:
    number: int
    path: Path
    slug: str
    # Which copy of a repeated number this is. Generators re-download as
    # "name (1).mp4", so several files can claim one scene; the take keeps
    # their order stable instead of leaving it to the filesystem.
    take: int = 0
    media: Optional[MediaInfo] = None
    scene: Optional[Scene] = None
    speech: List[SpeechSpan] = field(default_factory=list)
    # The same detector run at a lower threshold: everything that might be a
    # word, including the quiet edges the main pass leaves off. Used only to
    # keep a cut from landing on one; never to decide where speech is.
    speech_soft: List[SpeechSpan] = field(default_factory=list)
    flags: Set[Flag] = field(default_factory=set)
    state: ReviewState = ReviewState.PENDING
    keep: List[SpeechSpan] = field(default_factory=list)
    # Where the whole mix is quiet: no voice, no music, no ambience. Only
    # these gaps are safe to cut out of the middle of a scene.
    silence: List[SpeechSpan] = field(default_factory=list)
    # Share of the non-speech time that carries sound. Near 1.0 means a music
    # or ambient bed runs throughout.
    music_ratio: float = 1.0
    motion_score: float = 0.0
    # Mean frame difference per half second, first to last (motion.py), so
    # the cut rule knows where the action stops, not only whether there is
    # any. Empty means it could not be measured.
    motion_profile: List[float] = field(default_factory=list)
    # Runs of a repeated sound in the dialogue (repetition.py), as dicts;
    # the cut rule decides which are removed.
    repetitions: List[dict] = field(default_factory=list)
    # The cut log: every automatic removal on this clip, with its reason and
    # confidence. Rebuilt by each analysis, never accumulated.
    cuts: List[dict] = field(default_factory=list)
    note: str = ""
    # The editor's own say over the transition into and out of this clip.
    # None defers to the scene rule; True forces a fade, False forbids one.
    fade_in: Optional[bool] = None
    fade_out: Optional[bool] = None
    # The join into this clip, when the editor has chosen one by hand: "cut",
    # "dissolve" or "dip" (see JOIN_CHOICES). None defers to the join style.
    join: Optional[str] = None
    # Exported with a silent audio track rather than none, so the stream
    # layout stays identical to every other piece.
    muted: bool = False
    # Why the join into this clip was flagged; set alongside Flag.JOIN_RISK
    # and recomputed after every edit, never saved.
    join_warning: str = ""
    # True when the following clip is a different setting, i.e. this clip is the
    # last of its scene. Drives both the longer tail margin and where a
    # transition is placed.
    ends_scene: bool = False
    # 1-based position of this clip's scene within the episode, so the window
    # can say "scene 12 of 54" rather than only a clip number.
    scene_index: int = 0

    @property
    def speech_seconds(self) -> float:
        return sum(s.duration for s in self.speech)

    @property
    def has_speech(self) -> bool:
        return bool(self.speech)

    @property
    def cut_start(self) -> Optional[float]:
        return self.keep[0].start if self.keep else None

    @property
    def cut_end(self) -> Optional[float]:
        return self.keep[-1].end if self.keep else None

    @property
    def cut_duration(self) -> float:
        if not self.keep:
            return self.media.duration if self.media else 0.0
        return sum(k.duration for k in self.keep)

    @property
    def is_jump_cut(self) -> bool:
        """True when the plan drops material from the middle of the clip."""
        return len(self.keep) > 1

    # -- segments -----------------------------------------------------------
    # A clip plays as an ordered list of segments of its one source file.
    # `keep` has always been that list; these give it the editing vocabulary
    # the timeline uses. Every operation is non-destructive: only the in and
    # out points change, the file never does. Cutting material out of the
    # middle leaves a gap that the export closes by itself, since each
    # segment is one piece of the concatenation (a ripple edit).

    @property
    def segments(self) -> List[SpeechSpan]:
        return self.keep

    def segment_at(self, seconds: float) -> Optional[int]:
        """Index of the segment containing this source time, if any."""
        for index, span in enumerate(self.keep):
            if span.start <= seconds <= span.end:
                return index
        return None

    def split_segment(self, index: int, at: float, minimum: float) -> bool:
        """Cut one segment into two at a source time. Refused when either
        half would be shorter than `minimum`."""
        if not 0 <= index < len(self.keep):
            return False
        span = self.keep[index]
        if at - span.start < minimum or span.end - at < minimum:
            return False
        self.keep[index:index + 1] = [SpeechSpan(span.start, at), SpeechSpan(at, span.end)]
        return True

    def trim_segment_before(self, index: int, at: float, minimum: float) -> bool:
        """Drop the part of a segment before a source time (remove left)."""
        if not 0 <= index < len(self.keep):
            return False
        span = self.keep[index]
        if at <= span.start or span.end - at < minimum:
            return False
        self.keep[index] = SpeechSpan(at, span.end)
        return True

    def trim_segment_after(self, index: int, at: float, minimum: float) -> bool:
        """Drop the part of a segment after a source time (remove right)."""
        if not 0 <= index < len(self.keep):
            return False
        span = self.keep[index]
        if at >= span.end or at - span.start < minimum:
            return False
        self.keep[index] = SpeechSpan(span.start, at)
        return True

    def delete_segment(self, index: int) -> bool:
        """Remove one segment. The last one cannot go: a clip with no
        segments would count as whole, and rejecting is the way to drop a
        clip entirely."""
        if len(self.keep) <= 1 or not 0 <= index < len(self.keep):
            return False
        del self.keep[index]
        return True

    @property
    def saved_seconds(self) -> float:
        source = self.media.duration if self.media else 0.0
        return max(0.0, source - self.cut_duration)

    @property
    def severity(self) -> int:
        """Higher sorts earlier in the review queue."""
        weights = {
            Flag.UNREADABLE: 100,
            Flag.SCRIPTED_BUT_SILENT: 90,
            Flag.NO_AUDIO_TRACK: 80,
            Flag.SPEECH_NOT_SCRIPTED: 60,
            Flag.SPEECH_TRUNCATED: 50,
            Flag.MOTION_ANOMALY: 40,
            Flag.SPEECH_MUCH_SHORTER: 30,
            Flag.DURATION_OUTLIER: 20,
            Flag.NO_SCENE_MATCH: 10,
            Flag.DUPLICATE_NUMBER: 70,
            Flag.REPEATED_SPEECH: 45,
        }
        return sum(weights.get(f, 5) for f in self.flags)


@dataclass
class Episode:
    name: str
    source_dir: Path
    clips: List[Clip] = field(default_factory=list)
    script_path: Optional[Path] = None
    # Speaking rate measured from this episode's own audio. Languages differ
    # widely -- Urdu in Arabic script runs at roughly twice the characters per
    # second of English -- so a fixed number would misjudge every project but
    # the one it was taken from. 0 means not enough data; the config seed is
    # used instead.
    measured_chars_per_second: float = 0.0

    @property
    def approved(self) -> List[Clip]:
        return [c for c in self.clips if c.state == ReviewState.APPROVED]

    @property
    def flagged(self) -> List[Clip]:
        return sorted(
            [c for c in self.clips if c.flags],
            key=lambda c: (-c.severity, c.number),
        )

    @property
    def source_seconds(self) -> float:
        return sum(c.media.duration for c in self.clips if c.media)

    @property
    def planned_seconds(self) -> float:
        return sum(c.cut_duration for c in self.clips if c.state != ReviewState.REJECTED)
