"""The team sheet: one Google Sheet, on the owner's shared Google Drive, that
every laptop reports to. Two jobs, one small web app in front of the sheet
(tools/team-sheet/Code.gs):

  Production  one row per finished export -- when, who, on which laptop,
              the title, how many clips went in, their total length, and
              the length of the video that came out. The owner sees the
              whole team's output in one place instead of collecting logs.
  Users       which laptop each editor account is locked to. The first
              laptop an editor signs in on claims the account; any other
              laptop is refused. The owner frees an account by clearing
              its Laptop ID cell (or blocks it by writing "blocked" in
              Status). Admin accounts are never locked.

The sheet's address and its shared secret come from team-sheet.json in the
app folder, shipped by the installer. No file, or no url in it, means the
feature is off and the app behaves exactly as before -- Omni Flow and a
development checkout never carry one.

Offline behaviour, as the owner chose it: a laptop the sheet has already
confirmed for this account keeps working without internet (the
confirmation is sealed to this Windows account with DPAPI, so it cannot be
copied to another machine); a laptop never confirmed is refused until it
can reach the sheet. Production rows wait in production-outbox.json and are
sent when the sheet answers again, so a dropped connection loses nothing.

What this is not: a defence against someone who edits the app's files on
their own laptop. It is a clear rule, enforced in the normal course of
work, with a record the owner controls.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import socket
import threading
import time
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from .logging_setup import get
from .product import app_root
from .version import VERSION

log = get("teamsheet")

CONFIG_FILE = "team-sheet.json"
OUTBOX_FILE = "production-outbox.json"
LOCK_FILE = "laptop-lock.json"
TIMEOUT = 30.0                        # seconds; Apps Script answers in 1-4 s, but a cold start took over 20
_outbox_lock = threading.Lock()
_flushing = threading.Lock()


# ---------------------------------------------------------------- settings
@dataclass(frozen=True)
class Settings:
    url: str = ""
    secret: str = ""

    @property
    def enabled(self) -> bool:
        return bool(self.url and self.secret)


def settings(folder: Optional[Path] = None) -> Settings:
    path = Path(folder or app_root()) / CONFIG_FILE
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return Settings()
    except (OSError, ValueError) as exc:
        log.warning("Could not read %s: %s", path, exc)
        return Settings()
    return Settings(url=str(raw.get("url", "")).strip(), secret=str(raw.get("secret", "")).strip())


# ----------------------------------------------------------------- laptop
def _machine_guid() -> str:
    """Windows' own install id, the same for every Windows user on the
    machine and unchanged by renaming it; a MAC-based fallback elsewhere."""
    if os.name == "nt":
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography",
                                 0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
            return str(value)
        except OSError:
            pass
    return "node-{:012x}".format(uuid.getnode())


def laptop_id() -> str:
    """A short, stable id for this machine. Hashed, so the sheet never holds
    the raw Windows id."""
    digest = hashlib.sha256(("9sigma-laptop:" + _machine_guid()).encode("utf-8")).hexdigest()
    return "L-" + digest[:12].upper()


def laptop_name() -> str:
    return (os.environ.get("COMPUTERNAME") or socket.gethostname() or platform.node() or "unknown").strip()


# --------------------------------------------------------------- transport
class Unreachable(RuntimeError):
    """The sheet could not be asked: no internet, a timeout, a bad reply."""


ATTEMPTS = 3
RETRY_BUDGET = 40.0                   # seconds; no further try once this much time has gone


def _post(s: Settings, payload: dict) -> dict:
    """POST to the web app and return its JSON reply, trying again after a
    bad answer. Google's front end now and then answers a good request with
    a stray page or a 404 (about one call in five on 23 Sep 2026); every
    action is safe to repeat -- a claim from the same laptop is the same
    claim, a production row is stored once by its id -- so a retry is the
    cure. A machine with no connection fails fast on every try."""
    started = time.monotonic()
    for attempt in range(1, ATTEMPTS + 1):
        try:
            return _post_once(s, payload)
        except Unreachable as exc:
            if attempt == ATTEMPTS or time.monotonic() - started > RETRY_BUDGET:
                raise
            log.info("Team sheet answered badly (%s); trying again", exc)
            time.sleep(1.5 * attempt)
    raise Unreachable("no answer")        # not reached


def _post_once(s: Settings, payload: dict) -> dict:
    """One POST. Apps Script answers with a redirect to the result, which
    requests follows as a GET -- that is how the platform is meant to be
    called."""
    import requests
    body = dict(payload, secret=s.secret)
    try:
        response = requests.post(s.url, data=json.dumps(body), timeout=TIMEOUT,
                                 headers={"Content-Type": "text/plain;charset=utf-8"})
    except requests.RequestException as exc:
        raise Unreachable(str(exc)[:200]) from exc
    if response.status_code != 200:
        raise Unreachable("HTTP {}".format(response.status_code))
    try:
        reply = response.json()
    except ValueError as exc:
        # A sign-in page or an HTML error instead of JSON: the web app is not
        # deployed for "Anyone", or the url is wrong.
        raise Unreachable("the sheet did not answer with data (check the web app is deployed "
                          "for Anyone)") from exc
    if not isinstance(reply, dict):
        raise Unreachable("unexpected reply")
    if reply.get("error"):
        raise Unreachable(str(reply["error"])[:200])
    return reply


# ------------------------------------------------------------ laptop lock
def _lock_path(folder: Optional[Path]) -> Path:
    return Path(folder or app_root()) / LOCK_FILE


def _confirmation(username: str) -> str:
    return "{}|{}".format(username.strip().lower(), laptop_id())


def _remember_confirmed(username: str, folder: Optional[Path]) -> None:
    from . import seal
    if not seal.available():
        return                     # no DPAPI: offline sign-in is simply not offered
    path = _lock_path(folder)
    try:
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except (OSError, ValueError):
        data = {}
    try:
        data[username.strip().lower()] = seal.seal(_confirmation(username))
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except OSError as exc:
        log.warning("Could not keep the laptop confirmation: %s", exc)


def _forget_confirmed(username: str, folder: Optional[Path]) -> None:
    path = _lock_path(folder)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    if data.pop(username.strip().lower(), None) is not None:
        try:
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError:
            pass


def _was_confirmed(username: str, folder: Optional[Path]) -> bool:
    from . import seal
    try:
        data = json.loads(_lock_path(folder).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    sealed = data.get(username.strip().lower())
    return bool(sealed) and seal.unseal(str(sealed)) == _confirmation(username)


def check_laptop(username: str, display_name: str = "", role: str = "editor",
                 folder: Optional[Path] = None) -> Tuple[bool, str]:
    """May this account sign in on this laptop? Returns (allowed, message);
    the message is for the sign-in screen when refused, "" otherwise."""
    s = settings(folder)
    if not s.enabled:
        return True, ""
    payload = {"action": "claim", "username": username, "display_name": display_name or username,
               "role": role, "laptop_id": laptop_id(), "laptop_name": laptop_name(),
               "version": VERSION}
    try:
        reply = _post(s, payload)
    except Unreachable as exc:
        if role == "admin":
            log.info("Team sheet not reachable at sign-in (%s); admin signs in anyway", exc)
            return True, ""
        if _was_confirmed(username, folder):
            log.info("Team sheet not reachable (%s); %s signs in on the laptop already confirmed",
                     exc, username)
            return True, ""
        log.warning("Team sheet not reachable (%s); %s is refused on an unconfirmed laptop", exc, username)
        return False, ("This laptop has not been confirmed for your account yet, and the team sheet "
                       "cannot be reached. Connect to the internet and sign in again.")
    if reply.get("ok"):
        if role != "admin":
            _remember_confirmed(username, folder)
        log.info("Team sheet: %s confirmed on %s (%s)", username, laptop_name(), laptop_id())
        return True, ""
    _forget_confirmed(username, folder)
    message = str(reply.get("message") or "This account cannot sign in on this laptop.")
    log.warning("Team sheet refused %s on %s: %s", username, laptop_name(), message)
    return False, message


def sign_in_gate(username: str, display_name: str = "", role: str = "editor",
                 folder: Optional[Path] = None) -> Tuple[bool, str, bool]:
    """The check the sign-in screen waits for: (allowed, message, recheck).

    Google's front end is sometimes slow (a 404 after 28 s was seen on 23 Sep
    2026), and an editor must not sit at "Checking..." for that. So an admin,
    or an editor on the laptop the sheet already confirmed, goes straight in
    and `recheck` is True: the caller asks the sheet in the background and
    signs the person out if it now refuses (account moved or blocked). Only a
    laptop never confirmed for this account waits for the sheet's answer."""
    if not settings(folder).enabled:
        return True, "", False
    if role == "admin" or _was_confirmed(username, folder):
        return True, "", True
    allowed, message = check_laptop(username, display_name, role, folder)
    return allowed, message, False


# ------------------------------------------------------------- production
def _fmt(seconds: float) -> str:
    seconds = int(round(max(0.0, seconds)))
    return "{}:{:02d}:{:02d}".format(seconds // 3600, seconds % 3600 // 60, seconds % 60)


def export_record(episode, output: Path, username: str, display_name: str,
                  source: str, exported_seconds: Optional[float] = None) -> dict:
    """The row for one finished export. `source` says where it came from:
    "Editor" for an export from the editing screen, "Automatic" for the
    production pipeline."""
    used = [c for c in episode.clips if getattr(c.state, "value", c.state) != "rejected"]
    clip_seconds = sum(c.media.duration for c in used if c.media)
    if exported_seconds is None:
        from .assemble import _segment_seconds
        exported_seconds = _segment_seconds(Path(output))
    try:
        size_mb = round(Path(output).stat().st_size / (1024 * 1024), 1)
    except OSError:
        size_mb = 0.0
    folder = getattr(episode, "source_dir", None)
    return {
        "id": uuid.uuid4().hex[:16],
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "username": username,
        "editor": display_name or username,
        "laptop": laptop_name(),
        "laptop_id": laptop_id(),
        "title": Path(output).stem,
        "folder": str(folder) if folder else "",
        "clips": len(used),
        "clip_length": _fmt(clip_seconds),
        "clip_seconds": round(clip_seconds, 1),
        "video_length": _fmt(exported_seconds or 0.0),
        "video_seconds": round(exported_seconds or 0.0, 1),
        "size_mb": size_mb,
        "file": Path(output).name,
        "source": source,
        "version": VERSION,
    }


def _outbox_path(folder: Optional[Path]) -> Path:
    return Path(folder or app_root()) / OUTBOX_FILE


def _read_outbox(folder: Optional[Path]) -> List[dict]:
    try:
        data = json.loads(_outbox_path(folder).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, ValueError) as exc:
        log.warning("Could not read the production outbox: %s", exc)
        return []
    return [r for r in data.get("records", []) if isinstance(r, dict) and r.get("id")]


def _write_outbox(records: List[dict], folder: Optional[Path]) -> None:
    path = _outbox_path(folder)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps({"records": records}, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def queue(record: dict, folder: Optional[Path] = None) -> None:
    """Keep the row on disk first, then try to send it; a row is only ever
    removed once the sheet has said it has it."""
    if not settings(folder).enabled:
        return
    with _outbox_lock:
        records = _read_outbox(folder)
        records.append(record)
        try:
            _write_outbox(records, folder)
        except OSError as exc:
            log.warning("Could not keep the production row for %s: %s", record.get("title"), exc)
    log.info("Production row queued: %s, %s clips, %s", record.get("title"), record.get("clips"),
             record.get("video_length"))


def flush(folder: Optional[Path] = None) -> int:
    """Send every waiting row. Returns how many the sheet took; never raises.
    The sheet ignores an id it already has, so a row sent twice (an answer
    lost on the way back) is still one row."""
    s = settings(folder)
    if not s.enabled or not _flushing.acquire(blocking=False):
        return 0
    try:
        with _outbox_lock:
            waiting = _read_outbox(folder)
        if not waiting:
            return 0
        try:
            reply = _post(s, {"action": "production", "records": waiting})
        except Unreachable as exc:
            log.info("Team sheet not reachable (%s); %d production row(s) wait", exc, len(waiting))
            return 0
        taken = set(reply.get("saved", [])) | set(reply.get("duplicates", []))
        with _outbox_lock:
            left = [r for r in _read_outbox(folder) if r.get("id") not in taken]
            try:
                _write_outbox(left, folder)
            except OSError as exc:
                log.warning("Could not update the production outbox: %s", exc)
        log.info("Team sheet took %d production row(s); %d still waiting", len(taken), len(left))
        return len(taken)
    finally:
        _flushing.release()


def flush_later(folder: Optional[Path] = None) -> None:
    """Send in the background so an export or a sign-in never waits on it."""
    if settings(folder).enabled:
        threading.Thread(target=flush, args=(folder,), name="team-sheet", daemon=True).start()


def report_export(episode, output: Path, username: str, display_name: str, source: str,
                  exported_seconds: Optional[float] = None, folder: Optional[Path] = None) -> None:
    """Record one finished export and send it. Never raises: a reporting
    problem must never fail an export that worked."""
    if not settings(folder).enabled:
        return
    try:
        queue(export_record(episode, output, username, display_name, source, exported_seconds), folder)
    except Exception as exc:                   # noqa: BLE001
        log.warning("Could not record the export of %s: %s", output, exc)
        return
    flush_later(folder)
