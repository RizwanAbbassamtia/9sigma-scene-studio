"""Parse the episode script that ships alongside the generated clips.

Generators do not agree on a format, and the same operation produces different
shapes from one batch to the next, so the parser accepts a family of layouts
rather than one. Two seen in the wild:

    A   12. <setting>, <action>, says: hero - "..." heroine - "...",
            ambient: ..., music: ...
        13. <setting>, <action>, no says, ambient: ..., music: ...

    B   12: <setting>, <action>, heroine says: "...", elder daughter says: "..."
        13: <setting>, <action>            (no dialogue: the marker is absent)

What has to hold for a script to be usable at all:

  * scenes start at the beginning of a line with a number and a separator
  * dialogue, when present, is introduced by "says:" and quoted

Everything else -- whether the speaker sits before or after "says:", whether
silence is stated or merely implied, whether ambient and music are annotated --
is optional and detected per file.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .logging_setup import get
from .models import DialogueLine, Scene

log = get("script")

# "12." or "12:" or "12)" at the start of a line
_SCENE_SPLIT = re.compile(r"^[ \t]*(\d{1,4})[.:)][ \t]+", re.MULTILINE)

_MUSIC = re.compile(r",\s*music:\s*(.*?)\s*\.?\s*$", re.IGNORECASE | re.DOTALL)
_AMBIENT = re.compile(r",\s*ambient:\s*(.*?)(?=,\s*music:|$)", re.IGNORECASE | re.DOTALL)
_NO_SAYS = re.compile(r"\bno\s+says\b", re.IGNORECASE)
_SAYS = re.compile(r"\bsays:", re.IGNORECASE)

# Straight or curly quotes, and the guillemets some generators emit
_QUOTED = re.compile(r"[\"“«]([^\"“”«»]+)[\"”»]")
# `hero - "line"` immediately after says:  (speaker stated after the marker)
_SPEAKER_THEN_QUOTE = re.compile(
    r"\s*([A-Za-z][A-Za-z0-9 _']{0,28}?)\s*[—–-]\s*"
    r"[\"“«]([^\"“”«»]+)[\"”»]")

_MAX_SPEAKER_WORDS = 4
_UNKNOWN_SPEAKER = "speaker"


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().strip(",.").strip()


def _speaker_before(text: str) -> str:
    """Pull the speaker out of the words leading up to `says:`.

    In "...at charpai level, elder daughter says:" the name is whatever follows
    the last comma. Anything longer than a few words is prose, not a name.
    """
    tail = _clean(text.rsplit(",", 1)[-1])
    if not tail:
        return _UNKNOWN_SPEAKER
    words = tail.split()
    if len(words) > _MAX_SPEAKER_WORDS:
        words = words[-_MAX_SPEAKER_WORDS:]
    name = " ".join(words).lower()
    # A name is letters and spaces; digits or punctuation mean we grabbed prose
    if not re.fullmatch(r"[a-z][a-z '\-]*", name):
        return _UNKNOWN_SPEAKER
    return name


def parse_dialogue(body: str) -> List[DialogueLine]:
    """Every spoken line in a scene, in order, whichever layout it uses."""
    lines: List[DialogueLine] = []
    marks = list(_SAYS.finditer(body))

    for index, mark in enumerate(marks):
        after = body[mark.end(): marks[index + 1].start() if index + 1 < len(marks) else len(body)]

        # Layout A: says: hero - "..." heroine - "..."
        pairs = _SPEAKER_THEN_QUOTE.findall(after)
        if pairs:
            for speaker, text in pairs:
                text = text.strip()
                if text:
                    lines.append(DialogueLine(_clean(speaker).lower(), text))
            continue

        # Layout B: <speaker> says: "..."
        quoted = _QUOTED.search(after)
        if quoted and quoted.group(1).strip():
            speaker = _speaker_before(body[: mark.start()])
            lines.append(DialogueLine(speaker, quoted.group(1).strip()))
    return lines


def parse_scene(number: int, body: str) -> Scene:
    body = body.strip()

    music = ""
    match = _MUSIC.search(body)
    if match:
        music = _clean(match.group(1))

    ambient = ""
    match = _AMBIENT.search(body)
    if match:
        ambient = _clean(match.group(1))

    dialogue = parse_dialogue(body)
    # "no says" is stated in some formats and merely absent in others, so an
    # explicit denial wins, and otherwise the presence of a quoted line decides.
    if _NO_SAYS.search(body):
        has_dialogue = False
        dialogue = []
    else:
        has_dialogue = bool(dialogue)

    setting = _clean(body.split(",", 1)[0])

    return Scene(
        number=number,
        setting=setting,
        has_dialogue=has_dialogue,
        dialogue=dialogue,
        ambient=ambient,
        music=music,
        raw=body,
    )


def parse_script(path: Path) -> Dict[int, Scene]:
    """Return {scene number: Scene} for every numbered entry in the file."""
    text = Path(path).read_text(encoding="utf-8", errors="replace")

    matches = list(_SCENE_SPLIT.finditer(text))
    scenes: Dict[int, Scene] = {}
    for index, match in enumerate(matches):
        number = int(match.group(1))
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        scenes[number] = parse_scene(number, text[start:end])
    return scenes


def score_script(path: Path) -> Tuple[int, int]:
    """(scene count, dialogue count) for ranking candidate files."""
    try:
        text = Path(path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return 0, 0
    return len(_SCENE_SPLIT.findall(text)), len(_SAYS.findall(text))


def find_script(directory: Path) -> Optional[Path]:
    """Pick the most plausible script in a clip folder, or None.

    A folder can hold notes, prompts and exports alongside the real script, so
    the one with the most numbered scenes wins, dialogue breaking any tie.
    A .txt with no numbered scene at all is not a script -- a prompt list,
    a failed_prompts.txt from the generator, an editor's notes -- and the
    folder is treated as having none. Until 9.13 the first such file was
    taken as the script anyway: every clip then "missed" the script, was
    planned as wordless and kept whole, and an episode came out untrimmed.
    """
    candidates = sorted(Path(directory).glob("*.txt"))
    # The generator's own lists live beside the clips and are numbered like
    # a script: "…_prompts.txt", "failed_prompts.txt". Never the script.
    candidates = [c for c in candidates if "prompt" not in c.stem.lower()]
    if not candidates:
        return None
    best, best_score = None, (0, 0)
    for candidate in candidates:
        score = score_script(candidate)
        if score > best_score:
            best, best_score = candidate, score
    if not best_score[0]:
        log.info("No script in %s: %s carr%s no numbered scene; the audio is the script",
                 directory, ", ".join(c.name for c in candidates), "ies" if len(candidates) == 1 else "y")
        return None
    return best
