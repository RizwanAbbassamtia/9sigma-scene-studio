"""Read MP4 metadata by walking atoms directly -- no ffprobe required.

Enough for ingest: duration, resolution, fps, codec and whether an audio track
exists. ffmpeg is still needed to cut and join, but scanning a folder works on a
bare machine, which keeps first-run friction low for the editors.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from .models import MediaInfo

_MAX_READ = 64 * 1024 * 1024
_VIDEO_CODECS = ("avc1", "hvc1", "hev1", "av01", "mp4v")


def _be(data: bytes, offset: int, size: int) -> int:
    if offset < 0 or offset + size > len(data):
        return 0
    return int.from_bytes(data[offset : offset + size], "big")


def probe(path: Path) -> Optional[MediaInfo]:
    """Return MediaInfo, or None if the file cannot be understood as MP4."""
    path = Path(path)
    try:
        with path.open("rb") as handle:
            data = handle.read(_MAX_READ)
    except OSError:
        return None

    # latin-1 maps each byte to one char, so str.find gives us byte offsets
    blob = data.decode("latin-1")

    moov = blob.find("moov")
    if moov < 0:
        return None

    info = MediaInfo()

    mvhd = blob.find("mvhd", moov)
    if mvhd >= 0:
        version = _be(data, mvhd + 4, 1)
        if version == 1:
            timescale = _be(data, mvhd + 24, 4)
            duration = _be(data, mvhd + 28, 8)
        else:
            timescale = _be(data, mvhd + 16, 4)
            duration = _be(data, mvhd + 20, 4)
        if timescale:
            info.duration = round(duration / timescale, 4)

    # Search from moov so the ftyp compatible-brand list cannot masquerade as a codec
    for codec in _VIDEO_CODECS:
        at = blob.find(codec, moov)
        if at < 0:
            continue
        info.video_codec = codec
        info.width = _be(data, at + 28, 2)
        info.height = _be(data, at + 30, 2)
        stsz = blob.find("stsz", at)
        if stsz >= 0:
            info.frame_count = _be(data, stsz + 12, 4)
            if info.duration > 0 and info.frame_count:
                info.fps = round(info.frame_count / info.duration, 3)
        break

    for codec in ("mp4a", "ac-3", "opus", "alac"):
        at = blob.find(codec, moov)
        if at < 0:
            continue
        info.has_audio = True
        info.audio_channels = _be(data, at + 20, 2)
        info.audio_sample_rate = _be(data, at + 28, 2)
        break

    return info
