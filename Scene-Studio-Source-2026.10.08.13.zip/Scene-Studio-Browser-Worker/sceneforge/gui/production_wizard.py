"""New automated production, as six short steps.

    1 Production     2 Automation range     3 Inputs     4 Video settings
    5 Output         6 Check and start

Step 3 shows only the fields the chosen starting point needs: a production
that starts from existing clips asks for the clips folder and nothing about
scripts, frameworks or keys. Saving writes the manifest and starts nothing;
"Save and start" hands the production to the dashboard, which asks once
more before anything paid runs.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QRadioButton, QScrollArea, QSpinBox,
    QStackedWidget, QVBoxLayout, QWidget,
)

from ..config import Config
from ..logging_setup import get
from ..production import prompts as prompt_text
from ..production import stages
from ..production.credentials import Credentials
from ..production.frameworks import Frameworks
from ..production.manifest import (
    ORDER, ASPECT_RATIOS, EditingMode, ErrorPolicy, Production, ReviewMode, SOURCE_START, Stage, Status,
    stages_between,
)
from ..production.screenplay import parse as parse_screenplay
from ..production.setup import seed_production
from ..production.stages import STAGE_NAMES, stage_label

log = get("production.wizard")

STEPS = ("Production", "Automation range", "Inputs", "Video settings", "Output", "Check and start")

ASPECT_CHOICES = (
    ("auto", "Follow the clips (recommended)",
     "The clips decide: 16:9 clips make a 16:9 video, 9:16 clips make a 9:16 video. Nothing is cropped "
     "or stretched."),
    ("16:9", "YouTube Long — 16:9", "The clips must be 16:9 (landscape); others are refused, never stretched."),
    ("9:16", "YouTube Shorts — 9:16", "The clips must be 9:16 (vertical); others are refused, never stretched."),
)
EDITING_CHOICES = (
    (EditingMode.AUTOMATIC.value, "Fully automatic",
     "The tool trims, joins and renders in the background; the editor is not opened."),
    (EditingMode.REVIEW.value, "Automatic + review",
     "The tool makes the edit, then the run pauses before the final export for you to look."),
    (EditingMode.MANUAL.value, "Manual editor",
     "The run pauses at Editing for a pass in the editor, then continues when you approve."),
)


def _section(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("sectionTitle")
    return label


def _hint(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("hint")
    label.setWordWrap(True)
    return label


class ProductionSetupDialog(QDialog):
    """New automated production. Ends by saving a manifest; it never starts
    anything unless the person presses Save and start, and even then the
    dashboard confirms first."""

    def __init__(self, config: Config, frameworks: Frameworks, credentials: Credentials, parent=None):
        super().__init__(parent)
        self.config = config
        self.frameworks = frameworks
        self.credentials = credentials
        self.production: Optional[Production] = None
        self.start_now = False
        self.setWindowTitle("New automated production")
        self.setMinimumSize(820, 640)
        self._build()

    def preselect(self, stage: Stage) -> None:
        """Open on the Automation range step with the start that matches
        `stage` chosen: Script → the title, Scene prompts → a script, Clips →
        scene-prompt text, Editing → a folder of clips, Export → a saved
        composition."""
        radio = {Stage.SCRIPT: self.start_title, Stage.PROMPTS: self.start_script,
                 Stage.CLIPS: self.start_prompts, Stage.EDIT: self.start_clips,
                 Stage.EXPORT: self.start_export}.get(Stage(stage), self.start_title)
        radio.setChecked(True)
        self._go(1)

    # ------------------------------------------------------------ building
    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.crumbs = QLabel("")
        self.crumbs.setObjectName("hint")
        self.crumbs.setContentsMargins(24, 14, 24, 4)
        outer.addWidget(self.crumbs)

        self.stack = QStackedWidget()
        outer.addWidget(self.stack, 1)
        for builder in (self._page_production, self._page_range, self._page_inputs, self._page_video,
                        self._page_output, self._page_check):
            page = QWidget()
            box = QVBoxLayout(page)
            box.setContentsMargins(24, 8, 24, 12)
            box.setSpacing(10)
            builder(box)
            box.addStretch(1)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(page)
            self.stack.addWidget(scroll)

        buttons = QHBoxLayout()
        buttons.setContentsMargins(24, 8, 24, 16)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_back = QPushButton("‹ Back")
        self.btn_back.clicked.connect(lambda: self._go(self.stack.currentIndex() - 1))
        self.btn_next = QPushButton("Next ›")
        self.btn_next.setObjectName("primary")
        self.btn_next.clicked.connect(lambda: self._go(self.stack.currentIndex() + 1))
        self.btn_save = QPushButton("Save production")
        self.btn_save.setToolTip("Saves the plan. Nothing starts until you press Start on the dashboard.")
        self.btn_save.clicked.connect(self._create)
        self.btn_start = QPushButton("Save and start")
        self.btn_start.setObjectName("primary")
        self.btn_start.setToolTip("Saves the plan and opens the dashboard, which confirms before anything runs.")
        self.btn_start.clicked.connect(self._create_and_start)
        buttons.addWidget(self.btn_cancel)
        buttons.addStretch(1)
        for button in (self.btn_back, self.btn_next, self.btn_save, self.btn_start):
            buttons.addWidget(button)
        outer.addLayout(buttons)
        self._built = True
        self.start_title.setChecked(True)          # every step exists now; the slot may run
        self._go(0)
        self._refresh_requirements()

    def _page_production(self, box: QVBoxLayout):
        box.addWidget(_section("1. Production"))
        box.addWidget(_hint("Automation is off unless you set it up here. Nothing is generated, and nothing "
                            "is paid for, until you press Start on the dashboard."))
        form = QFormLayout()
        form.setSpacing(8)
        self.title = QLineEdit()
        self.title.setPlaceholderText("The video's title, e.g. Ghareeb Ghar-Damaad Ko Saas Ne … (filled from the "
                                      "clips folder or file you choose if left empty)")
        self.title.textEdited.connect(lambda _t: self.title.setProperty("suggested", False))
        self.name = QLineEdit()
        self.name.setPlaceholderText("Project / serial name (optional; the title is used if empty)")
        self.episodes = QSpinBox()
        self.episodes.setRange(1, 200)
        self.language = QLineEdit("Urdu")
        self.minutes = QDoubleSpinBox()
        self.minutes.setRange(1, 240)
        self.minutes.setValue(20)
        self.minutes.setSuffix(" min (estimate until timed)")
        form.addRow("Title", self.title)
        form.addRow("Project name", self.name)
        form.addRow("Episodes", self.episodes)
        form.addRow("Language", self.language)
        form.addRow("Target length", self.minutes)
        box.addLayout(form)
        self.synopsis = QPlainTextEdit()
        self.synopsis.setPlaceholderText("Optional: synopsis, characters, setting, creative notes (used when the "
                                         "script is written by the tool).")
        self.synopsis.setMaximumHeight(90)
        box.addWidget(self.synopsis)

    def _page_range(self, box: QVBoxLayout):
        box.addWidget(_section("2. Automation range"))
        box.addWidget(_hint("Start from what you already have. \"Scenes\" can mean two things, so say which: "
                            "scene-prompt text starts at Clips (videos are generated from it); video files "
                            "start at Editing."))
        box.addWidget(QLabel("Start from"))
        self.start_title = QRadioButton("1. Script — I have only the title; write the script and everything after")
        self.start_script = QRadioButton("2. Scene prompts — I have the script; write scene prompts and everything after")
        self.start_prompts = QRadioButton("3. Clips — I have the scene prompts (text); generate the videos and everything after")
        self.start_both = QRadioButton("3. Clips — I have the script and its scene prompts (text); generate the videos onward")
        self.start_clips = QRadioButton("4. Editing — I have the video clips in a folder; edit and export them")
        self.start_export = QRadioButton("5. Export — I have an edited composition (saved from the editor); export only")
        self.start_group = QButtonGroup(self)
        self.start_radios = (self.start_title, self.start_script, self.start_prompts, self.start_both,
                             self.start_clips, self.start_export)
        for radio in self.start_radios:
            self.start_group.addButton(radio)
            box.addWidget(radio)
            radio.toggled.connect(self._refresh_requirements)
        # The default is chosen in _build(), once every step exists: a
        # toggled slot that runs before the Inputs step is built would fail.
        until = QFormLayout()
        self.end_stage = QComboBox()
        until.addRow("Continue until", self.end_stage)
        box.addLayout(until)
        self.end_stage.currentIndexChanged.connect(self._refresh_range_text)
        self.range_text = _hint("")
        box.addWidget(self.range_text)

    def _page_inputs(self, box: QVBoxLayout):
        box.addWidget(_section("3. Inputs"))
        self.requirements = _hint("")
        box.addWidget(self.requirements)

        # -- frameworks: only when a model writes something ----------------
        self.fw_box = QWidget()
        fw = QVBoxLayout(self.fw_box)
        fw.setContentsMargins(0, 0, 0, 0)
        frames = QFormLayout()
        self.script_fw = QComboBox()
        self.prompt_fw = QComboBox()
        for combo, kind in ((self.script_fw, "script"), (self.prompt_fw, "prompt")):
            combo.addItem("— choose —", "")
            for name in self.frameworks.names(kind):
                combo.addItem(name, name)
        self.script_fw_label = QLabel("Scriptwriting framework (OpenAI)")
        self.prompt_fw_label = QLabel("Scene-prompt framework (Claude)")
        frames.addRow(self.script_fw_label, self.script_fw)
        frames.addRow(self.prompt_fw_label, self.prompt_fw)
        fw.addLayout(frames)
        self.continuity = QPlainTextEdit()
        self.continuity.setPlaceholderText("Optional shared continuity: character looks, visual style, rules.")
        self.continuity.setMaximumHeight(70)
        fw.addWidget(self.continuity)
        fw.addWidget(_hint("Frameworks are yours; nothing is invented in their place. Add or edit them in "
                           "Automate ▾ → Framework library."))
        box.addWidget(self.fw_box)

        imports = QFormLayout()
        imports.setSpacing(8)
        self.import_episode = QSpinBox()
        self.import_episode.setRange(1, 1)
        self.import_episode.setToolTip("The episode the script, prompts or clips belong to.")
        self.episodes.valueChanged.connect(lambda n: self.import_episode.setMaximum(max(1, n)))
        self.import_episode_label = QLabel("Import into episode")
        imports.addRow(self.import_episode_label, self.import_episode)

        self.script_file = self._file_row(imports, "Script file", "a .txt script, or paste it below")
        self.script_text = QPlainTextEdit()
        self.script_text.setPlaceholderText("…or paste the script here. Imported text is kept as written; "
                                            "no model rewrites it.")
        self.script_text.setMaximumHeight(90)
        imports.addRow("", self.script_text)
        self.prompts_file = self._file_row(imports, "Scene-prompt file", "numbered prompts: 1: …  2: …")
        self.prompts_text = QPlainTextEdit()
        self.prompts_text.setPlaceholderText("…or paste the scene prompts here. One number per scene; a prompt "
                                             "may run over several lines until the next number.")
        self.prompts_text.setMaximumHeight(90)
        imports.addRow("", self.prompts_text)
        self.clips_folder = QLineEdit()
        self.clips_folder.setPlaceholderText("The folder of finished clips (1.mp4, 2.mp4 … or scene_001.mp4 …)")
        clips_row = QHBoxLayout()
        clips_browse = QPushButton("Browse…")
        clips_browse.clicked.connect(lambda: self._browse_folder(self.clips_folder))
        clips_row.addWidget(self.clips_folder, 1)
        clips_row.addWidget(clips_browse)
        self.clips_label = QLabel("Clips folder")
        imports.addRow(self.clips_label, clips_row)
        box.addLayout(imports)
        self.preview = _hint("")
        box.addWidget(self.preview)
        for widget in (self.script_file, self.prompts_file, self.clips_folder):
            widget.textChanged.connect(self._refresh_preview)
        for widget in (self.script_text, self.prompts_text):
            widget.textChanged.connect(self._refresh_preview)
        self._script_widgets = [self.script_file, self.script_text]
        self._prompt_widgets = [self.prompts_file, self.prompts_text]
        self._rows = {"script": [], "prompts": [], "clips": []}
        # QFormLayout rows are hidden by hiding both cells; keep the labels
        for row in range(imports.rowCount()):
            label = imports.itemAt(row, QFormLayout.LabelRole)
            field = imports.itemAt(row, QFormLayout.FieldRole)
            widgets = [w.widget() for w in (label, field) if w is not None and w.widget() is not None]
            if field is not None and field.layout() is not None:
                lay = field.layout()
                widgets += [lay.itemAt(i).widget() for i in range(lay.count()) if lay.itemAt(i).widget()]
            key = ("script" if any(w in (self.script_file, self.script_text) for w in widgets) else
                   "prompts" if any(w in (self.prompts_file, self.prompts_text) for w in widgets) else
                   "clips" if self.clips_folder in widgets else "")
            if key:
                self._rows[key] += widgets

    def _page_video(self, box: QVBoxLayout):
        box.addWidget(_section("4. Video settings"))
        box.addWidget(QLabel("Video format"))
        self.aspect_group = QButtonGroup(self)
        self.aspect_radios: Dict[str, QRadioButton] = {}
        for value, label, hint in ASPECT_CHOICES:
            radio = QRadioButton(label)
            radio.setToolTip(hint)
            self.aspect_group.addButton(radio)
            self.aspect_radios[value] = radio
            box.addWidget(radio)
        self.aspect_radios["auto"].setChecked(True)
        box.addWidget(_hint("Omni Flash renders landscape clips; for Shorts, supply clips generated at 9:16. "
                            "The video is never cropped or stretched to another shape."))
        form = QFormLayout()
        self.resolution = QComboBox()
        self.resolution.addItem("1080p  (1920×1080 at 16:9, 1080×1920 at 9:16)", 1080)
        self.resolution.addItem("720p  (as generated)", 720)
        form.addRow("Resolution", self.resolution)
        box.addLayout(form)

        box.addWidget(QLabel("Editing"))
        self.editing_group = QButtonGroup(self)
        self.editing_radios: Dict[str, QRadioButton] = {}
        for value, label, hint in EDITING_CHOICES:
            radio = QRadioButton(label)
            radio.setToolTip(hint)
            self.editing_group.addButton(radio)
            self.editing_radios[value] = radio
            box.addWidget(radio)
        self.editing_radios[EditingMode.AUTOMATIC.value].setChecked(True)
        box.addWidget(_hint("Continuity is optimised automatically: professional cuts inside a scene, a short "
                            "invisible blend where one is cleaner, and the source quality kept through one "
                            "final encode. There is nothing to choose."))

        box.addWidget(QLabel("Review points"))
        self.review_each = QRadioButton("Review at each creative stage (script, prompts, clips, edit)")
        self.review_paid = QRadioButton("Review once, before paid video generation")
        self.review_auto = QRadioButton("Fully automatic: run to the end of the range while limits allow — recommended for batches")
        self.review_group = QButtonGroup(self)
        for radio in (self.review_each, self.review_paid, self.review_auto):
            self.review_group.addButton(radio)
            box.addWidget(radio)
        self.review_each.setChecked(True)

        limits = QFormLayout()
        self.policy = QComboBox()
        self.policy.addItem("Retry, then ask me (stop and wait)", ErrorPolicy.ASK.value)
        self.policy.addItem("Retry, then skip the clip and report it", ErrorPolicy.SKIP.value)
        self.policy.addItem("Stop at the first failure", ErrorPolicy.STOP.value)
        self.max_generations = QSpinBox()
        self.max_generations.setRange(0, 5000)
        self.max_generations.setSpecialValueText("no limit")
        self.max_generations.setSuffix(" clips")
        self.max_seconds = QDoubleSpinBox()
        self.max_seconds.setRange(0, 120)
        self.max_seconds.setSpecialValueText("provider default")
        self.max_seconds.setSuffix(" s per clip")
        self.policy_label = QLabel("If a clip fails")
        self.limit_label = QLabel("Generation limit")
        self.seconds_label = QLabel("Clip length")
        limits.addRow(self.policy_label, self.policy)
        limits.addRow(self.limit_label, self.max_generations)
        limits.addRow(self.seconds_label, self.max_seconds)
        box.addLayout(limits)
        self.generation_note = _hint("The generation limit is enforced by this application before each "
                                     "submission. Costs are shown only as the provider reports them.")
        box.addWidget(self.generation_note)
        self.mock = QCheckBox("Test mode: mock providers — no keys, no cost, test-pattern clips")
        box.addWidget(self.mock)
        self._generation_widgets = [self.policy_label, self.policy, self.limit_label, self.max_generations,
                                    self.seconds_label, self.max_seconds, self.generation_note]

    def _page_output(self, box: QVBoxLayout):
        box.addWidget(_section("5. Output"))
        folders = QFormLayout()
        self.working = self._folder_row(folders, "Working folder", "scripts, prompts, the record (production.json)")
        self.clips = self._folder_row(folders, "Generated clips", "where generated clips are saved (optional)")
        self.export = self._folder_row(folders, "Export folder", "where the finished video goes (default: the working folder)")
        self.final_filename = QLineEdit()
        self.final_filename.setPlaceholderText("optional; default is the episode name")
        folders.addRow("Final filename", self.final_filename)
        box.addLayout(folders)
        self.clips_out_label = folders.labelForField(self.clips.parentWidget() or self.clips)

    def _page_check(self, box: QVBoxLayout):
        box.addWidget(_section("6. Check and start"))
        self.checks = QLabel("")
        self.checks.setObjectName("hint")
        self.checks.setWordWrap(True)
        self.checks.setTextFormat(Qt.RichText)
        box.addWidget(self.checks)
        self.summary = _hint("")
        box.addWidget(self.summary)

    # ---------------------------------------------------------- navigation
    def _go(self, index: int):
        index = max(0, min(index, self.stack.count() - 1))
        if index == self.stack.count() - 1:
            self._refresh_checks()
        self.stack.setCurrentIndex(index)
        crumbs = []
        for position, step in enumerate(STEPS):
            crumbs.append("<b>{}</b>".format(step) if position == index else step)
        self.crumbs.setText("   ›   ".join(crumbs))
        last = index == self.stack.count() - 1
        self.btn_back.setEnabled(index > 0)
        self.btn_next.setVisible(not last)
        self.btn_save.setVisible(last)
        self.btn_start.setVisible(last)

    # ------------------------------------------------------- small helpers
    def _folder_row(self, form: QFormLayout, label: str, hint: str) -> QLineEdit:
        row = QHBoxLayout()
        field = QLineEdit()
        field.setPlaceholderText(hint)
        browse = QPushButton("Browse…")
        browse.clicked.connect(lambda: self._browse_folder(field))
        row.addWidget(field, 1)
        row.addWidget(browse)
        form.addRow(label, row)
        return field

    def _browse_folder(self, field: QLineEdit):
        path = QFileDialog.getExistingDirectory(self, "Choose a folder", field.text() or "")
        if path:
            field.setText(path)

    def _file_row(self, form: QFormLayout, label: str, hint: str) -> QLineEdit:
        row = QHBoxLayout()
        field = QLineEdit()
        field.setPlaceholderText(hint)
        browse = QPushButton("Browse…")
        browse.clicked.connect(lambda: self._browse_file(field))
        row.addWidget(field, 1)
        row.addWidget(browse)
        form.addRow(label, row)
        return field

    def _browse_file(self, field: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(self, "The file to start from", "", "Text (*.txt *.md);;All files (*)")
        if path:
            field.setText(path)

    # ------------------------------------------------------------- the range
    def start_point(self) -> str:
        return ("title" if self.start_title.isChecked() else "script" if self.start_script.isChecked()
                else "prompts" if self.start_prompts.isChecked() else "script_prompts" if self.start_both.isChecked()
                else "clips" if self.start_clips.isChecked() else "composition")

    def start_stage(self) -> Stage:
        return SOURCE_START[self.start_point()]

    def end_stage_value(self) -> Stage:
        data = self.end_stage.currentData()
        return Stage(data) if data else Stage.EXPORT

    def _refresh_requirements(self, *_):
        if not getattr(self, "_built", False):
            return                                 # a signal during construction: nothing to show yet
        start = self.start_point()
        first = self.start_stage()
        # Continue-until offers only the stages from the start onward.
        keep = self.end_stage.currentData() or Stage.EXPORT.value
        self.end_stage.blockSignals(True)
        self.end_stage.clear()
        for stage in ORDER[ORDER.index(first):]:
            self.end_stage.addItem(stage_label(stage), stage.value)
        index = self.end_stage.findData(keep)
        self.end_stage.setCurrentIndex(index if index >= 0 else self.end_stage.count() - 1)
        self.end_stage.blockSignals(False)
        self._refresh_range_text()

        needs = {"title": ["the scriptwriting framework", "the scene-prompt framework",
                           "OpenAI key", "Anthropic key", "Omni Flash key"],
                 "script": ["a script (file or pasted)", "the scene-prompt framework", "Anthropic key", "Omni Flash key"],
                 "prompts": ["scene prompts (file or pasted, numbered)", "Omni Flash key"],
                 "script_prompts": ["scene prompts (file or pasted, numbered); the script is optional and is "
                                    "kept for the record", "Omni Flash key"],
                 "clips": ["a folder of clips; no key, no framework, no script"],
                 "composition": ["a folder of clips with the composition saved beside them by the editor or "
                                 "by a previous Editing stage; no key"]}[start]
        self.requirements.setText("Needed for this starting point: " + ", ".join(needs) + ".")
        show_fw = start in ("title", "script")
        self.fw_box.setVisible(show_fw)
        self.script_fw_label.setVisible(start == "title")
        self.script_fw.setVisible(start == "title")
        for widget in self._rows["script"]:
            widget.setVisible(start in ("script", "script_prompts"))
        for widget in self._rows["prompts"]:
            widget.setVisible(start in ("prompts", "script_prompts"))
        for widget in self._rows["clips"]:
            widget.setVisible(start in ("clips", "composition"))
        for widget in self._script_widgets:
            widget.setEnabled(start in ("script", "script_prompts"))
        for widget in self._prompt_widgets:
            widget.setEnabled(start in ("prompts", "script_prompts"))
        self.clips_folder.setEnabled(start in ("clips", "composition"))
        self.import_episode.setEnabled(start != "title")
        self.import_episode_label.setVisible(start != "title")
        self.import_episode.setVisible(start != "title")
        generates = ORDER.index(Stage.CLIPS) in range(ORDER.index(first), ORDER.index(self.end_stage_value()) + 1)
        for widget in self._generation_widgets:
            widget.setVisible(generates)
        self._refresh_preview()

    def _refresh_range_text(self, *_):
        if not getattr(self, "_built", False):
            return
        self.range_text.setText("Automation range:  " + stages.range_text(self.start_stage(), self.end_stage_value()))
        generates = ORDER.index(Stage.CLIPS) in range(ORDER.index(self.start_stage()),
                                                    ORDER.index(self.end_stage_value()) + 1)
        if hasattr(self, "_generation_widgets"):
            for widget in self._generation_widgets:
                widget.setVisible(generates)

    # -- what is being imported ------------------------------------------------
    def _text_of(self, field: QLineEdit, pasted: QPlainTextEdit) -> str:
        """A file wins over the paste box when both are given; either may be empty."""
        path = field.text().strip()
        if path:
            try:
                return Path(path).read_text(encoding="utf-8", errors="replace")
            except OSError:
                return pasted.toPlainText()          # import_problems() names the missing file
        return pasted.toPlainText()

    def import_texts(self) -> Dict[str, str]:
        start = self.start_point()
        return {"script": self._text_of(self.script_file, self.script_text) if start in ("script", "script_prompts") else "",
                "prompts": self._text_of(self.prompts_file, self.prompts_text) if start in ("prompts", "script_prompts") else ""}

    def import_problems(self) -> List[str]:
        """What stops the import: the text is checked before anything is saved."""
        start = self.start_point()
        texts = self.import_texts()
        problems: List[str] = []
        if self.script_file.text().strip() and start in ("script", "script_prompts") \
                and not Path(self.script_file.text().strip()).is_file():
            problems.append("the script file was not found")
        if self.prompts_file.text().strip() and start in ("prompts", "script_prompts") \
                and not Path(self.prompts_file.text().strip()).is_file():
            problems.append("the scene-prompt file was not found")
        if start == "script" and not texts["script"].strip():
            problems.append("a script is needed (choose a file or paste it)")
        if start in ("prompts", "script_prompts"):
            if not texts["prompts"].strip():
                problems.append("scene prompts are needed (choose a file or paste them)")
            else:
                items, found = prompt_text.parse_report(texts["prompts"])
                # Gaps are a warning the preview shows; an ambiguous or
                # repeated number would generate the wrong clip, so it blocks.
                problems += [p for p in found if "numbered" in p or "appears" in p or "no numbered" in p]
        if start in ("clips", "composition"):
            report = stages.clip_folder_report(self.clips_folder.text().strip())
            problems += report["problems"]
            if start == "composition" and not report["problems"] and not report["composition"]:
                problems.append("no composition is saved beside those clips (open the folder in the editor and "
                                "save, or start from Editing instead)")
        return problems

    def _refresh_preview(self, *_):
        if not getattr(self, "_built", False):
            return
        start = self.start_point()
        self._suggest_title()
        if start == "title":
            self.preview.setText("")
            return
        texts = self.import_texts()
        parts = []
        if start in ("script", "script_prompts"):
            script = texts["script"]
            if script.strip():
                play = parse_screenplay(script)
                parts.append("Script: {} words, {} scenes; kept exactly as written.".format(
                    len(script.split()), len(play.scenes)))
            elif start == "script_prompts":
                parts.append("Script: none (optional).")
        if start in ("prompts", "script_prompts"):
            prompts = texts["prompts"]
            if prompts.strip():
                items, problems = prompt_text.parse_report(prompts)
                if items:
                    scenes = sorted({i.scene for i in items})
                    first = " ".join(items[0].prompt.split())[:80]
                    parts.append("Prompts: {} clips, scenes {}–{}; first: “{}…”".format(
                        len(items), scenes[0], scenes[-1], first))
                if problems:
                    parts.append("Check: " + "; ".join(problems))
        if start in ("clips", "composition"):
            folder = self.clips_folder.text().strip()
            if folder:
                report = stages.clip_folder_report(folder)
                if not report["problems"]:
                    expected = report["expected"]
                    parts.append("Expected clips: {}   Found clips: {}   Missing: {}".format(
                        expected if expected is not None else "unknown", report["found"],
                        len(report["missing"]) if report["missing"] else 0))
                    if report["missing"]:
                        shown = ", ".join(str(n) for n in report["missing"][:30])
                        parts.append("Missing numbers: {}{}".format(shown, " …" if len(report["missing"]) > 30 else ""))
                    if report["duplicates"]:
                        parts.append("More than one file for: {}".format(
                            ", ".join(str(n) for n in report["duplicates"][:20])))
                    parts.append("Composition saved beside the clips: {}".format("yes" if report["composition"] else "no"))
                else:
                    parts.append("Check: " + "; ".join(report["problems"]))
        self.preview.setText("\n".join(parts))

    # --------------------------------------------------------------- checks
    def _suggest_title(self) -> None:
        """A production started from existing material is named after it
        unless a title was typed: the clips folder, or the script / prompt
        file. A suggestion is tied to the source it came from: when that
        source changes or goes away (another folder, a pasted script, the
        start moved back to the title) the suggestion goes with it. Typed
        titles are never touched."""
        if self.title.text().strip() and not self.title.property("suggested"):
            return
        start = self.start_point()
        source = ""
        if start in ("clips", "composition"):
            source = self.clips_folder.text().strip()
        elif start in ("script", "script_prompts"):
            source = self.script_file.text().strip() or self.prompts_file.text().strip()
        elif start == "prompts":
            source = self.prompts_file.text().strip()
        came_from = self.title.property("suggested_from") or ""
        if self.title.property("suggested") and (not source or source != came_from):
            self.title.clear()
            self.title.setProperty("suggested", False)
            self.title.setProperty("suggested_from", "")
        if source and not self.title.text().strip():
            name = Path(source).stem if start not in ("clips", "composition") else Path(source).name
            if name:
                self.title.setText(name)
                self.title.setProperty("suggested", True)
                self.title.setProperty("suggested_from", source)

    def _checks(self) -> List[tuple]:
        """(ok, text) per check, for the last page."""
        out = []
        problems = self.import_problems()
        start = self.start_point()
        self._suggest_title()
        title = self.title.text().strip()
        out.append((bool(title), "Title: {}".format(title or "missing — type it on step 1 (Production)")))
        working = self.working.text().strip()
        out.append((bool(working), "Working folder: {}".format(working or "missing — choose it on step 5 (Output)")))
        if working:
            problem = stages._writable(working)
            out.append((not problem, "Working folder writable" if not problem else problem))
        export = self.export.text().strip() or working
        if export and self.end_stage_value() == Stage.EXPORT:
            problem = stages._writable(export)
            out.append((not problem, "Export folder writable: {}".format(export) if not problem else problem))
        if start in ("clips", "composition"):
            report = stages.clip_folder_report(self.clips_folder.text().strip())
            if not report["problems"]:
                out.append((True, "Clips folder found: {} clips detected ({} numbered)".format(
                    report["found"], report["numbered"])))
                if report["missing"]:
                    out.append((True, "{} clip number(s) missing from the run — they will be skipped; the "
                                      "retake sheet names them".format(len(report["missing"]))))
                if start == "composition":
                    out.append((report["composition"], "Composition saved beside the clips"
                                if report["composition"] else "No composition beside the clips"))
        for problem in problems:
            out.append((False, problem))
        from ..ffmpeg_tools import find_tool
        out.append((bool(find_tool("ffmpeg")), "FFmpeg available" if find_tool("ffmpeg") else "FFmpeg not found"))
        if not self.mock.isChecked():
            first, last = self.start_stage(), self.end_stage_value()
            for stage in stages_between(first, last):
                key = stages.STAGE_KEYS.get(stage)
                if key:
                    has = self.credentials.has(key)
                    out.append((has, "{} key {}".format(
                        {"openai": "OpenAI", "anthropic": "Anthropic", "omniflash": "Omni Flash"}[key],
                        "set" if has else "not set (Automate ▾ → API keys)")))
        if start == "title" and not self.mock.isChecked():
            out.append((bool(self.script_fw.currentData()), "Scriptwriting framework chosen"
                        if self.script_fw.currentData() else "No scriptwriting framework chosen"))
        if start in ("title", "script") and not self.mock.isChecked():
            out.append((bool(self.prompt_fw.currentData()), "Scene-prompt framework chosen"
                        if self.prompt_fw.currentData() else "No scene-prompt framework chosen"))
        out.append((True, "Editing settings valid: {}, {}, {}".format(
            dict((v, l) for v, l, _ in ASPECT_CHOICES)[self.aspect_value()],
            self.resolution.currentText().split("  ")[0],
            dict((v, l) for v, l, _ in EDITING_CHOICES)[self.editing_value()])))
        return out

    def _refresh_checks(self):
        rows = self._checks()
        html = "<br>".join("{} {}".format("✓" if ok else "✗", text) for ok, text in rows)
        self.checks.setText(html)
        blocked = [text for ok, text in rows if not ok]
        self.btn_start.setEnabled(not blocked)
        self.btn_save.setEnabled(not [t for ok, t in rows if not ok and ("Title" in t or "Working" in t)])
        self.summary.setText("Automation range: {}.  {}".format(
            stages.range_text(self.start_stage(), self.end_stage_value()),
            "Fix the items marked ✗ to start." if blocked else "Ready. Save and start opens the dashboard, "
                                                                "which confirms before anything runs."))

    def aspect_value(self) -> str:
        for value, radio in self.aspect_radios.items():
            if radio.isChecked():
                return value
        return "auto"

    def editing_value(self) -> str:
        for value, radio in self.editing_radios.items():
            if radio.isChecked():
                return value
        return EditingMode.AUTOMATIC.value

    # --------------------------------------------------------------- saving
    def _create_and_start(self):
        self.start_now = True
        self._create()
        if self.production is None:
            self.start_now = False

    def _create(self):
        title = self.title.text().strip()
        name = self.name.text().strip() or title[:40]
        working = self.working.text().strip()
        if not title or not working:
            QMessageBox.information(self, "New automated production", "A title and a working folder are needed.")
            return
        start = self.start_point()
        problems = self.import_problems()
        if problems:
            QMessageBox.information(self, "New automated production", "Before this can be saved:\n• " + "\n• ".join(problems))
            return
        review = (ReviewMode.EACH_STAGE if self.review_each.isChecked() else
                  ReviewMode.BEFORE_PAID if self.review_paid.isChecked() else ReviewMode.AUTOMATIC)
        script_ref = self.frameworks.latest(self.script_fw.currentData()) if self.script_fw.currentData() else None
        prompt_ref = self.frameworks.latest(self.prompt_fw.currentData()) if self.prompt_fw.currentData() else None
        first, last = self.start_stage(), self.end_stage_value()
        production = Production.new(
            title, name, Path(working), episodes=self.episodes.value(),
            language=self.language.text().strip() or "Urdu", target_minutes=self.minutes.value(),
            synopsis=self.synopsis.toPlainText().strip(), continuity=self.continuity.toPlainText().strip(),
            clips_dir=self.clips.text().strip() or str(Path(working) / "clips"),
            export_dir=self.export.text().strip() or working,
            review_mode=review.value, error_policy=self.policy.currentData(),
            start_stage=first.value, end_stage=last.value, source_type=start,
            editing_mode=self.editing_value(), aspect_ratio=self.aspect_value(),
            resolution=int(self.resolution.currentData()), final_filename=self.final_filename.text().strip(),
            generation_settings={"max_seconds": self.max_seconds.value(), "mock": self.mock.isChecked(),
                                 "max_generations": self.max_generations.value()},
            editing_settings={"trim_mode": self.config.trim_mode, "output_height": int(self.resolution.currentData()),
                              "aspect_ratio": self.aspect_value()})
        if script_ref:
            production.script_framework = script_ref
        if prompt_ref:
            production.prompt_framework = prompt_ref
        if start != "title":
            # The chosen episode, and only that one: the others start from
            # the title when their turn comes.
            number = min(self.import_episode.value(), len(production.episodes))
            episode = production.episode(number)
            texts = self.import_texts()
            self._seed(production, episode, start,
                       Path(self.clips_folder.text().strip()) if start in ("clips", "composition") else None,
                       script_text=texts["script"], prompts_text=texts["prompts"])
        production.save()
        self.production = production
        log.info("Production saved: %s, %s → %s (%s)", production.title, first.value, last.value, start)
        self.accept()

    @staticmethod
    def _seed(production: Production, episode, start: str, existing: Optional[Path] = None,
              script_text: str = "", prompts_text: str = ""):
        """Record what the user already has, and skip the stages before it
        (production.setup.seed_production, shared with the batch)."""
        seed_production(production, episode, start, existing, script_text=script_text, prompts_text=prompts_text)
