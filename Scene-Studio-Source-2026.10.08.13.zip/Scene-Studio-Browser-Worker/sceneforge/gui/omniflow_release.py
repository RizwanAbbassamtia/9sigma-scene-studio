"""Build-machine release panel; publishing reuses the existing checked uploader."""
from pathlib import Path
import re

from PySide6.QtCore import QProcess
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QFormLayout, QHBoxLayout,
    QLineEdit, QPushButton, QPlainTextEdit, QLabel, QFileDialog, QMessageBox)

from ..version import OMNIFLOW_VERSION, parse


class OmniFlowReleaseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Build and publish an Omni Flow update')
        self.resize(740, 550)
        self.process = None
        outer = QVBoxLayout(self)
        info = QLabel('Use this on the build machine with the SceneForge source and GitHub access. '
                      'Build creates the installer locally. Push update publishes it to '
                      'RizwanAbbassamtia/9sigma-omniflow-updates and makes it available to installed apps.')
        info.setWordWrap(True)
        outer.addWidget(info)
        form = QFormLayout()
        self.source = QLineEdit()
        here = Path(__file__).resolve().parents[2]
        if (here / 'tools/make_setup_exe.py').is_file():
            self.source.setText(str(here))
        row = QHBoxLayout()
        row.addWidget(self.source)
        pick = QPushButton('Browse…')
        pick.clicked.connect(self.choose_source)
        row.addWidget(pick)
        form.addRow('Source folder', row)
        self.version = QLineEdit(OMNIFLOW_VERSION)
        form.addRow('New version', self.version)
        self.notes = QPlainTextEdit()
        self.notes.setPlaceholderText('Release notes shown to users')
        self.notes.setMaximumHeight(100)
        form.addRow('Release notes', self.notes)
        outer.addLayout(form)
        buttons = QHBoxLayout()
        self.build = QPushButton('Build installer')
        self.build.clicked.connect(self.build_installer)
        self.publish = QPushButton('Push update…')
        self.publish.clicked.connect(self.publish_update)
        buttons.addWidget(self.build)
        buttons.addWidget(self.publish)
        outer.addLayout(buttons)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        outer.addWidget(self.log)

    def choose_source(self):
        folder = QFileDialog.getExistingDirectory(self, 'Select SceneForge source')
        if folder:
            self.source.setText(folder)

    def inputs(self):
        root = Path(self.source.text()).resolve()
        version = self.version.text().strip()
        if not re.fullmatch(r'\d+\.\d+(?:\.\d+)?', version):
            raise ValueError('Use a numeric version such as 1.05 or 1.06')
        python = root / '.venv/Scripts/python.exe'
        if not python.is_file() or not (root / 'tools/publish_release.py').is_file():
            raise ValueError('Choose the source repository with its build environment, not the installed app folder')
        source = root / 'sceneforge/version.py'
        code = source.read_text(encoding='utf-8')
        match = re.search(r'^OMNIFLOW_VERSION = "([^"]+)"', code, re.M)
        if not match or parse(version) < parse(match.group(1)):
            raise ValueError('The new version cannot be older than the source version')
        return root, python, source, code, match, version

    def build_installer(self):
        try:
            root, python, source, code, match, version = self.inputs()
            if version != match.group(1):
                source.write_text(code[:match.start(1)] + version + code[match.end(1):], encoding='utf-8')
            self.start(root, python, ['tools/make_setup_exe.py', '--product', 'omniflow'])
        except Exception as exc:
            QMessageBox.warning(self, 'Cannot build', str(exc))

    def publish_update(self):
        try:
            root, python, source, code, match, version = self.inputs()
            if version != match.group(1):
                raise ValueError('Build this version before publishing')
            notes = self.notes.toPlainText().strip()
            if not notes:
                raise ValueError('Enter release notes before publishing')
            if QMessageBox.question(self, 'Publish Omni Flow ' + version,
                'Publish the installer and update manifest to the public Omni Flow update channel?\n\n'
                + notes, QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                return
            self.start(root, python, ['tools/publish_release.py', '--product', 'omniflow', notes])
        except Exception as exc:
            QMessageBox.warning(self, 'Cannot publish', str(exc))

    def start(self, root, python, args):
        if self.process is not None:
            return
        self.process = QProcess(self)
        self.process.setWorkingDirectory(str(root))
        self.process.setProcessChannelMode(QProcess.MergedChannels)
        self.process.readyReadStandardOutput.connect(self.read_output)
        self.process.finished.connect(self.finished)
        self.process.errorOccurred.connect(self.failed)
        self.build.setEnabled(False)
        self.publish.setEnabled(False)
        self.process.start(str(python), args)

    def read_output(self):
        if self.process:
            self.log.appendPlainText(bytes(self.process.readAllStandardOutput()).decode('utf-8', 'replace'))

    def failed(self, error):
        if self.process and error == QProcess.FailedToStart:
            self.log.appendPlainText('The build process could not start.')
            self.finished(-1)

    def finished(self, code, status=None):
        self.read_output()
        self.log.appendPlainText('Completed.' if code == 0 else 'Failed; see the output above.')
        if self.process:
            self.process.deleteLater()
        self.process = None
        self.build.setEnabled(True)
        self.publish.setEnabled(True)

    def reject(self):
        if self.process is not None:
            QMessageBox.information(self, 'Operation running', 'Wait for the build or upload to finish.')
        else:
            super().reject()

    def closeEvent(self, event):
        if self.process is not None:
            event.ignore()
        else:
            super().closeEvent(event)
