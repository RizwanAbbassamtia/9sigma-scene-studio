"""The master log screen: one record per framework, a queue of titles under
each, and the worker that takes them through the pipeline unattended.

Every read of the shared folder runs on a small thread and the screen only
paints what came back, so a sleeping NAS or a dropped VPN cannot freeze the
window. Nothing reads the share when the app starts, and nothing runs until
Start worker is pressed: that button is the one place in the app where paid
work begins without a click per title, so it says exactly what it will run
before it starts, and the worker is stopped when the window closes.

Everything in titles.json and master.json was written by other machines and
other people, so ids, paths and export files read from it are checked here
before they become a folder to open or a file to hand to the shell.
"""
from __future__ import annotations

import dataclasses
import html
import os
import re
import socket
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog,
    QFormLayout, QFrame, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget, QMessageBox,
    QPlainTextEdit, QPushButton, QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout,
    QWidget,
)

from ..config import Config
from ..logging_setup import get
from ..production.credentials import Credentials
from ..production.manifest import FrameworkRef, Production, now
from ..production.master import MasterLog, MasterRecord, TitleJob
from ..production.notify import EmailSettings, Notifier
from ..production.worker import (
    default_worker_id,
    MOCK_PROMPTS, MOCK_SCRIPT, MasterWorker, budget_text, live_budget_problem, make_providers,
    missing_mock_samples,
)
from . import theme

log = get("master.page")

# The same rules master.py applies on every load. Repeated here because a
# folder is only ever built from an id that passed them, whatever the share
# says.
FRAMEWORK_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
JOB_ID = re.compile(r"^[a-z0-9][a-z0-9-]{2,31}$")
EMAIL = re.compile(r"^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$")

STATUS_WORDS = {"queued": "Queued", "script_running": "Writing script", "script_done": "Script done",
                "prompts_done": "Prompts done", "clips_done": "Clips done", "video_done": "Video done",
                "failed": "Failed", "paused": "Paused"}
# The badge has three looks; green and red are kept for the two outcomes.
BADGE_STATE = {"video_done": "approved", "failed": "rejected", "paused": ""}
IN_PROGRESS = ("script_running", "script_done", "prompts_done", "clips_done")
COLUMNS = ("#", "Title", "Status", "Progress", "Added by", "Added", "Updated", "Export")
COL_TITLE, COL_STATUS, COL_EXPORT = 1, 2, 7
TITLE_MIN_WIDTH = 240
FRAMEWORK_KINDS = (("hook", "Hook writer (optional; OpenAI, before the script)"),
                   ("script", "Script framework (OpenAI)"),
                   ("prompt", "Scene-prompt framework (Claude)"))
# The statuses the worker mails about; queued and paused are moves people
# make from this screen and nothing is ever sent for them.
MAIL_STATUSES = ("script_running", "script_done", "prompts_done", "clips_done", "video_done", "failed")
# The share is re-read this often while a folder is open, so titles added
# on another machine appear and a Pause press works from a fresh row.
POLL_MS = 20000
# How long the closing window waits for a read or write of the share.
SHARE_WAIT_MS = 2000

# Threads the closing window could not wait out: a read or write stuck on
# a sleeping share, or a worker still finishing a step. Deleting a running
# QThread aborts the process, so each is kept here until it finishes.
_ORPHANS = set()


def _orphan(thread: QThread, what: str) -> None:
    log.warning("%s did not stop in time; it is left to finish on its own", what)
    thread.setParent(None)
    _ORPHANS.add(thread)
    thread.finished.connect(lambda: _release(thread))
    if thread.isFinished():
        _release(thread)


def wait_for_orphans() -> None:
    """Called once the window is gone, before the process ends: a thread
    still running at interpreter exit is destroyed, and Qt aborts the
    process for that. Every orphan ends on its own (the runner checks its
    stop flag between steps, encodes have deadlines, requests time out),
    so this waits rather than bounds."""
    for thread in list(_ORPHANS):
        if thread.isRunning():
            log.info("Waiting for a background step to finish before exit")
            thread.wait()
        _release(thread)


def _release(thread: QThread) -> None:
    if thread in _ORPHANS:
        _ORPHANS.discard(thread)
        thread.deleteLater()


def _section(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("sectionTitle")
    label.setTextFormat(Qt.PlainText)
    return label


def _hint(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("hint")
    label.setWordWrap(True)
    label.setTextFormat(Qt.PlainText)
    return label


def _verbatim(text) -> str:
    """Text for a tooltip or a message box, which render HTML whenever the
    text looks like it. The log is other people's writing, so it is escaped
    and always sent as rich text: escaped-only text would show '&amp;'."""
    text = str(text or "")
    if not text:
        return ""
    return "<span>{}</span>".format(html.escape(text).replace("\n", "<br>"))


def _inside(root, candidate) -> bool:
    """Whether candidate lies under root, by path text alone: resolve() on
    a UNC path can stall the GUI thread while the share wakes up."""
    root = os.path.normcase(os.path.normpath(os.path.abspath(str(root)))).rstrip("\\/")
    candidate = os.path.normcase(os.path.normpath(os.path.abspath(str(candidate))))
    return candidate.startswith(root + os.sep)


def _when(stamp: str) -> str:
    """A timestamp the way an editor reads one: local time, no seconds."""
    if not stamp:
        return ""
    try:
        moment = datetime.fromisoformat(stamp)
    except ValueError:
        return stamp[:16].replace("T", " ")
    if moment.tzinfo is not None:
        moment = moment.astimezone()
    return moment.strftime("%d %b %H:%M")


def _ref_label(ref) -> str:
    name = getattr(ref, "name", "")
    return "{} v{}".format(name, getattr(ref, "version", 0)) if name else "none"


def _normalised(title: str) -> str:
    return " ".join(title.casefold().split())


def _progress_text(job) -> str:
    """'clips 12/40' once, whether the worker wrote the stage into the
    progress text or left it in its own column."""
    stage = str(getattr(job, "stage", "") or "")
    progress = str(getattr(job, "progress", "") or "")
    if stage and progress and not progress.startswith(stage):
        return "{} {}".format(stage, progress)
    return progress or stage


def export_target(folder: Path, export_path: str) -> Optional[Path]:
    """The file Open export may hand to the shell: an .mp4 inside the master
    folder, or nothing.

    export_path comes from a JSON anyone with write access to the share can
    edit, so it is never trusted to be a video, or to be in the folder at
    all: a .lnk or .exe planted there would run on the editor's machine.
    """
    if not export_path:
        return None
    try:
        candidate = Path(export_path)
        if not candidate.is_absolute():
            candidate = Path(folder) / candidate
        candidate = Path(os.path.normpath(os.path.abspath(str(candidate))))
        if candidate.suffix.lower() != ".mp4" or not _inside(folder, candidate):
            return None
    except (OSError, ValueError):
        return None
    return candidate


def job_folder(folder: Path, job) -> Optional[Path]:
    """Where a job's production lives, derived from ids that passed the
    checks -- never from the production_dir the share reports."""
    fid = getattr(job, "framework_id", "") or ""
    job_id = getattr(job, "id", "") or ""
    if not FRAMEWORK_ID.match(fid) or not JOB_ID.match(job_id):
        return None
    return Path(folder) / fid / "jobs" / job_id


def describe_event(event) -> str:
    """One line for whatever the worker reports: a runner event, a job, or
    a plain message."""
    if isinstance(event, str):
        return event
    message = getattr(event, "message", None)
    if message is not None:
        stage = getattr(event, "stage", "")
        total = getattr(event, "total", 0) or 0
        done = getattr(event, "done", 0) or 0
        progress = (" ({}%)".format(done // 10) if total == 1000 else
                    " ({}/{})".format(done, total) if total else "")
        return "[{}] {}{}".format(stage, message, progress) if stage else "{}{}".format(message, progress)
    title = getattr(event, "title", None)
    status = getattr(event, "status", None)
    if title is not None and status is not None:
        return "{}: {}".format(str(title)[:60], STATUS_WORDS.get(status, status))
    return str(event)


def _existing_record(master: MasterLog, fid: str):
    try:
        return master.record(fid)
    except (KeyError, ValueError):
        return None


# ------------------------------------------------------------- threads
class _LogLoader(QThread):
    """Reads the share off the GUI thread and hands back one snapshot."""
    loaded = Signal(object)                # (MasterLog, records, jobs)
    failed = Signal(str)

    def __init__(self, folder: Path, master: Optional[MasterLog], parent=None):
        super().__init__(parent)
        self.folder = folder
        self.master = master

    def run(self):
        try:
            master = self.master or MasterLog(self.folder)
            records = list(master.records())
            jobs = list(master.jobs())
        except Exception as exc:                                       # noqa: BLE001
            log.warning("Master log at %s could not be read: %s: %s", self.folder, type(exc).__name__, exc)
            self.failed.emit("{}: {}".format(type(exc).__name__, exc))
            return
        self.loaded.emit((master, records, jobs))


class _LogWriter(QThread):
    """One change to the shared log, off the GUI thread. A write waits for
    the cross-machine lock and retries while Excel holds a sheet -- over a
    minute in the worst case -- and the window must stay alive through it."""
    done = Signal(object)
    failed = Signal(object)                # the exception itself

    def __init__(self, action, parent=None):
        super().__init__(parent)
        self.action = action

    def run(self):
        try:
            result = self.action()
        except Exception as exc:                                       # noqa: BLE001 - shown to the person
            self.failed.emit(exc)
            return
        self.done.emit(result)


class _WorkerThread(QThread):
    event = Signal(object)
    crashed = Signal(str)

    def __init__(self, worker: MasterWorker, parent=None):
        super().__init__(parent)
        self.worker = worker

    def run(self):
        try:
            self.worker.run_forever()
        except Exception as exc:                                       # noqa: BLE001
            log.exception("master worker crashed")
            self.crashed.emit("{}: {}".format(type(exc).__name__, exc))


# ------------------------------------------------------------- dialogs
class RecordDialog(QDialog):
    """New or edited framework record. Saves the record and copies the
    chosen framework files into the master folder's library; it never
    queues or starts anything."""

    def __init__(self, master: MasterLog, config: Config, record: Optional[MasterRecord] = None, parent=None):
        super().__init__(parent)
        self.master = master
        self.record = record
        self.saved: Optional[MasterRecord] = None
        self._writer: Optional[_LogWriter] = None
        self._outcome = None                   # what the save thread reported, until finished lands
        editing = record is not None
        self.setWindowTitle("Edit framework record" if editing else "New framework record")
        self.setMinimumWidth(640)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)
        outer.addWidget(_section("Edit framework record" if editing else "New framework record"))
        outer.addWidget(_hint("One record per framework. Its id is the folder name inside the master log, "
                              "and the sheet the editors type titles into lives there."))

        form = QFormLayout()
        form.setSpacing(8)
        self.fid = QLineEdit(record.framework_id if editing else "")
        self.fid.setPlaceholderText("lower-case letters, digits and hyphens, e.g. family-drama")
        self.fid.setReadOnly(editing)
        self.niche = QLineEdit(record.niche if editing else "")
        self.niche.setPlaceholderText("e.g. Family drama")
        self.editor = QLineEdit(record.editor_name if editing else (config.editor_name or ""))
        self.email = QLineEdit(record.email if editing else "")
        self.email.setPlaceholderText("where the done / failed emails go (optional)")
        self.language = QLineEdit(record.language if editing else "Urdu")
        self.minutes = QDoubleSpinBox()
        self.minutes.setRange(1, 240)
        self.minutes.setValue(float(record.target_minutes) if editing else 20.0)
        self.minutes.setSuffix(" min")
        settings = dict(getattr(record, "generation_settings", None) or {}) if editing else {}
        self.limit = QSpinBox()
        self.limit.setRange(0, 5000)
        self.limit.setSpecialValueText("none: live titles are refused")
        self.limit.setSuffix(" clips per title")
        self.limit.setValue(int(settings.get("max_generations") or 0) if editing else 200)
        self.seconds = QDoubleSpinBox()
        self.seconds.setRange(0, 120)
        self.seconds.setSpecialValueText("provider default")
        self.seconds.setSuffix(" s per clip")
        self.seconds.setValue(float(settings.get("max_seconds") or 0))
        self.serial_label = QLabel(getattr(record, "serial", "") if editing and getattr(record, "serial", "")
                                   else "given on save (FW-001, FW-002, …)")
        self.serial_label.setObjectName("hint")
        form.addRow("Number", self.serial_label)
        form.addRow("Framework id", self.fid)
        form.addRow("Niche", self.niche)
        form.addRow("Editor", self.editor)
        form.addRow("Email", self.email)
        form.addRow("Language", self.language)
        form.addRow("Target length", self.minutes)
        form.addRow("Generation limit", self.limit)
        form.addRow("Clip length", self.seconds)
        outer.addLayout(form)

        outer.addWidget(_section("Frameworks"))
        files = QFormLayout()
        files.setSpacing(8)
        self.files: Dict[str, QLineEdit] = {}
        for kind, label in FRAMEWORK_KINDS:
            row = QHBoxLayout()
            field = QLineEdit()
            current = getattr(record, kind + "_framework", None) if editing else None
            field.setPlaceholderText("keeping {}".format(_ref_label(current)) if editing and getattr(current, "name", "")
                                     else "choose a .txt file")
            browse = QPushButton("Browse…")
            browse.clicked.connect(lambda _=False, f=field: self._browse(f))
            row.addWidget(field, 1)
            row.addWidget(browse)
            files.addRow(label, row)
            self.files[kind] = field
        outer.addLayout(files)
        outer.addWidget(_hint("Each file is copied into the master folder's library, so every machine that "
                              "runs the worker reads the same text. Choosing a file again makes a new "
                              "version; a title already running keeps the version it started with."))
        self.enabled = QCheckBox("Enabled: the worker picks this record's titles up")
        self.enabled.setChecked(bool(record.enabled) if editing else True)
        outer.addWidget(self.enabled)
        self.notes = QPlainTextEdit(record.notes if editing else "")
        self.notes.setPlaceholderText("Optional notes for the editors.")
        self.notes.setMaximumHeight(70)
        outer.addWidget(self.notes)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_save = QPushButton("Save")
        self.btn_save.setObjectName("primary")
        self.btn_save.clicked.connect(self._save)
        buttons.addWidget(self.btn_cancel)
        buttons.addWidget(self.btn_save)
        outer.addLayout(buttons)

    def _browse(self, field: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(self, "Choose the framework file", field.text() or "",
                                              "Text (*.txt *.md);;All files (*)")
        if path:
            field.setText(path)

    def saving(self) -> bool:
        return self._writer is not None

    def _save(self):
        """Checks that need nothing from the share happen here; the rest --
        the duplicate check, the save and the uploads, each waiting for the
        cross-machine lock -- runs on a thread and comes back to _saved or
        _save_failed, so the window keeps painting through a slow share."""
        if self.saving():
            return
        title = self.windowTitle()
        fid = self.fid.text().strip().lower()
        if not FRAMEWORK_ID.match(fid):
            QMessageBox.information(self, title, "The framework id becomes a folder name: lower-case letters, "
                                    "digits and hyphens only, e.g. family-drama.")
            return
        niche = self.niche.text().strip()
        editor = self.editor.text().strip()
        if not niche or not editor:
            QMessageBox.information(self, title, "Give the record a niche and an editor.")
            return
        email = self.email.text().strip()
        if email and not EMAIL.match(email):
            QMessageBox.information(self, title, "That does not look like one email address.")
            return
        files = {kind: field.text().strip() for kind, field in self.files.items()}
        new = self.record is None
        if new and (not files["script"] or not files["prompt"]):
            QMessageBox.information(self, title, "Choose the script framework and the scene-prompt framework "
                                    "files. The hook writer is optional.")
            return
        for kind, path in files.items():
            if path and not Path(path).is_file():
                QMessageBox.information(self, title, _verbatim("Not a file: {}".format(path)))
                return
        settings = dict(getattr(self.record, "generation_settings", None) or {}) if not new else {}
        settings["max_generations"] = int(self.limit.value())
        settings["max_seconds"] = float(self.seconds.value())
        fields = dict(niche=niche, editor_name=editor, email=email, language=self.language.text().strip() or "Urdu",
                      target_minutes=float(self.minutes.value()), enabled=self.enabled.isChecked(),
                      generation_settings=settings, notes=self.notes.toPlainText().strip())
        if new:
            record = MasterRecord(framework_id=fid, hook_framework=FrameworkRef(), script_framework=FrameworkRef(),
                                  prompt_framework=FrameworkRef(), created=now(), **fields)
        else:
            # A copy: the page paints from the original while the thread works.
            record = dataclasses.replace(self.record, **fields)
        master = self.master

        def action():
            if new and _existing_record(master, fid) is not None:
                raise ValueError("A record with the id '{}' already exists.".format(fid))
            master.save_record(record)
            # From here the record is on the share; a framework that could
            # not be uploaded is reported, not retried.
            try:
                for kind, path in files.items():
                    if path:
                        setattr(record, kind + "_framework", master.upload_framework(fid, kind, Path(path)))
                if any(files.values()):
                    master.save_record(record)
            except (OSError, ValueError, KeyError, TypeError) as exc:
                return record, exc
            return record, None

        self._outcome = None
        self._writer = _LogWriter(action, self)
        self._writer.done.connect(self._saved)
        self._writer.failed.connect(self._save_failed)
        self._writer.finished.connect(self._on_writer_finished)
        self._writer.finished.connect(self._writer.deleteLater)
        self._writer.start()
        self._paint_saving()

    def _paint_saving(self):
        saving = self.saving()
        self.btn_save.setEnabled(not saving)
        self.btn_cancel.setEnabled(not saving)
        self.btn_save.setText("Saving…" if saving else "Save")

    # done / failed arrive before the thread's own finished signal; the
    # dialog only closes or reports once the thread is really over.
    def _saved(self, result):
        self._outcome = ("saved", result)

    def _save_failed(self, exc):
        self._outcome = ("failed", exc)

    def _on_writer_finished(self):
        if self.sender() is not self._writer:
            return
        self._writer = None
        self._paint_saving()
        kind, payload = self._outcome or ("failed", RuntimeError("the save thread ended without a result"))
        self._outcome = None
        title = self.windowTitle()
        if kind == "failed":
            log.warning("Record could not be saved: %s", payload)
            QMessageBox.warning(self, title, _verbatim("The record could not be saved: {}".format(payload)))
            return
        record, upload_error = payload
        if upload_error is not None:
            log.warning("Record %s: a framework could not be uploaded: %s", record.framework_id, upload_error)
            QMessageBox.warning(self, title, _verbatim(
                "The record was saved, but a framework could not be uploaded: {}\n\nUse Edit record… to add "
                "it.".format(upload_error)))
        self.saved = record
        self.accept()

    def reject(self):
        # Closing the dialog while its thread is on the share would delete
        # a running QThread with it.
        if not self.saving():
            super().reject()

    def accept(self):
        if not self.saving():
            super().accept()

    def closeEvent(self, event):
        if self.saving():
            event.ignore()
            return
        super().closeEvent(event)


class EmailSettingsDialog(QDialog):
    """Where the done / failed emails come from. The password goes into the
    sealed credentials store, never into the settings file."""

    def __init__(self, credentials: Credentials, parent=None):
        super().__init__(parent)
        self.credentials = credentials
        self.settings = EmailSettings.load()
        self.setWindowTitle("Email settings")
        self.setMinimumWidth(560)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)
        outer.addWidget(_section("Email settings"))
        outer.addWidget(_hint("The worker emails a record's editor when a title finishes or fails. "
                              "The password is sealed to your Windows account like the API keys."))
        self.enabled = QCheckBox("Send emails")
        self.enabled.setChecked(bool(getattr(self.settings, "enabled", False)))
        outer.addWidget(self.enabled)
        form = QFormLayout()
        form.setSpacing(8)
        self.host = QLineEdit(getattr(self.settings, "host", "") or "")
        self.host.setPlaceholderText("smtp.gmail.com")
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(int(getattr(self.settings, "port", 587) or 587))
        self.security = QComboBox()
        self.security.addItem("STARTTLS (port 587)", "starttls")
        self.security.addItem("SSL (port 465)", "ssl")
        self.security.addItem("None", "none")
        current = getattr(self.settings, "security", None)
        if not current:
            current = "starttls" if getattr(self.settings, "use_tls", True) else "none"
        self.security.setCurrentIndex(max(0, self.security.findData(current)))
        self.username = QLineEdit(getattr(self.settings, "username", "") or "")
        self.sender = QLineEdit(getattr(self.settings, "sender", "") or "")
        self.sender.setPlaceholderText("the From address")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        # Never a character of it: the masked form the API-key screen shows
        # was made for long random keys and would print most of a short
        # mail password.
        self.password.setPlaceholderText("saved (hidden); type here to replace it" if credentials.get("smtp")
                                         else "not set")
        form.addRow("Mail server", self.host)
        form.addRow("Port", self.port)
        form.addRow("Security", self.security)
        form.addRow("Username", self.username)
        form.addRow("Sender", self.sender)
        form.addRow("Password", self.password)
        outer.addLayout(form)
        outer.addWidget(_section("Send an email when a title is"))
        wanted = set(getattr(self.settings, "notify_on", None) or ["video_done", "failed"])
        self.notify: Dict[str, QCheckBox] = {}
        for status in MAIL_STATUSES:
            box = QCheckBox(STATUS_WORDS.get(status, status))
            box.setChecked(status in wanted)
            outer.addWidget(box)
            self.notify[status] = box
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save")
        save.setObjectName("primary")
        save.clicked.connect(self._save)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        outer.addLayout(buttons)

    def _save(self):
        settings = self.settings
        settings.enabled = self.enabled.isChecked()
        settings.host = self.host.text().strip()
        settings.port = int(self.port.value())
        settings.username = self.username.text().strip()
        settings.sender = self.sender.text().strip()
        security = self.security.currentData() or "starttls"
        settings.security = security
        settings.use_tls = security == "starttls"
        settings.notify_on = [status for status, box in self.notify.items() if box.isChecked()]
        if settings.enabled and (not settings.host or not settings.sender):
            QMessageBox.information(self, "Email settings", "A mail server and a sender address are needed.")
            return
        try:
            settings.save()
        except OSError as exc:
            QMessageBox.warning(self, "Email settings", "The settings could not be saved: {}".format(exc))
            return
        if self.password.text().strip():
            try:
                self.credentials.set("smtp", self.password.text())
            except (KeyError, OSError) as exc:
                QMessageBox.warning(self, "Email settings", "The password could not be sealed: {}".format(exc))
                return
        self.accept()


# ---------------------------------------------------------------- page
class MasterLogPage(QWidget):
    back_requested = Signal()
    open_in_editor = Signal(str)           # a clips folder to open in the editor

    def __init__(self, config: Config, credentials: Credentials, parent=None):
        super().__init__(parent)
        self.config = config
        self.credentials = credentials
        self.folder: Optional[Path] = None
        self.log: Optional[MasterLog] = None
        self._records: List[MasterRecord] = []
        self._jobs: List[TitleJob] = []
        self._selected_fid = ""
        self._loader: Optional[_LogLoader] = None
        self._writer: Optional[_LogWriter] = None
        self._pending = None                   # (what, on_done, on_error) of the write in flight
        self._reload_wanted = False
        self._load_error = ""
        self.worker: Optional[MasterWorker] = None
        self.worker_thread: Optional[_WorkerThread] = None
        self.stop_event = threading.Event()
        self._live = False
        self._last_event = ""
        self.hostname = default_worker_id()
        # Worker events arrive many times a second during a run; the share is
        # re-read at most once every 1.5 s, and every POLL_MS while a folder
        # is open -- worker or not -- so titles added on another machine
        # still appear and Pause acts on a row that is at most that old.
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.setInterval(1500)
        self._refresh_timer.timeout.connect(self.refresh)
        self._closing = False
        self._poll_timer = QTimer(self)
        self._poll_timer.setInterval(POLL_MS)
        self._poll_timer.timeout.connect(self.refresh)
        self._build()

    # -- layout -------------------------------------------------------------
    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(theme.SPACE_2, theme.SPACE_1, theme.SPACE_2, theme.SPACE_1)
        outer.setSpacing(theme.SPACE_1)

        bar = QHBoxLayout()
        back = QPushButton("‹ Editor")
        back.clicked.connect(self.back_requested.emit)
        heading = QLabel("Master log")
        heading.setObjectName("title")
        self.folder_label = _hint("No folder open")
        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.setObjectName("quiet")
        self.btn_refresh.setToolTip("Read the log again")
        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_folder = QPushButton("Change folder…")
        self.btn_folder.setObjectName("quiet")
        self.btn_folder.clicked.connect(self.change_folder)
        self.btn_email = QPushButton("Email settings…")
        self.btn_email.setObjectName("quiet")
        self.btn_email.clicked.connect(lambda: EmailSettingsDialog(self.credentials, self).exec())
        bar.addWidget(back)
        bar.addSpacing(theme.SPACE_2)
        bar.addWidget(heading)
        bar.addSpacing(theme.SPACE_1)
        bar.addWidget(self.folder_label, 1)
        bar.addWidget(self.btn_refresh)
        bar.addWidget(self.btn_folder)
        bar.addWidget(self.btn_email)
        outer.addLayout(bar)

        split = QSplitter(Qt.Horizontal)

        # -- records ------------------------------------------------------
        left = QFrame()
        left.setObjectName("card")
        left_box = QVBoxLayout(left)
        left_box.setContentsMargins(12, 10, 12, 10)
        left_box.setSpacing(theme.SPACE_1)
        left_box.addWidget(_section("Framework records"))
        self.records_list = QListWidget()
        self.records_list.setObjectName("recentList")
        self.records_list.currentItemChanged.connect(self._on_record_selected)
        left_box.addWidget(self.records_list, 1)
        self.btn_new_record = QPushButton("New framework record…")
        self.btn_new_record.clicked.connect(self.new_record)
        self.btn_edit_record = QPushButton("Edit record…")
        self.btn_edit_record.setObjectName("quiet")
        self.btn_edit_record.clicked.connect(self.edit_record)
        left_box.addWidget(self.btn_new_record)
        left_box.addWidget(self.btn_edit_record)
        left.setMinimumWidth(260)
        left.setMaximumWidth(380)

        # -- titles -------------------------------------------------------
        right = QFrame()
        right.setObjectName("card")
        right_box = QVBoxLayout(right)
        right_box.setContentsMargins(12, 10, 12, 10)
        right_box.setSpacing(theme.SPACE_1)
        head = QHBoxLayout()
        self.record_heading = QLabel("No record selected")
        self.record_heading.setObjectName("sectionTitle")
        self.record_heading.setTextFormat(Qt.PlainText)
        self.record_badge = QLabel("")
        self.record_badge.setObjectName("stateBadge")
        self.record_badge.setVisible(False)
        head.addWidget(self.record_heading, 1)
        head.addWidget(self.record_badge)
        right_box.addLayout(head)
        self.record_hint = _hint("")
        right_box.addWidget(self.record_hint)

        add_row = QHBoxLayout()
        add_row.setSpacing(theme.SPACE_1)
        self.title_field = QLineEdit()
        self.title_field.setPlaceholderText("A new title for this framework")
        self.title_field.returnPressed.connect(self.add_title)
        self.btn_add = QPushButton("Add title")
        self.btn_add.clicked.connect(self.add_title)
        add_row.addWidget(self.title_field, 1)
        add_row.addWidget(self.btn_add)
        right_box.addLayout(add_row)

        actions = QHBoxLayout()
        actions.setSpacing(theme.SPACE_1)
        self.btn_sheet = QPushButton("Refresh from sheet")
        self.btn_sheet.setToolTip("Queue the titles editors typed into add-titles.csv in this record's folder")
        self.btn_sheet.clicked.connect(self.refresh_from_sheet)
        self.btn_open_folder = QPushButton("Open folder")
        self.btn_open_folder.setObjectName("quiet")
        self.btn_open_folder.clicked.connect(self.open_record_folder)
        self.btn_export = QPushButton("Open export")
        self.btn_export.clicked.connect(self.open_export)
        self.btn_clips = QPushButton("Open clips in editor")
        self.btn_clips.setObjectName("quiet")
        self.btn_clips.clicked.connect(self.open_clips)
        self.btn_retry = QPushButton("Retry")
        self.btn_retry.setToolTip("Queue a failed title again; the clips it already paid for are reused")
        self.btn_retry.clicked.connect(self.retry_job)
        self.btn_pause = QPushButton("Pause")
        self.btn_pause.setToolTip("Hold a queued title so the worker skips it, or release a held one")
        self.btn_pause.clicked.connect(self.toggle_pause)
        for button in (self.btn_sheet, self.btn_open_folder):
            actions.addWidget(button)
        actions.addStretch(1)
        for button in (self.btn_export, self.btn_clips, self.btn_retry, self.btn_pause):
            actions.addWidget(button)
        right_box.addLayout(actions)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(list(COLUMNS))
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(32)
        self.table.setShowGrid(False)
        # One line per title: a long title is cut with an ellipsis (the full
        # text is its tooltip) rather than wrapped into a tall row. The title
        # takes whatever width the other columns leave, but never less than
        # TITLE_MIN_WIDTH: a stretch column would shrink to nothing on a
        # narrow window, and the title is the one thing an editor reads.
        self.table.setWordWrap(False)
        self.table.setTextElideMode(Qt.ElideRight)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        for column in range(len(COLUMNS)):
            header.setSectionResizeMode(column, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(COL_TITLE, QHeaderView.Interactive)
        header.setSectionResizeMode(COL_EXPORT, QHeaderView.Interactive)
        header.resizeSection(COL_EXPORT, 220)
        self.table.setStyleSheet(
            "QTableWidget {{ background: {input}; border: 1px solid {soft}; border-radius: {r}px;"
            " color: {text}; font-size: {f}px; selection-background-color: {sel}; selection-color: {accent}; }}"
            "QTableWidget::item {{ padding: 2px 8px; }}"
            "QHeaderView::section {{ background: {panel}; color: {muted}; border: none;"
            " border-bottom: 1px solid {border}; padding: 6px 8px; font-weight: 600; font-size: {fl}px; }}"
            "QTableCornerButton::section {{ background: {panel}; border: none; }}".format(
                input=theme.BG_INPUT, soft=theme.BORDER_SOFT, r=theme.RADIUS, text=theme.TEXT_SECOND,
                f=theme.FONT_BODY, sel=theme.SELECT_BG, accent=theme.ACCENT, panel=theme.BG_PANEL,
                muted=theme.TEXT_MUTED, border=theme.BORDER, fl=theme.FONT_LABEL))
        self.table.itemSelectionChanged.connect(self._paint_job_actions)
        right_box.addWidget(self.table, 1)
        self.job_details = _hint("")
        self.job_details.setTextInteractionFlags(Qt.TextSelectableByMouse)
        right_box.addWidget(self.job_details)

        split.addWidget(left)
        split.addWidget(right)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setSizes([300, 1000])
        outer.addWidget(split, 1)

        # -- worker -------------------------------------------------------
        worker = QFrame()
        worker.setObjectName("card")
        worker_box = QVBoxLayout(worker)
        worker_box.setContentsMargins(12, 10, 12, 10)
        worker_box.setSpacing(theme.SPACE_1)
        worker_box.addWidget(_section("Worker"))
        self.status_line = QLabel("")
        self.status_line.setObjectName("readyBanner")
        self.status_line.setWordWrap(True)
        self.status_line.setTextFormat(Qt.PlainText)
        worker_box.addWidget(self.status_line)
        controls = QHBoxLayout()
        controls.setSpacing(theme.SPACE_1)
        self.btn_start = QPushButton("Start worker")
        self.btn_start.setObjectName("primary")
        self.btn_start.setToolTip("Take every queued title through script, prompts, clips, edit and export "
                                  "with no further clicks. In live mode this spends money.")
        self.btn_start.clicked.connect(self.start_worker)
        self.btn_stop = QPushButton("Stop worker")
        self.btn_stop.clicked.connect(self.stop_worker)
        self.chk_mock = QCheckBox("Test mode: mock providers — no keys, no cost, test-pattern clips")
        self.chk_mock.setChecked(True)
        self.budget_hint = _hint("")
        controls.addWidget(self.btn_start)
        controls.addWidget(self.btn_stop)
        controls.addSpacing(theme.SPACE_1)
        controls.addWidget(self.chk_mock)
        controls.addStretch(1)
        controls.addWidget(self.budget_hint)
        worker_box.addLayout(controls)
        self.events = QListWidget()
        self.events.setObjectName("recentList")
        self.events.setMaximumHeight(150)
        worker_box.addWidget(self.events)
        outer.addWidget(worker)

        self._paint_records()
        self._paint_worker()

    # -- loading ------------------------------------------------------------
    def clear(self):
        """Forget the folder on screen (sign-out). A running worker keeps its
        folder: it is paying for clips and must not be cut loose by a
        sign-out; sign_out() refuses until it is stopped."""
        if self._worker_running():
            return
        self._poll_timer.stop()
        self._refresh_timer.stop()
        self.folder = None
        self.log = None
        self._records = []
        self._jobs = []
        self._selected_fid = ""
        self._load_error = ""
        self.folder_label.setText("")
        self.folder_label.setToolTip("")
        self.events.clear()
        self._paint_records()
        self._paint_worker()

    def load(self, folder):
        """Open a master folder. The read happens on a thread; the screen
        shows 'reading' until it lands."""
        self._closing = False
        folder = Path(folder)
        if self.folder is not None and folder != self.folder and self._worker_running():
            QMessageBox.information(self, "Master log", "Stop the worker before opening another folder.")
            return
        if folder != self.folder:
            self.log = None
            self._records = []
            self._jobs = []
            self._selected_fid = ""
            self._paint_records()
        self.folder = folder
        self._load_error = ""
        self.folder_label.setText(str(folder))
        self.folder_label.setToolTip(_verbatim(folder))
        self._poll_timer.start()
        self.refresh()

    def refresh(self):
        if self.folder is None or self._closing:
            return
        if self._loader is not None and self._loader.isRunning():
            self._reload_wanted = True
            return
        self._reload_wanted = False
        # Only a log for this folder is reused; a read is tagged with the
        # folder it was started for so a late one from an earlier folder is
        # dropped rather than painted under the new label.
        master = self.log if self.log is not None and self.log.folder == self.folder else None
        self._loader = _LogLoader(self.folder, master, self)
        self._loader.loaded.connect(self._on_loaded)
        self._loader.failed.connect(self._on_load_failed)
        self._loader.finished.connect(self._on_loader_finished)
        self._loader.finished.connect(self._loader.deleteLater)
        self._loader.start()
        self._paint_worker()

    def _stale(self) -> bool:
        """Whether the read that just reported was started for another
        folder than the one open now."""
        loader = self.sender()
        folder = getattr(loader, "folder", None)
        if folder is not None and folder != self.folder:
            log.info("Dropped a read of %s: the folder is now %s", folder, self.folder)
            return True
        return False

    def _on_loaded(self, snapshot):
        if self._stale():
            return
        master, records, jobs = snapshot
        self.log = master
        self._records = list(records)
        self._jobs = list(jobs)
        self._load_error = ""
        self._paint_records()
        self._paint_worker()

    def _on_load_failed(self, message: str):
        if self._stale():
            return
        self._load_error = message
        self._paint_worker()

    def _on_loader_finished(self):
        # A read that is no longer the current one (a later refresh already
        # replaced it) must not clear the newer loader's slot.
        if self.sender() is not self._loader:
            return
        self._loader = None
        if self._reload_wanted:
            self.refresh()

    def wait_until_loaded(self, timeout_ms: int = 10000) -> bool:
        """Spin the event loop until the first snapshot is painted. For tests
        and scripts; the window itself never waits."""
        app = QApplication.instance()
        deadline = time.monotonic() + timeout_ms / 1000.0
        while time.monotonic() < deadline:
            if app is not None:
                app.processEvents()
            if self._load_error:
                return False
            if self.log is not None and self._loader is None and not self._reload_wanted:
                return True
            time.sleep(0.02)
        return False

    def wait_until_idle(self, timeout_ms: int = 10000) -> bool:
        """Spin the event loop until no write and no read is in flight and
        the last snapshot is painted. For tests and scripts."""
        app = QApplication.instance()
        deadline = time.monotonic() + timeout_ms / 1000.0
        while time.monotonic() < deadline:
            if app is not None:
                app.processEvents()
            if self._writer is None and self._loader is None and not self._reload_wanted:
                return True
            time.sleep(0.02)
        return False

    def _writing(self) -> bool:
        return self._writer is not None

    def _write(self, what: str, action, on_done, on_error=None) -> bool:
        """Run one log change on a thread and hand its result back on the
        GUI thread (the slots are this widget's own methods, so Qt queues
        them here). One at a time: a second press while the first is still
        waiting on the share is answered in the event list, not queued."""
        if self.log is None:
            return False
        if self._writing():
            self._say("Still saving the last change; try again in a moment.")
            return False
        self._pending = (what, on_done, on_error)
        self._writer = _LogWriter(action, self)
        self._writer.done.connect(self._on_write_done)
        self._writer.failed.connect(self._on_write_failed)
        self._writer.finished.connect(self._on_writer_finished)
        self._writer.finished.connect(self._writer.deleteLater)
        self._writer.start()
        self._paint_record()
        return True

    def _on_write_done(self, result):
        if self._pending is None or self.sender() is not self._writer:
            return                                 # a write the closing window gave up on
        _, on_done, _ = self._pending
        on_done(result)

    def _on_write_failed(self, exc):
        if self._pending is None or self.sender() is not self._writer:
            return
        what, _, on_error = self._pending
        if on_error is not None:
            on_error(exc)
        else:
            QMessageBox.warning(self, what, _verbatim(exc))

    def _on_writer_finished(self):
        if self.sender() is not self._writer:
            return
        self._writer = None
        self._pending = None
        self._paint_record()

    def status_text(self) -> str:
        return self.status_line.text()

    def change_folder(self):
        if self._worker_running():
            QMessageBox.information(self, "Master log", "Stop the worker before changing the folder.")
            return
        chosen = QFileDialog.getExistingDirectory(
            self, "Choose the master log folder (the shared folder every editor's machine can reach)",
            str(self.folder) if self.folder else "")
        if not chosen:
            return
        self.config.master_log_dir = chosen
        try:
            self.config.save(Path.cwd())
        except OSError as exc:
            log.warning("config.json could not be saved: %s", exc)
        self.load(Path(chosen))

    # -- painting -----------------------------------------------------------
    def _record(self, fid: str) -> Optional[MasterRecord]:
        return next((r for r in self._records if r.framework_id == fid), None)

    def _paint_records(self):
        wanted = self._selected_fid
        self.records_list.blockSignals(True)
        self.records_list.clear()
        chosen_row = -1
        for row, record in enumerate(self._records):
            text = "{}  ·  {}  ·  {}  ·  {}".format(getattr(record, "serial", "") or "FW-?", record.framework_id,
                                                    record.niche, record.editor_name)
            if not record.enabled:
                text += "  ·  off"
            self.records_list.addItem(text)
            item = self.records_list.item(row)
            item.setData(Qt.UserRole, record.framework_id)
            item.setToolTip(_verbatim(record.email or "no email"))
            if record.framework_id == wanted:
                chosen_row = row
        if chosen_row < 0 and self._records:
            chosen_row = 0
        if chosen_row >= 0:
            self.records_list.setCurrentRow(chosen_row)
            self._selected_fid = self._records[chosen_row].framework_id
        else:
            self._selected_fid = ""
        self.records_list.blockSignals(False)
        self.btn_new_record.setEnabled(self.log is not None)
        self.btn_edit_record.setEnabled(self.log is not None and bool(self._selected_fid))
        self._paint_record()

    def _on_record_selected(self, current, previous):
        self._selected_fid = current.data(Qt.UserRole) if current is not None else ""
        self.btn_edit_record.setEnabled(self.log is not None and bool(self._selected_fid))
        self._paint_record()

    def _paint_record(self):
        record = self._record(self._selected_fid)
        has = record is not None
        writing = self._writing()
        self.title_field.setEnabled(has and self.log is not None)
        self.btn_open_folder.setEnabled(has and self.log is not None)
        for widget in (self.btn_add, self.btn_sheet):
            widget.setEnabled(has and self.log is not None and not writing)
        if record is None:
            self.record_heading.setText("No record selected")
            self.record_hint.setText("Press New framework record… to add the first one." if self.log is not None
                                     else "")
            self.record_badge.setVisible(False)
            self.table.setRowCount(0)
            self.job_details.setText("")
            self._paint_job_actions()
            return
        self.record_heading.setText("{}  ·  {}  ·  {}  ·  {}".format(
            getattr(record, "serial", "") or "FW-?", record.framework_id, record.niche, record.editor_name))
        settings = getattr(record, "generation_settings", None) or {}
        cap = settings.get("max_generations")
        self.record_hint.setText(
            "{}  ·  about {:.0f} min  ·  hook: {}  ·  script: {}  ·  prompts: {}  ·  limit: {}  ·  email: {}".format(
                record.language, float(record.target_minutes or 0), _ref_label(record.hook_framework),
                _ref_label(record.script_framework), _ref_label(record.prompt_framework),
                "{} clips".format(cap) if cap else "none (live titles are refused)", record.email or "none"))
        self.record_badge.setText("Enabled" if record.enabled else "Disabled")
        self.record_badge.setProperty("state", "approved" if record.enabled else "rejected")
        self.record_badge.style().unpolish(self.record_badge)
        self.record_badge.style().polish(self.record_badge)
        self.record_badge.setVisible(True)
        self._paint_jobs(record)

    def _queue_positions(self) -> Dict[str, int]:
        """Where each queued title stands in the worker's order: oldest first
        across every enabled record, ties in the order the log holds them
        (the sheet's order) -- the same key the log's own pick uses."""
        enabled = {r.framework_id for r in self._records if r.enabled}
        queue = sorted(((index, j) for index, j in enumerate(self._jobs)
                        if j.status == "queued" and j.framework_id in enabled),
                       key=lambda pair: (pair[1].added or "", pair[0]))
        return {job.id: position + 1 for position, (_, job) in enumerate(queue)}

    def _paint_jobs(self, record: MasterRecord):
        positions = self._queue_positions()
        rank = {"queued": 1, "paused": 2, "failed": 3, "video_done": 4}

        def order(job):
            if job.status in IN_PROGRESS:
                return (0, job.added or "", job.id)
            if job.status == "queued":
                return (1, "{:08d}".format(positions.get(job.id, 0)), job.id)
            return (rank.get(job.status, 5), job.updated or job.added or "", job.id)

        rows = sorted((j for j in self._jobs if j.framework_id == record.framework_id), key=order)
        selected = self._selected_job_id()
        self.table.blockSignals(True)
        self.table.setRowCount(len(rows))
        reselect = -1
        for row, job in enumerate(rows):
            position = positions.get(job.id)
            export = Path(job.export_path).name if job.export_path else ""
            values = ["{}".format(position) if position else "", job.title, "", _progress_text(job),
                      job.added_by, _when(job.added), _when(job.updated), export]
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                if column == 0:
                    item.setTextAlignment(Qt.AlignCenter)
                if column == COL_TITLE:
                    item.setData(Qt.UserRole, job.id)
                    item.setToolTip(_verbatim(job.title))
                if column == COL_EXPORT and job.export_path:
                    item.setToolTip(_verbatim(job.export_path))
                self.table.setItem(row, column, item)
            self.table.setCellWidget(row, COL_STATUS, self._badge_cell(job))
            if job.id == selected:
                reselect = row
        if reselect >= 0:
            self.table.selectRow(reselect)
        self.table.blockSignals(False)
        self._fit_title_column()
        self._paint_job_actions()

    def _fit_title_column(self):
        header = self.table.horizontalHeader()
        others = sum(header.sectionSize(c) for c in range(len(COLUMNS)) if c != COL_TITLE)
        leftover = self.table.viewport().width() - others
        header.resizeSection(COL_TITLE, max(TITLE_MIN_WIDTH, leftover))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit_title_column()

    @staticmethod
    def _badge_cell(job) -> QWidget:
        """The review-state badge, left-aligned in its cell rather than
        stretched across it. The wrapper's own rule keeps the app's
        QWidget ground from painting a dark block over the row."""
        cell = QWidget()
        cell.setObjectName("badgeCell")
        cell.setStyleSheet("QWidget#badgeCell { background: transparent; }")
        box = QHBoxLayout(cell)
        box.setContentsMargins(6, 2, 6, 2)
        box.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        badge = QLabel(STATUS_WORDS.get(job.status, job.status))
        badge.setObjectName("stateBadge")
        badge.setTextFormat(Qt.PlainText)
        badge.setProperty("state", BADGE_STATE.get(job.status, "pending"))
        if job.status == "failed" and job.error:
            badge.setToolTip(_verbatim(job.error))
        elif getattr(job, "worker", ""):
            badge.setToolTip(_verbatim("on {}".format(job.worker)))
        box.addWidget(badge)
        return cell

    def _selected_job_id(self) -> str:
        rows = self.table.selectionModel().selectedRows() if self.table.selectionModel() else []
        if not rows:
            return ""
        item = self.table.item(rows[0].row(), COL_TITLE)
        return item.data(Qt.UserRole) if item is not None else ""

    def _selected_job(self) -> Optional[TitleJob]:
        job_id = self._selected_job_id()
        return next((j for j in self._jobs if j.id == job_id), None) if job_id else None

    def _paint_job_actions(self):
        job = self._selected_job()
        can_write = self.log is not None and job is not None and not self._writing()
        self.btn_export.setEnabled(job is not None and bool(job.export_path))
        self.btn_clips.setEnabled(job is not None and bool(job.production_dir))
        self.btn_retry.setEnabled(can_write and job.status == "failed")
        self.btn_pause.setEnabled(can_write and job.status in ("queued", "paused"))
        self.btn_pause.setText("Resume" if job is not None and job.status == "paused" else "Pause")
        if job is None:
            self.job_details.setText("")
            return
        parts = ["Job {}".format(job.id)]
        if getattr(job, "worker", ""):
            parts.append("worker: {}".format(job.worker))
        if job.production_dir:
            parts.append("production: {}".format(job.production_dir))
        if job.export_path:
            parts.append("export: {}".format(job.export_path))
        if job.error:
            parts.append("error: {}".format(job.error))
        history = getattr(job, "history", None) or []
        if history:
            last = history[-1]
            note = last.get("note", "") if isinstance(last, dict) else ""
            if note:
                parts.append("last note: {}".format(note))
        self.job_details.setText("   ·   ".join(parts))

    # -- record actions -----------------------------------------------------
    def new_record(self):
        if self.log is None:
            return
        dialog = RecordDialog(self.log, self.config, None, self)
        if dialog.exec() == QDialog.Accepted and dialog.saved is not None:
            self._selected_fid = dialog.saved.framework_id
            self._say("Record '{}' saved.".format(dialog.saved.framework_id))
            self.refresh()

    def edit_record(self):
        record = self._record(self._selected_fid)
        if self.log is None or record is None:
            return
        dialog = RecordDialog(self.log, self.config, record, self)
        if dialog.exec() == QDialog.Accepted and dialog.saved is not None:
            self._say("Record '{}' updated.".format(record.framework_id))
            self.refresh()

    def add_title(self):
        title = self.title_field.text().strip()
        fid = self._selected_fid
        if not title or self.log is None or not fid:
            return
        added_by = self.config.editor_name or "editor"
        master = self.log
        self._write("Add title", lambda: master.add_title(fid, title, added_by), self._title_added,
                    lambda exc: self._add_title_refused(fid, title, added_by, exc))

    def _title_added(self, job):
        self.title_field.clear()
        self._say("Added '{}' as {}.".format(job.title[:60], job.id))
        self.refresh()

    def _add_title_refused(self, fid: str, title: str, added_by: str, exc):
        """The log said no. A failed twin means Retry; a twin that is queued
        or being worked on is simply refused; only a finished twin asks
        whether to pay for a second production. Anything else is shown."""
        wanted = _normalised(title)
        twins = [j for j in self._jobs if j.framework_id == fid and _normalised(j.title) == wanted]
        if any(j.status == "failed" for j in twins):
            QMessageBox.information(self, "Add title", _verbatim(
                "{}\n\nSelect the failed title in the table and press Retry: its production folder and the "
                "clips already paid for are reused.".format(exc)))
            return
        if not twins or any(j.status != "video_done" for j in twins):
            QMessageBox.information(self, "Add title", _verbatim(exc))
            return
        answer = QMessageBox.question(
            self, "Add title", _verbatim("{}\n\nRun it again as a new production? Everything is generated, and "
                                         "paid for, a second time.".format(exc)),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        master = self.log
        if master is None:
            return
        self._write("Add title", lambda: master.add_title(fid, title, added_by, force=True), self._title_added,
                    lambda again: QMessageBox.information(self, "Add title", _verbatim(again)))

    def refresh_from_sheet(self):
        fid = self._selected_fid
        if self.log is None or not fid:
            return
        master = self.log

        def added(jobs):
            count = len(list(jobs))
            self._say("{} new title{} from the sheet for {}.".format(count, "" if count == 1 else "s", fid))
            self.refresh()

        self._write("Refresh from sheet", lambda: master.import_titles_from_csv(fid), added,
                    lambda exc: QMessageBox.warning(self, "Refresh from sheet",
                                                    _verbatim("The sheet could not be read: {}".format(exc))))

    def retry_job(self):
        job = self._selected_job()
        if self.log is None or job is None or job.status != "failed":
            return
        master = self.log

        def queued(_result):
            self._say("'{}' queued again.".format(job.title[:60]))
            self.refresh()

        self._write("Retry", lambda: master.retry(job.id), queued)

    def toggle_pause(self):
        job = self._selected_job()
        if self.log is None or job is None or job.status not in ("queued", "paused"):
            return
        by = self.config.editor_name or "editor"
        seen = job.status
        status, note = (("paused", "held by {}".format(by)) if seen == "queued"
                        else ("queued", "released by {}".format(by)))
        master = self.log

        def moved(_result):
            self._say("'{}' {}.".format(job.title[:60], STATUS_WORDS[status].lower()))
            self.refresh()

        def refused(exc):
            # The row was out of date: the log refused to move a job a
            # worker may be paying for. Say so and show the fresh row.
            self._say(str(exc))
            self.refresh()
            QMessageBox.information(self, "Master log", _verbatim(exc))

        # expect= makes the log write nothing unless the job still has the
        # status this row showed, whatever another machine did since.
        self._write("Master log", lambda: master.set_status(job.id, status, note=note, expect=seen), moved,
                    refused)

    def open_record_folder(self):
        fid = self._selected_fid
        if self.folder is None or not FRAMEWORK_ID.match(fid or ""):
            return
        self._open(self.folder / fid)

    def open_export(self):
        """The finished video, if it is a video inside the master folder;
        otherwise the job's own folder, never whatever path the share names."""
        job = self._selected_job()
        if job is None or self.folder is None:
            return
        target = export_target(self.folder, job.export_path)
        if target is None:
            target = job_folder(self.folder, job)
            if target is None:
                self._say("Job {} has ids that cannot be opened.".format(job.id))
                return
            self._say("The export path for '{}' is not a video inside the master folder; opening the job "
                      "folder instead.".format(job.title[:60]))
        self._open(target)

    def open_clips(self):
        job = self._selected_job()
        if job is None or self.folder is None:
            return
        folder = job_folder(self.folder, job)
        if folder is None:
            return

        def find_clips():
            # The manifest is on the share, so this runs on the writer
            # thread; and only a folder under the job's own is trusted.
            clips = folder / "clips" / "ep01"
            try:
                production = Production.load(folder)
                if production.episodes and production.episodes[0].clips_dir:
                    candidate = Path(production.episodes[0].clips_dir)
                    if _inside(folder, candidate):
                        clips = candidate
            except (OSError, ValueError, KeyError):
                pass
            return str(clips)

        self._write("Open clips", find_clips, self.open_in_editor.emit)

    def _open(self, target: Path) -> None:
        """Hands the shell an existing folder, or the .mp4 export_target
        already checked -- nothing else. A name that is not there is
        resolved by the shell with PATHEXT, so a planted .cmd or .exe next
        to a missing folder would run on this machine."""
        try:
            is_folder = target.is_dir()
            is_video = target.suffix.lower() == ".mp4" and target.is_file()
        except OSError:
            is_folder = is_video = False
        if not is_folder and not is_video:
            self._say("Not opened: {} is not a folder or a video that is there.".format(target))
            log.warning("Refused to open %s: not an existing folder or .mp4", target)
            return
        try:
            os.startfile(str(target))                    # noqa: S606
        except OSError as exc:
            log.warning("Could not open %s: %s", target, exc)

    # -- worker -------------------------------------------------------------
    def _worker_running(self) -> bool:
        return self.worker_thread is not None and self.worker_thread.isRunning()

    def _budgets(self):
        clips = int(getattr(self.config, "worker_max_generations", 200) or 0)
        titles = int(getattr(self.config, "worker_max_titles", 10) or 0)
        minutes = float(getattr(self.config, "worker_poll_minutes", 2) or 2)
        return clips, titles, minutes

    def start_worker(self):
        if self.log is None or self.folder is None:
            self._say("Open a master log folder first.")
            return
        if self._worker_running():
            return
        live = not self.chk_mock.isChecked()
        if not live and missing_mock_samples():
            QMessageBox.warning(self, "Start worker", "Test mode needs the sample pair {} but it is missing:\n{}".format(
                " and ".join(p.name for p in (MOCK_SCRIPT, MOCK_PROMPTS)),
                "\n".join(str(p) for p in missing_mock_samples())))
            return
        clips_budget, titles_budget, poll_minutes = self._budgets()
        # 0 means no limit, which the one confirmation before paid work must
        # never print as '0 clips'; a live run without a budget is refused.
        problem = live_budget_problem(clips_budget, titles_budget) if live else ""
        if problem:
            QMessageBox.warning(self, "Start worker", problem)
            return
        queued = [j for j in self._jobs if j.status == "queued"]
        lines = []
        for record in self._records:
            count = sum(1 for j in queued if j.framework_id == record.framework_id)
            cap = (getattr(record, "generation_settings", None) or {}).get("max_generations")
            note = ""
            if not record.enabled:
                note = "  ·  disabled, skipped"
            elif live and not (isinstance(cap, int) and cap > 0):
                note = "  ·  no generation limit: its titles are refused in live mode"
            lines.append("    {}  ·  {}  ·  {}  ·  {} queued{}".format(
                record.framework_id, record.niche, record.editor_name, count, note))
        keys = [p for p in ("openai", "anthropic", "omniflash") if self.credentials.has(p)]
        if live:
            providers = "LIVE: real keys ({}); every clip is paid for.".format(
                ", ".join(keys) if keys else "none saved: every title will fail")
        else:
            providers = "TEST MODE: mock providers, no keys, no cost, test-pattern clips."
        text = ("Start the worker on\n{}\n\nRecords:\n{}\n\nTitles queued: {}\n{}\n"
                "Budget for this run: {} clips, {} titles (config.json: worker_max_generations, "
                "worker_max_titles). The log is polled every {:g} min.\n\n"
                "The worker runs unattended until Stop, the window closes, the budget is spent, or the "
                "same failure repeats three times. This is the one place paid work starts without a "
                "click per title.".format(self.folder, "\n".join(lines) or "    none", len(queued), providers,
                                         budget_text(clips_budget), budget_text(titles_budget), poll_minutes))
        if QMessageBox.question(self, "Start worker", _verbatim(text), QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return

        self.stop_event.clear()
        notifier = Notifier(EmailSettings.load(), self.credentials)
        credentials = self.credentials
        config = self.config

        # Live or mock is this screen's choice and nothing else: a record's
        # settings on the share are never consulted, so a share editor
        # cannot switch a run under Test mode to real keys.
        def factory(record, is_live=live):
            return make_providers(credentials, record, bool(is_live), config)

        self.worker = MasterWorker(self.log, self.log.frameworks, self.config, factory, notifier=notifier,
                                   on_event=lambda e: None, stop=self.stop_event,
                                   poll_seconds=poll_minutes * 60.0, max_generations=clips_budget,
                                   max_jobs=titles_budget, live=live)
        self.worker_thread = _WorkerThread(self.worker, self)
        self.worker.on_event = self.worker_thread.event.emit
        self.worker_thread.event.connect(self._on_worker_event)
        self.worker_thread.crashed.connect(self._on_worker_crashed)
        self.worker_thread.finished.connect(self._on_worker_finished)
        self._live = live
        self._last_event = ""
        log.info("Master worker started on %s (%s)", self.folder, "live" if live else "mock")
        self.worker_thread.start()
        self._poll_timer.start()
        self._say("Worker started ({}).".format("live" if live else "test mode"))
        self._paint_worker()

    def stop_worker(self):
        if not self._worker_running():
            return
        self.stop_event.set()
        self._say("Stopping after the current step…")
        self._paint_worker()

    def shutdown(self, timeout_ms: int = 10000) -> bool:
        """Stop the worker and wait for it, bounded. Called when the window
        closes; a job that could not finish stopping is reclaimed later by
        its stale heartbeat. From here on the page starts nothing: a worker
        that finishes after the window closed must not start a read whose
        thread the dying page would then destroy."""
        self._closing = True
        self.stop_event.set()
        self._poll_timer.stop()
        self._refresh_timer.stop()
        self._reload_wanted = False
        finished = True
        # A thread still running when the wait is up is detached from the
        # page: the page is destroyed with the window, and destroying a
        # running QThread aborts the process instead of closing it.
        if self._worker_running():
            finished = self.worker_thread.wait(timeout_ms)
            if not finished:
                log.warning("The master worker did not stop within %d s", timeout_ms // 1000)
                for signal, slot in ((self.worker_thread.event, self._on_worker_event),
                                     (self.worker_thread.crashed, self._on_worker_crashed),
                                     (self.worker_thread.finished, self._on_worker_finished)):
                    try:
                        signal.disconnect(slot)
                    except (RuntimeError, TypeError):
                        pass
                _orphan(self.worker_thread, "The master worker")
                self.worker_thread = None
        # A record being saved from its dialog has a writer of its own.
        for dialog in self.findChildren(RecordDialog):
            writer = getattr(dialog, "_writer", None)
            if writer is not None and writer.isRunning() and not writer.wait(SHARE_WAIT_MS):
                _orphan(writer, "A record save")
                dialog._writer = None
        if self._loader is not None and self._loader.isRunning() and not self._loader.wait(SHARE_WAIT_MS):
            _orphan(self._loader, "A read of the master log")
            self._loader = None
        if self._writer is not None and self._writer.isRunning() and not self._writer.wait(SHARE_WAIT_MS):
            _orphan(self._writer, "A write to the master log")
            self._writer = None
            self._pending = None
        return finished

    def closeEvent(self, event):
        self.shutdown()
        super().closeEvent(event)

    def _on_worker_event(self, event):
        if self._closing:
            return
        text = describe_event(event)
        self._last_event = text
        self._say(text)
        self._paint_worker()
        if not self._refresh_timer.isActive():
            self._refresh_timer.start()

    def _on_worker_crashed(self, message: str):
        self._last_event = "crashed: " + message
        self._say("Worker crashed: " + message)

    def _on_worker_finished(self):
        # The poll timer keeps going: the folder is still open.
        log.info("Master worker stopped: %s", self._last_event)
        self._say("Worker stopped." + ("  Last: " + self._last_event if self._last_event else ""))
        self._paint_worker()
        if self._closing:
            return                                # no new read from a page that is going away
        self.refresh()

    def _current_job(self) -> Optional[TitleJob]:
        mine = [j for j in self._jobs if j.status in IN_PROGRESS
                and (not getattr(j, "worker", "") or getattr(j, "worker", "") == self.hostname)]
        return max(mine, key=lambda j: j.updated or "") if mine else None

    def _paint_worker(self):
        running = self._worker_running()
        has_log = self.log is not None
        self.btn_start.setEnabled(has_log and not running)
        self.btn_stop.setEnabled(running and not self.stop_event.is_set())
        self.chk_mock.setEnabled(not running)
        self.btn_folder.setEnabled(not running)
        self.btn_refresh.setEnabled(self.folder is not None)
        clips_budget, titles_budget, _ = self._budgets()
        self.budget_hint.setText("Budget per start: {} clips, {} titles".format(
            budget_text(clips_budget), budget_text(titles_budget)))
        queued = sum(1 for j in self._jobs if j.status == "queued")
        if self._load_error:
            text, state = ("The master log folder is not reachable: {}\n{}".format(self.folder, self._load_error),
                           "work")
        elif not has_log:
            text, state = (("Reading {}…".format(self.folder) if self.folder
                            else "Automate ▾ → Master log… opens the shared folder."), "almost")
        elif running:
            current = self._current_job()
            where = ("on '{}' ({})".format(current.title[:50], STATUS_WORDS.get(current.status, current.status))
                     if current else "waiting for a queued title")
            if self.stop_event.is_set():
                where = "stopping after the current step"
            text = "Worker running ({})  ·  {}".format("live" if self._live else "test mode", where)
            if self._last_event:
                text += "  ·  " + self._last_event
            state = "work"
        else:
            text = "Worker stopped.  {} title{} queued across {} record{}.".format(
                queued, "" if queued == 1 else "s", len(self._records), "" if len(self._records) == 1 else "s")
            if self._last_event:
                text += "  Last: " + self._last_event
            elif queued:
                text += "  Press Start worker to run them unattended."
            state = "almost" if queued else ""
        self.status_line.setText(text)
        self.status_line.setProperty("state", state)
        self.status_line.style().unpolish(self.status_line)
        self.status_line.style().polish(self.status_line)

    def _say(self, text: str):
        self.events.addItem("{}  {}".format(datetime.now().strftime("%H:%M:%S"), text))
        while self.events.count() > 300:
            self.events.takeItem(0)
        self.events.scrollToBottom()
