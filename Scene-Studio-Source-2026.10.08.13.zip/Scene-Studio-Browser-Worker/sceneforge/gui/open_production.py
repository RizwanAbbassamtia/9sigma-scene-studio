"""Open production: the list of productions this machine knows, with where
each one is, so the right one can be resumed from its saved state.

The list is the manifests the app created or opened here (kept in
config.json as recent_productions); a folder that is not in the list can
be browsed to. Opening one loads its manifest into the dashboard and starts
nothing.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QFileDialog, QHBoxLayout, QHeaderView, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QVBoxLayout,
)

from ..config import Config
from ..logging_setup import get
from ..production.manifest import MANIFEST_NAME, Production
from ..production.stages import STAGE_NAMES, range_text

log = get("production.open")

COLUMNS = ["Production", "Episode", "Project", "Current stage", "Status", "Progress", "Created", "Last updated",
           "Output folder"]
MAX_RECENT = 40


def remember_production(config: Config, working_dir, directory) -> None:
    """Put a production's folder at the front of the known list and save."""
    path = str(Path(working_dir))
    recent = [p for p in getattr(config, "recent_productions", []) if p != path]
    recent.insert(0, path)
    config.recent_productions = recent[:MAX_RECENT]
    try:
        config.save(directory)
    except OSError:
        pass


def known_productions(config: Config) -> List[Production]:
    """Every remembered manifest that still exists, newest first. A folder
    whose manifest is gone or unreadable is left out, not removed: it may
    be on a share that is asleep."""
    out = []
    for folder in getattr(config, "recent_productions", []):
        path = Path(folder)
        if not (path / MANIFEST_NAME).is_file():
            continue
        try:
            out.append(Production.load(path))
        except (OSError, ValueError, KeyError) as exc:
            log.warning("Production at %s could not be read: %s", folder, exc)
    return out


def _when(stamp: str) -> str:
    try:
        return datetime.fromisoformat(stamp.replace("Z", "+00:00")).astimezone().strftime("%d %b %Y %H:%M")
    except (ValueError, AttributeError):
        return stamp[:16]


class OpenProductionDialog(QDialog):
    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        self.chosen: Optional[Path] = None
        self.setWindowTitle("Open production")
        self.setMinimumSize(980, 520)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 16)
        outer.setSpacing(10)
        title = QLabel("Open production")
        title.setObjectName("title")
        outer.addWidget(title)
        hint = QLabel("A production is an automated job with its saved pipeline state. Opening one loads it into "
                      "the dashboard exactly where it left off; nothing runs until you press Start. This is not "
                      "the same as opening a clip folder in the editor (+ New Project).")
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        outer.addWidget(hint)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(len(COLUMNS) - 1, QHeaderView.Stretch)
        self.table.itemDoubleClicked.connect(lambda _i: self._open_selected())
        self.table.itemSelectionChanged.connect(self._sync)
        outer.addWidget(self.table, 1)

        self.empty = QLabel("No production has been created or opened on this machine yet. Use Automate ▾ → New "
                            "automated production, or Browse for a folder that holds a production.json.")
        self.empty.setObjectName("hint")
        self.empty.setWordWrap(True)
        outer.addWidget(self.empty)

        buttons = QHBoxLayout()
        self.btn_browse = QPushButton("Browse for a production folder…")
        self.btn_browse.clicked.connect(self._browse)
        self.btn_folder = QPushButton("Open working folder")
        self.btn_folder.setObjectName("quiet")
        self.btn_folder.clicked.connect(self._show_folder)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        self.btn_open = QPushButton("Open production")
        self.btn_open.setObjectName("primary")
        self.btn_open.clicked.connect(self._open_selected)
        buttons.addWidget(self.btn_browse)
        buttons.addWidget(self.btn_folder)
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        buttons.addWidget(self.btn_open)
        outer.addLayout(buttons)
        self.refresh()

    def refresh(self):
        productions = known_productions(self.config)
        rows = []
        for production in productions:
            for episode in production.episodes:
                nxt = episode.next_stage()
                stage = STAGE_NAMES[nxt] if nxt else "Completed"
                output = ""
                if episode.exports:
                    output = episode.exports[-1].path
                elif production.export_dir:
                    output = production.export_dir
                rows.append((production, episode.number,
                             [production.title, "{:03d}".format(episode.number), production.name, stage,
                              episode.progress_text(), range_text(production.start_stage, production.end_stage),
                              _when(production.created), _when(production.updated), output]))
        self.table.setRowCount(len(rows))
        for row, (production, number, cells) in enumerate(rows):
            for column, text in enumerate(cells):
                item = QTableWidgetItem(str(text))
                item.setData(Qt.UserRole, production.working_dir)
                item.setData(Qt.UserRole + 1, number)
                item.setToolTip(str(text))
                self.table.setItem(row, column, item)
        self.empty.setVisible(not rows)
        self.table.setVisible(bool(rows))
        if rows:
            self.table.selectRow(0)
        self._sync()

    def _sync(self):
        has = bool(self.table.selectedItems())
        self.btn_open.setEnabled(has)
        self.btn_folder.setEnabled(has)

    def _selected_dir(self) -> Optional[Path]:
        items = self.table.selectedItems()
        if not items:
            return None
        return Path(items[0].data(Qt.UserRole))

    def selected_episode(self) -> int:
        items = self.table.selectedItems()
        return int(items[0].data(Qt.UserRole + 1)) if items else 1

    def _open_selected(self):
        folder = self._selected_dir()
        if folder is None:
            return
        self.chosen = folder
        self.accept()

    def _browse(self):
        folder = QFileDialog.getExistingDirectory(self, "The production's working folder (holds production.json)", "")
        if not folder:
            return
        if not (Path(folder) / MANIFEST_NAME).is_file():
            self.empty.setText("No production.json in {}.".format(folder))
            self.empty.setVisible(True)
            return
        self.chosen = Path(folder)
        self.accept()

    def _show_folder(self):
        import os
        folder = self._selected_dir()
        if folder is not None and folder.is_dir():
            try:
                os.startfile(str(folder))                     # noqa: S606
            except OSError:
                pass
