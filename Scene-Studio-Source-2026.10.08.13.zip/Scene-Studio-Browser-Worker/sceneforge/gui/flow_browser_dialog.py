"""Browser generation panel. Settings are verified in Flow for every scene."""
from datetime import datetime
from pathlib import Path
from threading import Event
import os

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel,
    QPlainTextEdit, QComboBox, QSpinBox, QPushButton, QListWidget, QListWidgetItem,
    QFileDialog, QMessageBox, QTableWidget, QTableWidgetItem, QSplitter)

from ..production.flow_browser import FlowBrowser
from ..production.flow_browser_run import BrowserSettings, RunLedger, execute
from ..production.prompts import parse_report


class BrowserWorker(QThread):
    message = Signal(str)
    ended = Signal(str)
    rows = Signal(list)

    def __init__(self, profile_root, run_folder, accounts, connecting=False, parent=None, book=None):
        super().__init__(parent)
        self.profile_root, self.run_folder = profile_root, run_folder
        self.accounts, self.connecting = accounts, connecting
        self.stop_event = Event()
        self.book = book

    def stop(self):
        self.stop_event.set()

    def run(self):
        from ..production.scene_queue import browser_lock
        try:
            with browser_lock(self.profile_root):
                self.run_locked()
        except Exception as exc:
            self.ended.emit('Stopped: ' + str(exc))

    def run_locked(self):
        def observed(account_id, balance, cost):
            if self.book is not None:
                self.book.set_credits(account_id, balance, by='Google Flow browser', note='Live balance read from Google Flow')
                if cost is not None:
                    self.book.update(account_id, cost=cost, by='Google Flow browser')
        browser = FlowBrowser(self.profile_root, self.run_folder, self.message.emit, observed)
        ledger = None
        try:
            if self.connecting:
                result = browser.connect(self.accounts[0], self.stop_event.is_set)
            else:
                ledger = RunLedger(self.run_folder)
                def report(message):
                    self.message.emit(message)
                    self.rows.emit(ledger.rows())
                result = execute(ledger, self.accounts, browser, report, self.stop_event.is_set)
            self.ended.emit(result)
        except Exception as exc:
            self.ended.emit('Stopped: ' + str(exc))
        finally:
            browser.close()
            if ledger:
                self.rows.emit(ledger.rows())
                ledger.close()


class FlowBrowserDialog(QDialog):
    def __init__(self, accounts, prompts=None, parent=None, app_root=None, book=None):
        super().__init__(parent)
        self.setWindowTitle('Generate scenes in Google Flow')
        self.resize(1040, 830)
        self.setMinimumSize(840, 650)
        self.app_root = Path(app_root or Path(__file__).resolve().parents[2])
        self.profiles = self.app_root / 'browser-profiles'
        self.runs_root = self.app_root / 'browser-runs'
        self.worker = None
        self.book = book
        self.run_folder = None
        outer = QVBoxLayout(self)
        hint = QLabel('Reads Google’s displayed balance and generation cost before every scene. '
                      'One output per scene; switches account only when its confirmed balance is insufficient. '
                      'An uncertain result stops for review instead of submitting twice.')
        hint.setWordWrap(True)
        outer.addWidget(hint)
        columns = QSplitter()
        self.accounts = QListWidget()
        for account in accounts:
            if account.status == 'paused' or not account.email:
                continue
            item = QListWidgetItem('{} — {}'.format(account.id, account.email))
            item.setData(Qt.UserRole, {'id': account.id, 'email': account.email})
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked)
            self.accounts.addItem(item)
        self.accounts.setMinimumWidth(240)
        columns.addWidget(self.accounts)
        self.prompts = QPlainTextEdit()
        self.prompts.setPlaceholderText('Paste numbered prompts here:\n1: First scene…\n2: Second scene…')
        if prompts:
            self.prompts.setPlainText('\n\n'.join('{}: {}'.format(i, p) for i, p in enumerate(prompts, 1)))
        columns.addWidget(self.prompts)
        outer.addWidget(columns, 2)
        controls = QHBoxLayout()
        self.import_button = QPushButton('Import prompts…')
        self.import_button.clicked.connect(self.import_prompts)
        self.connect_button = QPushButton('Connect selected account…')
        self.connect_button.clicked.connect(self.connect_account)
        controls.addWidget(self.import_button)
        controls.addWidget(self.connect_button)
        outer.addLayout(controls)
        connect_hint = QLabel('Connect each account once in its own app-managed Chrome window. '
                              'You sign in there; existing personal Chrome profiles are not copied. '
                              'Tick the accounts to use, in the order shown.')
        connect_hint.setWordWrap(True)
        outer.addWidget(connect_hint)
        form = QFormLayout()
        self.model = QComboBox()
        self.model.addItems(['Omni 1.1 Flash', 'Veo 3.1 - Lite', 'Veo 3.1 - Fast', 'Veo 3.1 - Quality'])
        self.aspect = QComboBox()
        self.aspect.addItem('16:9 — Landscape', '16:9')
        self.aspect.addItem('9:16 — Portrait', '9:16')
        self.resolution = QComboBox()
        self.resolution.addItems(['720p', '360p'])
        self.duration = QComboBox()
        self.duration.addItems(['10s', '8s', '6s', '4s'])
        self.budget = QSpinBox()
        self.budget.setRange(1, 1000000)
        self.budget.setValue(100)
        form.addRow('Model', self.model)
        form.addRow('Scene format', self.aspect)
        settings_row = QHBoxLayout()
        settings_row.addWidget(self.resolution)
        settings_row.addWidget(self.duration)
        form.addRow('Resolution / duration', settings_row)
        form.addRow('Maximum credits for this run', self.budget)
        outer.addLayout(form)
        buttons = QHBoxLayout()
        self.start_button = QPushButton('Start new run')
        self.start_button.clicked.connect(self.start_run)
        self.resume_button = QPushButton('Resume saved run…')
        self.resume_button.clicked.connect(self.resume_run)
        self.stop_button = QPushButton('Stop after current scene')
        self.stop_button.clicked.connect(self.stop_run)
        self.stop_button.setEnabled(False)
        self.folder_button = QPushButton('Open output folder')
        self.folder_button.clicked.connect(self.open_folder)
        for button in (self.start_button, self.resume_button, self.stop_button, self.folder_button):
            buttons.addWidget(button)
        outer.addLayout(buttons)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['Scene', 'Status', 'Account', 'Charged', 'Remaining'])
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        outer.addWidget(self.table, 1)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(120)
        self.log.document().setMaximumBlockCount(300)
        outer.addWidget(self.log)

    def checked_accounts(self):
        return [self.accounts.item(i).data(Qt.UserRole) for i in range(self.accounts.count())
                if self.accounts.item(i).checkState() == Qt.Checked]

    def import_prompts(self):
        name, _ = QFileDialog.getOpenFileName(self, 'Import numbered prompts', '', 'Text files (*.txt)')
        if name:
            try:
                self.prompts.setPlainText(Path(name).read_text(encoding='utf-8-sig'))
            except Exception as exc:
                QMessageBox.warning(self, 'Import failed', str(exc))

    def connect_account(self):
        item = self.accounts.currentItem()
        if item is None:
            QMessageBox.information(self, 'Select an account', 'Click the account you want to sign in.')
            return
        self.begin([item.data(Qt.UserRole)], connecting=True)

    def start_run(self):
        accounts = self.checked_accounts()
        try:
            if not accounts:
                raise ValueError('Tick at least one account')
            items, problems = parse_report(self.prompts.toPlainText())
            if not items or problems:
                raise ValueError('Use a numbered prompt for each scene. ' + '; '.join(str(p) for p in problems))
            settings = BrowserSettings(self.model.currentText(), self.aspect.currentData(),
                                       self.resolution.currentText(), self.duration.currentText())
            settings.validate()
            self.run_folder = self.runs_root / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
            ledger = RunLedger(self.run_folder)
            try:
                ledger.create([item.prompt for item in items], settings, self.budget.value())
                self.show_rows(ledger.rows())
            finally:
                ledger.close()
            self.begin(accounts)
        except Exception as exc:
            QMessageBox.warning(self, 'Cannot start', str(exc))

    def resume_run(self):
        name = QFileDialog.getExistingDirectory(self, 'Choose a saved run', str(self.runs_root))
        if not name:
            return
        folder = Path(name).resolve()
        if not folder.is_relative_to(self.runs_root.resolve()) or not (folder / 'run.sqlite').is_file():
            QMessageBox.warning(self, 'Cannot resume', 'Choose a run inside this app’s browser-runs folder.')
            return
        accounts = self.checked_accounts()
        if not accounts:
            QMessageBox.warning(self, 'Cannot resume', 'Tick the accounts to use.')
            return
        self.run_folder = folder
        self.begin(accounts)

    def begin(self, accounts, connecting=False):
        if self.worker is not None:
            return
        self.worker = BrowserWorker(self.profiles, self.run_folder or self.runs_root, accounts, connecting, self, self.book)
        self.worker.message.connect(self.log.appendPlainText)
        self.worker.ended.connect(self.log.appendPlainText)
        self.worker.rows.connect(self.show_rows)
        self.worker.finished.connect(self.finished_work)
        for button in (self.start_button, self.resume_button, self.connect_button, self.import_button):
            button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.worker.start()

    def finished_work(self):
        self.worker.deleteLater()
        self.worker = None
        for button in (self.start_button, self.resume_button, self.connect_button, self.import_button):
            button.setEnabled(True)
        self.stop_button.setEnabled(False)

    def show_rows(self, rows):
        self.table.setRowCount(len(rows))
        for n, row in enumerate(rows):
            charged = '' if row['after_credit'] is None else row['before_credit'] - row['after_credit']
            for col, value in enumerate((row['number'], row['status'], row['account'] or '', charged,
                                         '' if row['after_credit'] is None else row['after_credit'])):
                self.table.setItem(n, col, QTableWidgetItem(str(value)))

    def stop_run(self):
        if self.worker:
            self.worker.stop()
            self.log.appendPlainText('Stopping after the current scene; no further submission will be made.')

    def open_folder(self):
        if self.run_folder:
            os.startfile(str(self.run_folder))

    def reject(self):
        if self.worker is not None:
            self.stop_run()
            QMessageBox.information(self, 'Finishing current work', 'Wait for the current scene or connection to finish before closing.')
            return
        super().reject()

    def closeEvent(self, event):
        if self.worker is not None:
            self.stop_run()
            event.ignore()
        else:
            super().closeEvent(event)
