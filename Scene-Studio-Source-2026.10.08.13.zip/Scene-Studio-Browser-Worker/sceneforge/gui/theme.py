"""Design tokens: the one place colour, spacing, radius and type are defined.

A dark slate workspace with a single blue accent. Blue means "this is the
action", "this is selected", "this has focus", "the playhead is here" -- and
nothing else uses it, so it always means one of those. Green, amber and red are
reserved for status that is genuinely good, worth attention, or wrong; they
never decorate.

The stylesheet in `styles.py` and the two hand-painted widgets (`timeline.py`
and `filmstrip.py`) all read from here, so a retune is an edit to this file.

Spacing is an 8-pixel system: SPACE_1..SPACE_3 for gaps between related
controls, groups and panels. Sticking to it is what stops a dense editing
window from turning ragged.
"""
from __future__ import annotations

# -- grounds -----------------------------------------------------------------
BG_MAIN      = "#101216"   # the application ground
BG_PANEL     = "#181C22"   # panels: inspector, timeline, toolbar
BG_RAISED    = "#232933"   # raised surfaces and secondary buttons
BG_HOVER     = "#2D3541"   # hovered secondary surfaces
BG_INPUT     = "#1B2028"   # inputs and dropdowns, a step below a raised surface
BG_CANVAS    = "#000000"   # inside the video canvas only

# -- lines -------------------------------------------------------------------
BORDER       = "#343D49"   # borders and dividers
BORDER_SOFT  = "#272E38"   # the quieter separators inside a panel

# -- type --------------------------------------------------------------------
TEXT_PRIMARY = "#F3F5F7"
TEXT_SECOND  = "#B4BECC"
TEXT_MUTED   = "#8D99AA"
TEXT_OFF     = "#5C6675"   # disabled: still legible, plainly inactive

# -- the one accent ----------------------------------------------------------
ACCENT       = "#4F8CFF"   # selection, focus, playhead
PRIMARY      = "#2563EB"   # primary button ground
PRIMARY_HOVER = "#1D4ED8"
PRIMARY_PRESS = "#1E40AF"
PRIMARY_TEXT = "#FFFFFF"
# The one warm accent: New Project, the way into everything. Golden yellow
# so it is never confused with the blue that means "do it".
GOLD         = "#E9B824"
GOLD_HOVER   = "#F5C94B"
GOLD_PRESS   = "#C9971A"
GOLD_TEXT    = "#141414"
SELECT_BG    = "#1B2740"   # the ground under a selected control
SELECT_LINE  = "#3D6BC4"   # its border, quieter than the accent itself

# -- status, and only status -------------------------------------------------
SUCCESS      = "#3CCB8E"
SUCCESS_BG   = "#152A22"
SUCCESS_LINE = "#2A6A4E"
WARNING      = "#F5B942"
WARNING_BG   = "#2A2415"
WARNING_LINE = "#6E5A22"
DANGER       = "#F47174"
DANGER_BG    = "#2A1719"
DANGER_LINE  = "#6E3336"

# -- hand-painted widgets ----------------------------------------------------
TL_BG        = "#14171C"   # the filmstrip's own ground, inside its panel
TL_RULER     = "#1B2028"   # its ruler strip
TL_CLIP      = "#232933"   # a clip block behind its thumbnail
TRIM_TRACK   = "#232933"   # the excluded part of the trim strip
TRIM_KEPT    = "#1E2A3D"   # the retained range: blue-tinted, not loud
TRIM_SPEECH  = "#6F7C8C"   # detected speech: neutral, it is information
OVERLAY      = "#0B0D11"   # the dark plate clip numbers are written on

# -- spacing, on an 8-pixel grid ---------------------------------------------
SPACE_1      = 8           # between related controls
SPACE_2      = 16          # between groups, and panel padding
SPACE_3      = 24          # between major regions
PAD_PANEL    = 16          # inside a panel

# -- shape -------------------------------------------------------------------
RADIUS       = 6           # inputs, dropdowns, small surfaces
RADIUS_BTN   = 7           # buttons
RADIUS_PANEL = 8           # panels and cards

# -- type --------------------------------------------------------------------
# Segoe UI is on every Windows machine this ships to; Inter if someone has it.
FONT_STACK   = '"Segoe UI", "Inter", "Roboto", sans-serif'
FONT_CONTROL = 13          # buttons and controls
FONT_BODY    = 13          # ordinary text
FONT_LABEL   = 12          # supporting labels and metadata
FONT_TITLE   = 14          # section titles, semibold
BTN_HEIGHT   = 34          # every standard button
INSPECTOR_W  = 340         # the inspector's starting width
