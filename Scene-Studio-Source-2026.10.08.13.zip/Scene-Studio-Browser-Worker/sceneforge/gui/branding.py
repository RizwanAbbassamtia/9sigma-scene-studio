"""Names, icon and logo. Every user-facing string for the product lives here.

The Python package is still called `sceneforge`. That is an internal module
name nobody sees, and renaming it would touch every import in the project to
change nothing an editor can observe.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor, QIcon, QImage, QPainter, QPixmap

from ..product import PRODUCT

COMPANY = PRODUCT.name          # "9 Sigma Automation" or "9 Sigma Omni Flow"
APP_NAME = COMPANY
TAGLINE = "Think It | 9SIGMA Creates It | Publishes It."
COPYRIGHT = "All rights reserved © rizwansamtia 2026"

ASSETS = Path(__file__).resolve().parent.parent.parent / "assets"
ICON_SVG = ASSETS / "icon.svg"
ICON_ICO = ASSETS / "sceneforge.ico"
LOGO_SVG = ASSETS / "logo.svg"


def _render(svg: Path, width: int, height: int) -> Optional[QPixmap]:
    if not svg.exists():
        return None
    try:
        from PySide6.QtSvg import QSvgRenderer
    except ImportError:
        return None
    renderer = QSvgRenderer(str(svg))
    if not renderer.isValid():
        return None
    image = QImage(QSize(width, height), QImage.Format_ARGB32_Premultiplied)
    image.fill(QColor(0, 0, 0, 0))
    painter = QPainter(image)
    painter.setRenderHint(QPainter.Antialiasing, True)
    renderer.render(painter)
    painter.end()
    return QPixmap.fromImage(image)


def app_icon() -> QIcon:
    """Window and taskbar icon. Prefers the .ico, which carries every size."""
    if ICON_ICO.exists():
        return QIcon(str(ICON_ICO))
    icon = QIcon()
    for size in (16, 32, 48, 64, 128, 256):
        pixmap = _render(ICON_SVG, size, size)
        if pixmap is not None:
            icon.addPixmap(pixmap)
    return icon


def logo_pixmap(height: int = 96) -> Optional[QPixmap]:
    """Horizontal lockup for the start screen, scaled to the given height."""
    return _render(LOGO_SVG, int(height * 1180 / 300), height)
