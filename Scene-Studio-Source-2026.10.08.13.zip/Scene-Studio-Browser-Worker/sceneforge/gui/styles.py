"""Single stylesheet for the whole app, kept out of the window code.

Every value comes from `theme.py`; there are no literals here. What this file
decides is which of four roles a control plays, and every control has all six
states -- default, hover, pressed, selected, disabled, keyboard focus:

    primary     blue ground, white text   -- Export video, Start, Sign in
    secondary   raised slate, light text  -- most of the interface
    selected    blue-tinted, blue rim     -- a toggle that is on
    status      green, amber or red       -- and only where it means something

Qt stylesheets have no `transition` property, so state changes land on the
frame. Easing them would mean animating each widget from Python, which is
application code rather than styling -- left alone deliberately.
"""
from __future__ import annotations

from . import theme as t


def _f(text: str) -> str:
    """Fill a rule block from the tokens. Keeps the mapping in one place."""
    return text.format(
        BG_MAIN=t.BG_MAIN, BG_PANEL=t.BG_PANEL, BG_RAISED=t.BG_RAISED,
        BG_HOVER=t.BG_HOVER, BG_INPUT=t.BG_INPUT,
        BORDER=t.BORDER, BORDER_SOFT=t.BORDER_SOFT,
        TEXT_PRIMARY=t.TEXT_PRIMARY, TEXT_SECOND=t.TEXT_SECOND,
        TEXT_MUTED=t.TEXT_MUTED, TEXT_OFF=t.TEXT_OFF,
        GOLD=t.GOLD, GOLD_HOVER=t.GOLD_HOVER, GOLD_PRESS=t.GOLD_PRESS, GOLD_TEXT=t.GOLD_TEXT,
        ACCENT=t.ACCENT, PRIMARY=t.PRIMARY, PRIMARY_HOVER=t.PRIMARY_HOVER,
        PRIMARY_PRESS=t.PRIMARY_PRESS, PRIMARY_TEXT=t.PRIMARY_TEXT,
        SELECT_BG=t.SELECT_BG, SELECT_LINE=t.SELECT_LINE,
        SUCCESS=t.SUCCESS, SUCCESS_BG=t.SUCCESS_BG, SUCCESS_LINE=t.SUCCESS_LINE,
        WARNING=t.WARNING, WARNING_BG=t.WARNING_BG, WARNING_LINE=t.WARNING_LINE,
        DANGER=t.DANGER, DANGER_BG=t.DANGER_BG, DANGER_LINE=t.DANGER_LINE,
        FONT=t.FONT_STACK, F_CTRL=t.FONT_CONTROL, F_BODY=t.FONT_BODY,
        F_LABEL=t.FONT_LABEL, F_TITLE=t.FONT_TITLE,
        R=t.RADIUS, R_BTN=t.RADIUS_BTN, R_PANEL=t.RADIUS_PANEL,
        H=t.BTN_HEIGHT, S1=t.SPACE_1, S2=t.SPACE_2, PAD=t.PAD_PANEL)


# --------------------------------------------------------------- foundations
STYLE = _f("""
QMainWindow, QWidget {{ background: {BG_MAIN}; color: {TEXT_SECOND};
                       font-family: {FONT}; font-size: {F_BODY}px; }}
QLabel {{ background: transparent; color: {TEXT_SECOND}; }}
QSplitter::handle {{ background: {BG_MAIN}; width: {S1}px; }}
QSplitter::handle:hover {{ background: {BORDER}; }}
QDialog {{ background: {BG_PANEL}; }}
QMessageBox {{ background: {BG_PANEL}; }}
QMessageBox QLabel {{ color: {TEXT_PRIMARY}; }}

/* A panel: the inspector, the timeline, the toolbar. */
QFrame#panel, QWidget#panel {{ background: {BG_PANEL};
                              border: 1px solid {BORDER_SOFT};
                              border-radius: {R_PANEL}px; }}
QFrame#card {{ background: {BG_RAISED}; border: 1px solid {BORDER};
              border-radius: {R_PANEL}px; }}
QFrame#divider {{ color: {BORDER_SOFT}; background: {BORDER_SOFT};
                 max-height: 1px; border: none; }}
""")

# ------------------------------------------------------------------- buttons
STYLE += _f("""
/* Secondary. Most of the interface is this. */
QPushButton {{ background: {BG_RAISED}; border: 1px solid {BORDER};
              border-radius: {R_BTN}px; padding: 0 14px;
              min-height: {H}px; max-height: {H}px;
              color: {TEXT_PRIMARY}; font-size: {F_CTRL}px; font-weight: 600; }}
QPushButton:hover:enabled {{ background: {BG_HOVER}; border-color: {BORDER}; }}
QPushButton:pressed:enabled {{ background: {BG_INPUT}; }}
QPushButton:focus {{ border: 1px solid {ACCENT}; outline: none; }}
QPushButton:disabled {{ background: {BG_PANEL}; border-color: {BORDER_SOFT};
                       color: {TEXT_OFF}; }}

/* Primary: one per region, the action the screen exists for. */
QPushButton#primary {{ background: {PRIMARY}; border: 1px solid {PRIMARY};
                      color: {PRIMARY_TEXT}; font-weight: 600; }}
QPushButton#primary:hover:enabled {{ background: {PRIMARY_HOVER};
                                    border-color: {PRIMARY_HOVER}; }}
QPushButton#primary:pressed:enabled {{ background: {PRIMARY_PRESS}; }}
QPushButton#primary:focus {{ border: 1px solid {ACCENT}; }}
QPushButton#primary:disabled {{ background: {BG_PANEL};
                               border-color: {BORDER_SOFT}; color: {TEXT_OFF}; }}

/* New Project: golden yellow, dark lettering. The way in, and the only
   warm colour in the chrome. */
QPushButton#actOpen {{ background: {GOLD}; border: 1px solid {GOLD};
                      color: {GOLD_TEXT}; font-weight: 700; }}
QPushButton#actOpen:hover:enabled {{ background: {GOLD_HOVER}; border-color: {GOLD_HOVER}; }}
QPushButton#actOpen:pressed:enabled {{ background: {GOLD_PRESS}; }}
QPushButton#actOpen:focus {{ border: 1px solid {ACCENT}; }}

/* Quiet: a button that should be available without being offered. */
QPushButton#quiet {{ background: transparent; border: 1px solid {BORDER};
                    color: {TEXT_SECOND}; font-weight: 500; }}
QPushButton#quiet:hover:enabled {{ background: {BG_RAISED};
                                  color: {TEXT_PRIMARY}; }}

/* Approve and reject: restrained green and red, readable text. */
QPushButton#actApprove {{ background: {SUCCESS_BG}; border: 1px solid {SUCCESS_LINE};
                         color: {SUCCESS}; font-weight: 600; }}
QPushButton#actApprove:hover:enabled {{ background: #1B3A2E;
                                       border-color: {SUCCESS}; }}
QPushButton#actReject {{ background: {DANGER_BG}; border: 1px solid {DANGER_LINE};
                        color: {DANGER}; font-weight: 600; }}
QPushButton#actReject:hover:enabled {{ background: #3A1F22;
                                      border-color: {DANGER}; }}
QPushButton#actApprove:disabled, QPushButton#actReject:disabled {{
    background: {BG_PANEL}; border-color: {BORDER_SOFT}; color: {TEXT_OFF}; }}

/* Next flagged: neutral, with amber only while flagged clips remain. */
QPushButton#actFlag[armed="true"] {{ border-color: {WARNING_LINE};
                                    color: {WARNING}; }}
QPushButton#actFlag[armed="true"]:hover:enabled {{ background: {WARNING_BG};
                                                  border-color: {WARNING}; }}

/* Transport buttons keep a fixed width so nothing shifts when Play becomes
   Pause -- an editor's hand should not have to re-aim mid-review. */
QPushButton#actPlay {{ min-width: 84px; }}
""")

# -------------------------------------------------------------- toggles
STYLE += _f("""
QPushButton#toggleSize, QPushButton#toggleCaptions, QPushButton#toggleFadeIn,
QPushButton#toggleFadeOut, QPushButton#choice {{
    background: {BG_RAISED}; border: 1px solid {BORDER};
    border-radius: {R_BTN}px; color: {TEXT_SECOND};
    font-size: {F_CTRL}px; font-weight: 600; }}
QPushButton#toggleSize:hover, QPushButton#toggleCaptions:hover,
QPushButton#toggleFadeIn:hover, QPushButton#toggleFadeOut:hover,
QPushButton#choice:hover {{ background: {BG_HOVER}; color: {TEXT_PRIMARY}; }}
QPushButton#toggleSize:checked, QPushButton#toggleCaptions:checked,
QPushButton#toggleFadeIn:checked, QPushButton#toggleFadeOut:checked,
QPushButton#choice:checked {{
    background: {SELECT_BG}; border: 1px solid {SELECT_LINE}; color: {ACCENT}; }}
QPushButton#choice {{ min-height: 46px; max-height: 46px;
                     font-size: {F_TITLE}px; }}
""")

# -------------------------------------------------------------------- inputs
STYLE += _f("""
QLineEdit {{ background: {BG_INPUT}; border: 1px solid {BORDER};
            border-radius: {R}px; padding: 0 11px; min-height: {H}px;
            color: {TEXT_PRIMARY}; font-size: {F_BODY}px; font-weight: 400;
            selection-background-color: {PRIMARY};
            selection-color: {PRIMARY_TEXT}; }}
QLineEdit:hover {{ border-color: {BG_HOVER}; }}
QLineEdit:focus {{ border-color: {ACCENT}; }}
QLineEdit:disabled {{ color: {TEXT_OFF}; }}

QTextEdit {{ background: {BG_INPUT}; border: 1px solid {BORDER_SOFT};
            border-radius: {R}px; color: {TEXT_SECOND};
            font-size: {F_LABEL}px; font-weight: 400; padding: {S1}px; }}

QComboBox {{ background: {BG_INPUT}; border: 1px solid {BORDER};
            border-radius: {R}px; padding: 0 10px; min-height: {H}px;
            color: {TEXT_PRIMARY}; font-size: {F_BODY}px; font-weight: 400; }}
QComboBox:hover {{ border-color: {BG_HOVER}; }}
QComboBox:focus, QComboBox:on {{ border-color: {ACCENT}; }}
QComboBox:disabled {{ color: {TEXT_OFF}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {BG_RAISED}; color: {TEXT_PRIMARY};
                               border: 1px solid {BORDER};
                               selection-background-color: {SELECT_BG};
                               selection-color: {ACCENT}; outline: none; }}

QListWidget {{ background: {BG_INPUT}; border: 1px solid {BORDER_SOFT};
              border-radius: {R}px; padding: 4px; font-size: {F_BODY}px; }}
QListWidget::item {{ padding: {S1}px 10px; border-radius: 5px;
                    color: {TEXT_SECOND}; font-weight: 400; }}
QListWidget::item:hover {{ background: {BG_RAISED}; color: {TEXT_PRIMARY}; }}
QListWidget::item:selected {{ background: {SELECT_BG}; color: {ACCENT}; }}

QCheckBox {{ color: {TEXT_SECOND}; font-size: {F_BODY}px; font-weight: 400;
            background: transparent; }}
QCheckBox::indicator {{ width: 15px; height: 15px; border: 1px solid {BORDER};
                        border-radius: 4px; background: {BG_INPUT}; }}
QCheckBox::indicator:hover {{ border-color: {ACCENT}; }}
QCheckBox::indicator:checked {{ background: {PRIMARY}; border-color: {PRIMARY}; }}

QProgressBar {{ background: {BG_INPUT}; border: 1px solid {BORDER_SOFT};
               border-radius: {R}px; height: 18px; text-align: center;
               color: {TEXT_SECOND}; font-size: {F_LABEL}px; font-weight: 400; }}
QProgressBar::chunk {{ background: {PRIMARY}; border-radius: 5px; }}

QSlider::groove:horizontal {{ height: 4px; background: {BG_RAISED};
                             border-radius: 2px; }}
QSlider::handle:horizontal {{ background: {ACCENT}; width: 13px; margin: -5px 0;
                             border-radius: 6px; }}
QSlider::handle:horizontal:hover {{ background: {PRIMARY_TEXT}; }}
""")

# ---------------------------------------------------------------- scrollbars
STYLE += _f("""
QScrollArea {{ background: transparent; border: none; }}
QScrollBar:horizontal {{ background: {BG_PANEL}; height: 11px; margin: 0;
                        border: none; }}
QScrollBar:vertical {{ background: {BG_PANEL}; width: 11px; margin: 0;
                      border: none; }}
QScrollBar::handle:horizontal {{ background: {BG_HOVER}; border-radius: 5px;
                                min-width: 48px; }}
QScrollBar::handle:vertical {{ background: {BG_HOVER}; border-radius: 5px;
                              min-height: 36px; }}
QScrollBar::handle:horizontal:hover, QScrollBar::handle:vertical:hover {{
    background: {ACCENT}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: transparent; }}
""")

# -------------------------------------------------------------------- chrome
STYLE += _f("""
QStatusBar {{ background: {BG_PANEL}; color: {TEXT_MUTED};
             font-size: {F_LABEL}px; font-weight: 400;
             border-top: 1px solid {BORDER_SOFT}; }}
QStatusBar::item {{ border: none; }}
QStatusBar QLabel {{ color: {TEXT_MUTED}; font-size: {F_LABEL}px; }}
QStatusBar QLabel#statusPosition {{ color: {TEXT_SECOND}; font-weight: 600; }}

QToolTip {{ background: {BG_RAISED}; color: {TEXT_PRIMARY};
           border: 1px solid {BORDER}; padding: 6px 9px; }}
QMenu {{ background: {BG_RAISED}; color: {TEXT_PRIMARY};
        border: 1px solid {BORDER}; padding: 5px; }}
QMenu::item {{ padding: {S1}px 18px; border-radius: 5px; font-weight: 400; }}
QMenu::item:selected {{ background: {SELECT_BG}; color: {ACCENT}; }}
QMenu::item:disabled {{ color: {TEXT_MUTED}; font-weight: 600; }}
QMenu::separator {{ height: 1px; background: {BORDER_SOFT}; margin: 5px 8px; }}

QToolButton {{ background: {BG_RAISED}; border: 1px solid {BORDER};
              border-radius: {R_BTN}px; color: {TEXT_PRIMARY};
              font-size: {F_CTRL}px; font-weight: 600; padding: 0 12px;
              min-height: {H}px; max-height: {H}px; }}
QToolButton:hover {{ background: {BG_HOVER}; }}
QToolButton:pressed {{ background: {BG_INPUT}; }}
QToolButton::menu-indicator {{ image: none; }}
""")

# ---------------------------------------------------------------------- type
STYLE += _f("""
QLabel#title {{ font-size: {F_TITLE}px; font-weight: 600;
               color: {TEXT_PRIMARY}; }}
QLabel#bigTitle {{ font-size: 30px; font-weight: 300; color: {TEXT_PRIMARY};
                  letter-spacing: 0.5px; }}
QLabel#subtitle {{ font-size: {F_BODY}px; font-weight: 400;
                  color: {TEXT_SECOND}; }}
/* Section titles inside the inspector and over the timeline. */
QLabel#sectionTitle {{ font-size: {F_TITLE}px; font-weight: 600;
                      color: {TEXT_PRIMARY}; }}
QLabel#stepLabel {{ font-size: {F_LABEL}px; font-weight: 600;
                   color: {TEXT_MUTED}; letter-spacing: 0.4px; }}
QLabel#clipHeading {{ font-size: {F_TITLE}px; font-weight: 600;
                     color: {TEXT_PRIMARY}; }}
QLabel#hint {{ color: {TEXT_MUTED}; font-size: {F_LABEL}px; font-weight: 400; }}
QLabel#stat {{ color: {TEXT_MUTED}; font-size: {F_LABEL}px; font-weight: 400;
              line-height: 150%; }}
QLabel#trimReadout {{ color: {TEXT_SECOND}; font-size: {F_LABEL}px;
                     font-weight: 500; }}
QLabel#folderStatus {{ color: {TEXT_MUTED}; font-size: {F_LABEL}px;
                      font-weight: 400; }}
QLabel#folderStatus[bad="true"] {{ color: {WARNING}; }}
QLabel#emptyState {{ color: {TEXT_MUTED}; font-size: {F_TITLE}px;
                    font-weight: 500; }}
""")

# --------------------------------------------------------------- status card
# One card answers "am I finished?". Neutral while there is work left, amber
# when flagged clips are unreviewed, green only when the edit is genuinely done.
STYLE += _f("""
QLabel#readyBanner {{ background: {BG_RAISED}; border: 1px solid {BORDER};
                     border-radius: {R}px; padding: 10px 12px;
                     font-size: {F_LABEL}px; font-weight: 400;
                     color: {TEXT_SECOND}; }}
QLabel#readyBanner[state="work"]   {{ border-color: {WARNING_LINE};
                                     color: {TEXT_PRIMARY}; }}
QLabel#readyBanner[state="almost"] {{ color: {TEXT_SECOND}; }}
QLabel#readyBanner[state="ready"]  {{ background: {SUCCESS_BG};
                                     border-color: {SUCCESS_LINE};
                                     color: {SUCCESS}; font-weight: 600; }}
QLabel#flagBanner {{ background: {WARNING_BG}; border: 1px solid {WARNING_LINE};
                    border-radius: {R}px; color: {TEXT_PRIMARY};
                    font-size: {F_LABEL}px; font-weight: 400; padding: 9px 11px; }}
""")

# ------------------------------------------------------------- editor regions
STYLE += _f("""
/* The preview well: black only inside the canvas, a panel around it. */
QWidget#previewWell {{ background: {BG_PANEL}; border: 1px solid {BORDER_SOFT};
                      border-radius: {R_PANEL}px; }}
QWidget#emptyPreview {{ background: {BG_PANEL}; border-radius: {R_PANEL}px; }}

QWidget#toolbar {{ background: {BG_PANEL}; border: 1px solid {BORDER_SOFT};
                  border-radius: {R_PANEL}px; }}
QWidget#inspector {{ background: {BG_PANEL}; }}
QScrollArea#inspectorScroll {{ background: {BG_PANEL};
                              border: 1px solid {BORDER_SOFT};
                              border-radius: {R_PANEL}px; }}
QWidget#timelinePanel {{ background: {BG_PANEL}; border: 1px solid {BORDER_SOFT};
                        border-radius: {R_PANEL}px; }}
""")

# ------------------------------------------------------------- sign-in screen
STYLE += _f("""
QWidget#loginRoot {{ background: {BG_MAIN}; }}
QLabel#loginHeading {{ font-size: 19px; font-weight: 600;
                      color: {TEXT_PRIMARY}; }}
QLabel#loginMessage {{ color: {TEXT_MUTED}; font-size: {F_LABEL}px;
                      font-weight: 400; }}
QLabel#loginMessage[bad="true"] {{ color: {DANGER}; }}
QLabel#signedIn {{ color: {TEXT_SECOND}; font-size: {F_BODY}px;
                  font-weight: 500; }}
QPushButton#linkButton {{ background: transparent; border: 1px solid {BORDER};
                         border-radius: {R_BTN}px; color: {TEXT_SECOND};
                         font-size: {F_LABEL}px; font-weight: 500; }}
QPushButton#linkButton:hover {{ background: {BG_RAISED};
                               color: {TEXT_PRIMARY}; }}
QPushButton#linkButton:checked {{ background: {SELECT_BG};
                                 border-color: {SELECT_LINE}; color: {ACCENT}; }}
QLabel#copyright {{ color: {TEXT_MUTED}; font-size: 11px; font-weight: 400; }}
QLabel#version {{ color: {TEXT_MUTED}; font-size: 11px; font-weight: 500; }}
""")

# -------------------------------------------------------------- update banner
STYLE += _f("""
QFrame#updateBanner {{ background: {BG_RAISED}; border: 1px solid {SELECT_LINE};
                      border-radius: {R_PANEL}px; }}
QFrame#updateBanner QLabel {{ color: {TEXT_SECOND}; font-size: {F_BODY}px;
                             font-weight: 400; background: transparent; }}
QFrame#updateBanner QLabel#updateTitle {{ font-weight: 600;
                                         color: {TEXT_PRIMARY}; }}
QFrame#updateBanner QProgressBar {{ background: {BG_INPUT};
                                   border-color: {BORDER}; }}
""")


# Review-state badge, the details fold, the preview notice, the strip's
# scrollbar, and white lettering on a selected choice.
STYLE += _f("""
QLabel#stateBadge {{ border-radius: 10px; padding: 2px 10px; font-size: {F_LABEL}px;
                    font-weight: 600; background: {BG_RAISED}; color: {TEXT_SECOND};
                    border: 1px solid {BORDER}; }}
QLabel#stateBadge[state="approved"] {{ background: {SUCCESS_BG}; color: {SUCCESS};
                                      border-color: {SUCCESS_LINE}; }}
QLabel#stateBadge[state="rejected"] {{ background: {DANGER_BG}; color: {DANGER};
                                      border-color: {DANGER_LINE}; }}
QLabel#stateBadge[state="pending"]  {{ background: {BG_RAISED}; color: {TEXT_SECOND}; }}

QPushButton#choice:checked {{ color: {TEXT_PRIMARY}; }}

QScrollArea#stripScroll QScrollBar:horizontal {{ height: 14px; background: {BG_INPUT};
                                                border-radius: 7px; }}
QScrollArea#stripScroll QScrollBar::handle:horizontal {{ background: {BG_HOVER};
                                                        border-radius: 6px; min-width: 60px; }}
QScrollArea#stripScroll QScrollBar::handle:horizontal:hover {{ background: {ACCENT}; }}
""")
