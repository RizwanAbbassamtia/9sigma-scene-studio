"""Background threads so the window never freezes during long jobs."""
from __future__ import annotations

import threading
import time
import traceback
from pathlib import Path

from PySide6.QtCore import QObject, QThread, Signal

from .. import teamsheet
from ..assemble import build as assemble_build
from ..config import Config
from ..logging_setup import get
from ..models import Episode
from ..pipeline import analyse
from ..state import load_into
from ..thumbs import ensure as ensure_thumbs

log = get("worker")


class AnalysisWorker(QThread):
    progress = Signal(int, int, str)
    thumbs_ready = Signal(dict)
    state_discarded = Signal(str, int)
    finished_ok = Signal(object)
    failed = Signal(str)

    def __init__(self, folder: Path, config: Config, parent: QObject | None = None):
        super().__init__(parent)
        self._folder = folder
        self._config = config

    def run(self):
        started = time.time()
        log.info("Analysis started: %s", self._folder)
        try:
            episode = analyse(
                self._folder,
                self._config,
                progress=lambda d, t, label: self.progress.emit(d, t, label),
            )
            loaded = load_into(episode)       # bring back any earlier review decisions
            if loaded.reason:
                log.info("Previous state discarded: %s", loaded.reason)
                self.state_discarded.emit(loaded.reason, loaded.discarded)

            # Thumbnails come after the analysis so the editor sees flags sooner;
            # they are cached on disk, so this only costs anything the first time.
            mapping = ensure_thumbs(
                episode,
                progress=lambda d, t, label: self.progress.emit(d, t, label),
            )
            self.thumbs_ready.emit({k: str(v) for k, v in mapping.items()})

            log.info(
                "Analysis finished in %.0fs: %d clips, %d flagged, %d decisions restored",
                time.time() - started, len(episode.clips), len(episode.flagged),
                loaded.restored,
            )
            self.finished_ok.emit(episode)
        except Exception as exc:              # noqa: BLE001
            log.error("Analysis failed on %s\n%s", self._folder, traceback.format_exc())
            self.failed.emit(str(exc))


class BuildWorker(QThread):
    progress = Signal(int, int, str)
    finished_ok = Signal(str)
    failed = Signal(str)

    def cancel(self) -> None:
        """Stop the export at its next safe point; the finished segments
        stay on disk and the next export of the same file continues."""
        self._cancel.set()

    def __init__(self, episode: Episode, config: Config, output: Path, parent=None,
                 username: str = "", display_name: str = ""):
        super().__init__(parent)
        self._episode = episode
        self._config = config
        self._output = output
        self._username = username
        self._display_name = display_name
        self._cancel = threading.Event()    # this export's own stop token

    def run(self):
        started = time.time()
        log.info("Export started -> %s", self._output)
        try:
            path = assemble_build(
                self._episode,
                self._config,
                self._output,
                include_pending=True,
                progress=lambda d, t, label: self.progress.emit(d, t, label),
                cancel=self._cancel,
            )
            size = Path(path).stat().st_size / (1024 * 1024)
            log.info("Export finished in %.0fs: %.1f MB", time.time() - started, size)
            teamsheet.report_export(self._episode, Path(path), self._username, self._display_name, "Editor")
            self.finished_ok.emit(str(path))
        except Exception as exc:              # noqa: BLE001
            log.error("Export failed -> %s\n%s", self._output, traceback.format_exc())
            self.failed.emit(str(exc))
