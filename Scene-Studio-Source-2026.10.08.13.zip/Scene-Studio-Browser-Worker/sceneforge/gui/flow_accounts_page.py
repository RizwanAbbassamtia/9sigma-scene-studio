"""The Google Flow accounts screen: the inventory of accounts people
generate clips in, the credits each had when someone last looked, who each
is assigned to, and a manual queue of one production's clips.

Nothing on this page talks to Google. Generation in Flow is done by a
person in a browser; the page keeps the bookkeeping so the office knows
which account has credits left, who is on which clip, and which files have
arrived. Every read and write of the shared folder runs on a small thread,
like the master log page, and the screen paints only what came back.
"""
from __future__ import annotations

import os
import time
from dataclasses import replace
from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QFrame,
    QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget, QMessageBox, QPlainTextEdit,
    QPushButton, QSpinBox, QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .. import chrome_profiles
from ..config import Config
from ..logging_setup import get
from ..production.credentials import GEMINI, Credentials
from ..production.flow_accounts import (
    FLOW_QUEUE_DIR, RENEWAL_BY, RENEWAL_DAY_MAX, FlowAccount, FlowAccountBook, ManualClipQueue, QueueRow,
    clips_left, reconcile, title_clips_dir, title_queue_path,
)
from ..production.gemini_video import MODEL_LABELS, OMNI_FLASH_MODEL, GeminiVideoGenerator
from ..production.manifest import MANIFEST_NAME, Production, now
from ..production.master import MasterLog, _decode, _one_line, safe_name
from ..production.prompts import parse_report
from ..production.providers import ProviderError, validate_clip
from . import theme
from .gemini_keys import GeminiKeysDialog
from .master_page import SHARE_WAIT_MS, _LogWriter, _hint, _inside, _orphan, _section, _verbatim, _when

log = get("flow_accounts.page")

BANNER = ("Manage accounts and credits. Generate scenes opens the browser queue with live credit checks; "
          "connect each Google account once before starting.")
# The same first-step text the master log uses: it is the same folder.
FOLDER_TEXT = ("The shared folder is one folder that every editor's machine can reach: it holds the Google "
               "Flow account inventory, the manual queues and the clips people drop in.\n\nFor the office, "
               "choose a folder on the shared drive. To try it on this PC first, use:\n{}")
FOLDER_SUGGESTED = Path.home() / "Documents" / "9 Sigma Master Log"
ACCOUNT_COLUMNS = ("Id", "Label", "Email", "Credits", "Checked", "Clips left", "Status", "Editor", "Renews")
A_ID, A_LABEL, A_EMAIL, A_CREDITS, A_CHECKED, A_LEFT, A_STATUS, A_EDITOR, A_RENEWS = range(9)
RENEWAL_HINT = ("Flow gives the plan's credits back on this day each month (Plus 200, Pro 1,000, Ultra "
                "10,000 or 25,000); the tool assumes it and marks the figure 'assumed' until someone checks "
                "Flow. 0 = no renewal known.")
ASSUMED_TIP = "assumed by the tool from a scheduled renewal; check Flow and press Set credits if different"
EDIT_NOTE = "edited in the table"
RENEWAL_CHECK_MS = 60 * 1000          # while the page is open, renewals are looked at this often
QUEUE_COLUMNS = ("Scene", "Clip", "Prompt", "Account", "Editor", "Status", "File")
Q_SCENE, Q_CLIP, Q_PROMPT, Q_ACCOUNT, Q_EDITOR, Q_STATUS, Q_FILE = range(7)
STATUS_WORDS = {"active": "Active", "low": "Low", "exhausted": "Exhausted", "paused": "Paused",
                "todo": "To do", "generating": "Generating", "done": "Done", "failed": "Failed"}
PROMPT_SHORT = 90
PROFILE_HINT = ("Sign in to this Google account once in that Chrome profile (Chrome menu → Add person). "
                "The app only opens Chrome with it; it never signs in for you.")
NO_PROFILE = "(none)"
BILLING_SENTENCE = "Each clip is billed per generated second on your Google Cloud account."
GEMINI_HINT = ("Automatic generation through Google's Gemini API on your own billed key: no Google account "
               "is signed in and no Flow credits are used. " + BILLING_SENTENCE)
MAX_IN_FLIGHT = 3                       # clips submitted to Gemini at once
GEN_LOG_MAX = 300                       # lines kept in the small log list
GEN_WAIT_MS = 15000                     # a closing window waits this long for the clip in flight


def _short(text: str) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= PROMPT_SHORT else text[:PROMPT_SHORT - 1] + "…"


def _plain(text) -> QTableWidgetItem:
    item = QTableWidgetItem(str(text if text is not None else ""))
    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
    return item


def _ordinal(day: int) -> str:
    day = int(day)
    suffix = "th" if 10 <= day % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
    return "{}{}".format(day, suffix)


def _renews_text(account: FlowAccount) -> str:
    """'1000 on 5th', or nothing when no renewal is known."""
    if account.daily_credits:
        monthly = " + {} monthly".format(account.monthly_credits) if account.monthly_credits else ""
        return "{}/day, 00:00 Pacific (assumed){}".format(account.daily_credits, monthly)
    if account.monthly_credits > 0 and account.renews_on_day > 0:
        return "{} on {}".format(account.monthly_credits, _ordinal(account.renews_on_day))
    return ""


# ------------------------------------------------------------- dialogs
class AccountDialog(QDialog):
    """New or edited account: a label, the email people know it by, the
    cost per clip, the editor and notes. No password field exists."""

    def __init__(self, default_cost: int, account: Optional[FlowAccount] = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Edit account" if account else "Add account")
        self.setMinimumWidth(460)
        form = QFormLayout(self)
        form.addRow(_hint("The email is only so people can tell the accounts apart; the app never "
                          "signs in with it and never asks for its password."))
        self.label = QLineEdit(account.label if account else "")
        self.label.setPlaceholderText("Flow 3 (Rizwan)")
        self.email = QLineEdit(account.email if account else "")
        self.email.setPlaceholderText("name@gmail.com")
        self.cost = QSpinBox()
        self.cost.setRange(1, 100000)
        self.cost.setValue(account.credit_cost_per_clip if account else default_cost)
        self.credits = QSpinBox()
        self.credits.setRange(0, 100000000)
        self.daily = QSpinBox()
        self.daily.setRange(0, 100000000)
        self.daily.setSpecialValueText("off")
        self.daily.setValue(account.daily_credits if account else 50)
        self.credits.setValue(account.credits_last_seen if account else 50)
        self.monthly = QSpinBox()
        self.monthly.setRange(0, 100000000)
        self.monthly.setSpecialValueText("none")
        self.monthly.setValue(account.monthly_credits if account else 0)
        self.monthly.setToolTip("The credits the plan gives back each month; 0 when it gives none")
        self.renews_day = QSpinBox()
        self.renews_day.setRange(0, RENEWAL_DAY_MAX)
        self.renews_day.setSpecialValueText("none")
        self.renews_day.setValue(account.renews_on_day if account else 0)
        self.renews_day.setToolTip("The day of the month the billing cycle starts, 1 to {}".format(RENEWAL_DAY_MAX))
        self.editor = QLineEdit(account.assigned_editor if account else "")
        self.notes = QPlainTextEdit(account.notes if account else "")
        self.notes.setFixedHeight(70)
        self.profile = QComboBox()
        self.profile.setToolTip("The Chrome profile that is signed in to this account")
        self.btn_profiles = QPushButton("Refresh profiles")
        self.btn_profiles.setObjectName("quiet")
        self.btn_profiles.setToolTip("Re-read the list of profiles from Chrome")
        self.btn_profiles.clicked.connect(self.refresh_profiles)
        profile_row = QHBoxLayout()
        profile_row.addWidget(self.profile, 1)
        profile_row.addWidget(self.btn_profiles)
        form.addRow("Label", self.label)
        form.addRow("Email (display only)", self.email)
        form.addRow("Credits per clip", self.cost)
        if account is None:
            form.addRow("Credits seen now", self.credits)
        form.addRow("Daily credits", self.daily)
        form.addRow(_hint("Resets to this amount at midnight Pacific (planning estimate, not a Google reading). "
                          "Unused daily credits do not accumulate. Enabling this classifies existing credits; "
                          "use Set credits to confirm daily and other balances."))
        form.addRow("Monthly credits", self.monthly)
        form.addRow("Renews on day", self.renews_day)
        form.addRow(_hint(RENEWAL_HINT))
        form.addRow("Assigned editor", self.editor)
        form.addRow("Chrome profile", profile_row)
        form.addRow(_hint(PROFILE_HINT))
        form.addRow("Notes", self.notes)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self.refresh_profiles(account.chrome_profile if account else "")

    def refresh_profiles(self, wanted=None):
        """The person's Chrome profiles, "(none)" first. The account's own
        profile stays chosen; failing that, the profile whose address
        matches the email typed here."""
        current = wanted if isinstance(wanted, str) and wanted else self.chrome_profile()
        profiles = chrome_profiles.list_profiles()
        self.profile.clear()
        self.profile.addItem(NO_PROFILE, "")
        for directory, name, email in profiles:
            self.profile.addItem("{} — {}".format(name, email) if email else name, directory)
        choose = current or chrome_profiles.profile_for_email(self.email.text(), profiles)
        index = self.profile.findData(choose) if choose else -1
        self.profile.setCurrentIndex(index if index >= 0 else 0)

    def chrome_profile(self) -> str:
        return str(self.profile.currentData() or "")

    def values(self) -> dict:
        return {"label": self.label.text(), "email": self.email.text(), "cost": self.cost.value(),
                "credits": self.credits.value(), "editor": self.editor.text(),
                "notes": self.notes.toPlainText(), "chrome_profile": self.chrome_profile(),
                "daily_credits": self.daily.value(), "monthly_credits": self.monthly.value(), "renews_on_day": self.renews_day.value()}


class SetCreditsDialog(QDialog):
    """The number the person sees in Flow right now."""

    def __init__(self, account: FlowAccount, by: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Set credits")
        form = QFormLayout(self)
        form.addRow(_hint("Open Flow in the browser, read the credits shown for {} and type that number. "
                          "It is recorded as seen by {} at this time.".format(account.label, by or "you")))
        self.credits = QSpinBox()
        self.credits.setRange(0, 100000000)
        self.credits.setValue(account.credits_last_seen)
        self.daily = QSpinBox()
        self.daily.setRange(0, account.daily_credits)
        self.daily.setValue(account.daily_remaining)
        self.other = QSpinBox()
        self.other.setRange(0, 100000000)
        self.other.setValue(account.credits_last_seen - account.daily_remaining)
        if account.daily_credits:
            form.addRow("Daily credits remaining", self.daily)
            form.addRow("Monthly / other remaining", self.other)
        else:
            form.addRow("Credits shown in Flow now", self.credits)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)


# ----------------------------------------------------- automatic generation
class _GenerateThread(QThread):
    """One Gemini run over the chosen rows, off the GUI thread: submit up
    to MAX_IN_FLIGHT, poll every poll_seconds, download, check, mark. The
    job id is written to the queue file the moment Google returns it, so a
    run cut short (Stop, a crash, a closed window) is resumed by polling
    those rows -- never by submitting, and paying for, the clip again.

    Stop lets the clips in flight finish and submits nothing more; a key
    with no quota or a bad key stops the whole run with the message, the
    rows in flight kept as generating with their ids for a later resume."""
    event = Signal(str)                    # one line for the status line and the log list
    rows_changed = Signal(object)          # copies of the queue's rows after every save
    ended = Signal(str)                    # how the run ended, in words

    def __init__(self, generator, queue: ManualClipQueue, keys: List[str], clips_dir: Path, parent=None):
        super().__init__(parent)
        self.generator = generator
        self.queue = queue
        self.keys = list(keys)
        self.clips_dir = Path(clips_dir)
        self._stop = False                 # finish what is in flight, submit nothing more
        self._abort = False                # the window is closing: leave now, ids are on disk
        self.submitted = 0
        self.done_count = 0
        self.failed_count = 0

    def stop(self) -> None:
        self._stop = True

    def abort(self) -> None:
        self._stop = True
        self._abort = True

    # -- the queue file ------------------------------------------------------
    def _update(self, key: str, **fields) -> Optional[QueueRow]:
        """Re-read, change one row, save, and hand copies to the page."""
        self.queue.reload()
        try:
            row = self.queue.row(key)
        except KeyError:
            return None
        for name, value in fields.items():
            setattr(row, name, value)
        row.updated = now()
        self.queue.save()
        self.rows_changed.emit([replace(r) for r in self.queue.rows])
        return row

    def _pause(self) -> None:
        remaining = float(getattr(self.generator, "poll_seconds", 10.0) or 0)
        while remaining > 0 and not self._abort:
            step = min(0.25, remaining)
            time.sleep(step)
            remaining -= step

    # -- the run ---------------------------------------------------------------
    def run(self):
        try:
            self.ended.emit(self._run())
        except Exception as exc:                                       # noqa: BLE001 - shown to the person
            log.exception("Gemini run stopped unexpectedly")
            self.ended.emit("The Gemini run stopped: {}: {}".format(type(exc).__name__, _one_line(str(exc))[:200]))

    def _run(self) -> str:
        self.queue.reload()
        wanted = {k for k in self.keys}
        resume, pending = [], []
        for row in self.queue.rows:
            if row.key not in wanted:
                continue
            if row.status == "generating" and row.job_id and not row.file:
                resume.append(row.key)
            elif row.status in ("todo", "failed"):
                pending.append(row.key)
        if resume:
            self.event.emit("{} clip{} already submitted earlier: polling {} first, not submitting again."
                            .format(len(resume), "" if len(resume) == 1 else "s", "it" if len(resume) == 1 else "them"))
        in_flight: List[str] = list(resume)
        model = str(getattr(self.generator, "model", "") or "")
        while (in_flight or pending) and not self._abort:
            while pending and len(in_flight) < MAX_IN_FLIGHT and not self._stop:
                key = pending.pop(0)
                try:
                    row = self.queue.row(key)
                except KeyError:
                    continue
                try:
                    job = self.generator.submit(row.prompt, {"aspect_ratio": getattr(self.generator, "aspect_ratio", ""),
                                                             "resolution": getattr(self.generator, "resolution", "")})
                except ProviderError as exc:
                    if exc.exhausted or exc.fatal:
                        return self._stopped_by(exc, in_flight)
                    self.failed_count += 1
                    self._update(key, status="failed", note=_one_line(str(exc))[:400], job_status="failed")
                    self.event.emit("{}: not submitted: {}".format(key, _one_line(str(exc))[:200]))
                    continue
                self.submitted += 1
                self._update(key, status="generating", job_id=job.job_id, job_status=job.status or "queued",
                             job_model=model, note="", file="")
                self.event.emit("{}: submitted to Gemini (job {}).".format(key, job.job_id[-24:]))
                in_flight.append(key)
            if not in_flight:
                break
            self._pause()
            if self._abort:
                break
            for key in list(in_flight):
                try:
                    row = self.queue.row(key)
                except KeyError:
                    in_flight.remove(key)
                    continue
                try:
                    job = self.generator.poll(row.job_id)
                except ProviderError as exc:
                    if exc.exhausted or exc.fatal:
                        return self._stopped_by(exc, in_flight)
                    if exc.retryable:
                        self.event.emit("{}: {} (asking again)".format(key, _one_line(str(exc))[:200]))
                        continue
                    self._fail(key, str(exc))
                    in_flight.remove(key)
                    continue
                if job.status == "failed":
                    self._fail(key, job.error or "generation failed")
                    in_flight.remove(key)
                    continue
                if job.status != "done":
                    if job.status != row.job_status:
                        self._update(key, job_status=job.status)
                    continue
                try:
                    self._finish(key, row, job)
                except ProviderError as exc:                    # a download refused for the key's sake
                    return self._stopped_by(exc, in_flight)
                in_flight.remove(key)
        if self._abort:
            return "Generation paused: {} clip{} still generating; open the queue again to resume.".format(
                len(in_flight), "" if len(in_flight) == 1 else "s")
        if self._stop:
            return "Stopped: {} clip{} done, {} failed, {} left to do.".format(
                self.done_count, "" if self.done_count == 1 else "s", self.failed_count, len(pending))
        return "Gemini run finished: {} clip{} done, {} failed.".format(
            self.done_count, "" if self.done_count == 1 else "s", self.failed_count)

    def _stopped_by(self, exc: ProviderError, in_flight: List[str]) -> str:
        text = _one_line(str(exc))[:400]
        self.event.emit(text)
        if in_flight:
            self.event.emit("{} clip{} in flight kept with {} job id{} for a later resume.".format(
                len(in_flight), "" if len(in_flight) == 1 else "s", "its" if len(in_flight) == 1 else "their",
                "" if len(in_flight) == 1 else "s"))
        return "Stopped: " + text

    def _fail(self, key: str, why: str) -> None:
        self.failed_count += 1
        self._update(key, status="failed", note=_one_line(why)[:400], job_status="failed")
        self.event.emit("{}: failed: {}".format(key, _one_line(why)[:200]))

    def _finish(self, key: str, row: QueueRow, job) -> None:
        dest = self.clips_dir / row.filename
        if dest.is_file() and not validate_clip(dest):
            # Someone dropped a good file for this row meanwhile: kept.
            self.done_count += 1
            self._update(key, status="done", file=dest.name, note="", job_status="done")
            self.event.emit("{}: {} was already there and is complete; kept.".format(key, dest.name))
            return
        try:
            self.generator.download(job, dest)
        except ProviderError as exc:
            if exc.exhausted or exc.fatal:
                raise
            self._fail(key, "download failed: {}".format(exc))
            return
        problem = validate_clip(dest)
        if problem:
            self._fail(key, "{} {}".format(dest.name, problem))
            return
        self.done_count += 1
        self._update(key, status="done", file=dest.name, note="", job_status="done")
        self.event.emit("{}: {} is done.".format(key, dest.name))


# ------------------------------------------------------------- the page
class FlowAccountsPage(QWidget):
    back_requested = Signal()

    def __init__(self, config: Config, parent=None, omniflow: bool = False,
                 credentials: Optional[Credentials] = None):
        super().__init__(parent)
        self.config = config
        self.credentials = credentials if credentials is not None else Credentials()
        self._gen_thread: Optional[_GenerateThread] = None
        # In 9 Sigma Omni Flow this page is the whole app: no editor to go
        # back to, and no production.json to open -- queues come from a
        # prompt file and live under the shared folder.
        self.omniflow = bool(omniflow)
        self.folder: Optional[Path] = None
        self.book: Optional[FlowAccountBook] = None
        self._accounts: List[FlowAccount] = []
        self._default_cost = 0
        self.production: Optional[Production] = None
        self.queue: Optional[ManualClipQueue] = None
        self._rows: List[QueueRow] = []
        self._loader: Optional[_LogWriter] = None
        self._writer: Optional[_LogWriter] = None
        self._pending = None
        self._reload_wanted = False
        self._load_error = ""
        self._closing = False
        self._painting = False                  # the table is being filled: its itemChanged is not an edit
        self._build()
        # Once a day is enough for a monthly renewal; every 6 h loses nothing.
        self._renewal_timer = QTimer(self)
        self._renewal_timer.setInterval(RENEWAL_CHECK_MS)
        self._renewal_timer.timeout.connect(self.refresh)
        self._renewal_timer.start()

    # -- layout -------------------------------------------------------------
    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(theme.SPACE_2, theme.SPACE_1, theme.SPACE_2, theme.SPACE_1)
        outer.setSpacing(theme.SPACE_1)

        bar = QHBoxLayout()
        self.bar = bar                          # the window adds its account menu here in Omni Flow
        self.btn_back = QPushButton("‹ Editor")
        self.btn_back.clicked.connect(self.back_requested.emit)
        self.btn_back.setVisible(not self.omniflow)
        heading = QLabel("Google Flow accounts")
        heading.setObjectName("title")
        self.folder_label = _hint("No folder open")
        self.btn_folder = QPushButton("Folder…")
        self.btn_folder.setObjectName("quiet")
        self.btn_folder.setToolTip("Choose the shared folder that holds the inventory and the queues")
        self.btn_folder.clicked.connect(self.choose_folder)
        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.setObjectName("quiet")
        self.btn_refresh.clicked.connect(self.refresh)
        self.btn_cost = QPushButton("Cost per clip…")
        self.btn_cost.setObjectName("quiet")
        self.btn_cost.setToolTip("The credits one clip costs, used for new accounts and the 'clips left' column")
        self.btn_cost.clicked.connect(self.change_default_cost)
        bar.addWidget(self.btn_back)
        bar.addSpacing(theme.SPACE_2)
        bar.addWidget(heading)
        bar.addSpacing(theme.SPACE_1)
        bar.addWidget(self.folder_label, 1)
        bar.addWidget(self.btn_folder)
        bar.addWidget(self.btn_refresh)
        bar.addWidget(self.btn_cost)
        outer.addLayout(bar)

        self.banner = QLabel(BANNER)
        self.banner.setObjectName("hint")
        self.banner.setWordWrap(True)
        self.banner.setTextFormat(Qt.PlainText)
        outer.addWidget(self.banner)

        split = QSplitter(Qt.Vertical)

        # -- accounts -------------------------------------------------------
        top = QFrame()
        top.setObjectName("card")
        top_box = QVBoxLayout(top)
        top_box.setContentsMargins(12, 10, 12, 10)
        top_box.setSpacing(theme.SPACE_1)
        top_box.addWidget(_section("Accounts"))
        self.accounts_table = QTableWidget(0, len(ACCOUNT_COLUMNS))
        self.accounts_table.setHorizontalHeaderLabels(ACCOUNT_COLUMNS)
        self.accounts_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.accounts_table.setSelectionMode(QAbstractItemView.SingleSelection)
        # Only the Credits cell is editable (double-click or F2); the rest stay read-only items.
        self.accounts_table.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        self.accounts_table.verticalHeader().setVisible(False)
        self.accounts_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.accounts_table.horizontalHeader().setSectionResizeMode(A_LABEL, QHeaderView.Stretch)
        self.accounts_table.itemSelectionChanged.connect(self._paint_account_actions)
        self.accounts_table.doubleClicked.connect(self._on_account_double_clicked)
        self.accounts_table.itemChanged.connect(self._on_account_item_changed)
        top_box.addWidget(self.accounts_table, 1)
        actions = QHBoxLayout()
        self.btn_browser = QPushButton("Generate scenes…")
        self.btn_browser.clicked.connect(self.open_browser_queue)
        self.btn_release = QPushButton("Build / push update…")
        self.btn_release.clicked.connect(self.open_release_panel)
        self.btn_release.setVisible(self.omniflow)
        self.bar.addWidget(self.btn_browser)
        self.btn_scene_web = QPushButton("Open Scene Studio (web)…")
        self.btn_scene_web.clicked.connect(self.open_scene_studio)
        self.btn_scene_web.setVisible(self.omniflow)
        self.bar.addWidget(self.btn_scene_web)
        self.bar.addWidget(self.btn_release)
        self.btn_add = QPushButton("Add account…")
        self.btn_add.clicked.connect(self.add_account_dialog)
        self.btn_bulk = QPushButton("Add emails…")
        self.btn_bulk.clicked.connect(self.bulk_accounts_dialog)
        self.btn_edit = QPushButton("Edit…")
        self.btn_edit.clicked.connect(self.edit_account_dialog)
        self.btn_credits = QPushButton("Set credits…")
        self.btn_credits.clicked.connect(self.set_credits_dialog)
        self.btn_pause = QPushButton("Pause")
        self.btn_pause.clicked.connect(self.toggle_pause)
        self.btn_assign_account = QPushButton("Assign to editor…")
        self.btn_assign_account.clicked.connect(self.assign_account_dialog)
        self.btn_next = QPushButton("Who's next")
        self.btn_next.setToolTip("The active account with the most credits, assigned to you or to nobody")
        self.btn_next.clicked.connect(self.show_next)
        self.btn_chrome = QPushButton("Open in Chrome")
        self.btn_chrome.setToolTip("Open flow.google.com in the Chrome profile set for this account "
                                   "(Edit… → Chrome profile). The app never signs in for you.")
        self.btn_chrome.clicked.connect(self.open_selected_in_chrome)
        for button in (self.btn_add, self.btn_bulk, self.btn_edit, self.btn_credits, self.btn_pause, self.btn_assign_account,
                       self.btn_next, self.btn_chrome):
            actions.addWidget(button)
        actions.addStretch(1)
        top_box.addLayout(actions)
        next_row = QHBoxLayout()
        self.next_line = _hint("")
        self.btn_next_chrome = QPushButton("Open next in Chrome")
        self.btn_next_chrome.setObjectName("quiet")
        self.btn_next_chrome.clicked.connect(self.open_next_in_chrome)
        self.btn_next_chrome.setVisible(False)
        self._next_account: Optional[FlowAccount] = None
        next_row.addWidget(self.next_line, 1)
        next_row.addWidget(self.btn_next_chrome)
        top_box.addLayout(next_row)
        split.addWidget(top)

        # -- queue ----------------------------------------------------------
        bottom = QFrame()
        bottom.setObjectName("card")
        bottom_box = QVBoxLayout(bottom)
        bottom_box.setContentsMargins(12, 10, 12, 10)
        bottom_box.setSpacing(theme.SPACE_1)
        head = QHBoxLayout()
        head.addWidget(_section("Manual queue"))
        self.btn_import = QPushButton("Import prompts…")
        self.btn_import.setToolTip("A numbered prompt file (.txt) becomes a queue of clips for one title")
        self.btn_import.clicked.connect(self.import_prompts_dialog)
        self.btn_open_queue = QPushButton("Open queue…")
        self.btn_open_queue.setToolTip("A queue imported earlier, from the shared folder's {}".format(FLOW_QUEUE_DIR))
        self.btn_open_queue.clicked.connect(self.open_queue_dialog)
        self.btn_open = QPushButton("Open production…")
        self.btn_open.clicked.connect(self.open_production_dialog)
        self.production_label = _hint("No queue open. Import a prompt file to list its clips as work for people."
                                      if self.omniflow else
                                      "No queue open. Import a prompt file, or open a production, to list its "
                                      "clips as work for people.")
        self.episode_label = QLabel("Episode")
        self.episode_pick = QComboBox()
        self.episode_pick.setToolTip("Episode")
        self.episode_pick.currentIndexChanged.connect(self._on_episode_picked)
        head.addWidget(self.btn_import)
        head.addWidget(self.btn_open_queue)
        head.addWidget(self.btn_open)
        head.addSpacing(theme.SPACE_1)
        head.addWidget(self.production_label, 1)
        head.addWidget(self.episode_label)
        head.addWidget(self.episode_pick)
        for widget in (self.btn_open, self.episode_label, self.episode_pick):
            widget.setVisible(not self.omniflow)
        bottom_box.addLayout(head)
        self.queue_table = QTableWidget(0, len(QUEUE_COLUMNS))
        self.queue_table.setHorizontalHeaderLabels(QUEUE_COLUMNS)
        self.queue_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.queue_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.queue_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.queue_table.verticalHeader().setVisible(False)
        self.queue_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.queue_table.horizontalHeader().setSectionResizeMode(Q_PROMPT, QHeaderView.Stretch)
        bottom_box.addWidget(self.queue_table, 1)
        q_actions = QHBoxLayout()
        self.btn_copy = QPushButton("Copy prompt")
        self.btn_copy.clicked.connect(self.copy_prompt)
        self.btn_copy_open = QPushButton("Copy prompt and open account")
        self.btn_copy_open.setToolTip("Copy the prompt, then open flow.google.com in the Chrome profile of the "
                                      "account this clip is assigned to")
        self.btn_copy_open.clicked.connect(self.copy_prompt_and_open)
        self.btn_q_account = QPushButton("Assign to account…")
        self.btn_q_account.clicked.connect(self.assign_rows_account_dialog)
        self.btn_q_editor = QPushButton("Assign to editor…")
        self.btn_q_editor.clicked.connect(self.assign_rows_editor_dialog)
        self.btn_generating = QPushButton("Mark generating")
        self.btn_generating.clicked.connect(lambda: self.mark_selected("generating"))
        self.btn_failed = QPushButton("Mark failed")
        self.btn_failed.clicked.connect(lambda: self.mark_selected("failed"))
        self.btn_reconcile = QPushButton("Refresh from clips folder")
        self.btn_reconcile.setToolTip("Match the files dropped into the clips folder to these rows")
        self.btn_reconcile.clicked.connect(self.refresh_from_clips)
        self.btn_clips = QPushButton("Open clips folder")
        self.btn_clips.clicked.connect(self.open_clips_folder)
        for button in (self.btn_copy, self.btn_copy_open, self.btn_q_account, self.btn_q_editor,
                       self.btn_generating, self.btn_failed, self.btn_reconcile, self.btn_clips):
            q_actions.addWidget(button)
        q_actions.addStretch(1)
        bottom_box.addLayout(q_actions)

        # -- automatic generation (Gemini) ----------------------------------
        gem_head = QHBoxLayout()
        gem_head.addWidget(_section("Generate with Gemini"))
        self.gemini_settings = _hint("")
        gem_head.addWidget(self.gemini_settings, 1)
        bottom_box.addLayout(gem_head)
        bottom_box.addWidget(_hint(GEMINI_HINT))
        g_actions = QHBoxLayout()
        self.btn_gemini_key = QPushButton("Google Gemini key…")
        self.btn_gemini_key.setToolTip("The Gemini API key, the model and the video settings")
        self.btn_gemini_key.clicked.connect(self.gemini_key_dialog)
        self.btn_gen_selected = QPushButton("Generate selected (Gemini)")
        self.btn_gen_selected.setToolTip("Submit the selected to-do or failed clips to Gemini")
        self.btn_gen_selected.clicked.connect(self.generate_selected)
        self.btn_gen_all = QPushButton("Generate all to-do (Gemini)")
        self.btn_gen_all.setToolTip("Submit every to-do or failed clip in the queue to Gemini")
        self.btn_gen_all.clicked.connect(self.generate_all_todo)
        self.btn_gen_stop = QPushButton("Stop")
        self.btn_gen_stop.setToolTip("Finish the clips in flight and submit nothing more")
        self.btn_gen_stop.clicked.connect(self.stop_generation)
        for button in (self.btn_gemini_key, self.btn_gen_selected, self.btn_gen_all, self.btn_gen_stop):
            g_actions.addWidget(button)
        g_actions.addStretch(1)
        bottom_box.addLayout(g_actions)
        self.gemini_log = QListWidget()
        self.gemini_log.setFixedHeight(84)
        self.gemini_log.setToolTip("What the Gemini run did, newest last")
        bottom_box.addWidget(self.gemini_log)
        self._paint_gemini_settings()
        split.addWidget(bottom)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 1)
        split.setSizes([320, 320])                 # the accounts list is the point of the page: half the height
        outer.addWidget(split, 1)

        self.status_line = _hint("")
        outer.addWidget(self.status_line)
        self._paint_accounts()
        self._paint_queue()

    # -- who is signed in -----------------------------------------------------
    def editor_name(self) -> str:
        return str(getattr(self.config, "editor_name", "") or "").strip()

    # -- the shared folder ----------------------------------------------------
    def choose_folder(self):
        """The first-step dialog the master log uses, then the folder is
        remembered in config.master_log_dir: it is the same folder."""
        box = QMessageBox(self)
        box.setWindowTitle("Shared folder")
        box.setText(FOLDER_TEXT.format(FOLDER_SUGGESTED))
        this_pc = box.addButton("Use this PC", QMessageBox.AcceptRole)
        choose = box.addButton("Choose a shared folder…", QMessageBox.ActionRole)
        box.addButton(QMessageBox.Cancel)
        box.exec()
        if box.clickedButton() is this_pc:
            try:
                FOLDER_SUGGESTED.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                QMessageBox.warning(self, "Shared folder", "That folder could not be created: {}".format(exc))
                return
            folder = str(FOLDER_SUGGESTED)
        elif box.clickedButton() is choose:
            chosen = QFileDialog.getExistingDirectory(
                self, "Choose the shared folder (the folder every editor's machine can reach)",
                str(self.folder) if self.folder else str(Path.home() / "Documents"))
            if not chosen:
                return
            folder = chosen
        else:
            return
        self.use_folder(folder)

    def use_folder(self, folder) -> None:
        self.config.master_log_dir = str(folder)
        try:
            self.config.save(Path.cwd())
        except OSError as exc:
            log.warning("config.json could not be saved: %s", exc)
        self.load(Path(folder))

    # -- loading the inventory -----------------------------------------------
    def load(self, folder):
        self._closing = False
        folder = Path(folder)
        if folder != self.folder:
            self.book = None
            self._accounts = []
            self._paint_accounts()
        self.folder = folder
        self._load_error = ""
        self.folder_label.setText(str(folder))
        self.folder_label.setToolTip(_verbatim(folder))
        self.refresh()

    def refresh(self):
        if self.folder is None or self._closing:
            return
        if self._loader is not None and self._loader.isRunning():
            self._reload_wanted = True
            return
        self._reload_wanted = False
        folder = self.folder
        book = self.book if self.book is not None and self.book.master.folder == folder else None

        def read():
            current = book or FlowAccountBook(MasterLog(folder))
            # Monthly renewals that fell due since the last look: written
            # under the master lock, and only when an account changed.
            renewed = current.renew()
            return folder, current, current.default_cost(), list(current.accounts()), len(renewed)
        self._loader = _LogWriter(read, self)
        self._loader.done.connect(self._on_loaded)
        self._loader.failed.connect(self._on_load_failed)
        self._loader.finished.connect(self._on_loader_finished)
        self._loader.finished.connect(self._loader.deleteLater)
        self._loader.start()
        self._say("Reading the inventory…")

    def _on_loaded(self, snapshot):
        folder, book, default_cost, accounts, renewed = snapshot
        if folder != self.folder:
            return
        self.book = book
        self._default_cost = default_cost
        self._accounts = accounts
        self._load_error = ""
        self._paint_accounts()
        self._say("{} account{} in the inventory.{}".format(
            len(accounts), "" if len(accounts) == 1 else "s",
            " {} renewed: the credits are assumed until someone checks Flow.".format(renewed)
            if renewed else ""))

    def _on_load_failed(self, exc):
        self._load_error = "{}: {}".format(type(exc).__name__, exc)
        self._say("The inventory could not be read: " + self._load_error)

    def _on_loader_finished(self):
        if self.sender() is not self._loader:
            return
        self._loader = None
        if self._reload_wanted:
            self.refresh()

    def wait_until_loaded(self, timeout_ms: int = 10000) -> bool:
        app = QApplication.instance()
        deadline = time.monotonic() + timeout_ms / 1000.0
        while time.monotonic() < deadline:
            if app is not None:
                app.processEvents()
            if self._load_error:
                return False
            if self.book is not None and self._loader is None and not self._reload_wanted:
                return True
            time.sleep(0.02)
        return False

    def wait_until_idle(self, timeout_ms: int = 10000) -> bool:
        app = QApplication.instance()
        deadline = time.monotonic() + timeout_ms / 1000.0
        while time.monotonic() < deadline:
            if app is not None:
                app.processEvents()
            if self._writer is None and self._loader is None and not self._reload_wanted:
                return True
            time.sleep(0.02)
        return False

    # -- writing ------------------------------------------------------------
    def _writing(self) -> bool:
        return self._writer is not None

    def _write(self, what: str, action, on_done, on_error=None) -> bool:
        if self._writing():
            self._say("Still saving the last change; try again in a moment.")
            return False
        self._pending = (what, on_done, on_error)
        self._writer = _LogWriter(action, self)
        self._writer.done.connect(self._on_write_done)
        self._writer.failed.connect(self._on_write_failed)
        self._writer.finished.connect(self._on_writer_finished)
        self._writer.finished.connect(self._writer.deleteLater)
        self._writer.start()
        return True

    def _on_write_done(self, result):
        if self._pending is None or self.sender() is not self._writer:
            return
        _, on_done, _ = self._pending
        on_done(result)

    def _on_write_failed(self, exc):
        if self._pending is None or self.sender() is not self._writer:
            return
        what, _, on_error = self._pending
        if on_error is not None:
            on_error(exc)
        else:
            self._say("{}: {}".format(what, exc))
            QMessageBox.warning(self, what, _verbatim(exc))

    def _on_writer_finished(self):
        if self.sender() is not self._writer:
            return
        self._writer = None
        self._pending = None

    def _after_account_change(self, account):
        self._say("Saved {} ({}).".format(account.label, STATUS_WORDS.get(account.status, account.status)))
        self.refresh()

    # -- painting -----------------------------------------------------------
    def _paint_accounts(self):
        wanted = self.selected_account_id()
        table = self.accounts_table
        self._painting = True
        try:
            table.setRowCount(0)
            table.setRowCount(len(self._accounts))
            for row, account in enumerate(self._accounts):
                self._paint_account_row(row, account)
                if account.id == wanted:
                    table.selectRow(row)
        finally:
            self._painting = False
        self._paint_account_actions()

    def _paint_account_row(self, row: int, account: FlowAccount):
        table = self.accounts_table
        cells = [account.id, account.label, account.email, str(account.credits_last_seen),
                 _when(account.credits_checked_at), str(clips_left(account)),
                 STATUS_WORDS.get(account.status, account.status), account.assigned_editor, _renews_text(account)]
        for column, text in enumerate(cells):
            item = _plain(text)
            if column == A_CREDITS:
                item.setFlags(item.flags() | Qt.ItemIsEditable)
                item.setToolTip("Daily: {} | Monthly/other: {}. Set credits edits each balance. "
                                "Editing the total deducts daily credits first.".format(
                                    account.daily_remaining, account.credits_last_seen - account.daily_remaining))
            if column == A_CHECKED and account.credits_checked_by:
                item.setToolTip(_verbatim(ASSUMED_TIP if account.credits_checked_by == RENEWAL_BY
                                          else "seen by " + account.credits_checked_by))
            if column == A_LABEL and account.notes:
                item.setToolTip(_verbatim(account.notes))
            if column == A_RENEWS and account.last_renewed:
                item.setToolTip(_verbatim("last renewal noted on " + account.last_renewed))
            table.setItem(row, column, item)

    def _repaint_account_row(self, account_id: str):
        for row, account in enumerate(self._accounts):
            if account.id == account_id:
                self._painting = True
                try:
                    self._paint_account_row(row, account)
                finally:
                    self._painting = False
                return

    def _on_account_double_clicked(self, index):
        # A double-click on Credits starts the in-place edit; anywhere else opens Chrome.
        if index.column() == A_CREDITS:
            return
        self.open_selected_in_chrome()

    def _on_account_item_changed(self, item: QTableWidgetItem):
        """A Credits cell committed by the person: the same as Set credits,
        noted as edited in the table. Anything but a whole number at or
        above zero is refused in the status line and the cell restored."""
        if self._painting or item.column() != A_CREDITS:
            return
        id_item = self.accounts_table.item(item.row(), A_ID)
        account_id = id_item.text() if id_item is not None else ""
        account = next((a for a in self._accounts if a.id == account_id), None)
        if account is None or self.book is None:
            return
        text = item.text().strip().replace(",", "")
        try:
            credits = int(text)
            if credits < 0:
                raise ValueError
        except ValueError:
            self._say("'{}' is not a credit figure: type a whole number at or above zero, the one Flow shows."
                      .format(item.text()[:40]))
            self._repaint_account_row(account_id)
            return
        if credits == account.credits_last_seen:
            self._repaint_account_row(account_id)
            return
        if not self.set_credits(account_id, credits, note=EDIT_NOTE):
            self._repaint_account_row(account_id)

    def _paint_account_actions(self):
        account = self.selected_account()
        have = account is not None and self.book is not None
        for button in (self.btn_edit, self.btn_credits, self.btn_pause, self.btn_assign_account):
            button.setEnabled(have)
        self.btn_browser.setEnabled(self.book is not None)
        self.btn_add.setEnabled(self.book is not None)
        self.btn_bulk.setEnabled(self.book is not None)
        self.btn_next.setEnabled(self.book is not None)
        self.btn_chrome.setEnabled(have and bool(account.chrome_profile))
        self.btn_pause.setText("Resume" if account is not None and account.status == "paused" else "Pause")

    def selected_account_id(self) -> str:
        rows = self.accounts_table.selectionModel().selectedRows() if self.accounts_table.selectionModel() else []
        if not rows:
            return ""
        item = self.accounts_table.item(rows[0].row(), A_ID)
        return item.text() if item is not None else ""

    def selected_account(self) -> Optional[FlowAccount]:
        wanted = self.selected_account_id()
        return next((a for a in self._accounts if a.id == wanted), None)

    def _paint_queue(self):
        table = self.queue_table
        selected = set(self.selected_keys())
        table.setRowCount(0)
        table.setRowCount(len(self._rows))
        labels = {a.id: a.label for a in self._accounts}
        for index, row in enumerate(self._rows):
            account = row.account_id
            if account and account in labels:
                account = "{} {}".format(account, labels[account])
            cells = [str(row.scene), str(row.clip), _short(row.prompt), account, row.editor,
                     STATUS_WORDS.get(row.status, row.status), row.file]
            for column, text in enumerate(cells):
                item = _plain(text)
                if column == Q_PROMPT:
                    item.setToolTip(_verbatim(row.prompt))
                elif column == Q_STATUS and row.note:
                    item.setToolTip(_verbatim(row.note))
                table.setItem(index, column, item)
            if row.key in selected:
                table.selectRow(index)
        have = self.queue is not None
        for button in (self.btn_copy, self.btn_copy_open, self.btn_q_account, self.btn_q_editor,
                       self.btn_generating, self.btn_failed, self.btn_reconcile, self.btn_clips):
            button.setEnabled(have)
        running = self.generating()
        self.btn_gen_selected.setEnabled(have and not running)
        self.btn_gen_all.setEnabled(have and not running)
        self.btn_gen_stop.setEnabled(running)

    def selected_keys(self) -> List[str]:
        model = self.queue_table.selectionModel()
        if model is None:
            return []
        keys = []
        for index in sorted(r.row() for r in model.selectedRows()):
            if index < len(self._rows):
                keys.append(self._rows[index].key)
        return keys

    def select_keys(self, keys) -> None:
        wanted = set(keys)
        self.queue_table.clearSelection()
        for index, row in enumerate(self._rows):
            if row.key in wanted:
                self.queue_table.selectRow(index)

    def status_text(self) -> str:
        return self.status_line.text()

    def _say(self, text: str):
        self.status_line.setText(text)

    # -- account actions ------------------------------------------------------
    def open_scene_studio(self):
        import subprocess
        import sys
        user = getattr(self.window(), 'user', None)
        if getattr(user, 'role', '') != 'admin':
            QMessageBox.information(self, 'Administrator access', 'An administrator opens the local account-management dashboard.')
            return
        if self.book is None:
            return
        root = Path(__file__).resolve().parents[2]
        subprocess.Popen([sys.executable, '-m', 'sceneforge.scene_server', '--root', str(root),
                          '--accounts-folder', str(self.book.master.folder)], cwd=str(root),
                         creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))

    def open_browser_queue(self):
        if self.book is None:
            return
        from .flow_browser_dialog import FlowBrowserDialog
        user = getattr(self.window(), "user", None)
        admin = getattr(user, "role", "") == "admin"
        name = self.editor_name().casefold()
        accounts = [a for a in self._accounts if admin or not a.assigned_editor
                    or a.assigned_editor.casefold() == name]
        dialog = FlowBrowserDialog(accounts, [r.prompt for r in self._rows] or None, self, book=self.book)
        dialog.exec()
        self.refresh()

    def open_release_panel(self):
        user = getattr(self.window(), "user", None)
        if getattr(user, "role", "") != "admin":
            QMessageBox.information(self, "Administrator required", "Sign in as an administrator on the build machine.")
            return
        from .omniflow_release import OmniFlowReleaseDialog
        OmniFlowReleaseDialog(self).exec()

    def bulk_accounts_dialog(self):
        if self.book is None:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Add multiple emails")
        dialog.resize(560, 450)
        form = QFormLayout(dialog)
        form.addRow(_hint("Paste emails separated by lines, commas or semicolons. Duplicates are skipped. "
                          "Existing matching Chrome profiles are linked; this does not sign in accounts. "
                          "Starting balances and midnight Pacific resets are estimates."))
        emails = QPlainTextEdit()
        form.addRow("Emails", emails)
        daily = QSpinBox()
        daily.setRange(0, 100000000)
        daily.setValue(50)
        cost = QSpinBox()
        cost.setRange(1, 100000)
        cost.setValue(self._default_cost)
        form.addRow("Daily credits", daily)
        form.addRow("Credits per clip", cost)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        profiles = {email.casefold(): directory for directory, _, email in chrome_profiles.list_profiles() if email}
        book, by = self.book, self.editor_name()
        text, allowance, clip_cost = emails.toPlainText(), daily.value(), cost.value()
        def done(result):
            self.refresh()
            QMessageBox.information(self, "Email import", "Added {added}; skipped {skipped} existing addresses.".format(**result))
        self._write("Add emails", lambda: book.add_many(text, allowance, clip_cost, by, profiles), done)

    def add_account_dialog(self):
        if self.book is None:
            return
        dialog = AccountDialog(self._default_cost, None, self)
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.values()
        self.add_account(values["label"], values["email"], values["credits"], values["cost"], values["editor"],
                         values["notes"], values["chrome_profile"], values["monthly_credits"],
                         values["renews_on_day"], values["daily_credits"])

    def add_account(self, label: str, email: str = "", credits: int = 0, cost: Optional[int] = None,
                    editor: str = "", notes: str = "", chrome_profile: str = "", monthly_credits: int = 0,
                    renews_on_day: int = 0, daily_credits: int = 0) -> bool:
        book, by = self.book, self.editor_name()
        if book is None:
            return False
        return self._write("Add account",
                           lambda: book.add(label, email, credits, cost, editor, notes, by=by,
                                            chrome_profile=chrome_profile, monthly_credits=monthly_credits,
                                            renews_on_day=renews_on_day, daily_credits=daily_credits),
                           self._after_account_change)

    def edit_account_dialog(self):
        account = self.selected_account()
        if account is None or self.book is None:
            return
        dialog = AccountDialog(self._default_cost, account, self)
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.values()
        book, by = self.book, self.editor_name()
        self._write("Edit account",
                    lambda: book.update(account.id, label=values["label"], email=values["email"],
                                        cost=values["cost"], notes=values["notes"], by=by,
                                        chrome_profile=values["chrome_profile"],
                                        monthly_credits=values["monthly_credits"],
                                        renews_on_day=values["renews_on_day"], daily_credits=values["daily_credits"]),
                    self._after_account_change)
        if values["editor"] != account.assigned_editor:
            # One write at a time: the assignment follows once the edit lands.
            self._say("Saving the details; assign the editor again if it did not take.")

    def set_credits_dialog(self):
        account = self.selected_account()
        if account is None or self.book is None:
            return
        dialog = SetCreditsDialog(account, self.editor_name(), self)
        if dialog.exec() != QDialog.Accepted:
            return
        if account.daily_credits:
            self._write("Set balances", lambda: self.book.set_balances(
                account.id, dialog.daily.value(), dialog.other.value(), by=self.editor_name()),
                self._after_account_change)
        else:
            self.set_credits(account.id, dialog.credits.value())

    def set_credits(self, account_id: str, credits: int, note: str = "") -> bool:
        book, by = self.book, self.editor_name()
        if book is None:
            return False
        return self._write("Set credits", lambda: book.set_credits(account_id, credits, by=by, note=note),
                           self._after_account_change)

    def toggle_pause(self):
        account = self.selected_account()
        if account is None or self.book is None:
            return
        book, by = self.book, self.editor_name()
        if account.status == "paused":
            self._write("Resume", lambda: book.resume(account.id, by=by), self._after_account_change)
        else:
            self._write("Pause", lambda: book.pause(account.id, by=by), self._after_account_change)

    def assign_account_dialog(self):
        account = self.selected_account()
        if account is None or self.book is None:
            return
        name, ok = QInputDialog.getText(self, "Assign to editor",
                                        "Editor for {} (leave empty for nobody):".format(account.label),
                                        QLineEdit.Normal, account.assigned_editor)
        if not ok:
            return
        self.assign_account(account.id, name)

    def assign_account(self, account_id: str, editor: str) -> bool:
        book, by = self.book, self.editor_name()
        if book is None:
            return False
        return self._write("Assign to editor", lambda: book.assign(account_id, editor, by=by),
                           self._after_account_change)

    def show_next(self):
        book, editor = self.book, self.editor_name()
        if book is None:
            return

        def shown(account):
            self._next_account = account
            self.btn_next_chrome.setVisible(account is not None)
            self.btn_next_chrome.setEnabled(account is not None and bool(account.chrome_profile))
            if account is None:
                self.next_line.setText("Nobody's next: no active account is assigned to {} or free.".format(
                    editor or "you"))
            else:
                self.next_line.setText("Next for {}: {} {} ({} credits, about {} clips, {}).".format(
                    editor or "you", account.id, account.label, account.credits_last_seen, clips_left(account),
                    STATUS_WORDS.get(account.status, account.status)))
        self._write("Who's next", lambda: book.next_for(editor), shown)

    # -- Chrome ----------------------------------------------------------------
    def open_in_chrome(self, account: Optional[FlowAccount]) -> bool:
        """Open flow.google.com in the Chrome profile set for the account:
        Chrome, the profile, the address, nothing else. Signing in is the
        person's own doing, once, in Chrome."""
        if account is None:
            self._say("Select an account first.")
            return False
        if not account.chrome_profile:
            self._say("No Chrome profile is set for {}: Edit… → Chrome profile.".format(account.label))
            return False
        ok, reason = chrome_profiles.launch(account.chrome_profile, chrome_profiles.FLOW_URL)
        if ok:
            self._say("Opened Chrome profile '{}' for {}.".format(account.chrome_profile, account.label))
        else:
            self._say("Could not open Chrome for {}: {}".format(account.label, reason))
        return ok

    def open_selected_in_chrome(self) -> bool:
        return self.open_in_chrome(self.selected_account())

    def open_next_in_chrome(self) -> bool:
        return self.open_in_chrome(self._next_account)

    def change_default_cost(self):
        if self.book is None:
            return
        value, ok = QInputDialog.getInt(self, "Cost per clip", "Credits one clip costs in Flow:",
                                        self._default_cost, 1, 100000)
        if not ok:
            return
        book = self.book
        self._write("Cost per clip", lambda: book.set_default_cost(value),
                    lambda cost: (self._say("Cost per clip is now {} credits.".format(cost)), self.refresh()))

    # -- the queue ------------------------------------------------------------
    def open_production_dialog(self):
        start = str(getattr(self.config, "last_production_dir", "") or "") or str(Path.home())
        chosen, _ = QFileDialog.getOpenFileName(self, "Open a production ({})".format(MANIFEST_NAME), start,
                                                "Production ({})".format(MANIFEST_NAME))
        if not chosen:
            return
        self.open_production(Path(chosen).parent)

    def open_production(self, working_dir, episode: Optional[int] = None) -> bool:
        """Reads the manifest and the queue file on a thread, adds the
        prompt set's clips to the queue and paints it."""
        working = Path(working_dir)

        def read():
            production = Production.load(working)
            number = episode if episode is not None else (production.episodes[0].number if production.episodes else 1)
            record = production.episode(number)
            queue = ManualClipQueue.load(working, number)
            items = record.prompt_set.items if record.prompt_set else []
            added = queue.sync(items)
            if added or not queue.path.exists():
                queue.save()
            return production, queue, list(queue.rows), len(added)

        def loaded(result):
            production, queue, rows, added = result
            self._show_queue(production, queue, rows)
            counts = queue.counts()
            self._say("{} clips in the queue ({} done, {} to do){}.".format(
                len(rows), counts["done"], counts["todo"],
                "; {} added from the prompt set".format(added) if added else ""))
        return self._write("Open production", read, loaded)

    def _on_episode_picked(self, index):
        if self.production is None or index < 0:
            return
        number = self.episode_pick.itemData(index)
        if self.queue is not None and number == self.queue.episode:
            return
        self.open_production(self.production.working_dir, int(number))

    def import_prompts_dialog(self):
        if self.folder is None:
            self._say("Choose the shared folder first (Folder…).")
            return
        chosen, _ = QFileDialog.getOpenFileName(self, "Choose the numbered prompt file", str(Path.home()),
                                                "Prompt files (*.txt);;All files (*)")
        if not chosen:
            return
        title, ok = QInputDialog.getText(self, "Import prompts", "Title of this production (names its queue and "
                                         "clips folder under the shared folder):", QLineEdit.Normal,
                                         Path(chosen).stem)
        if not ok or not title.strip():
            return
        self.import_prompts(Path(chosen), title)

    def import_prompts(self, prompt_file, title: str) -> bool:
        """A numbered prompt .txt becomes the queue for `title`, kept under
        the shared folder as flow-queue/<title>.json; read and written on a
        thread. Importing the same title again adds new clips and keeps what
        people already set on the rest."""
        folder = self.folder
        if folder is None:
            return False
        prompt_file = Path(prompt_file)
        title = " ".join(str(title or "").split())[:200]
        if not safe_name(title, "").strip():
            self._say("The title needs a letter or a digit in it.")
            return False

        def read():
            items, problems = parse_report(_decode(prompt_file.read_bytes()))
            if not items:
                raise ValueError("No numbered prompts were found in {}. Each prompt starts with its scene "
                                 "number, like '12.' or 'Scene 12:'.".format(prompt_file.name))
            queue = ManualClipQueue.load(folder, 1, path=title_queue_path(folder, title), title=title)
            queue.source = prompt_file.name
            added = queue.sync(items)
            queue.save()
            return queue, list(queue.rows), len(added), problems

        def loaded(result):
            queue, rows, added, problems = result
            self._show_queue(None, queue, rows)
            counts = queue.counts()
            self._say("{}: {} clips ({} done, {} to do){}{}.".format(
                queue.title, len(rows), counts["done"], counts["todo"],
                "; {} added from {}".format(added, prompt_file.name) if added else "",
                "; note: " + "; ".join(problems)[:200] if problems else ""))
        return self._write("Import prompts", read, loaded)

    def open_queue_dialog(self):
        if self.folder is None:
            self._say("Choose the shared folder first (Folder…).")
            return
        start = self.folder / FLOW_QUEUE_DIR
        chosen, _ = QFileDialog.getOpenFileName(self, "Open a queue", str(start if start.is_dir() else self.folder),
                                                "Queues (*.json)")
        if not chosen:
            return
        self.open_queue(Path(chosen))

    def open_queue(self, path) -> bool:
        folder = self.folder
        path = Path(path)
        if folder is None or not _inside(folder / FLOW_QUEUE_DIR, path) or path.suffix.lower() != ".json":
            self._say("Only a queue inside the shared folder's {} can be opened.".format(FLOW_QUEUE_DIR))
            return False

        def read():
            queue = ManualClipQueue.load(folder, 1, path=path, title=path.stem)
            return queue, list(queue.rows)

        def loaded(result):
            queue, rows = result
            self._show_queue(None, queue, rows)
            counts = queue.counts()
            self._say("{}: {} clips ({} done, {} to do).".format(queue.title, len(rows), counts["done"],
                                                                  counts["todo"]))
        return self._write("Open queue", read, loaded)

    def _show_queue(self, production: Optional[Production], queue: ManualClipQueue, rows: List[QueueRow]):
        self.production, self.queue, self._rows = production, queue, rows
        self.episode_pick.blockSignals(True)
        self.episode_pick.clear()
        if production is not None:
            for record in production.episodes:
                self.episode_pick.addItem(str(record.number), record.number)
            self.episode_pick.setCurrentIndex(max(0, self.episode_pick.findData(queue.episode)))
            self.production_label.setText("{} (episode {}): {}".format(production.name, queue.episode,
                                                                        production.working_dir))
            self.production_label.setToolTip(_verbatim(production.working_dir))
        else:
            self.production_label.setText("{} (from {}): {}".format(queue.title, queue.source or "a prompt file",
                                                                    queue.path))
            self.production_label.setToolTip(_verbatim(queue.path))
        self.episode_pick.blockSignals(False)
        self._paint_queue()

    def _clips_dir(self) -> Optional[Path]:
        """The episode's clips folder, only when it lies under the
        production's own folder (the manifest is a file anyone can edit);
        for a queue from a prompt file, its own folder under the shared
        folder's flow-queue/."""
        if self.queue is None:
            return None
        if self.production is None:
            if self.folder is None or not self.queue.title:
                return None
            return title_clips_dir(self.folder, self.queue.title)
        working = Path(self.production.working_dir)
        try:
            record = self.production.episode(self.queue.episode)
        except KeyError:
            return None
        candidate = Path(record.clips_dir) if record.clips_dir else working / "clips" / "ep{:02d}".format(
            self.queue.episode)
        if not candidate.is_absolute():
            candidate = working / candidate
        return candidate if _inside(working, candidate) else None

    def _queue_write(self, what: str, change, on_done=None) -> bool:
        """One change to the queue file, off the GUI thread: re-read,
        apply, save, and hand the rows back to paint."""
        queue = self.queue
        if queue is None:
            return False
        if self.generating():
            self._say("A Gemini run is writing this queue; Stop it first, or wait for it to finish.")
            return False

        def action():
            queue.reload()
            result = change(queue)
            queue.save()
            return list(queue.rows), result

        def done(pair):
            rows, result = pair
            self._rows = rows
            self._paint_queue()
            if on_done is not None:
                on_done(result)
        return self._write(what, action, done)

    def copy_prompt(self):
        keys = self.selected_keys()
        if not keys:
            self._say("Select a clip first.")
            return
        row = next((r for r in self._rows if r.key == keys[0]), None)
        if row is None:
            return
        QApplication.clipboard().setText(row.prompt)
        self._say("Prompt for scene {} clip {} copied; paste it into Flow.".format(row.scene, row.clip))
        return row

    def copy_prompt_and_open(self) -> bool:
        """Copy the selected clip's prompt, then open Chrome with the profile
        of the account the row is assigned to."""
        row = self.copy_prompt()
        if row is None:
            return False
        if not row.account_id:
            self._say("Prompt for scene {} clip {} copied, but the clip has no account yet: "
                      "Assign to account… first.".format(row.scene, row.clip))
            return False
        account = next((a for a in self._accounts if a.id == row.account_id), None)
        if account is None:
            self._say("Prompt for scene {} clip {} copied, but account {} is not in the list.".format(
                row.scene, row.clip, row.account_id))
            return False
        return self.open_in_chrome(account)

    def assign_rows_account_dialog(self):
        keys = self.selected_keys()
        if not keys or self.queue is None:
            self._say("Select one or more clips first.")
            return
        choices = ["(none)"] + ["{} {}".format(a.id, a.label) for a in self._accounts]
        chosen, ok = QInputDialog.getItem(self, "Assign to account", "Account for {} clip{}:".format(
            len(keys), "" if len(keys) == 1 else "s"), choices, 0, False)
        if not ok:
            return
        self.assign_rows(keys, account_id=chosen.split(" ", 1)[0] if chosen != "(none)" else "")

    def assign_rows_editor_dialog(self):
        keys = self.selected_keys()
        if not keys or self.queue is None:
            self._say("Select one or more clips first.")
            return
        name, ok = QInputDialog.getText(self, "Assign to editor", "Editor for {} clip{}:".format(
            len(keys), "" if len(keys) == 1 else "s"), QLineEdit.Normal, self.editor_name())
        if not ok:
            return
        self.assign_rows(keys, editor=name)

    def assign_rows(self, keys, account_id: Optional[str] = None, editor: Optional[str] = None) -> bool:
        keys = list(keys)
        return self._queue_write("Assign", lambda queue: queue.assign(keys, account_id=account_id, editor=editor),
                                 lambda n: (self.select_keys(keys), self._say("{} clip{} assigned.".format(
                                     n, "" if n == 1 else "s"))))

    def mark_selected(self, status: str) -> bool:
        keys = self.selected_keys()
        if not keys:
            self._say("Select one or more clips first.")
            return False
        return self.mark(keys, status)

    def mark(self, keys, status: str) -> bool:
        keys = list(keys)
        by = self.editor_name()

        def change(queue):
            for key in keys:
                queue.set_status(key, status, "marked {} by {}".format(status, by or "?"))
            return len(keys)
        return self._queue_write("Mark " + status, change,
                                 lambda n: (self.select_keys(keys), self._say("{} clip{} marked {}.".format(
                                     n, "" if n == 1 else "s", STATUS_WORDS.get(status, status).lower()))))

    def refresh_from_clips(self) -> bool:
        clips = self._clips_dir()
        if clips is None:
            self._say("The production has no clips folder of its own to look in.")
            return False

        def shown(changes):
            if not changes:
                self._say("Nothing new in {}.".format(clips))
            else:
                self._say("; ".join(changes)[:400])
        return self._queue_write("Refresh from clips folder", lambda queue: reconcile(queue, clips), shown)

    def open_clips_folder(self):
        clips = self._clips_dir()
        if clips is None:
            self._say("The production has no clips folder of its own to open.")
            return
        try:
            clips.mkdir(parents=True, exist_ok=True)
            is_dir = clips.is_dir()
        except OSError:
            is_dir = False
        if not is_dir:
            self._say("Not opened: {} is not a folder that is there.".format(clips))
            return
        try:
            os.startfile(str(clips))                     # noqa: S606
        except (OSError, AttributeError) as exc:
            log.warning("Could not open %s: %s", clips, exc)

    # -- automatic generation (Gemini) -----------------------------------------
    def generating(self) -> bool:
        return self._gen_thread is not None and self._gen_thread.isRunning()

    def _paint_gemini_settings(self):
        model = str(getattr(self.config, "gemini_model", "") or "")
        parts = [MODEL_LABELS.get(model, model or "no model")]
        parts.append(str(getattr(self.config, "gemini_aspect_ratio", "") or "9:16"))
        parts.append(str(getattr(self.config, "gemini_resolution", "") or "720p"))
        if model != OMNI_FLASH_MODEL:
            parts.append("{} s".format(getattr(self.config, "gemini_duration_seconds", 8) or 8))
        saved = "key saved" if self.credentials.has(GEMINI) else "no key saved"
        self.gemini_settings.setText("{} ({})".format(", ".join(parts), saved))

    def gemini_key_dialog(self):
        dialog = GeminiKeysDialog(self.credentials, self.config, self)
        dialog.exec()
        dialog.deleteLater()
        self._paint_gemini_settings()

    def _gemini_generator(self) -> Optional[GeminiVideoGenerator]:
        key = self.credentials.get(GEMINI)
        if not key:
            self._say("No Google Gemini key is saved: Google Gemini key… first.")
            return None
        return GeminiVideoGenerator(key, model=str(getattr(self.config, "gemini_model", "") or ""),
                                    aspect_ratio=str(getattr(self.config, "gemini_aspect_ratio", "") or "9:16"),
                                    resolution=str(getattr(self.config, "gemini_resolution", "") or "720p"),
                                    duration_seconds=getattr(self.config, "gemini_duration_seconds", 8))

    def generate_selected(self) -> bool:
        keys = self.selected_keys()
        if not keys:
            self._say("Select one or more clips first.")
            return False
        return self.start_generation(keys)

    def generate_all_todo(self) -> bool:
        return self.start_generation([r.key for r in self._rows])

    def start_generation(self, keys, confirm: bool = True, generator=None) -> bool:
        """Rows among `keys` that are to do or failed are submitted; rows
        already generating with a job id are polled, never resubmitted.
        The confirmation says how many, with what, and that it is billed."""
        if self.queue is None:
            self._say("Open a queue first.")
            return False
        if self.generating():
            self._say("A Gemini run is already going; Stop it first.")
            return False
        clips = self._clips_dir()
        if clips is None:
            self._say("This queue has no clips folder of its own to save into.")
            return False
        wanted = set(keys)
        submit = [r for r in self._rows if r.key in wanted and r.status in ("todo", "failed")]
        resume = [r for r in self._rows if r.key in wanted and r.status == "generating" and r.job_id and not r.file]
        if not submit and not resume:
            self._say("Nothing to generate: none of the chosen clips is to do or failed.")
            return False
        if generator is None:
            generator = self._gemini_generator()
            if generator is None:
                return False
        if confirm:
            model = str(getattr(generator, "model", "") or "")
            settings = "{}, {}, {}".format(MODEL_LABELS.get(model, model), getattr(generator, "aspect_ratio", ""),
                                           getattr(generator, "resolution", ""))
            if model != OMNI_FLASH_MODEL:
                settings += ", {} s".format(getattr(generator, "duration_seconds", 8))
            text = "{} clip{} will be submitted to Gemini ({}).".format(len(submit), "" if len(submit) == 1 else "s",
                                                                       settings)
            if resume:
                text += " {} already submitted will be polled, not submitted again.".format(len(resume))
            text += "\n\n" + BILLING_SENTENCE
            if QMessageBox.question(self, "Generate with Gemini", text, QMessageBox.Ok | QMessageBox.Cancel,
                                    QMessageBox.Cancel) != QMessageBox.Ok:
                return False
        self.gemini_log.clear()
        thread = _GenerateThread(generator, self.queue, [r.key for r in submit + resume], clips, self)
        thread.event.connect(self._on_gen_event)
        thread.rows_changed.connect(self._on_gen_rows)
        thread.ended.connect(self._on_gen_ended)
        thread.finished.connect(self._on_gen_finished)
        thread.finished.connect(thread.deleteLater)
        self._gen_thread = thread
        thread.start()
        self._on_gen_event("Generating {} clip{} with Gemini{}…".format(
            len(submit), "" if len(submit) == 1 else "s",
            " (and polling {} submitted earlier)".format(len(resume)) if resume else ""))
        self._paint_queue()
        return True

    def stop_generation(self) -> bool:
        thread = self._gen_thread
        if thread is None or not thread.isRunning():
            return False
        thread.stop()
        self._on_gen_event("Stopping: the clips in flight finish, nothing more is submitted.")
        self.btn_gen_stop.setEnabled(False)
        return True

    def _on_gen_event(self, text: str):
        self._say(text)
        self.gemini_log.addItem(text)
        while self.gemini_log.count() > GEN_LOG_MAX:
            self.gemini_log.takeItem(0)
        self.gemini_log.scrollToBottom()

    def _on_gen_rows(self, rows):
        if self.sender() is not self._gen_thread:
            return
        self._rows = list(rows)
        self._paint_queue()

    def _on_gen_ended(self, text: str):
        if self.sender() is not self._gen_thread:
            return
        self._on_gen_event(text)

    def _on_gen_finished(self):
        if self.sender() is not self._gen_thread:
            return
        self._gen_thread = None
        self._paint_queue()

    def wait_until_generated(self, timeout_ms: int = 20000) -> bool:
        app = QApplication.instance()
        deadline = time.monotonic() + timeout_ms / 1000.0
        while time.monotonic() < deadline:
            if app is not None:
                app.processEvents()
            if self._gen_thread is None:
                return True
            time.sleep(0.02)
        return False

    # -- shutdown -------------------------------------------------------------
    def shutdown(self) -> None:
        self._closing = True
        self._reload_wanted = False
        self._renewal_timer.stop()
        if self._gen_thread is not None and self._gen_thread.isRunning():
            self._gen_thread.abort()
            if not self._gen_thread.wait(GEN_WAIT_MS):
                _orphan(self._gen_thread, "A Gemini generation run")
            self._gen_thread = None
        if self._loader is not None and self._loader.isRunning() and not self._loader.wait(SHARE_WAIT_MS):
            _orphan(self._loader, "A read of the Flow account inventory")
            self._loader = None
        if self._writer is not None and self._writer.isRunning() and not self._writer.wait(SHARE_WAIT_MS):
            _orphan(self._writer, "A write to the Flow account inventory")
            self._writer = None
            self._pending = None

    def closeEvent(self, event):
        self.shutdown()
        super().closeEvent(event)
