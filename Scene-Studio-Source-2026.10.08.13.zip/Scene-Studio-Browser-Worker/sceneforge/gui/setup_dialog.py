"""Prepare episode: the questions asked when a folder is opened, before any
clip is analysed. Whether the tool or the editor does the trimming, and
what size to export at; the joins are decided by the continuity engine. The same choices live in the
editor's Output panel for changing afterwards; nothing is cut until export."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QButtonGroup, QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout,
)

from ..config import Config

TRIMMING = [
    ("auto", "Automatic",
     "The tool trims the dead air before and after speech in every clip and "
     "cuts wordless clips to two seconds. You adjust anything it got wrong. "
     "Recommended."),
    ("manual", "Manual",
     "Every clip starts at full length and you trim each one by hand. The "
     "tool still detects speech and flags problems for you."),
]
SIZES = [
    (1080, "1080p  (Full HD)",
     "Upscales the 1280×720 clips to 1920×1080 with a Lanczos filter. "
     "What the platforms expect; the export takes longer."),
    (720, "720p  (as generated)",
     "Keeps the clips at their original 1280×720. No scaling, faster export."),
]
TICK = "✓  "


def _choice(label: str, hint: str) -> QPushButton:
    button = QPushButton(label)
    button.setObjectName("choice")
    button.setCheckable(True)
    button.setToolTip(hint)
    button.setProperty("label", label)
    return button


class _Choice:
    """One row of exclusive options with a hint line under it. Ticks the
    chosen button as well as colouring it, so the choice reads without
    relying on colour."""

    def __init__(self, parent: QDialog, outer: QVBoxLayout, title: str,
                 options, current) -> None:
        heading = QLabel(title)
        heading.setObjectName("stepLabel")
        outer.addWidget(heading)
        self.group = QButtonGroup(parent)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.options = options
        for value, label, hint in options:
            button = _choice(label, hint)
            button.setProperty("value", value)
            button.setChecked(value == current)
            self.group.addButton(button)
            row.addWidget(button)
        outer.addLayout(row)
        self.hint = QLabel("")
        self.hint.setObjectName("hint")
        self.hint.setWordWrap(True)
        outer.addWidget(self.hint)
        self.group.buttonClicked.connect(lambda _b: self._refresh())
        self._refresh()

    def _refresh(self) -> None:
        for button in self.group.buttons():
            label = button.property("label")
            button.setText((TICK + label) if button.isChecked() else label)
            if button.isChecked():
                self.hint.setText(button.toolTip())

    def value(self):
        button = self.group.checkedButton()
        return button.property("value") if button is not None else None


class SetupDialog(QDialog):
    def __init__(self, config: Config, folder_name: str, parent=None):
        super().__init__(parent)
        self.config = config
        self.setWindowTitle("Prepare episode")
        self.setModal(True)
        self.setMinimumWidth(560)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)

        title = QLabel("Prepare episode")
        title.setObjectName("title")
        outer.addWidget(title)
        name = QLabel(folder_name)
        name.setObjectName("subtitle")
        name.setWordWrap(True)
        outer.addWidget(name)
        outer.addSpacing(6)

        trim = config.trim_mode if config.trim_mode in ("auto", "manual") else "auto"
        self.trimming = _Choice(self, outer, "Trimming", TRIMMING, trim)
        outer.addSpacing(6)
        size = config.output_height if config.output_height in (720, 1080) else 1080
        self.size = _Choice(self, outer, "Video size", SIZES, size)

        note = QLabel("Clips are analysed first and nothing is cut until you export. "
                      "Every trim can be adjusted or reset per clip in the editor, and "
                      "these choices can be changed in the Output panel. Joins are "
                      "optimised automatically: clean cuts inside a scene, a short "
                      "invisible blend where one is cleaner, one final encode.")
        note.setObjectName("hint")
        note.setWordWrap(True)
        outer.addSpacing(6)
        outer.addWidget(note)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        start = QPushButton("Analyse clips")
        start.setObjectName("primary")
        start.setDefault(True)
        start.setToolTip("Detect speech in every clip and plan the cuts. Nothing is written.")
        start.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(start)
        outer.addLayout(buttons)

    def apply(self) -> None:
        """Write the choices into the config. Call after exec() accepted."""
        if self.trimming.value() is not None:
            self.config.trim_mode = self.trimming.value()
        if self.size.value() is not None:
            self.config.output_height = int(self.size.value())
