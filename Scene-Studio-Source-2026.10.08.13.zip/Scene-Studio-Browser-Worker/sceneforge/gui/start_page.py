"""Start screen: pick a clip folder, check it, begin.

Editors arrive here with a folder Omni Flash just wrote. The page validates it
before anything runs, because "0 clips found" twenty minutes in is a bad way to
learn the files were named wrong.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QVBoxLayout, QWidget,
)

from .branding import COPYRIGHT, TAGLINE, logo_pixmap
from ..ingest import VIDEO_SUFFIXES, _parse_name
from ..product import PRODUCT
from ..script_parser import find_script

VERSION = PRODUCT.version

MAX_RECENT = 8


def inspect_folder(folder: Path) -> dict:
    """Cheap pre-flight: what is in this folder, and is anything obviously wrong."""
    result = {"ok": False, "clips": 0, "numbered": 0, "script": None, "problems": []}
    folder = Path(folder)

    if not folder.is_dir():
        result["problems"].append("That folder does not exist.")
        return result

    videos = [p for p in folder.iterdir()
              if p.is_file() and p.suffix.lower() in VIDEO_SUFFIXES]
    result["clips"] = len(videos)

    # Ask the importer itself rather than guessing. This check used to look
    # only at the text before the first separator, so a folder of CLIP_001.mp4
    # was declared unusable and the Start button stayed dead -- even though
    # ingest reads those numbers perfectly well. A validator that is stricter
    # than the thing it validates is worse than no validator.
    numbered = sum(1 for path in videos if _parse_name(path.stem)[0] is not None)
    result["numbered"] = numbered

    script = find_script(folder)
    result["script"] = script.name if script else None

    if not videos:
        result["problems"].append("No video files here. Expected .mp4 clips.")
    elif numbered == 0:
        result["problems"].append(
            "No number could be read from any filename. Names need a number "
            "somewhere -- 1.mp4, 1_scene.mp4 or CLIP_001.mp4 all work -- so "
            "the clips can be ordered and paired with the script.")
    elif numbered < len(videos):
        result["problems"].append(
            "{} of {} clips have no number in the filename and will be placed "
            "at the end.".format(len(videos) - numbered, len(videos)))

    if not script:
        result["problems"].append(
            "No script .txt found. Editing still works, but you lose the quality "
            "flags that tell you which clips are cut off or wrong.")

    result["ok"] = bool(videos) and numbered > 0
    return result


class StartPage(QWidget):
    start_requested = Signal(Path)
    sign_out_requested = Signal()
    update_check_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 14, 24, 16)
        outer.setSpacing(0)

        # ---- signed-in strip: who is here, and the way out
        strip = QHBoxLayout()
        strip.setSpacing(8)
        self.signed_in_as = QLabel("")
        self.signed_in_as.setObjectName("signedIn")
        self.btn_updates = QPushButton("Check for updates")
        self.btn_updates.setObjectName("actUpdates")
        self.btn_updates.setToolTip("Look for a newer build now")
        self.btn_updates.clicked.connect(self.update_check_requested.emit)
        self.btn_signout = QPushButton("Sign out")
        self.btn_signout.setObjectName("actSignout")
        self.btn_signout.clicked.connect(self.sign_out_requested.emit)
        strip.addWidget(self.signed_in_as)
        strip.addStretch(1)
        strip.addWidget(self.btn_updates)
        strip.addWidget(self.btn_signout)
        outer.addLayout(strip)

        outer.addStretch(1)

        logo = logo_pixmap(112)
        if logo is not None:
            mark = QLabel()
            mark.setPixmap(logo)
            outer.addWidget(mark, 0, Qt.AlignHCenter)
        else:
            title = QLabel(PRODUCT.name)
            title.setObjectName("bigTitle")
            outer.addWidget(title, 0, Qt.AlignHCenter)
        subtitle = QLabel(TAGLINE)
        subtitle.setObjectName("subtitle")
        subtitle.setAlignment(Qt.AlignHCenter)
        subtitle.setWordWrap(True)
        outer.addWidget(subtitle)
        outer.addSpacing(26)

        card = QFrame()
        card.setObjectName("card")
        # Fixed, not maximum: with only a max width Qt shrinks the card to its
        # content hint and the path field ends up unusably narrow.
        card.setFixedWidth(660)
        box = QVBoxLayout(card)
        box.setContentsMargins(24, 22, 24, 22)
        box.setSpacing(10)

        step = QLabel("Paste the folder that holds your clips")
        step.setObjectName("stepLabel")
        box.addWidget(step)

        row = QHBoxLayout()
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText(r"F:\Drama clips\My new episode")
        self.path_edit.textChanged.connect(self._on_path_changed)
        self.path_edit.returnPressed.connect(self._start)
        self.btn_browse = QPushButton("Browse")
        self.btn_browse.clicked.connect(self._browse)
        row.addWidget(self.path_edit, 1)
        row.addWidget(self.btn_browse)
        box.addLayout(row)

        self.status = QLabel("")
        self.status.setObjectName("folderStatus")
        self.status.setWordWrap(True)
        self.status.setMinimumHeight(52)
        self.status.setAlignment(Qt.AlignTop)
        box.addWidget(self.status)

        self.btn_start = QPushButton("Start editing")
        self.btn_start.setObjectName("primary")
        self.btn_start.setMinimumHeight(38)
        self.btn_start.setEnabled(False)
        self.btn_start.clicked.connect(self._start)
        box.addWidget(self.btn_start)

        outer.addWidget(card, 0, Qt.AlignHCenter)
        outer.addSpacing(26)

        recent_label = QLabel("Recent projects")
        recent_label.setObjectName("stepLabel")
        recent_label.setFixedWidth(660)
        self.recent = QListWidget()
        self.recent.setObjectName("recentList")
        self.recent.setFixedWidth(660)
        self.recent.setMaximumHeight(148)
        self.recent.itemDoubleClicked.connect(self._open_recent)
        holder = QVBoxLayout()
        holder.setSpacing(6)
        holder.addWidget(recent_label)
        holder.addWidget(self.recent)
        wrap = QWidget()
        wrap.setLayout(holder)
        wrap.setFixedWidth(660)
        self.recent_wrap = wrap
        outer.addWidget(wrap, 0, Qt.AlignHCenter)

        outer.addStretch(2)

        footer = QHBoxLayout()
        version = QLabel("Version " + VERSION)
        version.setObjectName("version")
        credit = QLabel(COPYRIGHT)
        credit.setObjectName("copyright")
        footer.addWidget(version)
        footer.addStretch(1)
        footer.addWidget(credit)
        outer.addLayout(footer)

    # ------------------------------------------------------------------ data
    def set_user(self, display_name: str):
        self.signed_in_as.setText("Signed in as " + display_name)

    def set_recent(self, paths: List[str]):
        self.recent.clear()
        live = [p for p in paths if Path(p).is_dir()]
        for path in live[:MAX_RECENT]:
            item = QListWidgetItem("{}      {}".format(Path(path).name, path))
            item.setData(Qt.UserRole, path)
            self.recent.addItem(item)
        self.recent_wrap.setVisible(bool(live))

    def _open_recent(self, item: QListWidgetItem):
        self.path_edit.setText(item.data(Qt.UserRole))
        self._start()

    def _browse(self):
        folder = QFileDialog.getExistingDirectory(self, "Choose the folder of generated clips")
        if folder:
            self.path_edit.setText(folder)

    # ---------------------------------------------------------------- checks
    def _on_path_changed(self, text: str):
        text = text.strip().strip('"')
        if not text:
            self.status.setText("")
            self.btn_start.setEnabled(False)
            return

        info = inspect_folder(Path(text))
        lines = []
        if info["clips"]:
            lines.append("{} clips found, {} numbered".format(info["clips"], info["numbered"]))
        if info["script"]:
            lines.append("script: {}".format(info["script"]))
        for problem in info["problems"]:
            lines.append("\u2022 " + problem)

        self.status.setText("\n".join(lines))
        self.status.setProperty("bad", bool(info["problems"]) and not info["ok"])
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.btn_start.setEnabled(info["ok"])

    def _start(self):
        text = self.path_edit.text().strip().strip('"')
        if not text:
            return
        folder = Path(text)
        if inspect_folder(folder)["ok"]:
            self.start_requested.emit(folder)

    def set_path(self, folder: Optional[Path]):
        self.path_edit.setText(str(folder) if folder else "")
