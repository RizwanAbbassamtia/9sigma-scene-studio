"""SceneForge main window: start page, then a CapCut-style editor."""
from __future__ import annotations

import shutil
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel,
    QDialog, QMainWindow, QMenu,
    QMessageBox, QProgressBar, QPushButton, QScrollArea, QSlider, QSplitter,
    QStackedWidget, QSystemTrayIcon, QTextEdit, QToolButton, QVBoxLayout, QWidget,
)

from .. import teamsheet
from ..assemble import flag_joins, planned_timeline
from ..auth import User, UserStore
from ..autocut import plan_clip, trimmed_clip_numbers
from ..config import Config, remember_project
from ..ingest import missing_clip_numbers
from ..logging_setup import get
from ..models import Clip, Episode, Flag, ReviewState, SpeechSpan
from ..retakes import build as build_retakes, sheet_path_for, write as write_retakes
from ..state import EditHistory, save as save_state
from ..product import PRODUCT
from ..thumbs import invalidate as invalidate_thumb
from .branding import APP_NAME, COPYRIGHT as BRAND_COPYRIGHT, app_icon
from .filmstrip import Filmstrip
from .login_page import LOGIN_HEIGHT, LOGIN_WIDTH, LoginPage
from .production_page import (
    CredentialsDialog, FrameworkLibraryDialog, ProductionDashboard, ProductionSetupDialog,
)
from .master_page import MasterLogPage
from .flow_accounts_page import FlowAccountsPage
from .batch_page import BatchPage
from ..production.credentials import Credentials
from ..production.frameworks import Frameworks
from ..production.manifest import Production
from .setup_dialog import SetupDialog
from .start_page import StartPage, inspect_folder
from . import theme
from .styles import STYLE
from .timeline import Timeline
from .update_banner import UpdateBanner
from .workers import AnalysisWorker, BuildWorker

log = get("window")
VERSION = PRODUCT.version       # the running product's version line

NUDGE = 0.10

COPYRIGHT = BRAND_COPYRIGHT

FLAG_LABEL = {
    Flag.SCRIPTED_BUT_SILENT: "no speech",
    Flag.SPEECH_NOT_SCRIPTED: "extra voice",
    Flag.SPEECH_TRUNCATED: "cut off",
    Flag.SPEECH_MUCH_SHORTER: "short",
    Flag.NO_AUDIO_TRACK: "no audio",
    Flag.MOTION_ANOMALY: "motion",
    Flag.DURATION_OUTLIER: "length",
    Flag.NO_SCENE_MATCH: "no scene",
    Flag.UNREADABLE: "unreadable",
    Flag.JOIN_RISK: "join",
    Flag.REPEATED_SPEECH: "repeat",
}

FLAG_ADVICE = {
    Flag.SPEECH_TRUNCATED:
        "Dialogue was still running when the clip ended, so words are missing. "
        "Re-generate this scene, split into two shorter ones.",
    Flag.SPEECH_NOT_SCRIPTED:
        "The script says nobody speaks here, but a voice was heard. Often just "
        "background voices in the ambient track. Listen, then approve.",
    Flag.SCRIPTED_BUT_SILENT:
        "The script has dialogue but nothing was heard. The generation failed. "
        "Replace this clip.",
    Flag.SPEECH_MUCH_SHORTER:
        "Far less speech than the script implies. A line may have been dropped.",
    Flag.NO_AUDIO_TRACK: "This clip has no audio track at all.",
    Flag.DURATION_OUTLIER: "This clip is a different length from the rest.",
    Flag.NO_SCENE_MATCH: "No scene in the script matches this clip number.",
    Flag.UNREADABLE: "This file could not be read.",
    Flag.JOIN_RISK:
        "The join into this clip may jump: it starts in the middle of a word, or a "
        "scene is missing before it. Move the start, or replace the clip.",
    Flag.REPEATED_SPEECH:
        "A word may be said twice by mistake, but not clearly enough to remove it "
        "automatically (or the picture moves too much to cut). Listen; if it is a "
        "loop, split the segment and delete the repeat; if it is meant, approve.",
}


class MainWindow(QMainWindow):
    laptop_refused = Signal(str, str)      # username, message: the team sheet said no

    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        self.episode: Optional[Episode] = None
        self.folder: Optional[Path] = None
        self.thumbs: Dict[int, str] = {}
        self.current: Optional[Clip] = None
        self._worker = None
        self._discarded_notice = ""
        self.last_export: Optional[Path] = None

        self.user: Optional[User] = None
        # 9 Sigma Omni Flow is the Google Flow manager and nothing else: the
        # editor, the automation pages and their menus are built (the code
        # is shared) but never added to the stack or the bar.
        self.omniflow = PRODUCT.key == "omniflow"
        self.store = UserStore(Path.cwd())
        self._syncing_fades = False
        self._audition_queue = []          # (path, from, to) pieces still to play
        self._audition_stop = None         # where the current audition pauses
        self.segment = 0                   # which of the clip's segments is selected
        self.history = EditHistory()       # undo/redo for the cutting buttons

        self.setWindowTitle("{} {}".format(APP_NAME, VERSION))
        self.setStyleSheet(STYLE)

        self.pages = QStackedWidget()
        self.login_page = LoginPage(self.store)
        self.login_page.logged_in.connect(self.on_logged_in)
        self.laptop_refused.connect(self._on_laptop_refused)
        self.start_page = StartPage()
        self.start_page.start_requested.connect(lambda p: self.open_folder(p, True))
        self.start_page.sign_out_requested.connect(self.sign_out)
        self.start_page.update_check_requested.connect(
            lambda: self.check_for_updates(manual=True))
        self.editor = self._build_editor()
        # The optional production pipeline. Nothing in it runs unless a
        # person sets a production up and presses Start production.
        self.frameworks = Frameworks()
        self.credentials = Credentials()
        self.production_page = ProductionDashboard(self.config, self.frameworks, self.credentials)
        self.production_page.back_requested.connect(lambda: self.pages.setCurrentWidget(self.editor))
        self.production_page.open_in_editor.connect(
            lambda folder: self.open_folder(Path(folder), analyse_now=True))
        self.production_page.new_production_requested.connect(self.new_production)
        if not self.omniflow:
            self.pages.addWidget(self.production_page)
        # The master log: a shared queue of titles the worker takes through
        # the same pipeline unattended. Its folder is opened from the menu,
        # never at start-up, so a sleeping share cannot stall the window.
        self.master_page = MasterLogPage(self.config, self.credentials)
        # Several episodes at once, run one after another through the same
        # runner as a single production.
        self.batch_page = BatchPage(self.config, self.frameworks, self.credentials)
        self.batch_page.back_requested.connect(lambda: self.pages.setCurrentWidget(self.editor))
        self.batch_page.open_production.connect(self._open_production_folder)
        self.master_page.back_requested.connect(lambda: self.pages.setCurrentWidget(self.editor))
        self.master_page.open_in_editor.connect(
            lambda folder: self.open_folder(Path(folder), analyse_now=True))
        # Google Flow accounts, credits and the manual queue: bookkeeping
        # for work people do in a browser. In Omni Flow it is the only page.
        self.flow_page = FlowAccountsPage(self.config, omniflow=self.omniflow)
        self.flow_page.back_requested.connect(lambda: self.pages.setCurrentWidget(self.editor))
        if self.omniflow:
            self._build_flow_account_menu()
        else:
            self.pages.addWidget(self.master_page)
            self.pages.addWidget(self.batch_page)
        self.pages.addWidget(self.flow_page)
        self.pages.addWidget(self.login_page)
        if not self.omniflow:
            self.pages.addWidget(self.start_page)
            self.pages.addWidget(self.editor)

        # The update banner sits above whichever page is showing, so it is
        # seen on the start page and in the editor alike.
        self.update_banner = UpdateBanner(state_dir=Path.cwd())          # update-state.json beside config.json
        self.update_banner.install_started.connect(self._on_install_started)
        self.update_banner.status.connect(lambda text: self.statusBar().showMessage(text))
        self.update_banner.set_busy_provider(self._busy_reason)
        # Checked again while the app stays open, so an editor who never
        # restarts still hears about a release the same day.
        self._update_timer = QTimer(self)
        self._update_timer.timeout.connect(lambda: self.check_for_updates(manual=False))
        # A machine that slept or lost its connection missed the timer; a
        # one-minute heartbeat notices a jump in the clock (sleep) or the
        # network coming back and checks again. The check itself is cheap
        # and the banner never re-nags a version that was put away.
        self._wake_timer = QTimer(self)
        self._wake_timer.setInterval(60 * 1000)
        self._wake_timer.timeout.connect(self._heartbeat)
        self._last_beat = time.monotonic()
        self._online = True
        self._watch_network()
        # Desktop notifications go through a tray icon; it also gives the
        # app a presence to click when the window is behind others.
        self.tray = QSystemTrayIcon(app_icon(), self)
        self.tray.setToolTip(APP_NAME)
        self.tray.activated.connect(lambda _r: (self.showNormal(), self.activateWindow()))
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()
        self.update_banner.set_tray(self.tray)

        central = QWidget()
        central_box = QVBoxLayout(central)
        central_box.setContentsMargins(0, 0, 0, 0)
        central_box.setSpacing(0)
        central_box.addWidget(self.update_banner)
        central_box.addWidget(self.pages, 1)
        self.setCentralWidget(central)

        self._build_shortcuts()
        self._sized_for_work = False
        self._enter_login_size()
        self.pages.setCurrentWidget(self.login_page)
        self.login_page.focus_first_field()
        self.statusBar().showMessage("Sign in to continue.")

        # The update check belongs to the program, not the session: it runs
        # at launch (before anyone signs in), after sign-in, on the hour,
        # and whenever the machine wakes or comes back online.
        if self.config.check_updates and self.config.update_url:
            self.check_for_updates(manual=False)
            self._update_timer.start(max(5, int(self.config.update_recheck_minutes)) * 60 * 1000)
            self._wake_timer.start()

        # "Keep me signed in" from last time: skip the gate entirely.
        kept = self.store.remembered()
        if kept is not None:
            allowed, message, recheck = teamsheet.sign_in_gate(kept.username, kept.display_name, kept.role)
            kept.recheck_laptop = recheck
            if allowed:
                log.info("Signed in from the remembered account: %s", kept.username)
                self.on_logged_in(kept)
            else:
                # The account was moved to another laptop or blocked since
                # last time: the kept session ends here.
                self.store.forget()
                self.login_page._say(message, bad=True)

    def on_logged_in(self, user: User):
        """Past the gate: show who is signed in and let them pick a project.
        Nothing from before is opened: the recent list is offered, the
        project itself waits for a click."""
        self.reset_session()
        self.user = user
        self.config.editor_name = user.display_name
        self.config.editor_username = user.username
        teamsheet.flush_later()               # production rows left from an offline spell
        if getattr(user, "recheck_laptop", False):
            self._recheck_laptop(user)
        # The version sits in the title bar: after an update, one glance says
        # which build this is.
        self.setWindowTitle("{} {}  -  {}".format(APP_NAME, VERSION, user.display_name))
        self.signed_in_as.setText("Signed in as {}".format(user.display_name))
        self.account_header.setText("Signed in as {}".format(user.display_name))
        self.start_page.set_user(user.display_name)
        self.start_page.set_recent(self.config.recent_projects)
        self._refresh_recent_menu()
        self._enter_work_size()
        if self.omniflow:
            # Straight into the Flow manager; the shared folder opens when
            # one was chosen before, otherwise its Folder… button asks.
            self.setWindowTitle("{} {}".format(APP_NAME, VERSION))
            self.flow_account_header.setText("Signed in as {}".format(user.display_name))
            self.pages.setCurrentWidget(self.flow_page)
            folder = str(getattr(self.config, "master_log_dir", "") or "").strip()
            if folder:
                self.flow_page.load(Path(folder))
                self.statusBar().showMessage("Signed in as {}.".format(user.display_name))
            else:
                self.statusBar().showMessage("Press Folder… to choose the shared folder.")
        else:
            # Straight into the editor: the folder button lives in its top bar.
            self.pages.setCurrentWidget(self.editor)
            self.btn_reanalyse.setEnabled(self.episode is not None)
            self.statusBar().showMessage(
                "Press + New Project to choose an episode folder on this computer.")
        # What the last "Update now" started: "Updated to …" once, or the
        # downloaded installer offered again. A newer release found by the
        # check that follows replaces either.
        self.update_banner.resume_pending()
        if self.config.check_updates:
            self.check_for_updates(manual=False)

    def _heartbeat(self):
        """Once a minute: if far more than a minute passed, the machine
        slept -- check for a release it may have missed."""
        now = time.monotonic()
        slept = now - self._last_beat > 180
        self._last_beat = now
        if slept and self.config.check_updates:
            log.info("Woke after %.0f s; checking for updates", now - self._last_beat)
            self.check_for_updates(manual=False)

    def _watch_network(self):
        """Check again the moment the network comes back (Qt 6.1+; quietly
        nothing on a build without QNetworkInformation)."""
        try:
            from PySide6.QtNetwork import QNetworkInformation
            if not QNetworkInformation.loadDefaultBackend():
                return
            info = QNetworkInformation.instance()
            if info is None:
                return

            def changed(reach):
                online = reach == QNetworkInformation.Reachability.Online
                if online and not self._online and self.config.check_updates:
                    log.info("Network is back; checking for updates")
                    self.check_for_updates(manual=False)
                self._online = online
            info.reachabilityChanged.connect(changed)
        except Exception as exc:                       # noqa: BLE001 - optional
            log.info("Network watch unavailable: %s", exc)

    def reset_session(self):
        """Forget everything about the project and production that were open,
        on screen and in memory, without touching anything saved on disk.
        Run at sign-in and sign-out: a person always starts from a blank
        editor and chooses what to open."""
        self.player.stop()
        self._audition_queue = []
        self._audition_stop = None
        self.episode = None
        self.current = None
        self.folder = None
        self.thumbs = {}
        self.last_export = None
        self.segment = 0
        self.history = EditHistory()
        self._discarded_notice = ""
        self.preview_stack.setCurrentIndex(0)
        self.timeline.clear()
        self.filmstrip.set_clips([], None)
        self.state_badge.setVisible(False)
        self.clip_heading.setText("No clip selected")
        self._set_clip_controls_enabled(False)
        self.btn_export.setEnabled(False)
        self.btn_reanalyse.setEnabled(False)
        self.project_name.setText("Open a folder to begin")
        self.project_name.setToolTip("")
        self.position.setVisible(False)
        self.summary.setText("")
        self.trimmed_block.setText("None yet.")
        self.ready_banner.setText("")
        self.ready_banner.setVisible(False)
        self._refresh_watch_button()
        self.start_page.set_path(None)
        self.production_page.clear()
        self.master_page.clear()
        self.batch_page.clear()

    def _recheck_laptop(self, user: User):
        """Ask the team sheet in the background whether this account may
        still work on this laptop; sign out if it says no. See
        teamsheet.sign_in_gate for why the sign-in did not wait for it."""
        def work():
            allowed, message = teamsheet.check_laptop(user.username, user.display_name, user.role)
            if not allowed:
                self.laptop_refused.emit(user.username, message)
        threading.Thread(target=work, name="laptop-check", daemon=True).start()

    def _on_laptop_refused(self, username: str, message: str):
        if self.user is None or self.user.username != username:
            return                           # already signed out, or someone else now
        log.warning("Signing out %s: %s", username, message)
        self.sign_out()
        if self.user is not None:            # a run is in progress; sign_out said so
            QMessageBox.warning(self, "Account", message + "\n\nStop the running job: this account "
                                "cannot keep working on this laptop.")
            return
        self.login_page._say(message, bad=True)

    def sign_out(self):
        """End the session: back to the login screen with nothing from it left
        on screen. The details the person asked to remember (username and
        sealed password) are kept -- that is a separate choice from staying
        signed in -- and nothing is ever signed back in on its own."""
        if self.production_page.thread is not None and self.production_page.thread.isRunning():
            QMessageBox.information(self, "Sign out", "A production run is in progress. Stop it first.")
            return
        if self.master_page._worker_running():
            QMessageBox.information(self, "Sign out", "The master log worker is running. Stop it first.")
            return
        if self.batch_page.running:
            QMessageBox.information(self, "Sign out", "A batch is running. Stop it first.")
            return
        self.reset_session()
        self.user = None
        self.store.forget()                  # the session token; never the saved details
        self.setWindowTitle("{} {}".format(APP_NAME, VERSION))
        # The update strip is about the program, not the session: a notice
        # already found stays; the periodic check keeps going.
        self.login_page.load_saved()
        self.login_page.password.setText(self.login_page.password.text())
        self.pages.setCurrentWidget(self.login_page)
        self._enter_login_size()
        self.login_page.focus_first_field()
        self.statusBar().showMessage("Signed out.")

    # --------------------------------------------------------------- updates
    def check_for_updates(self, manual: bool = False):
        """Ask for the newest published build. Quiet unless asked by hand;
        the banner owns the check thread, the notice and the download."""
        if not self.config.update_url:
            if manual:
                self.statusBar().showMessage("Update checks are switched off in config.json.")
            return
        self.update_banner.check(self.config.update_url, manual=manual)
        # Same rhythm for the team sheet: production rows that could not be
        # sent (no internet, or Google slow to answer) go on the hour.
        teamsheet.flush_later()

    def _busy_reason(self) -> str:
        """Why an update must wait: the banner installs only when this is
        empty, so an export, an analysis, a production run or the master
        worker is never cut off by the installer."""
        if self.progress.isVisible():
            return (self.progress.format() or "the current job").strip("% ") or "the current job"
        thread = getattr(self.production_page, "thread", None)
        if thread is not None and thread.isRunning():
            return "the production run"
        if self.master_page._worker_running():
            return "the master log worker"
        if self.batch_page.running:
            return "the batch"
        return ""

    def _on_install_started(self):
        """The installer is running; get out of its way so it can replace files."""
        self._save()
        self.player.stop()
        self.statusBar().showMessage("Installer started. Closing…")
        QApplication.instance().quit()

    # ---------------------------------------------------------------- layout
    def _enter_login_size(self):
        """A compact, portrait, non-resizable window, like most sign-in screens."""
        self.statusBar().hide()
        self.setFixedSize(LOGIN_WIDTH, LOGIN_HEIGHT)
        self._sized_for_work = False
        screen = self.screen() or QApplication.primaryScreen()
        if screen is not None:
            area = screen.availableGeometry()
            self.move(area.left() + (area.width() - self.width()) // 2,
                      area.top() + max(0, (area.height() - self.height()) // 2 - 20))

    def _enter_work_size(self):
        """Release the fixed login size and take the working footprint."""
        if self._sized_for_work:
            return
        self.setMinimumSize(0, 0)
        self.setMaximumSize(16777215, 16777215)
        self.statusBar().show()
        self._fit_to_screen()
        self._sized_for_work = True

    def _fit_to_screen(self):
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            self.resize(1200, 720)
            return
        area = screen.availableGeometry()
        # Leave room for the title bar and border: resize() sizes the client
        # area, so asking for the full available height pushes the status bar
        # off the bottom of the screen.
        chrome = 46
        width = min(1420, area.width() - 40)
        height = min(900, area.height() - chrome)
        self.resize(width, height)
        if height < 800:
            # A 768-tall laptop is the common case. Everything the review
            # actually needs -- approve, reject, the output choices -- has to
            # stay above the fold in the inspector, so the clip's reference
            # material gives up the pixels rather than the controls.
            self.video.setMinimumHeight(190)
            self.strip_scroll.setFixedHeight(132)
        self.move(area.left() + max(0, (area.width() - width) // 2), area.top())

    @staticmethod
    def _section(text: str) -> QLabel:
        """A section title in the inspector. Grouping is what makes a column of
        twelve controls readable rather than a list."""
        label = QLabel(text)
        label.setObjectName("sectionTitle")
        return label

    def _build_editor(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(theme.SPACE_2, theme.SPACE_1,
                                 theme.SPACE_2, theme.SPACE_1)
        outer.setSpacing(theme.SPACE_1)

        # ---- toolbar
        # Left: the way in and what is open. Right: what to do with it, ending
        # in the one blue button. Account business lives in a menu at the far
        # right so it never competes with the editing controls.
        bar = QWidget()
        bar.setObjectName("toolbar")
        top = QHBoxLayout(bar)
        top.setContentsMargins(theme.SPACE_1, theme.SPACE_1,
                               theme.SPACE_1, theme.SPACE_1)
        top.setSpacing(theme.SPACE_1)

        self.btn_home = QPushButton("+ New Project")
        self.btn_home.setObjectName("actOpen")
        self.btn_home.setToolTip("Choose the folder of generated clips on this computer")
        self.btn_home.clicked.connect(self.choose_folder)
        self.btn_recent = QToolButton()
        self.btn_recent.setText("Recent ▾")
        self.btn_recent.setObjectName("actRecent")
        self.btn_recent.setToolTip("Reopen a folder you have worked on before")
        self.btn_recent.setPopupMode(QToolButton.InstantPopup)
        self.recent_menu = QMenu(self)
        self.btn_recent.setMenu(self.recent_menu)

        self.project_name = QLabel("Open a folder to begin")
        self.project_name.setObjectName("title")
        # A long episode name must not push the export button off the bar.
        self.project_name.setMinimumWidth(80)

        self.btn_watch = QPushButton("Play full video")
        self.btn_watch.setObjectName("actWatch")
        self.btn_watch.setToolTip("Play the exported episode in your video player")
        self.btn_watch.clicked.connect(self.watch_finished)
        self.btn_reanalyse = QPushButton("Re-analyse")
        self.btn_reanalyse.setToolTip("Run the analysis over this folder again")
        self.btn_reanalyse.clicked.connect(lambda: self.start_analysis())
        self.btn_export = QPushButton("Export video")
        self.btn_export.setObjectName("primary")
        self.btn_export.setEnabled(False)
        self.btn_export.setToolTip("Join the approved clips into one episode")
        self.btn_export.clicked.connect(self.finish_video)

        # The account menu. The old bar carried three of these as buttons of
        # their own, which put signing out beside exporting.
        self.signed_in_as = QLabel("")            # kept: the menu header reads it
        self.signed_in_as.setObjectName("signedIn")
        self.signed_in_as.setVisible(False)
        self.btn_account = QToolButton()
        self.btn_account.setText("Account ▾")
        self.btn_account.setObjectName("actAccount")
        self.btn_account.setToolTip("Account, updates and about")
        self.btn_account.setPopupMode(QToolButton.InstantPopup)
        self.account_menu = QMenu(self)
        self.account_header = self.account_menu.addAction("Not signed in")
        self.account_header.setEnabled(False)
        self.account_menu.addSeparator()
        self.account_menu.addAction("Check for updates",
                                    lambda: self.check_for_updates(manual=True))
        if not self.omniflow:
            self.account_menu.addAction("Save retake sheet…", self.save_retake_sheet)
            self.account_menu.addAction("Keyboard shortcuts", self.show_shortcuts)
        self.account_menu.addAction("About " + APP_NAME, self.show_about)
        self.account_menu.addSeparator()
        self.account_menu.addAction("Sign out", self.sign_out)
        self.btn_account.setMenu(self.account_menu)

        top.addWidget(self.btn_home)
        top.addWidget(self.btn_recent)
        top.addSpacing(theme.SPACE_1)
        top.addWidget(self.project_name, 1)
        top.addSpacing(theme.SPACE_2)
        top.addWidget(self.btn_watch)
        top.addWidget(self.btn_reanalyse)
        top.addWidget(self.btn_export)
        # Automation lives behind one menu: off by default, explicit to enter.
        self.btn_automate = QToolButton()
        self.btn_automate.setText("Automate ▾")
        self.btn_automate.setToolTip("Optional: generate a script, scene prompts and clips, then edit and export")
        self.btn_automate.setPopupMode(QToolButton.InstantPopup)
        self.automate_menu = QMenu(self)
        self.automate_menu.addAction("New automated production…", lambda: self.new_production())
        self.automate_menu.addAction("Open production…", self.open_production)
        self.automate_menu.addAction("Production dashboard", lambda: self.pages.setCurrentWidget(self.production_page))
        self.automate_menu.addAction("Master log…", self.master_log)
        self.automate_menu.addAction("Google Flow accounts…", self.flow_accounts)
        self.automate_menu.addSeparator()
        self.automate_menu.addAction("New batch / Multi-episode automation…", self.new_batch)
        self.automate_menu.addAction("Open batch…", self.open_batch)
        self.automate_menu.addAction("Batch dashboard", lambda: self.pages.setCurrentWidget(self.batch_page))
        self.automate_menu.addSeparator()
        self.automate_menu.addAction("Framework library…", lambda: FrameworkLibraryDialog(self.frameworks, self).exec())
        self.automate_menu.addAction("API keys…", lambda: CredentialsDialog(self.credentials, self, config=self.config).exec())
        self.btn_automate.setMenu(self.automate_menu)
        top.addSpacing(theme.SPACE_1)
        if not self.omniflow:
            # Omni Flow has no automation to offer; the bar is the editor's,
            # which Omni Flow never shows either.
            top.addWidget(self.btn_automate)
        top.addWidget(self.btn_account)
        outer.addWidget(bar)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        outer.addWidget(self.progress)

        # ---- preview + inspector
        split = QSplitter(Qt.Horizontal)

        left = QWidget()
        left_box = QVBoxLayout(left)
        left_box.setContentsMargins(0, 0, theme.SPACE_1, 0)   # clear the splitter
        left_box.setSpacing(theme.SPACE_1)

        # The preview sits in a well of its own: black inside the canvas, a
        # panel around it, and a plain empty state before a folder is opened so
        # the first screen says what to do rather than showing a black box.
        self.video = QVideoWidget()
        self.video.setMinimumHeight(280)
        self.video.setStyleSheet("background: {}; border-radius: {}px;".format(
            theme.BG_CANVAS, theme.RADIUS))
        self.player = QMediaPlayer(self)
        self.audio_out = QAudioOutput(self)
        self.player.setAudioOutput(self.audio_out)
        self.player.setVideoOutput(self.video)
        self.player.positionChanged.connect(self.on_position)
        self.player.mediaStatusChanged.connect(self._on_media_status)
        self.player.errorOccurred.connect(self._on_player_error)

        empty = QWidget()
        empty.setObjectName("emptyPreview")
        empty_box = QVBoxLayout(empty)
        empty_box.setSpacing(theme.SPACE_2)
        empty_box.addStretch(1)
        empty_label = QLabel("Open a folder to start editing")
        empty_label.setObjectName("emptyState")
        empty_label.setAlignment(Qt.AlignCenter)
        btn_empty_open = QPushButton("+ New Project")
        btn_empty_open.setObjectName("actOpen")
        btn_empty_open.clicked.connect(self.choose_folder)
        empty_row = QHBoxLayout()
        empty_row.addStretch(1)
        empty_row.addWidget(btn_empty_open)
        empty_row.addStretch(1)
        empty_box.addWidget(empty_label)
        empty_box.addLayout(empty_row)
        empty_box.addStretch(1)

        self.preview_stack = QStackedWidget()
        self.preview_stack.addWidget(empty)          # 0: nothing open yet
        self.preview_stack.addWidget(self.video)     # 1: the picture
        # 2: what went wrong, with the one thing to try. A blank panel with no
        # explanation is the one thing this area must never show.
        notice = QWidget()
        notice.setObjectName("emptyPreview")
        notice_box = QVBoxLayout(notice)
        notice_box.setSpacing(theme.SPACE_2)
        notice_box.addStretch(1)
        self.preview_notice = QLabel("")
        self.preview_notice.setObjectName("emptyState")
        self.preview_notice.setAlignment(Qt.AlignCenter)
        self.preview_notice.setWordWrap(True)
        btn_retry_preview = QPushButton("Retry")
        btn_retry_preview.clicked.connect(self._retry_preview)
        retry_row = QHBoxLayout()
        retry_row.addStretch(1)
        retry_row.addWidget(btn_retry_preview)
        retry_row.addStretch(1)
        notice_box.addWidget(self.preview_notice)
        notice_box.addLayout(retry_row)
        notice_box.addStretch(1)
        self.preview_stack.addWidget(notice)
        self.preview_stack.setObjectName("previewWell")

        self.timeline = Timeline()
        self.timeline.seek_requested.connect(self.seek_to)
        self.timeline.segment_changed.connect(self.on_segment_changed)
        self.timeline.segment_selected.connect(self.on_segment_selected)

        # Transport, in the order the hand uses it: back, play, forward, then
        # the one that plays the cut. Next flagged sits at the far end because
        # it jumps somewhere else entirely.
        controls = QHBoxLayout()
        controls.setSpacing(theme.SPACE_1)
        self.btn_prev = QPushButton("‹ Previous")
        self.btn_prev.setObjectName("actNav")
        self.btn_prev.setToolTip("Previous clip  (←)")
        self.btn_prev.clicked.connect(lambda: self.step(-1))
        self.btn_play = QPushButton("Play")
        self.btn_play.setObjectName("actPlay")
        self.btn_play.setToolTip("Play or pause  (Space)")
        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_next = QPushButton("Next ›")
        self.btn_next.setObjectName("actNav")
        self.btn_next.setToolTip("Next clip  (→)")
        self.btn_next.clicked.connect(lambda: self.step(1))
        self.btn_preview = QPushButton("Preview cut")
        self.btn_preview.setObjectName("actPreview")
        self.btn_preview.setToolTip("Play just the part that will be kept  (C)")
        self.btn_preview.clicked.connect(self.preview_cut)
        self.btn_next_flag = QPushButton("Next flagged")
        self.btn_next_flag.setObjectName("actFlag")
        self.btn_next_flag.setToolTip("Jump to the next clip that needs a look  (Tab)")
        self.btn_next_flag.setProperty("armed", False)
        self.btn_next_flag.clicked.connect(self.next_flagged)
        for widget in (self.btn_prev, self.btn_play, self.btn_next):
            controls.addWidget(widget)
        controls.addSpacing(theme.SPACE_2)
        controls.addWidget(self.btn_preview)
        self.btn_audition = QPushButton("Check cut")
        self.btn_audition.setToolTip("Play 0.8 s either side of each cut point, so you hear whether a word was clipped  (A)")
        self.btn_audition.clicked.connect(self.audition_cut)
        controls.addWidget(self.btn_audition)
        controls.addStretch(1)
        controls.addWidget(self.btn_next_flag)

        # The cutting row: everything acts on the selected segment at the
        # playhead, and nothing here touches the source file. Cutting a
        # piece out closes the gap -- the rest of the episode moves up.
        cutting = QHBoxLayout()
        cutting.setSpacing(theme.SPACE_1)
        self.btn_split = QPushButton("Split")
        self.btn_split.setToolTip("Cut the selected segment in two at the playhead  (S)")
        self.btn_split.clicked.connect(self.split_at_playhead)
        self.btn_remove_left = QPushButton("Remove left")
        self.btn_remove_left.setToolTip(
            "Drop the part of the selected segment before the playhead; what follows moves up  ([)")
        self.btn_remove_left.clicked.connect(self.remove_left)
        self.btn_remove_right = QPushButton("Remove right")
        self.btn_remove_right.setToolTip(
            "Drop the part of the selected segment after the playhead; what follows moves up  (])")
        self.btn_remove_right.clicked.connect(self.remove_right)
        self.btn_delete_segment = QPushButton("Delete segment")
        self.btn_delete_segment.setToolTip(
            "Drop the selected segment; the others close up  (Del)")
        self.btn_delete_segment.clicked.connect(self.delete_segment)
        self.btn_mute = QPushButton("Mute")
        self.btn_mute.setObjectName("toggleFadeIn")
        self.btn_mute.setCheckable(True)
        self.btn_mute.setToolTip("Export this clip with silent audio  (M)")
        self.btn_mute.clicked.connect(self.toggle_mute)
        self.btn_undo = QPushButton("Undo")
        self.btn_undo.setObjectName("quiet")
        self.btn_undo.setToolTip("Undo the last cut, trim, mute or join change  (Ctrl+Z)")
        self.btn_undo.clicked.connect(self.undo_edit)
        self.btn_redo = QPushButton("Redo")
        self.btn_redo.setObjectName("quiet")
        self.btn_redo.setToolTip("Redo what was just undone  (Ctrl+Y)")
        self.btn_redo.clicked.connect(self.redo_edit)
        for widget in (self.btn_split, self.btn_remove_left, self.btn_remove_right,
                       self.btn_delete_segment):
            cutting.addWidget(widget)
        cutting.addSpacing(theme.SPACE_2)
        cutting.addWidget(self.btn_mute)
        cutting.addStretch(1)
        cutting.addWidget(self.btn_undo)
        cutting.addWidget(self.btn_redo)

        left_box.addWidget(self.preview_stack, 1)
        left_box.addWidget(self.timeline)
        left_box.addLayout(controls)
        left_box.addLayout(cutting)

        right = QWidget()
        right.setObjectName("inspector")
        right_box = QVBoxLayout(right)
        right_box.setContentsMargins(theme.PAD_PANEL, theme.PAD_PANEL,
                                     theme.PAD_PANEL, theme.PAD_PANEL)
        right_box.setSpacing(theme.SPACE_1)

        self.clip_heading = QLabel("No clip selected")
        self.clip_heading.setObjectName("clipHeading")
        # Review state as a badge of its own, so "approved" never reads as
        # part of the analysis warning next to it.
        self.state_badge = QLabel("")
        self.state_badge.setObjectName("stateBadge")
        self.state_badge.setVisible(False)
        heading_row = QHBoxLayout()
        heading_row.setSpacing(theme.SPACE_1)
        heading_row.addWidget(self.clip_heading, 1)
        heading_row.addWidget(self.state_badge)
        self.flag_banner = QLabel("")
        self.flag_banner.setObjectName("flagBanner")
        self.flag_banner.setWordWrap(True)
        self.flag_banner.setVisible(False)

        # The clip's reference material -- the script line, what was heard --
        # folded away by default. A small scrolling box inside a scrolling
        # column was two scrollbars for one job.
        self.btn_details = QPushButton("Show details")
        self.btn_details.setObjectName("quiet")
        self.btn_details.setCheckable(True)
        self.btn_details.toggled.connect(self._toggle_details)
        self.details = QLabel("")
        self.details.setObjectName("stat")
        self.details.setWordWrap(True)
        self.details.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.details.setVisible(False)

        self.btn_replace = QPushButton("Replace this clip…")
        self.btn_replace.setObjectName("quiet")
        self.btn_replace.setToolTip("Swap in a re-generated file for this clip")
        self.btn_replace.clicked.connect(self.replace_clip)
        self.btn_reset = QPushButton("Reset trim  (R)")
        self.btn_reset.clicked.connect(self.reset_cut)

        self.btn_play_join = QPushButton("Play join  (J)")
        self.btn_play_join.setToolTip(
            "Play the last 0.8 s of the previous clip and the first 0.8 s of this one. The join itself "
            "is decided automatically at export: a clean cut inside a scene, a short blend where one is "
            "cleaner.")
        self.btn_play_join.clicked.connect(self.audition_join)

        decide = QHBoxLayout()
        self.btn_reject = QPushButton("Reject  (X)")
        self.btn_reject.setObjectName("actReject")
        self.btn_reject.clicked.connect(lambda: self.decide(ReviewState.REJECTED))
        self.btn_approve = QPushButton("Approve  (Enter)")
        self.btn_approve.setObjectName("actApprove")
        self.btn_approve.clicked.connect(lambda: self.decide(ReviewState.APPROVED))
        decide.setSpacing(theme.SPACE_1)
        decide.addWidget(self.btn_reject, 1)
        decide.addWidget(self.btn_approve, 1)

        self.btn_approve_all = QPushButton("Approve every remaining clip")
        self.btn_approve_all.setObjectName("actApproveAll")
        self.btn_approve_all.clicked.connect(self.approve_all)

        # One line that answers "am I finished?" without counting anything up
        self.ready_banner = QLabel("")
        self.ready_banner.setObjectName("readyBanner")
        self.ready_banner.setWordWrap(True)
        self.ready_banner.setVisible(False)

        self.summary = QLabel("")
        # Which clips the tool shortened, each a link to that clip, so the
        # editor can see the tool's work at a glance and jump to any of it.
        self.trimmed_label = QLabel("Trimmed by the tool")
        self.trimmed_label.setObjectName("stepLabel")
        self.trimmed_block = QLabel("")
        self.trimmed_block.setObjectName("stat")
        self.trimmed_block.setWordWrap(True)
        self.trimmed_block.setTextFormat(Qt.RichText)
        self.trimmed_block.setOpenExternalLinks(False)
        self.trimmed_block.linkActivated.connect(lambda n: self.select_clip(int(n)))
        self.summary.setObjectName("stat")
        self.summary.setWordWrap(True)

        output_label = QLabel("Joins")
        output_label.setObjectName("stepLabel")
        self.join_note = QLabel("Optimised automatically: clean cuts inside a scene, a short invisible "
                                "blend where the scene changes or a cut would flash, dead frames "
                                "trimmed, neighbouring colour matched, one final encode.")
        self.join_note.setObjectName("hint")
        self.join_note.setWordWrap(True)
        resolution_label = QLabel("Resolution")
        resolution_label.setObjectName("stepLabel")

        # Toggles, not tick boxes: whether these are on changes what the export
        # produces, so their state should be readable across the room rather
        # than from a 13-pixel check mark.
        size_row = QHBoxLayout()
        size_row.setSpacing(theme.SPACE_1)
        self.btn_720 = QPushButton("720p")
        self.btn_720.setObjectName("toggleSize")
        self.btn_720.setCheckable(True)
        self.btn_1080 = QPushButton("1080p")
        self.btn_1080.setObjectName("toggleSize")
        self.btn_1080.setCheckable(True)
        self.btn_720.clicked.connect(lambda: self._pick_size(720))
        self.btn_1080.clicked.connect(lambda: self._pick_size(1080))
        size_row.addWidget(self.btn_720)
        size_row.addWidget(self.btn_1080)
        self.size_row = size_row
        self._sync_output_controls()

        # Captions stay off unless asked for, and the kind only appears once
        # they are on, so the default path is one switch rather than a menu
        # whose first entry means "do nothing".
        self.chk_captions = QPushButton("  Add captions")
        self.chk_captions.setObjectName("toggleCaptions")
        self.chk_captions.setCheckable(True)
        self.chk_captions.setChecked(self.config.captions in ("srt", "burn"))
        self.chk_captions.toggled.connect(self._on_output_options)
        self.captions_choice = QComboBox()
        self.captions_choice.addItem("Save a .srt subtitle file", "srt")
        self.captions_choice.addItem("Burn captions into the picture", "burn")
        wanted = self.config.captions if self.config.captions in ("srt", "burn") else "srt"
        self.captions_choice.setCurrentIndex(max(0, self.captions_choice.findData(wanted)))
        self.captions_choice.setVisible(self.chk_captions.isChecked())
        self.captions_choice.currentIndexChanged.connect(self._on_output_options)

        # A compact read-out of where the cut sits. The handles and the
        # keyboard do the editing; this only says what they did.
        self.trim_readout = QLabel("")
        self.trim_readout.setObjectName("trimReadout")

        right_box.addLayout(heading_row)
        right_box.addWidget(self.flag_banner)
        right_box.addWidget(self.btn_details)
        right_box.addWidget(self.details)

        right_box.addSpacing(theme.SPACE_1)
        right_box.addWidget(self._section("Trim"))
        right_box.addWidget(self.trim_readout)
        trim_row = QHBoxLayout()
        trim_row.setSpacing(theme.SPACE_1)
        self.btn_full = QPushButton("Use full clip")
        self.btn_full.setToolTip("Keep the whole clip and trim it by hand")
        self.btn_full.clicked.connect(self.use_full_clip)
        trim_row.addWidget(self.btn_reset, 1)
        trim_row.addWidget(self.btn_full, 1)
        right_box.addLayout(trim_row)
        right_box.addWidget(self.btn_play_join)

        right_box.addSpacing(theme.SPACE_1)
        right_box.addWidget(self._section("Clip review"))
        right_box.addLayout(decide)
        right_box.addWidget(self.btn_approve_all)
        right_box.addWidget(self.btn_replace)
        right_box.addWidget(self.ready_banner)

        right_box.addSpacing(theme.SPACE_1)
        right_box.addWidget(self._section("Output"))
        right_box.addWidget(output_label)
        right_box.addWidget(self.join_note)
        right_box.addWidget(resolution_label)
        right_box.addLayout(self.size_row)
        right_box.addWidget(self.chk_captions)
        right_box.addWidget(self.captions_choice)
        right_box.addWidget(self._divider())
        right_box.addWidget(self.summary)
        right_box.addWidget(self.trimmed_label)
        right_box.addWidget(self.trimmed_block)
        right_box.addStretch(1)

        # The inspector stacks a lot of controls, and their combined minimum
        # height was forcing the whole window taller than a laptop screen --
        # which pushed the filmstrip off the bottom, the one thing that must
        # always be visible. Letting this column scroll caps what it can demand.
        right_scroll = QScrollArea()
        right_scroll.setObjectName("inspectorScroll")
        right_scroll.setWidget(right)
        right_scroll.setWidgetResizable(True)
        right_scroll.setFrameShape(QFrame.NoFrame)
        right_scroll.setMinimumWidth(320)
        right_scroll.setMaximumWidth(420)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        split.addWidget(left)
        split.addWidget(right_scroll)
        split.setSizes([1000, theme.INSPECTOR_W])

        self.edit_split = split

        # ---- timeline
        # A panel of its own, with its title and zoom in a header, so the strip
        # reads as one region rather than three things stacked on the page.
        timeline_panel = QWidget()
        timeline_panel.setObjectName("timelinePanel")
        panel_box = QVBoxLayout(timeline_panel)
        panel_box.setContentsMargins(theme.SPACE_1, theme.SPACE_1,
                                     theme.SPACE_1, theme.SPACE_1)
        panel_box.setSpacing(theme.SPACE_1)

        strip_bar = QHBoxLayout()
        strip_bar.setSpacing(theme.SPACE_1)
        strip_label = self._section("Timeline")
        self.zoom = QSlider(Qt.Horizontal)
        self.zoom.setMinimum(4)
        self.zoom.setMaximum(60)
        self.zoom.setValue(14)
        self.zoom.setMaximumWidth(150)
        self.zoom.setToolTip("Zoom the timeline")
        self.zoom.valueChanged.connect(lambda v: self.filmstrip.set_zoom(float(v)))
        zoom_label = QLabel("Zoom")
        zoom_label.setObjectName("stepLabel")
        strip_bar.addWidget(strip_label)
        strip_bar.addStretch(1)
        strip_bar.addWidget(zoom_label)
        strip_bar.addWidget(self.zoom)
        panel_box.addLayout(strip_bar)

        self.filmstrip = Filmstrip()
        self.filmstrip.clip_selected.connect(self.select_clip)
        self.filmstrip.trim_changed.connect(self.on_strip_trim)
        self.filmstrip.scrub.connect(lambda n, s: self.seek_to(s))

        self.strip_scroll = QScrollArea()
        self.strip_scroll.setObjectName("stripScroll")
        self.strip_scroll.setWidget(self.filmstrip)
        self.strip_scroll.setWidgetResizable(False)
        self.strip_scroll.setFixedHeight(140)
        self.strip_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.strip_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        panel_box.addWidget(self.strip_scroll)

        vertical = QSplitter(Qt.Vertical)
        vertical.addWidget(split)
        vertical.addWidget(timeline_panel)
        vertical.setStretchFactor(0, 1)
        vertical.setStretchFactor(1, 0)
        vertical.setCollapsible(0, False)
        vertical.setCollapsible(1, False)
        vertical.setSizes([480, 176])
        outer.addWidget(vertical, 1)

        # ---- status bar
        # One line, three jobs: what the app is doing on the left, where you
        # are in the episode in the middle, and the way into the shortcut list
        # on the right. It used to be a stacked footer plus a bar.
        self.position = QLabel("")
        self.position.setObjectName("statusPosition")
        self.position.setAlignment(Qt.AlignCenter)
        self.position.setVisible(False)
        self.btn_shortcuts = QPushButton("Shortcuts")
        self.btn_shortcuts.setObjectName("quiet")
        self.btn_shortcuts.setToolTip("Show the keyboard shortcuts")
        self.btn_shortcuts.setMaximumHeight(22)
        self.btn_shortcuts.clicked.connect(self.show_shortcuts)
        status = self.statusBar()
        status.addPermanentWidget(self.position, 1)
        status.addPermanentWidget(self.btn_shortcuts)
        self._set_clip_controls_enabled(False)

        return page

    def _finished_length(self):
        """(total seconds, where each clip starts) for the video as configured.

        Asks the assembler rather than adding up the kept spans, because the
        Hollywood join overlaps every cut: the same edit comes out about a
        dissolve length shorter per join than a hard cut of it.
        """
        if not self.episode:
            return 0.0, {}
        return planned_timeline(self.episode, self.config)

    def _update_position(self, clip: Clip):
        """Say where this clip sits: which scene, which clip, how far in."""
        if not self.episode:
            return
        clips = sorted(self.episode.clips, key=lambda c: c.number)
        scenes = max((c.scene_index for c in clips), default=1)
        index = next((i for i, c in enumerate(clips) if c.number == clip.number), 0)

        # position in the finished cut, not in the source footage
        total, offsets = self._finished_length()
        elapsed = offsets.get(clip.number, 0.0)

        setting = ""
        if clip.scene and clip.scene.setting:
            setting = "   ·   {}".format(clip.scene.setting[:52])

        if scenes <= 0 or not clip.scene_index:
            scene_part = "No scene assigned"
        else:
            scene_part = "Scene {} of {}".format(clip.scene_index, scenes)
        self.position.setText(
            "{}     ·     Clip {}  ({} of {})     ·     "
            "{:.0f}:{:02.0f} into {:.0f}:{:02.0f}{}".format(
                scene_part,
                clip.number, index + 1, len(clips),
                elapsed // 60, elapsed % 60, total // 60, total % 60, setting))
        self.position.setVisible(True)

    def _divider(self) -> QFrame:
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setObjectName("divider")
        return line

    def _build_shortcuts(self):
        def bind(key, slot):
            QShortcut(QKeySequence(key), self, activated=slot)

        bind("Space", self.toggle_play)
        bind("C", self.preview_cut)
        bind("Return", lambda: self.decide(ReviewState.APPROVED))
        bind("Enter", lambda: self.decide(ReviewState.APPROVED))
        bind("X", lambda: self.decide(ReviewState.REJECTED))
        bind("Left", lambda: self.step(-1))
        bind("Right", lambda: self.step(1))
        bind("Up", lambda: self.step(-1))
        bind("Down", lambda: self.step(1))
        bind("Tab", self.next_flagged)
        bind("A", self.audition_cut)
        bind("Q", lambda: self.nudge("start", -NUDGE))
        bind("W", lambda: self.nudge("start", NUDGE))
        bind("O", lambda: self.nudge("end", -NUDGE))
        bind("P", lambda: self.nudge("end", NUDGE))
        bind("R", self.reset_cut)
        bind("S", self.split_at_playhead)
        bind("[", self.remove_left)
        bind("]", self.remove_right)
        bind("Delete", self.delete_segment)
        bind("M", lambda: self.toggle_mute(not (self.current and self.current.muted)))
        bind("J", self.audition_join)
        bind("Ctrl+Z", self.undo_edit)
        bind("Ctrl+Y", self.redo_edit)
        bind("Ctrl+Shift+Z", self.redo_edit)

    # ------------------------------------------------------------- lifecycle
    def go_home(self):
        self.player.stop()
        self.start_page.set_recent(self.config.recent_projects)
        self.pages.setCurrentWidget(self.start_page)
        self.statusBar().showMessage("Choose a folder of generated clips to begin.")

    def choose_folder(self):
        """Pick a clips folder from this computer and start analysing it."""
        start_in = str(self.folder.parent) if self.folder else ""
        if not start_in and self.config.recent_projects:
            start_in = str(Path(self.config.recent_projects[0]).parent)
        chosen = QFileDialog.getExistingDirectory(
            self, "Choose the folder of generated clips", start_in)
        if not chosen:
            return
        folder = Path(chosen)
        info = inspect_folder(folder)
        if not info["ok"]:
            QMessageBox.warning(self, "That folder cannot be used",
                                "\n".join(info["problems"]) or "No usable clips found.")
            return
        if info["problems"]:
            # Usable, but worth a word: usually a missing script.
            self.statusBar().showMessage("  ".join(info["problems"]))
        self.open_folder(folder, analyse_now=True)

    def _refresh_recent_menu(self):
        self.recent_menu.clear()
        live = [p for p in self.config.recent_projects if Path(p).is_dir()]
        if not live:
            action = self.recent_menu.addAction("No recent folders")
            action.setEnabled(False)
            return
        for path in live[:8]:
            action = self.recent_menu.addAction(Path(path).name[:60])
            action.setToolTip(path)
            action.triggered.connect(lambda _=False, p=path: self.open_folder(Path(p), True))

    def open_folder(self, folder: Path, analyse_now: bool = True):
        self.folder = Path(folder)
        self.last_export = None
        name = self.folder.name
        self.project_name.setText(name if len(name) <= 46 else name[:45] + "…")
        self.project_name.setToolTip(name)
        self.preview_stack.setCurrentIndex(1)
        self.pages.setCurrentWidget(self.editor)
        remember_project(self.config, self.folder, Path.cwd())
        self._refresh_recent_menu()
        log.info("Project opened: %s", self.folder)
        if self.config.check_updates and self.user is not None:
            self.check_for_updates(manual=False)
        if analyse_now:
            # Ask how the episode should be joined and at what size before
            # anything is planned. Nothing is cut until export either way.
            dialog = SetupDialog(self.config, self.folder.name[:70], self)
            if dialog.exec() != QDialog.Accepted:
                self.statusBar().showMessage("Cancelled. Open a folder when ready.")
                return
            dialog.apply()
            self._sync_output_controls()
            try:
                self.config.save(Path.cwd())
            except OSError:
                pass
            self.start_analysis()

    def start_analysis(self):
        if not self.folder:
            return
        self._set_busy(True, "Analysing")
        self._discarded_notice = ""
        self.last_export: Optional[Path] = None
        self._worker = AnalysisWorker(self.folder, self.config, self)
        self._worker.progress.connect(self.on_progress)
        self._worker.thumbs_ready.connect(self.on_thumbs)
        self._worker.state_discarded.connect(self.on_state_discarded)
        self._worker.finished_ok.connect(self.on_analysis_done)
        self._worker.failed.connect(self.on_failed)
        self._worker.start()

    def on_state_discarded(self, reason: str, count: int):
        """Never let stale saved work quietly replace a fresh, better analysis."""
        self._discarded_notice = (
            "Your previous review of this folder was not restored, because {}.\n\n"
            "{} clip decisions were set aside and everything has been planned "
            "again from the current footage.".format(reason, count))

    def on_thumbs(self, mapping: dict):
        self.thumbs = {int(k): str(v) for k, v in mapping.items()}

    def on_analysis_done(self, episode: Episode):
        self.episode = episode
        self.history = EditHistory()
        flag_joins(episode)
        self._set_busy(False)
        self.filmstrip.set_clips(episode.clips, episode.source_dir)
        self.btn_export.setEnabled(True)
        flagged = len(episode.flagged)
        if episode.clips:
            first = episode.flagged[0].number if flagged else episode.clips[0].number
            self.select_clip(first)
        self._update_summary()
        self._refresh_watch_button()
        clean = sum(1 for c in episode.clips
                    if c.state == ReviewState.APPROVED and not c.flags)
        trimmed = len(trimmed_clip_numbers(episode))
        if self.config.trim_mode == "manual":
            self.statusBar().showMessage(
                "{} clips at full length for manual trimming. {} flagged — Tab steps "
                "through them.".format(len(episode.clips), flagged))
        else:
            self.statusBar().showMessage(
                "{} clips; {} trimmed. {} clean clips approved automatically, {} flagged need "
                "a look — Tab steps through them; ← → reviews every clip.".format(
                    len(episode.clips), trimmed, clean, flagged))
        if self._discarded_notice:
            QMessageBox.information(self, "Previous review reset", self._discarded_notice)
            self._discarded_notice = ""
        missing = missing_clip_numbers(episode)
        if missing:
            shown = ", ".join(str(n) for n in missing[:40]) + (", …" if len(missing) > 40 else "")
            QMessageBox.warning(
                self, "Clips missing from the sequence",
                "{} clip number{} missing between {} and {}:\n\n{}\n\nThe episode will skip "
                "them. Check the generator's output for these numbers, add the files to the "
                "folder, then press Re-analyse.".format(
                    len(missing), "" if len(missing) == 1 else "s are",
                    min(c.number for c in episode.clips), max(c.number for c in episode.clips),
                    shown))

    def on_failed(self, message: str):
        self._set_busy(False)
        self._restore_preview()
        QMessageBox.critical(self, "SceneForge", message)
        self.statusBar().showMessage("Failed: " + message)

    # ----------------------------------------------------------- clip select
    def select_clip(self, number: int):
        if not self.episode:
            return
        clip = next((c for c in self.episode.clips if c.number == number), None)
        if clip is None:
            return
        if clip is not self.current:
            self.segment = 0
        self.current = clip
        self._set_clip_controls_enabled(True)
        self.filmstrip.set_selected(number)
        self._scroll_to(number)

        self._load_timeline(clip)
        self.preview_stack.setCurrentIndex(1)
        self.player.setSource(QUrl.fromLocalFile(str(clip.path)))
        self.player.pause()
        self.btn_play.setText("Play")
        self._show_details(clip)
        self._update_position(clip)

    def _set_clip_controls_enabled(self, on: bool):
        """Before a clip exists there is nothing to play, trim, fade, replace or
        decide, and a button that does nothing is worse than a grey one."""
        for widget in (self.btn_play, self.btn_preview, self.btn_prev, self.btn_next,
                       self.btn_next_flag, self.btn_reset,
                       self.btn_replace, self.btn_reject,
                       self.btn_approve, self.btn_approve_all, self.btn_details,
                       self.btn_audition, self.btn_full, self.btn_mute,
                       self.btn_play_join):
            widget.setEnabled(on)
        if not on:
            for widget in (self.btn_split, self.btn_remove_left, self.btn_remove_right,
                           self.btn_delete_segment, self.btn_undo, self.btn_redo):
                widget.setEnabled(False)

    def _load_timeline(self, clip: Clip, keep_position: bool = False):
        """Show the clip's segments on the strip, the selected one with handles."""
        duration = clip.media.duration if clip.media else 10.0
        if not clip.keep:
            clip.keep = [SpeechSpan(0.0, duration)]
        self.segment = max(0, min(len(clip.keep) - 1, self.segment))
        self.timeline.min_length = self.config.min_clip_seconds
        self.timeline.set_segments(duration, clip.speech, clip.keep, self.segment,
                                   clip.muted, keep_position=keep_position)
        self._sync_edit_buttons()

    def _playhead(self) -> float:
        # Also the moment every cutting button reads the selection, so a
        # stale index from a deleted segment can never reach the model.
        if self.current and self.current.keep:
            self.segment = max(0, min(len(self.current.keep) - 1, self.segment))
        return self.player.position() / 1000.0

    def _sync_edit_buttons(self):
        """Grey out whatever the playhead's position makes impossible, so a
        press never has to be refused."""
        clip = self.current
        if clip is None or not clip.keep:
            self._set_clip_controls_enabled(False)
            return
        at = self._playhead()
        minimum = self.config.min_clip_seconds
        span = clip.keep[max(0, min(len(clip.keep) - 1, self.segment))]
        inside = span.start < at < span.end
        self.btn_split.setEnabled(inside and at - span.start >= minimum
                                  and span.end - at >= minimum)
        self.btn_remove_left.setEnabled(inside and span.end - at >= minimum)
        self.btn_remove_right.setEnabled(inside and at - span.start >= minimum)
        self.btn_delete_segment.setEnabled(len(clip.keep) > 1)
        self.btn_undo.setEnabled(self.history.can_undo)
        self.btn_redo.setEnabled(self.history.can_redo)
        self._syncing_fades = True
        try:
            self.btn_mute.setChecked(clip.muted)
            self.btn_mute.setText("Muted" if clip.muted else "Mute")
        finally:
            self._syncing_fades = False

    def _toggle_details(self, on: bool):
        self.details.setVisible(on)
        self.btn_details.setText("Hide details" if on else "Show details")

    def _on_media_status(self, status):
        if not self.current:
            return
        if status == QMediaPlayer.LoadingMedia:
            self.statusBar().showMessage("Loading clip {}…".format(self.current.number), 3000)
        elif status == QMediaPlayer.InvalidMedia:
            self._show_preview_notice(
                "Clip {} could not be opened for preview.\n{}\n\nThe file may be "
                "damaged or still being written.".format(self.current.number,
                                                           self.current.path.name))
        elif status in (QMediaPlayer.LoadedMedia, QMediaPlayer.BufferedMedia):
            if self.preview_stack.currentIndex() == 2:
                self.preview_stack.setCurrentIndex(1)

    def _on_player_error(self, error, text: str):
        if not self.current or error == QMediaPlayer.NoError:
            return
        log.warning("Preview error on clip %d: %s", self.current.number, text)
        self._show_preview_notice(
            "Clip {} could not be played.\n{}\n\n{}".format(
                self.current.number, self.current.path.name, text or "The video decoder reported an error."))

    def _show_preview_notice(self, text: str):
        self.preview_notice.setText(text)
        self.preview_stack.setCurrentIndex(2)

    def _retry_preview(self):
        if self.current:
            self.select_clip(self.current.number)

    def _scroll_to(self, number: int):
        x = self.filmstrip.x_for_clip(number)
        if x is None:
            return
        bar = self.strip_scroll.horizontalScrollBar()
        view = self.strip_scroll.viewport().width()
        if x < bar.value() + 40 or x > bar.value() + view - 120:
            bar.setValue(max(0, int(x) - view // 3))

    def _show_details(self, clip: Clip):
        self._update_trim_readout(clip)
        label, state = {ReviewState.APPROVED: ("Approved", "approved"),
                        ReviewState.REJECTED: ("Rejected", "rejected")}.get(
                            clip.state, ("Not reviewed", "pending"))
        self.clip_heading.setText("Clip {}   ·   {:.2f}s kept".format(
            clip.number, clip.cut_duration))
        self.state_badge.setText(label)
        self.state_badge.setProperty("state", state)
        self.state_badge.style().unpolish(self.state_badge)
        self.state_badge.style().polish(self.state_badge)
        self.state_badge.setVisible(True)

        if clip.flags:
            worst = sorted(clip.flags, key=lambda f: -({
                Flag.UNREADABLE: 100, Flag.SCRIPTED_BUT_SILENT: 90,
                Flag.NO_AUDIO_TRACK: 80, Flag.SPEECH_NOT_SCRIPTED: 60,
                Flag.SPEECH_TRUNCATED: 50}.get(f, 10)))[0]
            advice = FLAG_ADVICE.get(worst, "")
            if worst == Flag.JOIN_RISK and clip.join_warning:
                advice = "This clip {}. {}".format(clip.join_warning, advice)
            headline = advice.split(". ")[0]
            if headline and not headline.endswith("."):
                headline += "."
            self.flag_banner.setText("Analysis warning · {}  —  {}".format(
                FLAG_LABEL.get(worst, worst.value).upper(), headline))
            self.flag_banner.setToolTip(
                advice + "\n\nThis is what the analysis heard. Approving the clip "
                "records your decision; it does not clear the warning.")
            self.flag_banner.setVisible(True)
        else:
            self.flag_banner.setVisible(False)

        lines = []
        if clip.scene:
            lines.append("Scene {} — {}".format(clip.scene.number, clip.scene.setting))
            lines.append("")
            if clip.scene.has_dialogue:
                for line in clip.scene.dialogue:
                    lines.append("{}:  {}".format(line.speaker, line.text))
            else:
                lines.append("(no dialogue scripted)")
            lines.append("")
            lines.append("ambient: {}".format(clip.scene.ambient))
            lines.append("music:   {}".format(clip.scene.music))
        else:
            lines.append("No scene in the script matches clip {}.".format(clip.number))
        lines.append("")
        lines.append("speech heard: {:.2f}s over {} span(s)".format(
            clip.speech_seconds, len(clip.speech)))
        lines.append("true silence: {:.2f}s   music/ambience: {:.0f}%   motion: {:.1f}".format(
            sum(s.duration for s in clip.silence), clip.music_ratio * 100, clip.motion_score))
        if clip.cuts:
            lines.append("")
            lines.append("automatic cuts:")
            for cut in clip.cuts:
                lines.append("  {}{} ({}){}".format(
                    cut.get("reason", ""),
                    ": removed {:.2f}s".format(cut["removed"]) if cut.get("removed") else "",
                    cut.get("confidence", ""), " — " + cut["detail"] if cut.get("detail") else ""))
        lines.append("source file:  {}".format(clip.path.name))
        self.details.setText("\n".join(lines))

    # -------------------------------------------------------------- playback
    def toggle_play(self):
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
            self.btn_play.setText("Play")
        else:
            self.player.play()
            self.btn_play.setText("Pause")

    def preview_cut(self):
        if not self.current or self.current.cut_start is None:
            return
        self.player.setPosition(int(self.current.cut_start * 1000))
        self.player.play()
        self.btn_play.setText("Pause")

    def seek_to(self, seconds: float):
        self.player.setPosition(int(seconds * 1000))

    def on_position(self, ms: int):
        seconds = ms / 1000.0
        self.timeline.set_position(seconds)
        self.filmstrip.set_play_position(seconds)
        if self._audition_stop is not None:
            if seconds >= self._audition_stop:
                self.player.pause()
                self._audition_stop = None
                if self._audition_queue:
                    QTimer.singleShot(300, self._play_next_audition)
                else:
                    self.btn_play.setText("Play")
                    self._restore_source()
            return
        if self.current:
            self._sync_edit_buttons()
        clip = self.current
        if clip and clip.cut_end is not None and seconds > clip.cut_end + 0.05:
            if self.player.playbackState() == QMediaPlayer.PlayingState:
                self.player.pause()
                self.btn_play.setText("Play")

    # --------------------------------------------------------------- editing
    def nudge(self, edge: str, delta: float):
        if self.current:
            self.timeline.nudge(edge, delta)

    def audition_cut(self):
        """Play a moment either side of each cut point.

        The one question no measurement settles is whether a cut clips a
        word. Ears settle it in two seconds, if the two seconds are put in
        front of them: 0.8 s before the start cut through 0.8 s after it, then
        the same around the end cut.
        """
        clip = self.current
        if not clip or clip.cut_start is None:
            return
        margin = 0.8
        duration = clip.media.duration if clip.media else 10.0
        pieces = []
        # Every edge of every segment that is not the clip's own edge, so a
        # split or a removed middle is checked the same way as a trim.
        for span in clip.keep:
            if span.start > 0.05:
                pieces.append((clip.path, max(0.0, span.start - margin), span.start + margin))
            if span.end < duration - 0.05:
                pieces.append((clip.path, max(0.0, span.end - margin),
                               min(duration, span.end + margin)))
        if not pieces:
            self.statusBar().showMessage("Clip {} is kept whole; there is no cut to check.".format(
                clip.number), 4000)
            return
        self._audition_queue = pieces
        self._play_next_audition()

    def audition_join(self):
        """Play across the join into this clip: the last 0.8 s the previous
        kept clip contributes, then the first 0.8 s of this one. The two
        sit in different files, so the preview swaps source in between."""
        clip = self.current
        if not clip or not self.episode or not clip.keep:
            return
        before = None
        for other in sorted(self.episode.clips, key=lambda c: c.number):
            if other.number >= clip.number:
                break
            if other.state != ReviewState.REJECTED and other.keep:
                before = other
        if before is None:
            self.statusBar().showMessage(
                "Clip {} opens the episode; there is no join before it.".format(clip.number), 4000)
            return
        margin = 0.8
        tail = before.keep[-1]
        head = clip.keep[0]
        self._audition_queue = [
            (before.path, max(tail.start, tail.end - margin), tail.end),
            (clip.path, head.start, min(head.end, head.start + margin)),
        ]
        self._play_next_audition()

    def _play_next_audition(self):
        if not self._audition_queue:
            self._audition_stop = None
            return
        path, start, stop = self._audition_queue.pop(0)
        self._audition_stop = stop
        wanted = QUrl.fromLocalFile(str(path))
        if self.player.source() != wanted:
            # A fresh source needs a moment before it takes a seek.
            self.player.setSource(wanted)
            QTimer.singleShot(400, lambda: self._play_from(start))
            return
        self._play_from(start)

    def _play_from(self, start: float):
        self.player.setPosition(int(start * 1000))
        self.player.play()
        self.btn_play.setText("Pause")

    def _restore_source(self):
        """After a join preview the player may hold the previous clip."""
        if self.current:
            wanted = QUrl.fromLocalFile(str(self.current.path))
            if self.player.source() != wanted:
                self.player.setSource(wanted)
                self.player.pause()

    def use_full_clip(self):
        """Hand the trim to the editor: keep everything, then adjust by hand."""
        clip = self.current
        if not clip or not clip.media:
            return
        self.history.record(clip, "use full clip")
        clip.keep = [SpeechSpan(0.0, clip.media.duration)]
        self.segment = 0
        self._load_timeline(clip, keep_position=True)
        self._update_trim_readout(clip)
        log.info("Clip %d kept whole by the editor", clip.number)
        self._after_edit()

    # ------------------------------------------------------ segment cutting
    def _finish_cut(self, clip: Clip, message: str):
        """Common tail of every cutting operation: redraw, re-plan the joins
        and captions (both read `keep`), persist, and say what happened."""
        self._load_timeline(clip, keep_position=True)
        self._update_trim_readout(clip)
        self._after_edit()
        self.statusBar().showMessage(message, 6000)

    def split_at_playhead(self):
        clip = self.current
        if not clip or not clip.keep:
            return
        at = self._playhead()
        self.history.record(clip, "split")
        if not clip.split_segment(self.segment, at, self.config.min_clip_seconds):
            self.history.discard()
            self.statusBar().showMessage(
                "Put the playhead inside the selected segment, at least {:.1f} s from "
                "either end, then press Split.".format(self.config.min_clip_seconds), 5000)
            return
        self.segment += 1                      # the new right half is selected
        self._finish_cut(clip, "Split clip {} at {:.2f}s into {} segments.".format(
            clip.number, at, len(clip.keep)))

    def remove_left(self):
        clip = self.current
        if not clip or not clip.keep:
            return
        at = self._playhead()
        span = clip.keep[self.segment]
        self.history.record(clip, "remove left")
        if not clip.trim_segment_before(self.segment, at, self.config.min_clip_seconds):
            self.history.discard()
            self.statusBar().showMessage(
                "Nothing to remove: the playhead must be inside the selected segment "
                "with at least {:.1f} s left after it.".format(self.config.min_clip_seconds), 5000)
            return
        self._finish_cut(clip, "Removed {:.2f}s before the playhead from clip {}; everything "
                         "after it moves up to close the gap.".format(at - span.start, clip.number))

    def remove_right(self):
        clip = self.current
        if not clip or not clip.keep:
            return
        at = self._playhead()
        span = clip.keep[self.segment]
        self.history.record(clip, "remove right")
        if not clip.trim_segment_after(self.segment, at, self.config.min_clip_seconds):
            self.history.discard()
            self.statusBar().showMessage(
                "Nothing to remove: the playhead must be inside the selected segment "
                "with at least {:.1f} s left before it.".format(self.config.min_clip_seconds), 5000)
            return
        self._finish_cut(clip, "Removed {:.2f}s after the playhead from clip {}; everything "
                         "after it moves up to close the gap.".format(span.end - at, clip.number))

    def delete_segment(self):
        clip = self.current
        if not clip or not clip.keep:
            return
        if len(clip.keep) <= 1:
            self.statusBar().showMessage(
                "This is the clip's only segment. Press X to reject the whole clip instead.", 5000)
            return
        span = clip.keep[self.segment]
        self.history.record(clip, "delete segment")
        clip.delete_segment(self.segment)
        self.segment = min(self.segment, len(clip.keep) - 1)
        self._finish_cut(clip, "Deleted a {:.2f}s segment from clip {}; the rest moves up "
                         "to close the gap.".format(span.duration, clip.number))

    def toggle_mute(self, on: bool):
        clip = self.current
        if not clip or self._syncing_fades:
            return
        on = bool(on)
        if on == clip.muted:
            return
        self.history.record(clip, "mute" if on else "unmute")
        clip.muted = on
        log.info("Clip %d %s", clip.number, "muted" if on else "unmuted")
        self._finish_cut(clip, "Clip {} will be exported {}.".format(
            clip.number, "silent" if on else "with its audio"))

    def undo_edit(self):
        self._step_history(self.history.undo, "Undid", "undo")

    def redo_edit(self):
        self._step_history(self.history.redo, "Redid", "redo")

    def _step_history(self, step, verb: str, name: str):
        if not self.episode:
            return
        entry = step(self.episode)
        if entry is None:
            self.statusBar().showMessage("Nothing to {}.".format(name), 3000)
            return
        if not self.current or self.current.number != entry["number"]:
            self.select_clip(entry["number"])
        clip = self.current
        self.segment = min(self.segment, len(clip.keep) - 1)
        self._finish_cut(clip, "{} {} on clip {}.".format(verb, entry["label"], clip.number))

    def on_segment_selected(self, index: int):
        self.segment = index
        self._sync_edit_buttons()
        if self.current:
            self._update_trim_readout(self.current)

    def save_retake_sheet(self):
        if not self.episode:
            QMessageBox.information(self, APP_NAME, "Open an episode first.")
            return
        rows = build_retakes(self.episode)
        if not rows:
            QMessageBox.information(self, APP_NAME,
                                    "Nothing to regenerate: no clip is flagged as cut off, "
                                    "silent, unreadable or rejected.")
            return
        start_dir = Path(self.config.export_dir) if self.config.export_dir else Path(self.config.output_dir)
        default = str(start_dir / (self.episode.name[:60] + " - retakes.csv"))
        target, _ = QFileDialog.getSaveFileName(self, "Save the retake sheet", default, "CSV (*.csv)")
        if not target:
            return
        try:
            write_retakes(rows, Path(target))
        except OSError as exc:
            QMessageBox.critical(self, APP_NAME, "Could not write the sheet: {}".format(exc))
            return
        self.statusBar().showMessage("Retake sheet saved: {} clips → {}".format(len(rows), target))

    def _update_trim_readout(self, clip: Optional[Clip]):
        """Say where the cut sits in words, next to the buttons that change it.

        The trim strip draws the same three numbers, but an editor reading the
        inspector should not have to look back at the strip to check them.
        """
        if clip is None or not clip.keep:
            self.trim_readout.setText("")
            return
        if len(clip.keep) > 1:
            index = max(0, min(len(clip.keep) - 1, self.segment))
            span = clip.keep[index]
            self.trim_readout.setText(
                "Segment {} of {}:  {:.2f}s – {:.2f}s      Kept {:.2f}s in all".format(
                    index + 1, len(clip.keep), span.start, span.end, clip.cut_duration))
            return
        self.trim_readout.setText(
            "Start {:.2f}s      End {:.2f}s      Kept {:.2f}s".format(
                clip.keep[0].start, clip.keep[-1].end, clip.cut_duration))

    def on_segment_changed(self, index: int, start: float, end: float):
        clip = self.current
        if not clip or not 0 <= index < len(clip.keep):
            return
        self.history.record(clip, "trim")
        clip.keep[index] = SpeechSpan(start, end)
        self._update_trim_readout(clip)
        self._after_edit()
        self._sync_edit_buttons()

    def on_strip_trim(self, number: int, start: float, end: float):
        clip = next((c for c in self.episode.clips if c.number == number), None) \
            if self.episode else None
        if clip is None:
            return
        self.history.record(clip, "trim")
        if len(clip.keep) > 1:
            # The strip's handles are the outer edges; the inner cuts stay.
            first, last = clip.keep[0], clip.keep[-1]
            least = self.config.min_clip_seconds
            clip.keep[0] = SpeechSpan(min(start, first.end - least), first.end)
            clip.keep[-1] = SpeechSpan(last.start, max(end, last.start + least))
        else:
            clip.keep = [SpeechSpan(start, end)]
        if clip is self.current:
            self._load_timeline(clip, keep_position=True)
            self._update_trim_readout(clip)
        self._after_edit()

    def reset_cut(self):
        if not self.current:
            return
        self.history.record(self.current, "reset trim")
        plan_clip(self.current, self.config,
                  has_script=self.episode is not None and self.episode.script_path is not None)
        self.segment = 0
        self.select_clip(self.current.number)
        self._after_edit()

    def decide(self, state: ReviewState):
        if not self.current:
            return
        self.current.state = state
        log.info("Clip %d marked %s", self.current.number, state.value)
        self._after_edit()
        self.step(1)

    def _after_edit(self):
        if self.episode:
            flag_joins(self.episode)
        self.filmstrip.rebuild()
        if self.current:
            self._show_details(self.current)
            self._update_position(self.current)
        self._update_summary()
        self._save()

    def step(self, delta: int):
        if not self.episode or not self.current:
            return
        clips = self.episode.clips
        index = next((i for i, c in enumerate(clips) if c.number == self.current.number), 0)
        index = max(0, min(len(clips) - 1, index + delta))
        self.select_clip(clips[index].number)

    def next_flagged(self):
        if not self.episode:
            return
        clips = self.episode.clips
        start = 0
        if self.current:
            start = next((i for i, c in enumerate(clips)
                          if c.number == self.current.number), -1) + 1
        for clip in clips[start:] + clips[:start]:
            if clip.flags and clip.state == ReviewState.PENDING:
                self.select_clip(clip.number)
                return
        for clip in clips[start:] + clips[:start]:
            if clip.flags:
                self.select_clip(clip.number)
                return
        self.statusBar().showMessage("No flagged clips left.")

    # --------------------------------------------------------------- replace
    def replace_clip(self):
        """Swap in a re-generated file for this clip, keeping its place in the edit."""
        if not self.current or not self.episode:
            return
        clip = self.current
        chosen, _ = QFileDialog.getOpenFileName(
            self, "Choose the replacement clip for clip {}".format(clip.number),
            str(clip.path.parent), "Video files (*.mp4 *.mov *.mkv *.webm *.m4v)")
        if not chosen:
            return
        source = Path(chosen)
        if source.resolve() == clip.path.resolve():
            QMessageBox.information(self, "SceneForge", "That is the same file.")
            return

        confirm = QMessageBox.question(
            self, "Replace clip {}".format(clip.number),
            "Replace clip {} with:\n\n{}\n\nThe current file is kept in "
            ".sceneforge\\replaced, so this can be undone by hand.".format(
                clip.number, source.name),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if confirm != QMessageBox.Yes:
            return

        # The preview player holds an open handle on the clip; Windows refuses
        # to move a file that is in use. Clear the source and let Qt process the
        # release before touching the file.
        self.player.stop()
        self.player.setSource(QUrl())
        QApplication.processEvents()

        try:
            backup_dir = Path(self.episode.source_dir) / ".sceneforge" / "replaced"
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup = backup_dir / clip.path.name
            index = 1
            while backup.exists():
                backup = backup_dir / "{}_{}{}".format(
                    clip.path.stem, index, clip.path.suffix)
                index += 1
            _move_with_retry(clip.path, backup)
            shutil.copy2(str(source), str(clip.path))
            log.info("Clip %d replaced with %s (old file kept at %s)",
                     clip.number, source, backup)
        except OSError as exc:
            log.error("Replace failed for clip %d: %s", clip.number, exc)
            QMessageBox.critical(
                self, "SceneForge",
                "Could not replace the file:\n\n{}\n\nIf the clip is still "
                "playing, press Space to stop it and try again.".format(exc))
            return

        invalidate_thumb(self.episode.source_dir, clip.number)
        self._reanalyse_clip(clip)
        self.statusBar().showMessage(
            "Clip {} replaced and re-checked.".format(clip.number))

    def _reanalyse_clip(self, clip: Clip):
        """Re-probe, re-detect speech and re-plan a single clip after replacement."""
        from ..audio import decode
        from ..probe import probe
        from ..thumbs import extract, thumb_path
        from ..vad import VoiceDetector, spans_from_probabilities

        clip.flags.clear()
        clip.state = ReviewState.PENDING
        clip.media = probe(clip.path)
        if clip.media is None or clip.media.duration <= 0:
            clip.flags.add(Flag.UNREADABLE)
        else:
            samples = decode(clip.path)
            if samples is None:
                clip.flags.add(Flag.NO_AUDIO_TRACK)
                clip.speech = []
            else:
                detector = VoiceDetector()
                clip.speech = spans_from_probabilities(
                    detector.probabilities(samples),
                    threshold=self.config.vad_threshold,
                    min_speech_ms=self.config.vad_min_speech_ms,
                    min_silence_ms=self.config.vad_min_silence_ms,
                )
        plan_clip(clip, self.config)

        dest = thumb_path(self.episode.source_dir, clip.number)
        if extract(clip.path, dest):
            self.thumbs[clip.number] = str(dest)
            self.filmstrip.refresh_thumb(clip.number)
        self.select_clip(clip.number)
        self._after_edit()

    # ---------------------------------------------------------------- finish
    def _update_summary(self):
        if not self.episode:
            return
        episode = self.episode
        approved = sum(1 for c in episode.clips if c.state == ReviewState.APPROVED)
        rejected = sum(1 for c in episode.clips if c.state == ReviewState.REJECTED)
        pending = len(episode.clips) - approved - rejected
        flagged_left = sum(1 for c in episode.clips
                           if c.flags and c.state == ReviewState.PENDING)
        self._update_readiness(flagged_left, pending, approved + rejected)
        # Amber on Next flagged only while there is something to jump to.
        self.btn_next_flag.setProperty("armed", flagged_left > 0)
        self.btn_next_flag.style().unpolish(self.btn_next_flag)
        self.btn_next_flag.style().polish(self.btn_next_flag)
        numbers = trimmed_clip_numbers(episode)
        if numbers:
            links = ", ".join('<a href="{0}" style="color:{1}">{0}</a>'.format(n, theme.ACCENT)
                              for n in numbers)
            self.trimmed_block.setText("{} clip{}: {}".format(
                len(numbers), "" if len(numbers) == 1 else "s", links))
        else:
            self.trimmed_block.setText("None yet.")
        source = episode.source_seconds
        planned = self._finished_length()[0]
        self.summary.setText(
            "{} clips     {} approved     {} rejected     {} untouched\n"
            "{} flagged clips still unreviewed\n\n"
            "final length  {:.0f}m {:02.0f}s     (from {:.0f}m {:02.0f}s, saves {:.0f}%)".format(
                len(episode.clips), approved, rejected, pending, flagged_left,
                planned // 60, planned % 60, source // 60, source % 60,
                100 * (source - planned) / max(1e-9, source)))

    def finish_video(self):
        """Export. Warns first if flagged clips have not been looked at."""
        if not self.episode:
            return
        episode = self.episode
        included = [c for c in episode.clips if c.state != ReviewState.REJECTED]
        if not included:
            QMessageBox.warning(self, "SceneForge",
                                "Every clip is rejected, so there is nothing to export.")
            return

        unreviewed = [c for c in episode.clips
                      if c.flags and c.state == ReviewState.PENDING]
        planned = self._finished_length()[0]
        message = ("{} clips will be joined into one video.\n"
                   "Final length: {:.0f}m {:02.0f}s\n\n").format(
            len(included), planned // 60, planned % 60)
        if unreviewed:
            message += ("{} flagged clips have not been reviewed yet. They will "
                        "still be included.\nPress Tab in the editor to step "
                        "through them first.\n\n".format(len(unreviewed)))
        message += "Export now?"

        if QMessageBox.question(self, "Export video", message,
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.Yes) != QMessageBox.Yes:
            return

        # Ask where to save every time, starting in the folder used last.
        start_dir = Path(self.config.export_dir) if self.config.export_dir else None
        if start_dir is None or not start_dir.is_dir():
            start_dir = Path(self.config.output_dir).resolve()
        default = str(start_dir / (episode.name[:60] + ".mp4"))
        target, _ = QFileDialog.getSaveFileName(
            self, "Choose where to save the finished video", default, "MP4 (*.mp4)")
        if not target:
            return
        self.config.export_dir = str(Path(target).parent)
        try:
            self.config.save(Path.cwd())
        except OSError:
            pass

        # The preview holds the graphics card's decoder while a clip is
        # loaded, and the export wants the same card's encoder. Measured:
        # with a clip in the preview, Quick Sync crawled to ~19 s a piece;
        # with the player released it encodes in under a second. Let go of
        # the clip for the duration; it comes back when the export ends.
        self.player.stop()
        self.player.setSource(QUrl())
        self.preview_stack.setCurrentIndex(0)
        self._set_busy(True, "Exporting")
        self._worker = BuildWorker(episode, self.config, Path(target), self,
                                   username=self.user.username if self.user else "",
                                   display_name=self.user.display_name if self.user else "")
        self._worker.progress.connect(self.on_progress)
        self._worker.finished_ok.connect(self.on_build_done)
        self._worker.failed.connect(self.on_failed)
        self._worker.start()

    def _restore_preview(self):
        """Put the current clip back in the preview after an export."""
        if self.current and self.episode:
            self.select_clip(self.current.number)

    def on_build_done(self, path: str):
        self._set_busy(False)
        self._restore_preview()
        self.last_export = Path(path)
        self._refresh_watch_button()
        self.statusBar().showMessage("Exported " + path)

        size = 0.0
        try:
            size = self.last_export.stat().st_size / (1024 * 1024)
        except OSError:
            pass
        runtime = self._finished_length()[0]

        box = QMessageBox(self)
        box.setWindowTitle("Video ready")
        box.setText("Your episode is finished.\n\n{:.0f}m {:02.0f}s   ·   {:.0f} MB".format(
            runtime // 60, runtime % 60, size))
        retakes = ""
        if self.episode:
            try:
                rows = build_retakes(self.episode)
                if rows:
                    sheet = write_retakes(rows, sheet_path_for(self.last_export))
                    log.info("Retake sheet: %d rows -> %s", len(rows), sheet)
                    retakes = "\n\nRetake sheet ({} clip{} to regenerate): {}".format(
                        len(rows), "" if len(rows) == 1 else "s", sheet.name)
            except OSError as exc:
                log.warning("Could not write the retake sheet: %s", exc)
        box.setInformativeText(path + retakes)
        watch = box.addButton("▶  Watch it now", QMessageBox.AcceptRole)
        folder = box.addButton("Open folder", QMessageBox.ActionRole)
        box.addButton("Close", QMessageBox.RejectRole)
        box.setDefaultButton(watch)
        box.exec()

        if box.clickedButton() is watch:
            self.watch_finished()
        elif box.clickedButton() is folder:
            self._open_in_explorer(self.last_export.parent)

    def _refresh_watch_button(self):
        """Say on the button itself whether there is anything to play."""
        existing = self.last_export if (
            self.last_export and self.last_export.exists()) else self._find_existing_export()
        if existing:
            self.last_export = existing
            self.btn_watch.setText("▶  Play full video")
            self.btn_watch.setToolTip("Play {}".format(existing.name))
            self.btn_watch.setProperty("ready", True)
        else:
            self.btn_watch.setText("▶  Play full video")
            self.btn_watch.setToolTip("Nothing exported yet — press Export video first")
            self.btn_watch.setProperty("ready", False)
        self.btn_watch.style().unpolish(self.btn_watch)
        self.btn_watch.style().polish(self.btn_watch)

    def _find_existing_export(self) -> Optional[Path]:
        """Look for a video already exported for this episode.

        An editor who exported yesterday should still be able to press play
        today, so the newest matching file in the output folder counts, not
        only one produced in this session.
        """
        if not self.episode:
            return None
        stem = self.episode.name[:60]
        candidates = []
        folders = [Path(self.config.output_dir).resolve(), Path(self.episode.source_dir)]
        if self.config.export_dir:
            folders.insert(0, Path(self.config.export_dir))
        for folder in folders:
            try:
                if folder.is_dir():
                    candidates += [p for p in folder.glob("*.mp4")
                                   if p.stem.startswith(stem[:24])]
            except OSError:
                continue
        if not candidates:
            return None
        return max(candidates, key=lambda p: p.stat().st_mtime)

    def watch_finished(self):
        """Play the exported episode in whatever the machine uses for video.

        Deliberately the system player rather than the preview widget: this is
        the finished thing, and it deserves a full window and a seek bar.
        """
        target = self.last_export
        if not target or not target.exists():
            target = self._find_existing_export()

        if not target or not target.exists():
            answer = QMessageBox.question(
                self, "Nothing to play yet",
                "This episode has not been exported yet, so there is no full "
                "video to watch.\n\nExport it now?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if answer == QMessageBox.Yes:
                self.finish_video()
            return

        self.last_export = target
        # release the preview's handle so the player is not fighting us for it
        self.player.pause()
        log.info("Playing %s", target)
        self._open_in_explorer(target)

    @staticmethod
    def _open_in_explorer(target: Path) -> None:
        import os
        try:
            os.startfile(str(target))                    # noqa: S606
        except OSError as exc:
            log.warning("Could not open %s: %s", target, exc)

    def show_shortcuts(self):
        """The keyboard list, on demand. It used to run along the bottom of the
        window as a permanent strip of text nobody read after the first day."""
        rows = [("← / →", "Previous or next clip"),
                ("Space", "Play or pause"),
                ("C", "Preview just the kept part"),
                ("Q / W", "Nudge the trim start"),
                ("O / P", "Nudge the trim end"),
                ("R", "Reset the trim"),
                ("A", "Check the cut: play round each cut point"),
                ("J", "Play the join from the previous clip into this one"),
                ("S", "Split the selected segment at the playhead"),
                ("[ / ]", "Remove the part of the segment before / after the playhead"),
                ("Del", "Delete the selected segment"),
                ("M", "Mute or unmute this clip's audio in the export"),
                ("Ctrl+Z / Ctrl+Y", "Undo / redo a cut, trim, mute or join change"),
                ("Enter", "Approve this clip"),
                ("X", "Reject this clip"),
                ("Tab", "Jump to the next flagged clip")]
        body = "<table cellspacing='0' cellpadding='5'>" + "".join(
            "<tr><td><b>{}</b></td><td>{}</td></tr>".format(key, what)
            for key, what in rows) + "</table>"
        box = QMessageBox(self)
        box.setWindowTitle("Keyboard shortcuts")
        box.setTextFormat(Qt.RichText)
        box.setText(body)
        box.exec()

    def new_production(self, start_stage=None):
        """The setup wizard; `start_stage` (from Run from here with nothing
        open) preselects where the production starts."""
        dialog = ProductionSetupDialog(self.config, self.frameworks, self.credentials, self)
        if start_stage is not None:
            dialog.preselect(start_stage)
        if dialog.exec() == QDialog.Accepted and dialog.production is not None:
            self.production_page.load(dialog.production)
            self.pages.setCurrentWidget(self.production_page)
            log.info("Production created: %s (%s)", dialog.production.title, dialog.production.working_dir)
            if dialog.start_now:
                # The dashboard still confirms; the wizard only brought us here.
                self.production_page.start()

    def open_production(self):
        """Load an existing production from its saved state. A list, not a
        file picker: the person sees where each one is before choosing."""
        from .open_production import OpenProductionDialog
        dialog = OpenProductionDialog(self.config, self)
        if dialog.exec() != QDialog.Accepted or dialog.chosen is None:
            return
        try:
            production = Production.load(dialog.chosen)
        except (OSError, ValueError, KeyError) as exc:
            QMessageBox.warning(self, APP_NAME, "No production was found in that folder ({}).".format(exc))
            return
        self.production_page.load(production)
        try:
            self.production_page.episode_pick.setCurrentIndex(
                self.production_page.episode_pick.findData(dialog.selected_episode()))
        except Exception:                                  # noqa: BLE001 - a convenience
            pass
        self.pages.setCurrentWidget(self.production_page)
        log.info("Production opened: %s (%s)", production.title, production.working_dir)

    def new_batch(self):
        from .batch_page import NewBatchDialog, remember_batch
        dialog = NewBatchDialog(self.config, self.frameworks, self)
        if dialog.exec() == QDialog.Accepted and dialog.batch is not None:
            remember_batch(self.config, dialog.batch.folder, Path.cwd())
            self.batch_page.editor_name = self.user.display_name if self.user else ""
            self.batch_page.load(dialog.batch)
            self.pages.setCurrentWidget(self.batch_page)
            log.info("Batch created: %s (%s)", dialog.batch.name, dialog.batch.folder)

    def open_batch(self):
        from .batch_page import OpenBatchDialog, remember_batch
        from ..production.batch import Batch
        if self.batch_page.running:
            QMessageBox.information(self, "Open batch", "A batch is running; stop it before opening another.")
            return
        dialog = OpenBatchDialog(self.config, self)
        if dialog.exec() != QDialog.Accepted or dialog.chosen is None:
            return
        try:
            batch = Batch.load(dialog.chosen)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            QMessageBox.warning(self, APP_NAME, "No batch was found in that folder ({}).".format(exc))
            return
        remember_batch(self.config, batch.folder, Path.cwd())
        self.batch_page.editor_name = self.user.display_name if self.user else ""
        self.batch_page.load(batch)
        self.pages.setCurrentWidget(self.batch_page)

    def _open_production_folder(self, folder: str):
        try:
            production = Production.load(Path(folder))
        except (OSError, ValueError, KeyError) as exc:
            QMessageBox.warning(self, APP_NAME, "That production could not be read ({}).".format(exc))
            return
        self.production_page.load(production)
        self.pages.setCurrentWidget(self.production_page)

    def master_log(self):
        """The shared queue of titles. Asks for its folder the first time and
        remembers it; the folder is read now, on the click, never at start-up,
        so a sleeping share can only ever stall this one action."""
        folder = str(getattr(self.config, "master_log_dir", "") or "").strip()
        if not folder:
            # The first time: say what is being asked for, and offer a folder
            # on this PC for a start, since a share is a decision for later.
            suggested = Path.home() / "Documents" / "9 Sigma Master Log"
            box = QMessageBox(self)
            box.setWindowTitle("Master log")
            box.setText("The master log is one folder that every editor's machine can reach: it holds the "
                        "framework records (niche, editor, email, the framework files), the titles and "
                        "their status.\n\nFor the office, choose a folder on the shared drive. To try it "
                        "on this PC first, use:\n{}".format(suggested))
            this_pc = box.addButton("Use this PC", QMessageBox.AcceptRole)
            choose = box.addButton("Choose a shared folder…", QMessageBox.ActionRole)
            box.addButton(QMessageBox.Cancel)
            box.exec()
            if box.clickedButton() is this_pc:
                try:
                    suggested.mkdir(parents=True, exist_ok=True)
                except OSError as exc:
                    QMessageBox.warning(self, "Master log", "That folder could not be created: {}".format(exc))
                    return
                folder = str(suggested)
            elif box.clickedButton() is choose:
                chosen = QFileDialog.getExistingDirectory(
                    self, "Choose the master log folder (the shared folder every editor's machine can reach)",
                    str(Path.home() / "Documents"))
                if not chosen:
                    return
                folder = chosen
            else:
                return
            self.config.master_log_dir = folder
            try:
                self.config.save(Path.cwd())
            except OSError as exc:
                log.warning("config.json could not be saved: %s", exc)
        self.master_page.load(Path(folder))
        self.pages.setCurrentWidget(self.master_page)

    def flow_accounts(self):
        """Google Flow accounts, credits and the manual queue. The inventory
        lives in the master log's folder, so that folder must be chosen
        first; the page has a Folder… button of its own as well."""
        folder = str(getattr(self.config, "master_log_dir", "") or "").strip()
        if folder:
            self.flow_page.load(Path(folder))
        else:
            self.statusBar().showMessage("Choose the master log folder first under Master log… or Folder….")
        self.pages.setCurrentWidget(self.flow_page)

    def _build_flow_account_menu(self):
        """Omni Flow's account menu, on the Flow page's own bar: only what
        the app has -- updates, about and sign out."""
        self.btn_flow_account = QToolButton()
        self.btn_flow_account.setText("Account ▾")
        self.btn_flow_account.setObjectName("actAccount")
        self.btn_flow_account.setToolTip("Account, updates and about")
        self.btn_flow_account.setPopupMode(QToolButton.InstantPopup)
        self.flow_account_menu = QMenu(self)
        self.flow_account_header = self.flow_account_menu.addAction("Not signed in")
        self.flow_account_header.setEnabled(False)
        self.flow_account_menu.addSeparator()
        self.flow_account_menu.addAction("Check for updates", lambda: self.check_for_updates(manual=True))
        self.flow_account_menu.addAction("About " + APP_NAME, self.show_about)
        self.flow_account_menu.addSeparator()
        self.flow_account_menu.addAction("Sign out", self.sign_out)
        self.btn_flow_account.setMenu(self.flow_account_menu)
        self.flow_page.bar.addSpacing(theme.SPACE_1)
        self.flow_page.bar.addWidget(self.btn_flow_account)

    def closeEvent(self, event):
        """Closing the window must not leave a worker submitting paid jobs,
        or destroy a thread mid-write. Both runners are told to stop and
        given a bounded wait; a job that could not finish stopping is picked
        up again later by its stale heartbeat."""
        worker = getattr(self, "_worker", None)
        if isinstance(worker, BuildWorker) and worker.isRunning():
            answer = QMessageBox.question(
                self, "Export in progress",
                "An export is running. Close anyway?\n\nThe finished segments are kept: export "
                "again to the same file to continue from where it stopped.",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer != QMessageBox.Yes:
                event.ignore()
                return
            worker.cancel()
            if not worker.wait(15000):
                # Qt aborts the process when a running QThread is destroyed with
                # its parent. Let it go instead: the job object ends its ffmpeg
                # when the process exits, and the manifest keeps the work.
                log.warning("The export did not stop within 15 s; leaving it to end with the process")
                worker.setParent(None)
        self.master_page.shutdown()
        self.flow_page.shutdown()
        self.batch_page.shutdown()
        self.production_page.stop_event.set()
        thread = self.production_page.thread
        if thread is not None and thread.isRunning() and not thread.wait(10000):
            log.warning("The production run did not stop within 10 s")
        super().closeEvent(event)

    def show_about(self):
        box = QMessageBox(self)
        box.setWindowTitle("About")
        box.setText("{}  ·  Version {}".format(APP_NAME, VERSION))
        box.setInformativeText(COPYRIGHT)
        box.exec()

    def _update_readiness(self, flagged_left: int, pending: int, decided: int):
        """Say plainly whether the edit is finished, and what is left if not.

        Three states, in the order an editor meets them: clips that were
        flagged and still have not been looked at, clips nobody has decided on,
        and done. Counting rows in a list to work this out is exactly the chore
        the tool exists to remove.
        """
        if not self.episode:
            return
        runtime = self._finished_length()[0]
        length = "{:.0f}m {:02.0f}s".format(runtime // 60, runtime % 60)

        if flagged_left:
            state, text = "work", (
                "{} flagged clip{} still to check.\n"
                "Press Tab to jump to the next one.".format(
                    flagged_left, "" if flagged_left == 1 else "s"))
        elif pending:
            state, text = "almost", (
                "No flagged clips left.\n"
                "{} clip{} nobody has decided on — they will be included with the "
                "automatic cut. Approve all, or step through with Enter.".format(
                    pending, "" if pending == 1 else "s"))
        else:
            state, text = "ready", (
                "Ready to export.\n"
                "Every clip reviewed. Final video will be {}.".format(length))

        self.ready_banner.setText(text)
        self.ready_banner.setProperty("state", state)
        self.ready_banner.style().unpolish(self.ready_banner)
        self.ready_banner.style().polish(self.ready_banner)
        self.ready_banner.setVisible(True)
        self.btn_export.setText("Export video" if state != "ready" else "Export video  ✓")

    # -------------------------------------------------------- bulk + options
    def approve_all(self):
        """Approve everything still untouched, after saying what that includes."""
        if not self.episode:
            return
        pending = [c for c in self.episode.clips if c.state == ReviewState.PENDING]
        if not pending:
            QMessageBox.information(self, "SceneForge",
                                    "Every clip has already been reviewed.")
            return

        flagged = [c for c in pending if c.flags]
        message = "Approve {} clips that have not been reviewed?".format(len(pending))
        if flagged:
            numbers = ", ".join(str(c.number) for c in flagged[:14])
            if len(flagged) > 14:
                numbers += ", …"
            message += ("\n\n{} of them are flagged and will be approved without "
                        "anyone watching them:\n{}".format(len(flagged), numbers))
        message += "\n\nThe automatic cut is kept for each one."

        if QMessageBox.question(self, "Approve all", message,
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return

        for clip in pending:
            clip.state = ReviewState.APPROVED
        log.info("Approved all %d remaining clips (%d flagged)", len(pending), len(flagged))
        self.filmstrip.rebuild()
        if self.current:
            self._show_details(self.current)
        self._update_summary()
        self._save()
        self.statusBar().showMessage("Approved {} clips.".format(len(pending)))

    def _sync_output_controls(self):
        """Show the config's current choices in the Output panel."""
        self._syncing_output = True
        try:
            height = self.config.output_height if self.config.output_height in (720, 1080) else 1080
            self.btn_720.setChecked(height == 720)
            self.btn_1080.setChecked(height == 1080)
        finally:
            self._syncing_output = False

    def _pick_size(self, height: int):
        self.config.output_height = height
        self._sync_output_controls()
        self._on_output_options()

    def _on_output_options(self, *_):
        """Keep the config in step with the output controls, and persist it."""
        if getattr(self, "_syncing_output", False):
            return
        wants_captions = self.chk_captions.isChecked()
        self.captions_choice.setVisible(wants_captions)
        self.config.captions = (
            self.captions_choice.currentData() or "srt") if wants_captions else "off"
        if self.episode:
            self._update_summary()
            if self.current:
                self._update_position(self.current)
        try:
            self.config.save(Path.cwd())
        except OSError:
            pass

    # ---------------------------------------------------------------- shared
    def _save(self):
        if self.episode:
            try:
                save_state(self.episode, self.config.editor_name)
            except OSError:
                pass

    def on_progress(self, done: int, total: int, label: str):
        self.progress.setMaximum(max(1, total))
        self.progress.setValue(done)
        # A percentage, not "done / total": the export counts in thousandths
        # of the whole job, and a count of steps froze at "547 / 550" for the
        # length of the final encode.
        self.progress.setFormat("{}%   {}".format(int(100 * done / max(1, total)), label))

    def _set_busy(self, busy: bool, label: str = ""):
        self.progress.setVisible(busy)
        if busy:
            self.progress.setValue(0)
            self.statusBar().showMessage(label + "…")
        for widget in (self.btn_home, self.btn_recent, self.btn_reanalyse,
                       self.btn_export, self.btn_replace):
            widget.setEnabled(not busy)
        if not busy:
            self.btn_export.setEnabled(self.episode is not None)
            self.btn_reanalyse.setEnabled(self.folder is not None)


def _move_with_retry(source: Path, dest: Path, attempts: int = 8) -> None:
    """Move a file that Windows may still consider open.

    Clearing the media player's source releases the handle, but not always by
    the time the next statement runs. Retrying briefly turns an intermittent
    WinError 32 into a non-event.
    """
    last: OSError | None = None
    for attempt in range(attempts):
        try:
            shutil.move(str(source), str(dest))
            return
        except OSError as exc:
            last = exc
            if getattr(exc, "winerror", None) not in (32, 33):
                raise
            QApplication.processEvents()
            time.sleep(0.15 * (attempt + 1))
    raise last if last else OSError("could not move " + str(source))
