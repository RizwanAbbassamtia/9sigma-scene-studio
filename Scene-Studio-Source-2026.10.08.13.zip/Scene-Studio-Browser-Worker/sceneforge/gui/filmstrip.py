"""CapCut-style filmstrip: every clip laid end to end, width set by its runtime.

Trimming a clip visibly shrinks its block and the rest slide left, so an editor
can see the episode getting shorter as they work. Clips they reject grey out and
stop taking up room.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import QEvent, QRect, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QSizePolicy, QToolTip, QWidget

from pathlib import Path

from ..models import Clip, Flag, ReviewState
from ..thumbs import thumb_path
from . import theme

# Colours come from the one token file; see `theme.py`.
#
# The thumbnails are the only picture in the strip and have to stay
# inspectable, so nothing is painted across them: the selected clip is marked
# by a blue outline, and clip numbers and durations sit on a small dark plate
# rather than being drawn straight onto the frame.
_BG = QColor(theme.TL_BG)
_RULER = QColor(theme.TL_RULER)
_CLIP = QColor(theme.TL_CLIP)
_CLIP_SEL = QColor(theme.SELECT_BG)
_BORDER = QColor(theme.BORDER)
_BORDER_SEL = QColor(theme.ACCENT)
_TEXT = QColor(theme.TEXT_PRIMARY)
_DIM = QColor(theme.TEXT_MUTED)
_OVERLAY = QColor(11, 13, 17, 190)     # the plate the labels are written on

# Status marks. Each one is a colour AND a shape, so the strip still reads for
# an editor who cannot separate the hues: a tick for approved, a cross for
# rejected, a bar plus an exclamation for flagged, and a thicker bar for the
# one flag that means footage is genuinely missing.
_FLAG = QColor(theme.WARNING)
_TRUNC = QColor(theme.DANGER)
_OK = QColor(theme.SUCCESS)
_REJECT = QColor(theme.DANGER_BG)
_PLAYHEAD = QColor(theme.ACCENT)
_HANDLE = QColor(theme.ACCENT)

# What each mark on a clip means, in the words the tooltip uses.
_FLAG_WORDS = {
    Flag.SCRIPTED_BUT_SILENT: "script has dialogue, none was heard",
    Flag.SPEECH_NOT_SCRIPTED: "a voice was heard where none is scripted",
    Flag.NO_AUDIO_TRACK: "no audio track",
    Flag.SPEECH_TRUNCATED: "dialogue cut off at the end of the clip",
    Flag.SPEECH_MUCH_SHORTER: "far less speech than the script implies",
    Flag.MOTION_ANOMALY: "unusual motion",
    Flag.DURATION_OUTLIER: "different length from the rest",
    Flag.NO_SCENE_MATCH: "no scene in the script has this number",
    Flag.DUPLICATE_NUMBER: "another file claims this number",
    Flag.UNREADABLE: "file could not be read",
}

STRIP_HEIGHT = 132
RULER_HEIGHT = 18
CLIP_TOP = RULER_HEIGHT + 6
CLIP_HEIGHT = STRIP_HEIGHT - CLIP_TOP - 8
HANDLE_W = 8
GAP = 2
MIN_CLIP_PX = 26


class Filmstrip(QWidget):
    clip_selected = Signal(int)                 # clip number
    trim_changed = Signal(int, float, float)    # clip number, start, end
    scrub = Signal(int, float)                  # clip number, seconds into clip

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(STRIP_HEIGHT)
        self.setMaximumHeight(STRIP_HEIGHT)
        self.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.NoFocus)

        self.clips: List[Clip] = []
        self.source_dir: Optional[Path] = None
        self._pixmaps: Dict[int, QPixmap] = {}
        self.px_per_second: float = 14.0
        self.selected: Optional[int] = None
        self.play_position: float = 0.0

        self._drag: Optional[str] = None
        self._drag_number: Optional[int] = None
        self._layout: List[Tuple[Clip, float, float]] = []   # clip, x, width

    # ------------------------------------------------------------------ data
    def set_clips(self, clips: List[Clip], source_dir):
        """Take the clips and where they live; thumbnails are resolved on demand.

        Earlier this took a {number: path} map handed over by the analysis
        thread. Passing it through a signal meant the strip could paint before
        the map arrived, and every clip drew blank. Looking the path up from
        the source folder at paint time removes the race entirely.
        """
        self.clips = list(clips)
        self.source_dir = Path(source_dir) if source_dir else None
        self._pixmaps.clear()
        self.rebuild()

    def refresh_thumb(self, number: int):
        """Forget one cached pixmap, e.g. after that clip was replaced."""
        self._pixmaps.pop(number, None)
        self.update()

    def set_zoom(self, px_per_second: float):
        self.px_per_second = max(3.0, min(60.0, px_per_second))
        self.rebuild()

    def set_selected(self, number: Optional[int]):
        self.selected = number
        self.update()

    def set_play_position(self, seconds: float):
        self.play_position = seconds
        self.update()

    def rebuild(self):
        """Recompute x positions. Rejected clips take no space, as in a real edit."""
        self._layout = []
        x = 0.0
        for clip in self.clips:
            if clip.state == ReviewState.REJECTED:
                width = MIN_CLIP_PX * 0.7          # a stub, so it can still be clicked
            else:
                width = max(MIN_CLIP_PX, clip.cut_duration * self.px_per_second)
            self._layout.append((clip, x, width))
            x += width + GAP
        self.setMinimumWidth(int(x) + 20)
        self.resize(int(x) + 20, STRIP_HEIGHT)
        self.update()

    def x_for_clip(self, number: int) -> Optional[float]:
        for clip, x, _ in self._layout:
            if clip.number == number:
                return x
        return None

    # -------------------------------------------------------------- painting
    def _pixmap(self, clip: Clip) -> Optional[QPixmap]:
        if clip.number in self._pixmaps:
            return self._pixmaps[clip.number]
        if self.source_dir is None:
            return None
        path = thumb_path(self.source_dir, clip.number)
        if not path.exists():
            return None
        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            return None
        pixmap = pixmap.scaledToHeight(CLIP_HEIGHT, Qt.SmoothTransformation)
        self._pixmaps[clip.number] = pixmap
        return pixmap

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), _BG)
        self._paint_ruler(painter, event.rect())

        font = QFont()
        font.setPointSize(8)
        painter.setFont(font)

        for clip, x, width in self._layout:
            if x + width < event.rect().left() - 40 or x > event.rect().right() + 40:
                continue                                   # offscreen, skip
            self._paint_clip(painter, clip, x, width)

        painter.end()

    def _paint_ruler(self, painter: QPainter, visible: QRect):
        painter.fillRect(QRect(0, 0, self.width(), RULER_HEIGHT), _RULER)
        painter.setPen(QPen(_DIM))
        font = QFont()
        font.setPointSize(7)
        painter.setFont(font)

        # a tick every 30 seconds of finished runtime
        step = 30.0 * self.px_per_second
        if step < 40:
            step = 60.0 * self.px_per_second
        seconds_per_tick = step / self.px_per_second
        x = 0.0
        index = 0
        while x < self.width():
            if x >= visible.left() - step and x <= visible.right() + step:
                total = int(index * seconds_per_tick)
                painter.drawLine(int(x), RULER_HEIGHT - 5, int(x), RULER_HEIGHT)
                painter.drawText(QRectF(x + 3, 1, 60, RULER_HEIGHT - 3), Qt.AlignLeft,
                                 "{}:{:02d}".format(total // 60, total % 60))
            x += step
            index += 1

    @staticmethod
    def _paint_badge(painter: QPainter, x: float, y: float, glyph: str,
                     colour: QColor):
        """A small dark disc with a status glyph on it, in the clip's corner.

        The glyph is what makes the state readable without relying on the
        colour: a tick, a cross, an exclamation or a triangle.
        """
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(_OVERLAY))
        painter.drawEllipse(QRectF(x, y, 14, 14))
        font = painter.font()
        size = font.pointSize()
        font.setPointSize(7)
        font.setBold(True)
        painter.setFont(font)
        painter.setPen(QPen(colour))
        painter.drawText(QRectF(x, y, 14, 14), Qt.AlignCenter, glyph)
        font.setPointSize(size)
        font.setBold(False)
        painter.setFont(font)

    def _paint_clip(self, painter: QPainter, clip: Clip, x: float, width: float):
        rect = QRectF(x, CLIP_TOP, width, CLIP_HEIGHT)
        rejected = clip.state == ReviewState.REJECTED
        selected = clip.number == self.selected

        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(_REJECT if rejected else (_CLIP_SEL if selected else _CLIP)))
        painter.drawRoundedRect(rect, 3, 3)

        pixmap = self._pixmap(clip)
        if pixmap and not rejected and width > 14:
            painter.save()
            painter.setClipRect(rect)
            source_w = min(pixmap.width(), int(width))
            painter.setOpacity(1.0 if selected else 0.9)
            painter.drawPixmap(QRectF(x, CLIP_TOP, source_w, CLIP_HEIGHT),
                               pixmap, QRectF(0, 0, source_w, pixmap.height()))
            painter.setOpacity(1.0)
            painter.restore()

        # Status stripe along the top edge, plus a glyph in the corner. The
        # stripe finds the clip across the strip; the glyph says which state it
        # is in without the editor having to separate two dark hues.
        truncated = Flag.SPEECH_TRUNCATED in clip.flags
        if rejected:
            stripe, thickness, glyph = _TRUNC, 3, "✕"       # cross
        elif truncated:
            stripe, thickness, glyph = _TRUNC, 5, "▲"       # filled triangle
        elif clip.flags:
            stripe, thickness, glyph = _FLAG, 3, "!"
        elif clip.state == ReviewState.APPROVED:
            stripe, thickness, glyph = _OK, 3, "✓"          # tick
        else:
            stripe, thickness, glyph = None, 0, ""
        if stripe and not rejected:
            painter.setBrush(QBrush(stripe))
            painter.setPen(Qt.NoPen)
            painter.drawRect(QRectF(x, CLIP_TOP, width, thickness))
        if glyph and width > 22:
            self._paint_badge(painter, x + width - 17, CLIP_TOP + thickness + 3,
                              glyph, stripe or _DIM)

        painter.setPen(QPen(_BORDER_SEL if selected else _BORDER, 2 if selected else 1))
        painter.setBrush(Qt.NoBrush)
        # The selection sits just outside the frame, so it never covers the
        # number plate or the corner badge.
        if selected:
            painter.drawRoundedRect(rect.adjusted(-1, -1, 1, 1), 4, 4)
        else:
            painter.drawRoundedRect(rect, 3, 3)

        if width > 30:
            plate = QRectF(x + 1, CLIP_TOP + CLIP_HEIGHT - 17, width - 2, 16)
            painter.setPen(Qt.NoPen)
            painter.setBrush(QBrush(_OVERLAY))
            painter.drawRect(plate)
            painter.setPen(QPen(_DIM if rejected else _TEXT))
            painter.drawText(plate.adjusted(5, 0, -5, -1), Qt.AlignLeft | Qt.AlignVCenter,
                             str(clip.number))
            if width > 62:
                painter.setPen(QPen(_DIM))
                painter.drawText(plate.adjusted(5, 0, -5, -1),
                                 Qt.AlignRight | Qt.AlignVCenter,
                                 "{:.1f}s".format(clip.cut_duration))

        if rejected and width > 16:
            painter.setPen(QPen(_DIM, 2))
            painter.drawLine(int(x + 4), CLIP_TOP + 8,
                             int(x + width - 4), CLIP_TOP + CLIP_HEIGHT - 8)
            painter.drawLine(int(x + width - 4), CLIP_TOP + 8,
                             int(x + 4), CLIP_TOP + CLIP_HEIGHT - 8)

        if selected and not rejected:
            painter.setBrush(QBrush(_HANDLE))
            painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(QRectF(x, CLIP_TOP, HANDLE_W, CLIP_HEIGHT), 2, 2)
            painter.drawRoundedRect(
                QRectF(x + width - HANDLE_W, CLIP_TOP, HANDLE_W, CLIP_HEIGHT), 2, 2)

            if clip.cut_duration > 0:
                offset = self.play_position - (clip.cut_start or 0.0)
                ratio = max(0.0, min(1.0, offset / clip.cut_duration))
                head = x + ratio * width
                painter.setPen(QPen(_PLAYHEAD, 2))
                painter.drawLine(QRectF(head, CLIP_TOP, 0, CLIP_HEIGHT).topLeft(),
                                 QRectF(head, CLIP_TOP + CLIP_HEIGHT, 0, 0).topLeft())

    # ----------------------------------------------------------- interaction
    def _hit(self, px: float, py: float):
        if py < CLIP_TOP or py > CLIP_TOP + CLIP_HEIGHT:
            return None, None
        for clip, x, width in self._layout:
            if x <= px <= x + width:
                if clip.number == self.selected and clip.state != ReviewState.REJECTED:
                    if px - x <= HANDLE_W:
                        return clip, "start"
                    if (x + width) - px <= HANDLE_W:
                        return clip, "end"
                return clip, "body"
        return None, None

    def mousePressEvent(self, event):
        clip, where = self._hit(event.position().x(), event.position().y())
        if clip is None:
            return
        if where in ("start", "end"):
            self._drag = where
            self._drag_number = clip.number
            return
        if clip.number != self.selected:
            self.clip_selected.emit(clip.number)
            return
        # clicking inside the already-selected clip scrubs it
        x = self.x_for_clip(clip.number)
        width = next(w for c, _, w in self._layout if c.number == clip.number)
        if width > 0:
            ratio = (event.position().x() - x) / width
            self.scrub.emit(clip.number, (clip.cut_start or 0.0) + ratio * clip.cut_duration)

    def mouseMoveEvent(self, event):
        px, py = event.position().x(), event.position().y()
        if self._drag is None:
            _, where = self._hit(px, py)
            self.setCursor(Qt.SizeHorCursor if where in ("start", "end") else Qt.ArrowCursor)
            return

        clip = next((c for c in self.clips if c.number == self._drag_number), None)
        if clip is None or not clip.keep:
            return
        duration = clip.media.duration if clip.media else 10.0
        x = self.x_for_clip(clip.number)
        if x is None:
            return

        start, end = clip.keep[0].start, clip.keep[-1].end
        if self._drag == "start":
            start = max(0.0, min((px - x) / self.px_per_second + start, end - 0.15))
        else:
            width = next(w for c, _, w in self._layout if c.number == clip.number)
            end = min(duration, max(start + 0.15, start + (px - x) / self.px_per_second))
        self.trim_changed.emit(clip.number, start, end)

    def mouseReleaseEvent(self, event):
        self._drag = None
        self._drag_number = None

    def event(self, ev):
        # The stripe and the badge say something is up; hovering says what.
        if ev.type() == QEvent.ToolTip:
            px = ev.pos().x()
            for clip, x, width in self._layout:
                if x <= px <= x + width:
                    QToolTip.showText(ev.globalPos(), self._describe(clip), self)
                    return True
            QToolTip.hideText()
            return True
        return super().event(ev)

    @staticmethod
    def _describe(clip: Clip) -> str:
        source = clip.media.duration if clip.media else 0.0
        state = {ReviewState.APPROVED: "Approved", ReviewState.REJECTED: "Rejected"}.get(
            clip.state, "Not reviewed")
        lines = ["Clip {}  ·  {:.1f}s kept of {:.1f}s  ·  {}".format(
            clip.number, clip.cut_duration, source, state)]
        for flag in sorted(clip.flags, key=lambda f: f.value):
            lines.append("⚠ " + _FLAG_WORDS.get(flag, flag.value))
        return "\n".join(lines)

    def wheelEvent(self, event):
        if event.modifiers() & Qt.ControlModifier:
            delta = event.angleDelta().y()
            self.set_zoom(self.px_per_second * (1.15 if delta > 0 else 0.87))
            event.accept()
        else:
            event.ignore()
