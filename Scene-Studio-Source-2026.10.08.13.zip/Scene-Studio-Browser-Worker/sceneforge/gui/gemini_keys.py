"""The Google Gemini key dialog for Omni Flow: the key (sealed on save),
the model and the video settings it generates with, and a free check that
the key is accepted. Nothing here estimates cost: Google bills per
generated second to the Cloud account behind the key, and the API reports
no balance to show.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import (
    QComboBox, QDialog, QFormLayout, QHBoxLayout, QLineEdit, QPushButton, QVBoxLayout,
)

from ..config import Config
from ..logging_setup import get
from ..production.credentials import GEMINI, Credentials
from ..production.gemini_video import (
    ASPECT_RATIOS, DURATIONS, MODEL_LABELS, MODELS, OMNI_FLASH_MODEL, RESOLUTIONS, GeminiVideoGenerator,
)
from ..production.providers import ProviderError
from .master_page import _hint, _section

log = get("gemini_keys.dialog")

TITLE = "Google Gemini key"
BILLING_HINT = ("Clips are billed per generated second by Google; see the Cloud console for the bill. "
                "The key is sealed to your Windows account before it is saved and is never written in "
                "plain text or logged.")
DURATION_HINT = "Duration applies to the Veo models; Gemini Omni Flash sets its own."
CHECK_WAIT_MS = 16000


def make_generator(key: str, model: str, aspect_ratio: str, resolution: str, duration_seconds: int):
    return GeminiVideoGenerator(key, model=model, aspect_ratio=aspect_ratio, resolution=resolution,
                                duration_seconds=duration_seconds)


class _KeyCheck(QThread):
    """One model lookup with the key, off the window's thread. Free: it
    generates nothing."""
    done = Signal(str)

    def __init__(self, generator, parent=None):
        super().__init__(parent)
        self.generator = generator

    def run(self):
        try:
            self.done.emit(self.generator.check())
        except ProviderError as exc:
            self.done.emit(str(exc))
        except Exception as exc:                                       # noqa: BLE001 - shown, never raised
            self.done.emit("The Gemini key could not be checked: {}".format(type(exc).__name__))


class GeminiKeysDialog(QDialog):
    def __init__(self, credentials: Credentials, config: Config, parent=None,
                 make_generator: Optional[Callable] = None):
        super().__init__(parent)
        self.credentials = credentials
        self.config = config
        self._make = make_generator or globals()["make_generator"]
        self._check: Optional[_KeyCheck] = None
        self.setWindowTitle(TITLE)
        self.setMinimumWidth(560)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)
        outer.addWidget(_section(TITLE))
        outer.addWidget(_hint("An API key from Google AI Studio with billing on. It generates clips through "
                              "Google's own API: no Google account is signed in, no Flow credits are used."))
        form = QFormLayout()
        form.setSpacing(8)
        self.key = QLineEdit()
        self.key.setEchoMode(QLineEdit.Password)
        current = credentials.get(GEMINI)
        self.key.setPlaceholderText("saved: " + Credentials.masked(current) if current else "not set")
        self.btn_check = QPushButton("Check key")
        self.btn_check.setObjectName("quiet")
        self.btn_check.setToolTip("Asks Google whether the key is accepted for the chosen model. Generates nothing.")
        self.btn_check.clicked.connect(self.check_key)
        key_row = QHBoxLayout()
        key_row.addWidget(self.key, 1)
        key_row.addWidget(self.btn_check)
        form.addRow("Gemini API key", key_row)
        self.model = QComboBox()
        for model_id in MODELS:
            self.model.addItem(MODEL_LABELS[model_id], model_id)
        self.model.setCurrentIndex(max(0, self.model.findData(str(getattr(config, "gemini_model", "") or ""))))
        self.model.currentIndexChanged.connect(self._model_picked)
        form.addRow("Model", self.model)
        self.aspect = QComboBox()
        for ratio in ASPECT_RATIOS:
            self.aspect.addItem(ratio, ratio)
        self.aspect.setCurrentIndex(max(0, self.aspect.findData(str(getattr(config, "gemini_aspect_ratio", "") or ""))))
        form.addRow("Aspect ratio", self.aspect)
        self.resolution = QComboBox()
        for res in RESOLUTIONS:
            self.resolution.addItem(res, res)
        self.resolution.setCurrentIndex(max(0, self.resolution.findData(
            str(getattr(config, "gemini_resolution", "") or ""))))
        form.addRow("Resolution", self.resolution)
        self.duration = QComboBox()
        for seconds in DURATIONS:
            self.duration.addItem("{} s".format(seconds), seconds)
        try:
            wanted = int(getattr(config, "gemini_duration_seconds", 8) or 8)
        except (TypeError, ValueError):
            wanted = 8
        self.duration.setCurrentIndex(max(0, self.duration.findData(wanted)))
        form.addRow("Duration (Veo)", self.duration)
        form.addRow(_hint(DURATION_HINT))
        outer.addLayout(form)
        self.check_result = _hint("")
        outer.addWidget(self.check_result)
        outer.addWidget(_hint(BILLING_HINT))
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_save = QPushButton("Save")
        self.btn_save.setObjectName("primary")
        self.btn_save.clicked.connect(self.save)
        buttons.addWidget(self.btn_cancel)
        buttons.addWidget(self.btn_save)
        outer.addLayout(buttons)
        self._model_picked()

    # -- values -------------------------------------------------------------
    def model_id(self) -> str:
        return str(self.model.currentData() or MODELS[0])

    def values(self) -> dict:
        return {"model": self.model_id(), "aspect_ratio": str(self.aspect.currentData() or ASPECT_RATIOS[0]),
                "resolution": str(self.resolution.currentData() or RESOLUTIONS[0]),
                "duration_seconds": int(self.duration.currentData() or 8)}

    def _model_picked(self, *_):
        self.duration.setEnabled(self.model_id() != OMNI_FLASH_MODEL)

    # -- the check ------------------------------------------------------------
    def check_key(self) -> bool:
        key = self.key.text().strip() or self.credentials.get(GEMINI)
        if not key:
            self.check_result.setText("Enter the Gemini key first.")
            return False
        values = self.values()
        for button in (self.btn_check, self.btn_save, self.btn_cancel):
            button.setEnabled(False)
        self.check_result.setText("Checking…")
        generator = self._make(key, values["model"], values["aspect_ratio"], values["resolution"],
                               values["duration_seconds"])
        self._check = _KeyCheck(generator, self)
        self._check.done.connect(self._checked)
        self._check.start()
        return True

    def _checked(self, text: str):
        self.check_result.setText(text)
        for button in (self.btn_check, self.btn_save, self.btn_cancel):
            button.setEnabled(True)

    def checking(self) -> bool:
        return self._check is not None and self._check.isRunning()

    def done(self, result: int):
        check = self._check
        if check is not None and check.isRunning():
            check.wait(CHECK_WAIT_MS)                # the check's own timeout, so never for ever
        super().done(result)

    # -- saving -----------------------------------------------------------------
    def save(self):
        if self.key.text().strip():
            self.credentials.set(GEMINI, self.key.text())
        values = self.values()
        self.config.gemini_model = values["model"]
        self.config.gemini_aspect_ratio = values["aspect_ratio"]
        self.config.gemini_resolution = values["resolution"]
        self.config.gemini_duration_seconds = values["duration_seconds"]
        try:
            self.config.save(Path.cwd())
        except OSError as exc:
            log.warning("config.json could not be saved: %s", exc)
        self.accept()
