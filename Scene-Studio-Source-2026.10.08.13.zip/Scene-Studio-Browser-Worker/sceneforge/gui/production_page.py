"""The production screens: setting one up, watching it run, and the two
small libraries it draws on (frameworks, API keys).

None of this runs unless a person presses Start production. Opening a
production, importing a script, or launching the app never starts paid work.
"""
from __future__ import annotations

import threading
from pathlib import Path
from typing import Callable, Dict, List, Optional

from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QFrame,
    QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QListWidget, QMessageBox, QPlainTextEdit,
    QPushButton, QRadioButton, QScrollArea, QSpinBox, QDoubleSpinBox, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from ..config import Config
from ..logging_setup import get
from ..production.credentials import API_KEYS, Credentials
from ..production.omniflash import normalise_address
from ..production.frameworks import Frameworks
from ..production.omniflash import MODEL as OMNI_MODEL, OmniFlashGenerator
from ..production.manifest import (
    ORDER, ErrorPolicy, Production, PromptItem, ReviewMode, Stage, Status,
)
from ..production import prompts as prompt_text
from ..production.providers import (
    AnthropicPromptWriter, MockClipGenerator, MockPromptWriter, MockScriptWriter,
    OpenAIScriptWriter, ProviderError,
)
from ..production.runner import Event, Providers, Runner, UNCONFIRMED
from ..production import stages
from ..production.setup import make_providers
from ..production.screenplay import parse as parse_screenplay
from . import theme

log = get("production.page")

STAGE_TITLES = {Stage.SCRIPT: "Script", Stage.PROMPTS: "Scene prompts", Stage.CLIPS: "Clips",
                Stage.EDIT: "Editing", Stage.EXPORT: "Export"}
STATUS_WORDS = {"pending": "Not started", "running": "Running", "needs_review": "Needs your review",
                "approved": "Approved", "done": "Done", "failed": "Failed", "outdated": "Outdated",
                "skipped": "Skipped", "ready": "Ready", "waiting": "Waiting", "not in range": "Not in range"}
PROVIDER_LABELS = {"openai": "OpenAI (script writing)", "anthropic": "Anthropic (scene prompts)",
                   "omniflash": "Omni Flash (video generation)"}


def _section(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("sectionTitle")
    return label


def _hint(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("hint")
    label.setWordWrap(True)
    return label


# ---------------------------------------------------------------- API keys
class _QuotaCheck(QThread):
    """One usage request to Omni Flash, off the window's thread. Free: it
    generates nothing."""
    done = Signal(str)

    def __init__(self, generator, parent=None):
        super().__init__(parent)
        self.generator = generator

    def run(self):
        try:
            self.done.emit(self.generator.quota_text(timeout=15))
        except ProviderError as exc:
            self.done.emit(str(exc))
        except Exception as exc:                                       # noqa: BLE001 - shown, never raised
            self.done.emit("Omni Flash could not be checked: {}".format(type(exc).__name__))


class CredentialsDialog(QDialog):
    def __init__(self, credentials: Credentials, parent=None, config: Optional[Config] = None):
        super().__init__(parent)
        self.credentials = credentials
        self.config = config
        self._check: Optional[_QuotaCheck] = None
        self.setWindowTitle("API keys")
        self.setMinimumWidth(560)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)
        outer.addWidget(_section("API keys"))
        outer.addWidget(_hint("Each key is sealed to your Windows account before it is saved; it is never "
                              "written in plain text or logged. Only the providers your starting point "
                              "needs are required. Editing existing clips needs none of them."))
        self.fields: Dict[str, QLineEdit] = {}
        form = QFormLayout()
        form.setSpacing(8)
        for provider in API_KEYS:                # never the mail password: masked() would show most of it
            row = QHBoxLayout()
            field = QLineEdit()
            field.setEchoMode(QLineEdit.Password)
            current = credentials.get(provider)
            field.setPlaceholderText("saved: " + Credentials.masked(current) if current else "not set")
            remove = QPushButton("Remove")
            remove.setObjectName("quiet")
            remove.clicked.connect(lambda _=False, p=provider: self._remove(p))
            row.addWidget(field, 1)
            row.addWidget(remove)
            form.addRow(PROVIDER_LABELS[provider], row)
            self.fields[provider] = field
        # Omni Flash's document leaves its base URL blank, so the address is
        # a setting beside the key. Not a secret: it is kept in config.json.
        self.address = QLineEdit(normalise_address(str(getattr(config, "omniflash_base_url", "") or "")))
        self.address.setPlaceholderText("https://…  where the Generation API runs")
        self.btn_check = QPushButton("Check Omni Flash")
        self.btn_check.setObjectName("quiet")
        self.btn_check.setToolTip("Asks Omni Flash for today's quota. Generates nothing.")
        self.btn_check.clicked.connect(self._check_omniflash)
        address_row = QHBoxLayout()
        address_row.addWidget(self.address, 1)
        address_row.addWidget(self.btn_check)
        form.addRow("Omni Flash address", address_row)
        outer.addLayout(form)
        self.check_result = _hint("")
        outer.addWidget(self.check_result)
        outer.addWidget(_hint("OpenAI and Anthropic access is separate from a chat subscription and is billed "
                              "per use. An Omni Flash key has daily limits set by whoever issued it rather "
                              "than a per-clip price; Check Omni Flash shows today's."))
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_save = QPushButton("Save")
        self.btn_save.setObjectName("primary")
        self.btn_save.clicked.connect(self._save)
        buttons.addWidget(self.btn_cancel)
        buttons.addWidget(self.btn_save)
        outer.addLayout(buttons)

    def _check_omniflash(self):
        key = self.fields["omniflash"].text().strip() or self.credentials.get("omniflash")
        address = self.address.text().strip()
        if not key or not address:
            self.check_result.setText("Enter the Omni Flash key and its address first.")
            return
        for button in (self.btn_check, self.btn_save, self.btn_cancel):
            button.setEnabled(False)
        self.check_result.setText("Checking…")
        self._check = _QuotaCheck(OmniFlashGenerator(key, base_url=address), self)
        self._check.done.connect(self._checked)
        self._check.start()

    def _checked(self, text: str):
        self.check_result.setText(text)
        for button in (self.btn_check, self.btn_save, self.btn_cancel):
            button.setEnabled(True)

    def done(self, result: int):
        check = self._check
        if check is not None and check.isRunning():
            check.wait(16000)                         # the check's own timeout, so never for ever
        super().done(result)

    def _remove(self, provider: str):
        self.credentials.delete(provider)
        self.fields[provider].setPlaceholderText("not set")
        self.fields[provider].clear()

    def _save(self):
        for provider, field in self.fields.items():
            if field.text().strip():
                self.credentials.set(provider, field.text())
        if self.config is not None:
            # "omniflows.tech" typed plain is saved as https://omniflows.tech
            address = normalise_address(self.address.text())
            if address != str(getattr(self.config, "omniflash_base_url", "") or ""):
                self.config.omniflash_base_url = address
                try:
                    self.config.save(Path.cwd())
                except OSError as exc:
                    log.warning("config.json could not be saved: %s", exc)
        self.accept()


# ------------------------------------------------------------- frameworks
class FrameworkLibraryDialog(QDialog):
    def __init__(self, frameworks: Frameworks, parent=None):
        super().__init__(parent)
        self.frameworks = frameworks
        self.setWindowTitle("Framework library")
        self.setMinimumSize(760, 560)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 20)
        outer.setSpacing(10)
        outer.addWidget(_section("Framework library"))
        outer.addWidget(_hint("Your instructions to the models: the scriptwriting framework (OpenAI), the "
                              "scene-prompt framework (Claude), and shared continuity notes. Every save is a "
                              "new version; a production records the exact version it used, so editing a "
                              "framework later never silently changes an existing job."))
        body = QHBoxLayout()
        self.list = QListWidget()
        self.list.setMaximumWidth(240)
        self.list.currentTextChanged.connect(self._load)
        body.addWidget(self.list)
        right = QVBoxLayout()
        form = QFormLayout()
        self.name = QLineEdit()
        self.kind = QComboBox()
        self.kind.addItem("Scriptwriting (OpenAI)", "script")
        self.kind.addItem("Scene prompts (Claude)", "prompt")
        self.kind.addItem("Hook writer (OpenAI, before the script)", "hook")
        self.kind.addItem("Continuity / style", "continuity")
        form.addRow("Name", self.name)
        form.addRow("Used for", self.kind)
        right.addLayout(form)
        self.text = QPlainTextEdit()
        self.text.setPlaceholderText("Paste the framework here, or import a file.")
        right.addWidget(self.text, 1)
        self.versions = QLabel("")
        self.versions.setObjectName("hint")
        right.addWidget(self.versions)
        row = QHBoxLayout()
        import_btn = QPushButton("Import file…")
        import_btn.clicked.connect(self._import)
        save = QPushButton("Save as new version")
        save.setObjectName("primary")
        save.clicked.connect(self._save)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row.addWidget(import_btn)
        row.addStretch(1)
        row.addWidget(save)
        row.addWidget(close)
        right.addLayout(row)
        body.addLayout(right, 1)
        outer.addLayout(body, 1)
        self._refresh()

    def _refresh(self):
        current = self.list.currentItem().text() if self.list.currentItem() else ""
        self.list.clear()
        for name in self.frameworks.names():
            self.list.addItem(name)
        if current:
            matches = self.list.findItems(current, Qt.MatchExactly)
            if matches:
                self.list.setCurrentItem(matches[0])

    def _load(self, name: str):
        if not name:
            return
        ref = self.frameworks.latest(name)
        if ref is None:
            return
        self.name.setText(name)
        kind = next((e.get("kind") for n, e in self.frameworks._index().items() if n == name), "script")
        self.kind.setCurrentIndex(max(0, self.kind.findData(kind)))
        self.text.setPlainText(self.frameworks.text(ref))
        versions = self.frameworks.versions(name)
        self.versions.setText("{} version{}; latest v{} saved {} ({} words)".format(
            len(versions), "" if len(versions) == 1 else "s", ref.version,
            versions[-1]["saved"][:16].replace("T", " "), versions[-1]["words"]))

    def _import(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import a framework", "", "Text (*.txt *.md);;All files (*)")
        if path:
            self.text.setPlainText(Path(path).read_text(encoding="utf-8", errors="replace"))
            if not self.name.text().strip():
                self.name.setText(Path(path).stem)

    def _save(self):
        name = self.name.text().strip()
        if not name or not self.text.toPlainText().strip():
            QMessageBox.information(self, "Framework library", "Give it a name and some text first.")
            return
        ref = self.frameworks.save(name, self.kind.currentData(), self.text.toPlainText())
        self._refresh()
        self.versions.setText("Saved as v{}.".format(ref.version))


# ------------------------------------------------------------------ setup
# The setup dialog lives in production_wizard.py as six steps; it is
# re-exported here so callers and tests keep one import.
from .production_wizard import ProductionSetupDialog  # noqa: E402,F401


# -------------------------------------------------------------- dashboard
class _RunnerThread(QThread):
    event = Signal(object)
    finished_stage = Signal(object)          # Stage or None
    failed = Signal(str)

    def __init__(self, runner: Runner, episode: int, parent=None, work: Optional[Callable] = None):
        super().__init__(parent)
        self.runner = runner
        self.episode = episode
        self.work = work or (lambda: runner.run(episode))

    def run(self):
        try:
            stopped = self.work()
        except Exception as exc:                                   # noqa: BLE001
            log.exception("production run crashed")
            self.failed.emit(str(exc))
            return
        self.finished_stage.emit(stopped)


# Which provider each stage needs; nothing else is asked for.
STAGE_PROVIDERS = {Stage.SCRIPT: ("openai", "script_writer"), Stage.PROMPTS: ("anthropic", "prompt_writer"),
                   Stage.CLIPS: ("omniflash", "clip_generator")}


def _shorten(text: str, width: int = 90) -> str:
    flat = " ".join(text.split())
    return flat if len(flat) <= width else flat[:width - 1] + "…"


def _item_status(item: PromptItem) -> str:
    if item.validated:
        return "Ready" + (" (take {})".format(len(item.takes) + 1) if item.takes else "")
    if item.job_status == UNCONFIRMED:
        return "Unconfirmed: no job id"
    if item.job_id:
        return "Submitted ({})".format(item.job_status or "waiting")
    if item.error:
        return "Failed"
    return "Not generated"


class ProductionDashboard(QWidget):
    """Script → Scene prompts → Clips → Editing → Export, with what each is
    doing, what went wrong, and the one thing to do next."""

    back_requested = Signal()
    open_in_editor = Signal(str)           # a clips folder to open in the editor
    new_production_requested = Signal(object)   # Stage: Run from here pressed with no production open

    def __init__(self, config: Config, frameworks: Frameworks, credentials: Credentials, parent=None):
        super().__init__(parent)
        self.config = config
        self.frameworks = frameworks
        self.credentials = credentials
        self.production: Optional[Production] = None
        self.runner: Optional[Runner] = None
        self.thread: Optional[_RunnerThread] = None
        self.stop_event = threading.Event()
        self.episode_number = 1
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(theme.SPACE_2, theme.SPACE_1, theme.SPACE_2, theme.SPACE_1)
        outer.setSpacing(theme.SPACE_1)

        bar = QHBoxLayout()
        back = QPushButton("‹ Editor")
        back.clicked.connect(self.back_requested.emit)
        self.heading = QLabel("No production open")
        self.heading.setObjectName("title")
        self.episode_pick = QComboBox()
        self.episode_pick.currentIndexChanged.connect(self._pick_episode)
        bar.addWidget(back)
        bar.addSpacing(theme.SPACE_2)
        bar.addWidget(self.heading, 1)
        bar.addWidget(QLabel("Episode"))
        bar.addWidget(self.episode_pick)
        outer.addLayout(bar)

        self.summary = _hint("")
        outer.addWidget(self.summary)
        self.range_label = QLabel("")
        self.range_label.setObjectName("stepLabel")
        self.range_label.setWordWrap(True)
        outer.addWidget(self.range_label)

        grid = QGridLayout()
        grid.setSpacing(theme.SPACE_1)
        self.cards: Dict[Stage, Dict[str, QLabel]] = {}
        for column, stage in enumerate(ORDER):
            card = QFrame()
            card.setObjectName("card")
            box = QVBoxLayout(card)
            box.setContentsMargins(12, 10, 12, 10)
            box.setSpacing(4)
            title = QLabel("{}. {}".format(column + 1, STAGE_TITLES[stage]))
            title.setObjectName("sectionTitle")
            status = QLabel("Not started")
            status.setObjectName("stateBadge")
            activity = QLabel("")
            activity.setObjectName("hint")
            activity.setWordWrap(True)
            error = QLabel("")
            error.setObjectName("hint")
            error.setWordWrap(True)
            error.setStyleSheet("color: {};".format(theme.DANGER))
            run_here = QPushButton("▶ Run from here")
            run_here.setObjectName("quiet")
            run_here.setToolTip("Start at {} and continue automatically to the end of the range. Earlier stages "
                                "are skipped (their material must already exist); a later stage that already "
                                "ran is marked outdated and redone.".format(STAGE_TITLES[stage]))
            run_here.clicked.connect(lambda _c=False, s=stage: self.start_from(s))
            box.addWidget(title)
            box.addWidget(status)
            box.addWidget(activity)
            box.addWidget(error)
            box.addStretch(1)
            box.addWidget(run_here)
            grid.addWidget(card, 0, column)
            self.cards[stage] = {"status": status, "activity": activity, "error": error, "run": run_here}
        outer.addLayout(grid)

        self.next_action = QLabel("")
        self.next_action.setObjectName("readyBanner")
        self.next_action.setWordWrap(True)
        outer.addWidget(self.next_action)

        actions = QHBoxLayout()
        self.btn_start = QPushButton("Run this stage only")
        self.btn_start.setObjectName("primary")
        self.btn_start.setToolTip("Runs the current stage and stops, whatever the review setting. "
                                  "Starting the clips stage sends paid requests to the video provider.")
        self.btn_start.clicked.connect(self.start_stage)
        self.btn_continue = QPushButton("Continue automatically")
        self.btn_continue.setObjectName("primary")
        self.btn_continue.setToolTip("Runs from the current stage until the next review point, a failure, or the end.")
        self.btn_continue.clicked.connect(self.start)
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.clicked.connect(self.stop_run)
        self.btn_approve = QPushButton("Approve this stage")
        self.btn_approve.setObjectName("actApprove")
        self.btn_approve.clicked.connect(self.approve)
        self.btn_regen = QPushButton("Regenerate this stage")
        self.btn_regen.clicked.connect(self.regenerate)
        self.btn_open = QPushButton("Open the clips in the editor")
        self.btn_open.clicked.connect(self._open_editor)
        self.btn_files = QPushButton("Open working folder")
        self.btn_files.setObjectName("quiet")
        self.btn_files.clicked.connect(self._open_folder)
        for button in (self.btn_start, self.btn_continue, self.btn_stop, self.btn_approve, self.btn_regen,
                       self.btn_open, self.btn_files):
            actions.addWidget(button)
        actions.addStretch(1)
        outer.addLayout(actions)

        # -- the scenes: one row per clip, chosen by checkbox -----------------
        outer.addWidget(_section("Scenes"))
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["", "#", "Scene", "Prompt", "Status", "File", "Error"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        header.setSectionResizeMode(6, QHeaderView.Stretch)
        outer.addWidget(self.table, 2)
        scene_actions = QHBoxLayout()
        self.btn_all = QPushButton("Select all")
        self.btn_all.setObjectName("quiet")
        self.btn_all.clicked.connect(lambda: self._select(True))
        self.btn_none = QPushButton("Select none")
        self.btn_none.setObjectName("quiet")
        self.btn_none.clicked.connect(lambda: self._select(False))
        self.btn_gen_selected = QPushButton("Generate selected")
        self.btn_gen_selected.setToolTip("Asks the video provider for the ticked scenes that have no valid clip yet.")
        self.btn_gen_selected.clicked.connect(lambda: self._generate(self.selected_keys(), new_take=False))
        self.btn_gen_missing = QPushButton("Generate missing")
        self.btn_gen_missing.setToolTip("Asks for every scene without a valid clip. Existing clips are kept.")
        self.btn_gen_missing.clicked.connect(lambda: self._generate(self.missing_keys(), new_take=False))
        self.btn_retake = QPushButton("Regenerate selected (new take)")
        self.btn_retake.setToolTip("Asks again for the ticked scenes. The previous clip is kept in the takes folder.")
        self.btn_retake.clicked.connect(lambda: self._generate(self.selected_keys(), new_take=True))
        for button in (self.btn_all, self.btn_none, self.btn_gen_selected, self.btn_gen_missing, self.btn_retake):
            scene_actions.addWidget(button)
        scene_actions.addStretch(1)
        outer.addLayout(scene_actions)

        self.log = QListWidget()
        self.log.setObjectName("recentList")
        outer.addWidget(self.log, 1)
        self._refresh()

    # -- the scene table ------------------------------------------------------
    def _items(self) -> List[PromptItem]:
        if not self.production:
            return []
        episode = self.production.episode(self.episode_number)
        return sorted(episode.prompt_set.items if episode.prompt_set else [], key=lambda i: i.sequence)

    def _fill_table(self):
        items = self._items()
        keep = self.selected_keys() if self.table.rowCount() == len(items) else set()
        self.table.setRowCount(len(items))
        for row, item in enumerate(items):
            tick = QTableWidgetItem()
            tick.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            tick.setCheckState(Qt.Checked if item.key in keep else Qt.Unchecked)
            tick.setData(Qt.UserRole, item.key)
            cells = [tick, QTableWidgetItem(str(item.sequence)), QTableWidgetItem(item.key),
                     QTableWidgetItem(_shorten(item.prompt)), QTableWidgetItem(_item_status(item)),
                     QTableWidgetItem(Path(item.path).name if item.path else ""),
                     QTableWidgetItem(_shorten(item.error, 120) if not item.validated else "")]
            cells[3].setToolTip(item.prompt)
            for column, cell in enumerate(cells):
                self.table.setItem(row, column, cell)

    def _select(self, on: bool):
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(Qt.Checked if on else Qt.Unchecked)

    def selected_keys(self) -> set:
        keys = set()
        for row in range(self.table.rowCount()):
            cell = self.table.item(row, 0)
            if cell is not None and cell.checkState() == Qt.Checked:
                keys.add(cell.data(Qt.UserRole))
        return keys

    def missing_keys(self) -> set:
        """Every clip that is not valid, except one whose submission got no
        job id: that one waits to be chosen by hand."""
        return {i.key for i in self._items() if not i.validated and i.job_status != UNCONFIRMED}

    # -- loading ----------------------------------------------------------
    def clear(self):
        """No production open. Only the screen and this object forget it;
        the manifest on disk is untouched and Open production finds it."""
        if self.thread is not None and self.thread.isRunning():
            return                              # a run owns the screen until it stops
        self.production = None
        self.runner = None
        self.episode_number = 1
        self.episode_pick.blockSignals(True)
        self.episode_pick.clear()
        self.episode_pick.blockSignals(False)
        self.log.clear()
        self.summary.setText("")
        self.range_label.setText("")
        for stage in ORDER:
            card = self.cards[stage]
            card["run"].setEnabled(False)
            card["status"].setText("Not started")
            card["status"].setProperty("state", "pending")
            card["status"].style().unpolish(card["status"])
            card["status"].style().polish(card["status"])
            card["activity"].setText("")
            card["error"].setText("")
        self._refresh()

    def load(self, production: Production):
        from .open_production import remember_production
        self.production = production
        remember_production(self.config, production.working_dir, Path.cwd())
        self.episode_pick.blockSignals(True)
        self.episode_pick.clear()
        for episode in production.episodes:
            self.episode_pick.addItem("{}".format(episode.number), episode.number)
        self.episode_pick.blockSignals(False)
        self.episode_number = production.episodes[0].number
        self.log.clear()
        self._refresh()

    def _pick_episode(self, index: int):
        if index >= 0 and self.production:
            self.episode_number = self.episode_pick.itemData(index)
            self._refresh()

    # -- providers ----------------------------------------------------------
    def _providers(self) -> Providers:
        settings = self.production.generation_settings if self.production else {}
        return make_providers(self.credentials, self.config, bool(settings.get("mock")))

    def missing_providers(self, first: Stage, until: Optional[Stage] = None) -> List[str]:
        """The keys the stages from `first` to `until` need and do not have;
        stages that will not run ask for nothing."""
        if self.production and self.production.generation_settings.get("mock"):
            return []
        providers = self._providers()
        if until is None and self.production:
            until = Stage(self.production.end_stage)
        wanted = ORDER[ORDER.index(first):(ORDER.index(until) + 1 if until else len(ORDER))]
        missing = []
        for stage in wanted:
            if stage in STAGE_PROVIDERS and getattr(providers, STAGE_PROVIDERS[stage][1]) is None:
                missing.append(PROVIDER_LABELS[STAGE_PROVIDERS[stage][0]])
        return missing

    # -- running ------------------------------------------------------------
    def start_stage(self):
        """Run this stage only: the runner stops after it whatever the review mode."""
        if self.production:
            self.start(until=self.production.episode(self.episode_number).next_stage())

    def start(self, until: Optional[Stage] = None):
        if not self.production or (self.thread and self.thread.isRunning()):
            return
        episode = self.production.episode(self.episode_number)
        stage = episode.next_stage()
        if stage is None:
            self._say("This episode is already exported.")
            return
        missing = self.missing_providers(stage, until)
        if missing:
            QMessageBox.information(self, "Start production", "Not set under Automate ▾ → API keys: " +
                                    ", ".join(missing) + ". Only the stages about to run are asked for.")
            return
        paid = stage == Stage.CLIPS and not self.production.generation_settings.get("mock")
        runner = self._runner()
        last = until or Stage(self.production.end_stage)
        text = "Start '{}' at {}{}?\n\nWill run: {}\nReview: {}\nIf a clip fails: {}\nEditing: {}\n".format(
            self.production.title, STAGE_TITLES[stage],
            " and stop after it" if until == stage else "",
            stages.range_text(stage, last), self.production.review_mode.replace("_", " "),
            self.production.error_policy, self.production.editing_mode)
        if stage == Stage.CLIPS:
            text += self._generation_text(runner.plan(self.episode_number), paid)
        if QMessageBox.question(self, "Start production", text, QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return
        self._launch(runner, lambda: runner.run(self.episode_number, until=until))

    def start_from(self, stage: Stage):
        """Run from `stage` to the end of the range. Stages before it are
        skipped (what they would have made must already exist); a later
        stage that already ran is marked outdated, since it will be redone.
        With no production open the button means "set one up starting
        here": the wizard opens at that stage."""
        if self.thread and self.thread.isRunning():
            return
        if not self.production:
            self.new_production_requested.emit(stage)
            return
        episode = self.production.episode(self.episode_number)
        end = Stage(self.production.end_stage)
        if ORDER.index(end) < ORDER.index(stage):
            end = Stage.EXPORT
        problems = stages.validate_range(self.production, episode, stage, end, self.credentials)
        if problems:
            lines = ["{}: {}".format(STAGE_TITLES[Stage(k)], "; ".join(v)) for k, v in problems.items()]
            QMessageBox.information(self, "Run from " + STAGE_TITLES[stage],
                                    "Not ready to run from {}:\n• {}".format(STAGE_TITLES[stage], "\n• ".join(lines)))
            return
        state = episode.stage(stage)
        redo = state.status in (Status.DONE.value, Status.APPROVED.value, Status.FAILED.value,
                                Status.NEEDS_REVIEW.value, Status.OUTDATED.value)
        downstream = [s for s in ORDER[ORDER.index(stage) + 1:]
                      if episode.stage(s).status not in (Status.PENDING.value, Status.SKIPPED.value)]
        text = "Run '{}' from {} to {}?\n\nWill run: {}".format(
            self.production.title, STAGE_TITLES[stage], STAGE_TITLES[end], stages.range_text(stage, end))
        if redo:
            text += "\n\n{} already ran; it will be done again.".format(STAGE_TITLES[stage])
        if downstream:
            text += "\n{} will be marked outdated and redone.".format(", ".join(STAGE_TITLES[s] for s in downstream))
        if stage == Stage.CLIPS and not self.production.generation_settings.get("mock"):
            text += "\n\nThe clips stage sends paid requests to the video provider."
        if QMessageBox.question(self, "Run from " + STAGE_TITLES[stage], text, QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return
        stages.prepare_range(self.production, episode, stage, end)
        if redo:
            state.set(Status.PENDING, next_action="", error="")
            episode.mark_outdated_after(stage)
            for later in ORDER[ORDER.index(stage) + 1:]:
                if episode.stage(later).status == Status.OUTDATED.value:
                    episode.stage(later).set(Status.PENDING, next_action="", error="")
        self.production.save()
        self._refresh()
        runner = self._runner()
        self._launch(runner, lambda: runner.run(self.episode_number, until=end))

    def _generate(self, keys, new_take: bool):
        """Clips for chosen scenes, by hand: a confirmation with the count,
        then the runner's generate() on its own thread."""
        if not self.production or (self.thread and self.thread.isRunning()):
            return
        keys = set(keys)
        if not keys:
            self._say("Tick the scenes first." if not new_take else "Tick the scenes to regenerate first.")
            return
        missing = self.missing_providers(Stage.CLIPS, Stage.CLIPS)
        if missing:
            QMessageBox.information(self, "Generate clips", "Not set under Automate ▾ → API keys: " + ", ".join(missing))
            return
        runner = self._runner()
        plan = runner.plan(self.episode_number, keys, new_take=new_take)
        if plan["problems"]:
            QMessageBox.information(self, "Generate clips", "Nothing was sent: " + "; ".join(plan["problems"]))
            return
        if not plan["submit"] and not plan["polling"]:
            self._say("The chosen scenes already have valid clips; use Regenerate selected (new take) to ask again.")
            return
        paid = not self.production.generation_settings.get("mock")
        text = ("Regenerate {} scene(s) as a new take? The previous clips are kept in the takes folder.\n\n"
                if new_take else "Generate clips for {} scene(s)?\n\n").format(len(keys))
        text += self._generation_text(plan, paid)
        if QMessageBox.question(self, "Generate clips", text, QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return
        self._launch(runner, lambda: runner.generate(self.episode_number, keys, new_take=new_take))

    @staticmethod
    def _generation_text(plan: Dict[str, object], paid: bool) -> str:
        cap = plan["cap"]
        quota = plan["quota"]
        lines = ["New submissions: {}".format(plan["submit"]),
                 "Clips reused (already valid): {}".format(plan["reused"])]
        if plan["polling"]:
            lines.append("Jobs already submitted, to be checked: {}".format(plan["polling"]))
        lines.append("Generation limit: {} ({} submitted so far)".format(cap or "none", plan["cap_used"]))
        lines.append("Provider {}: {}".format(
            plan.get("quota_label", "quota left today"),
            quota if quota is not None else "unknown (Automate ▾ → API keys → Check Omni Flash)"))
        if plan.get("price") is not None and paid:
            lines.append("Price the provider states: {:g} per video, so about {:g} for the {} new submission(s).".format(
                plan["price"], plan["price"] * plan["submit"], plan["submit"]))
        if paid and plan["submit"]:
            lines.append("These are paid requests to the video provider.")
        return "\n".join(lines)

    def _runner(self) -> Runner:
        self.stop_event.clear()
        return Runner(self.production, self._providers(), self.frameworks, self.config,
                      on_event=lambda e: None, stop=self.stop_event,
                      max_generations=int(self.production.generation_settings.get("max_generations") or 0))

    def _launch(self, runner: Runner, work: Callable):
        self.runner = runner
        self.thread = _RunnerThread(runner, self.episode_number, self, work=work)
        runner.on_event = self.thread.event.emit
        self.thread.event.connect(self._on_event)
        self.thread.finished_stage.connect(self._on_finished)
        self.thread.failed.connect(lambda m: self._say("Crashed: " + m))
        self.thread.start()
        self._refresh()

    def stop_run(self):
        self.stop_event.set()
        self._say("Stopping after the current step…")

    def approve(self):
        if not self.production:
            return
        episode = self.production.episode(self.episode_number)
        stage = episode.waiting_for_person()
        if stage is None:
            self._say("Nothing is waiting for review.")
            return
        runner = self.runner or Runner(self.production, self._providers(), self.frameworks, self.config)
        runner.approve(self.episode_number, stage, self.config.editor_name or "editor")
        self._say("{} approved by {}.".format(STAGE_TITLES[stage], self.config.editor_name or "editor"))
        self._refresh()

    def regenerate(self):
        if not self.production:
            return
        episode = self.production.episode(self.episode_number)
        stage = episode.waiting_for_person() or episode.next_stage()
        if stage is None:
            return
        if stage == Stage.CLIPS:
            QMessageBox.information(self, "Regenerate", "Clips are regenerated by scene, never all at once: tick "
                                    "the scenes in the table and press Regenerate selected (new take). Paid "
                                    "work is never repeated automatically.")
            return
        episode.stage(stage).set(Status.PENDING, next_action="", error="")
        for later in ORDER[ORDER.index(stage) + 1:]:
            if episode.stage(later).status not in (Status.PENDING.value, Status.SKIPPED.value):
                episode.stage(later).set(Status.OUTDATED)
        self.production.save()
        self._say("{} will be regenerated on the next Start production.".format(STAGE_TITLES[stage]))
        self._refresh()

    # -- events -------------------------------------------------------------
    def _on_event(self, event: Event):
        self._say("[{}] {}".format(STAGE_TITLES[Stage(event.stage)], event.message))
        self._refresh()

    def _on_finished(self, stopped):
        self._refresh()
        if stopped is None:
            self._say("Episode exported.")

    def _say(self, text: str):
        self.log.addItem(text)
        self.log.scrollToBottom()

    def _refresh(self):
        running = bool(self.thread and self.thread.isRunning())
        has = self.production is not None
        self.btn_start.setEnabled(has and not running)
        self.btn_continue.setEnabled(has and not running)
        self.btn_stop.setEnabled(running)
        self.btn_regen.setEnabled(has and not running)
        self._fill_table()
        can_generate = has and not running and bool(self._items())
        for button in (self.btn_gen_selected, self.btn_gen_missing, self.btn_retake):
            button.setEnabled(can_generate)
        if not has:
            self.heading.setText("No production open")
            self.next_action.setText("No production open. Press Run from here on the stage you have material "
                                     "for (for example Editing, if you have the clips) and the setup opens at "
                                     "that stage; or Automate ▾ → New automated production… / Open production….")
            self.btn_approve.setEnabled(False)
            self.btn_open.setEnabled(False)
            for stage in ORDER:
                self.cards[stage]["run"].setEnabled(True)
            return
        episode = self.production.episode(self.episode_number)
        self.heading.setText("{}  ·  {}".format(self.production.title, episode.name))
        self.summary.setText("Review: {}   ·   editing: {}   ·   if a clip fails: {}   ·   {} {}p   ·   spent (as reported): {:.2f}   ·   working folder: {}".format(
            self.production.review_mode.replace("_", " "), self.production.editing_mode, self.production.error_policy,
            "follow the clips" if self.production.aspect_ratio == "auto" else self.production.aspect_ratio,
            self.production.resolution, self.production.spent_reported, self.production.working_dir))
        self.range_label.setText("Automation range:  " + stages.range_text(self.production.start_stage,
                                                                          self.production.end_stage))
        words = episode.stage_words(self.production.start_stage, self.production.end_stage)
        for stage in ORDER:
            state = episode.stage(stage)
            card = self.cards[stage]
            word = words.get(stage.value, state.status)
            card["status"].setText(STATUS_WORDS.get(word, word))
            card["status"].setProperty("state", {"done": "approved", "approved": "approved", "failed": "rejected",
                                                 "needs_review": "pending", "ready": "approved"}.get(word, "pending"))
            card["run"].setEnabled(not running)
            card["status"].style().unpolish(card["status"])
            card["status"].style().polish(card["status"])
            card["activity"].setText(state.next_action if state.status != "failed" else "")
            card["error"].setText(state.error if state.status == "failed" else "")
        waiting = episode.waiting_for_person()
        failed = next((s for s in ORDER if episode.stage(s).status == Status.FAILED.value), None)
        nxt = episode.next_stage()
        if running:
            text, state = "Running. You can stop after the current step.", "work"
        elif waiting:
            text, state = "{} needs your review: {}".format(STAGE_TITLES[waiting], episode.stage(waiting).next_action), "work"
        elif failed:
            text, state = "{} failed: {}  {}".format(STAGE_TITLES[failed], episode.stage(failed).error,
                                                       episode.stage(failed).next_action), "work"
        elif nxt is None:
            text, state = "Exported: {}".format(Path(episode.exports[-1].path).name if episode.exports else ""), "ready"
        else:
            text, state = "Next: {}. Run this stage only, or Continue automatically.".format(STAGE_TITLES[nxt]), "almost"
        self.next_action.setText(text)
        self.next_action.setProperty("state", state)
        self.next_action.style().unpolish(self.next_action)
        self.next_action.style().polish(self.next_action)
        self.btn_approve.setEnabled(bool(waiting) and not running)
        self.btn_open.setEnabled(bool(episode.clips_dir) and Path(episode.clips_dir).is_dir())

    def _open_editor(self):
        if self.production:
            self.open_in_editor.emit(self.production.episode(self.episode_number).clips_dir)

    def _open_folder(self):
        import os
        if self.production:
            try:
                os.startfile(self.production.working_dir)            # noqa: S606
            except OSError:
                pass
