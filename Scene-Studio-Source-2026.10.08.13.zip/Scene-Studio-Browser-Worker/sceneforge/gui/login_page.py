"""Login screen (for whichever product this is: sceneforge/product.py).

Shown in a compact, portrait, fixed-size window -- the way most desktop
software greets you -- rather than filling the screen. The main window grows
to its working size only once someone is signed in.
"""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QCheckBox, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout,
    QWidget,
)

from .. import teamsheet
from ..auth import MAX_ATTEMPTS, User, UserStore
from ..logging_setup import get
from ..product import PRODUCT
from .branding import COMPANY, COPYRIGHT, TAGLINE, logo_pixmap

VERSION = PRODUCT.version

log = get("login")

# Long enough to make repeated guessing tedious, short enough that a genuine
# mistyped password does not lock somebody out of their afternoon.
LOCKOUT_SECONDS = 30

# Client-area size of the login window. Roughly portrait, comfortably inside
# a 1366x768 laptop screen once the title bar is added.
LOGIN_WIDTH = 440
LOGIN_HEIGHT = 680


class LoginPage(QWidget):
    logged_in = Signal(object)          # User

    def __init__(self, store: UserStore, parent=None):
        super().__init__(parent)
        self.store = store
        self._attempts = 0
        self._locked_until = 0
        self.setObjectName("loginRoot")
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(34, 30, 34, 18)
        outer.setSpacing(0)
        outer.addStretch(2)

        logo = logo_pixmap(86)
        if logo is not None:
            mark = QLabel()
            mark.setPixmap(logo)
            outer.addWidget(mark, 0, Qt.AlignHCenter)
        else:
            name = QLabel(COMPANY)
            name.setObjectName("bigTitle")
            outer.addWidget(name, 0, Qt.AlignHCenter)

        tagline = QLabel(TAGLINE)
        tagline.setObjectName("subtitle")
        tagline.setAlignment(Qt.AlignHCenter)
        tagline.setWordWrap(True)
        outer.addWidget(tagline)
        outer.addSpacing(26)

        card = QFrame()
        card.setObjectName("card")
        box = QVBoxLayout(card)
        box.setContentsMargins(26, 24, 26, 24)
        box.setSpacing(12)

        heading = QLabel("Sign in")
        heading.setObjectName("loginHeading")
        box.addWidget(heading)

        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")
        self.username.setMinimumHeight(40)
        self.username.returnPressed.connect(self._focus_password)

        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setMinimumHeight(40)
        self.password.returnPressed.connect(self.attempt)

        # Typing a password blind is the commonest cause of a wrong one
        self.show_password = QPushButton("Show")
        self.show_password.setObjectName("linkButton")
        self.show_password.setCheckable(True)
        self.show_password.setFixedWidth(58)
        self.show_password.toggled.connect(self._toggle_echo)

        password_row = QHBoxLayout()
        password_row.setSpacing(8)
        password_row.addWidget(self.password, 1)
        password_row.addWidget(self.show_password)

        box.addWidget(self.username)
        box.addLayout(password_row)

        # Two separate promises, because editors read them as two things:
        # the fields filled in next time, and not being asked at all.
        self.remember_details = QCheckBox("Remember my login details on this computer")
        self.remember_details.setToolTip(
            "Fill in the username and password next time. The password is sealed to "
            "your Windows account and never stored in plain text. Untick to remove them.")
        self.remember = QCheckBox("Keep me signed in on this computer")
        self.remember.setChecked(True)
        self.remember.setToolTip("Open straight into the editor next time without asking. "
                                 "Sign out to stop.")
        box.addWidget(self.remember_details)
        box.addWidget(self.remember)
        self.btn_forget = QPushButton("Forget saved login details")
        self.btn_forget.setObjectName("linkButton")
        self.btn_forget.setToolTip("Remove the username and password saved on this computer.")
        self.btn_forget.clicked.connect(self.forget_saved)
        self.btn_forget.setVisible(False)
        box.addWidget(self.btn_forget, 0, Qt.AlignLeft)
        self.username.textEdited.connect(self._on_username_edited)
        self._saved_username = ""

        self.message = QLabel("")
        self.message.setObjectName("loginMessage")
        self.message.setWordWrap(True)
        self.message.setMinimumHeight(34)
        self.message.setAlignment(Qt.AlignTop)
        box.addWidget(self.message)

        self.btn_login = QPushButton("Sign in")
        self.btn_login.setObjectName("primary")
        self.btn_login.setMinimumHeight(42)
        self.btn_login.clicked.connect(self.attempt)
        box.addWidget(self.btn_login)

        outer.addWidget(card)
        outer.addStretch(3)

        footer = QHBoxLayout()
        version = QLabel("Version " + VERSION)
        version.setObjectName("version")
        credit = QLabel(COPYRIGHT)
        credit.setObjectName("copyright")
        footer.addWidget(version)
        footer.addStretch(1)
        footer.addWidget(credit)
        outer.addLayout(footer)

        self._countdown = QTimer(self)
        self._countdown.setInterval(1000)
        self._countdown.timeout.connect(self._tick)

        if self.store.is_empty:
            self._say("No accounts exist on this machine yet. Run "
                      "9sigma-cli.bat user add <name> to create one.", bad=True)
            self.btn_login.setEnabled(False)
        self.load_saved()

    # ----------------------------------------------------------------- helpers
    def _focus_password(self):
        self.password.setFocus()

    def _toggle_echo(self, shown: bool):
        self.password.setEchoMode(QLineEdit.Normal if shown else QLineEdit.Password)
        self.show_password.setText("Hide" if shown else "Show")

    def _say(self, text: str, bad: bool = False):
        self.message.setText(text)
        self.message.setProperty("bad", bad)
        self.message.style().unpolish(self.message)
        self.message.style().polish(self.message)

    def focus_first_field(self):
        (self.password if self.username.text().strip() else self.username).setFocus()

    # ------------------------------------------------------ saved details
    def load_saved(self):
        """Fill the fields from the details kept on this computer, if any.
        Called at start-up and again after every sign-out, so signing out
        never empties what the person asked to keep. The password comes
        back masked; Show/Hide works on it like on a typed one."""
        saved = self.store.saved_login()
        self._saved_username = saved["username"] if saved else ""
        self.remember_details.setChecked(saved is not None)
        self.btn_forget.setVisible(saved is not None)
        if saved is None:
            return
        self.username.setText(saved["username"])
        self.password.setText(saved["password"])
        self.show_password.setChecked(False)

    def forget_saved(self):
        self.store.forget_login()
        self._saved_username = ""
        self.username.clear()
        self.password.clear()
        self.remember_details.setChecked(False)
        self.btn_forget.setVisible(False)
        self._say("Saved login details removed from this computer.")
        self.username.setFocus()

    def _on_username_edited(self, text: str):
        """A different account than the saved one must not inherit the
        saved password: the moment the username no longer matches, the
        password field is emptied."""
        if self._saved_username and text.strip().lower() != self._saved_username.lower():
            self.password.clear()

    # ------------------------------------------------------------------ login
    def attempt(self):
        if self._locked_until:
            return
        username = self.username.text().strip()
        password = self.password.text()
        if not username or not password:
            self._say("Enter your username and password.", bad=True)
            return

        self.btn_login.setEnabled(False)
        self.btn_login.setText("Checking...")
        # Hashing deliberately takes a moment; let the label repaint first
        QTimer.singleShot(30, lambda: self._check(username, password))

    def _check(self, username: str, password: str):
        user: Optional[User] = self.store.verify(username, password)
        if user is not None:
            # The right password is not enough: an editor account works on
            # one laptop only, the one the team sheet has on record.
            allowed, message, recheck = teamsheet.sign_in_gate(user.username, user.display_name, user.role)
            user.recheck_laptop = recheck         # the main window asks the sheet again, in the background
            if not allowed:
                self.btn_login.setEnabled(True)
                self.btn_login.setText("Sign in")
                self.password.clear()
                self._say(message, bad=True)
                return
        self.btn_login.setEnabled(True)
        self.btn_login.setText("Sign in")

        if user is not None:
            log.info("Signed in: %s", user.username)
            self._attempts = 0
            self._say("")
            # The details first, then the session: they are independent, and
            # a saved record is only ever replaced by a sign-in that worked,
            # so a typo for another account never overwrites the good one.
            if self.remember_details.isChecked():
                if not self.store.save_login(user.username, password):
                    log.info("Only the username could be remembered on this machine")
            else:
                self.store.forget_login()
            self.password.clear()
            if self.remember.isChecked():
                self.store.remember(user)
            else:
                self.store.forget()
            self.load_saved()
            self.logged_in.emit(user)
            return

        self._attempts += 1
        log.warning("Failed sign-in for %r (attempt %d)", username, self._attempts)
        self.password.clear()
        self.password.setFocus()

        if self._attempts >= MAX_ATTEMPTS:
            self._locked_until = LOCKOUT_SECONDS
            self.btn_login.setEnabled(False)
            self._countdown.start()
            self._tick()
        else:
            left = MAX_ATTEMPTS - self._attempts
            self._say("Wrong username or password. {} attempt{} left.".format(
                left, "" if left == 1 else "s"), bad=True)

    def _tick(self):
        if self._locked_until <= 0:
            self._countdown.stop()
            self._attempts = 0
            self.btn_login.setEnabled(True)
            self._say("You can try again now.")
            return
        self._say("Too many failed attempts. Try again in {} seconds.".format(
            self._locked_until), bad=True)
        self._locked_until -= 1
