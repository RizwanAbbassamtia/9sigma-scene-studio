"""The strip that appears above the page when a newer build is published.

One banner for the whole window, shown on every page except the login. It
runs the check and the download itself so the main window only has to call
`check(url)` (quiet, at sign-in and on a timer) or `check_now(url)` (from the
menu, always answers) and connect one signal for "installer is running,
please quit".

"Later" hides the banner for this session and writes the version to
update-state.json next to config.json, so the next launch shows it once
more; a periodic check never re-opens a banner that was put away.

While the app is busy (an export, a production run) the banner downloads but
does not install: `set_busy_provider` hands it a callable that returns the
reason ("exporting") or "" when free, and the banner waits, asks once, then
starts the installer.

`resume_pending()` at sign-in finishes what the last "Update now" started:
"Updated to 9.14" shown once when this build is the version that was
installed, or the downloaded installer offered again when it is not.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton, QSystemTrayIcon, QVBoxLayout,
)

from ..logging_setup import get
from ..updates import (
    Downloader, Release, UpdateCheck, clear_pending, installer_running, launch_installer, read_deferred,
    read_pending, write_deferred, write_pending,
)
from ..product import PRODUCT
from ..version import is_newer

VERSION = PRODUCT.version       # the running product's version

log = get("updates")

BUSY_POLL_MS = 2000
# After a check that could not reach any source: try again after these
# many seconds, then give up until the next scheduled check. A login on a
# flaky connection used to be one attempt and then an hour of silence.
RETRY_SECONDS = (60, 300, 900)


def _mb(n: int) -> str:
    return "{:.0f} MB".format(n / 1_000_000)


class UpdateBanner(QFrame):
    install_started = Signal()      # the installer is running; the app should quit
    status = Signal(str)            # one line for the status bar

    def __init__(self, parent=None, state_dir: Optional[Path] = None):
        super().__init__(parent)
        self.setObjectName("updateBanner")
        self.state_dir = Path(state_dir) if state_dir else Path.cwd()
        self.release: Optional[Release] = None
        self.ask_before_install = True
        self._downloader: Optional[Downloader] = None
        self._check: Optional[UpdateCheck] = None
        self._manual = False
        self._dismissed: set = set()        # versions Later was pressed on this session
        self._busy_provider: Callable[[], str] = lambda: ""
        self._downloaded: str = ""
        self._asked = False
        self._poll = QTimer(self)
        self._poll.setInterval(BUSY_POLL_MS)
        self._poll.timeout.connect(self._poll_busy)
        self._retry = QTimer(self)
        self._retry.setSingleShot(True)
        self._retry.timeout.connect(self._retry_check)
        self._retries = 0
        self._last_url = ""
        self._toasted: set = set()          # versions a desktop notification was shown for
        self._resumed_version = ""          # offered again from the pending record; keeps its wording
        self._installer_running = False     # the strip says "close and install"; no second installer
        self.tray: Optional[QSystemTrayIcon] = None
        self.last_result = ""               # one line: what the latest check found
        self._build()
        self.hide()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 10, 14, 10)
        outer.setSpacing(6)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.title = QLabel("")
        self.title.setObjectName("updateTitle")
        self.detail = QLabel("")
        self.detail.setWordWrap(True)
        self.btn_update = QPushButton("Update now")
        self.btn_update.setObjectName("primary")
        self.btn_update.clicked.connect(self._on_update_clicked)
        self.btn_later = QPushButton("Later")
        self.btn_later.setObjectName("quiet")
        self.btn_later.clicked.connect(self.defer)
        self.btn_close = QPushButton("OK")
        self.btn_close.setObjectName("quiet")
        self.btn_close.clicked.connect(self.hide)
        self.btn_close.setVisible(False)
        row.addWidget(self.title)
        row.addWidget(self.detail, 1)
        row.addWidget(self.btn_update)
        row.addWidget(self.btn_later)
        row.addWidget(self.btn_close)
        outer.addLayout(row)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setTextVisible(True)
        outer.addWidget(self.progress)

    # ----------------------------------------------------------------- hooks
    def set_busy_provider(self, provider: Optional[Callable[[], str]]):
        """`provider()` returns why the app must not be restarted right now
        ("exporting", "generating clips") or "" when it is free."""
        self._busy_provider = provider or (lambda: "")

    def deferred_version(self) -> str:
        """The version Later was last pressed on (kept across launches)."""
        return read_deferred(self.state_dir)

    # ----------------------------------------------------------------- check
    def check(self, manifest_url: str, manual: bool = False):
        """Read the manifest in the background. Quiet unless `manual`."""
        if self._check is not None and self._check.isRunning():
            return
        if not manifest_url:
            if manual:
                self._notice("Update checks are switched off in config.json.")
            return
        self._manual = manual
        self._last_url = manifest_url
        if manual:
            self._retry.stop()
            self._retries = 0
            self.status.emit("Checking for updates…")
        self._check = UpdateCheck(manifest_url, self)
        self._check.checked.connect(self._on_checked)
        self._check.found.connect(self._on_found)
        self._check.unreachable.connect(self._on_unreachable)
        self._check.start()

    def check_now(self, manifest_url: str):
        """The menu action: always answers, even when nothing is newer."""
        self.check(manifest_url, manual=True)

    def _on_unreachable(self, reason: str):
        self.last_result = "could not reach the update server: " + reason[:120]
        if self._manual:
            self._notice("Could not reach the update server ({}). You have version {}."
                         .format(reason, VERSION))
            return
        # Quiet check: try again soon, a bounded number of times, so a
        # dropped connection at sign-in does not cost an hour.
        if self._retries < len(RETRY_SECONDS) and self._last_url:
            delay = RETRY_SECONDS[self._retries]
            self._retries += 1
            log.info("Update check failed (%s); trying again in %d s", reason[:80], delay)
            self._retry.start(delay * 1000)

    def _retry_check(self):
        if self._last_url:
            self.check(self._last_url, manual=False)

    def _on_checked(self, release: Optional[Release]):
        if release is not None:
            self._retries = 0
            self._retry.stop()
            self.last_result = ("version {} is published; you have {}".format(release.version, VERSION)
                                if release.is_newer else "you have the newest version ({})".format(VERSION))
        if release is None or not self._manual:
            return
        if not release.is_newer:
            self._notice("You have the newest version ({}).".format(VERSION))
        elif not release.is_compatible:
            self._notice("Version {} is published but needs {} or newer installed first; "
                         "you have {}.".format(release.version, release.min_version, VERSION))

    def _on_found(self, release: Release):
        self.status.emit("Version {} is available.".format(release.version))
        self.offer(release, force=self._manual)
        self._toast(release)

    def set_tray(self, tray: Optional[QSystemTrayIcon]):
        """The desktop notification goes through the app's tray icon; without
        one (or with OS notifications off) the in-app strip still shows."""
        self.tray = tray

    def _toast(self, release: Release):
        """One Windows notification per version per run; Later'd versions
        are not repeated, a newer version is."""
        if release.version in self._toasted or release.version in self._dismissed:
            return
        if not release.is_offerable or release.version == read_deferred(self.state_dir) and not self._manual:
            return
        self._toasted.add(release.version)
        tray = self.tray
        if tray is None or not QSystemTrayIcon.isSystemTrayAvailable() or not QSystemTrayIcon.supportsMessages():
            log.info("Update %s: no desktop notification (tray unavailable); the in-app notice is shown", release.version)
            return
        try:
            tray.showMessage(PRODUCT.name + " update",
                             "Version {} is available (you have {}). Open the app and press Update now."
                             .format(release.version, VERSION), QSystemTrayIcon.Information, 15000)
            log.info("Update %s: desktop notification shown", release.version)
        except Exception as exc:                       # noqa: BLE001 - never let a toast break the check
            log.info("Update %s: desktop notification failed: %s", release.version, exc)

    def _notice(self, text: str):
        """A non-modal one-liner in the banner's place, for manual checks."""
        if self._downloader is not None or self._downloaded:
            self.status.emit(text)
            return
        self.release = None
        self.title.setText(text)
        self.detail.setText("")
        self.btn_update.setVisible(False)
        self.btn_later.setVisible(False)
        self.btn_close.setVisible(True)
        self.progress.setVisible(False)
        self.status.emit(text)
        self.show()

    # ------------------------------------------------------------------ show
    def offer(self, release: Release, force: bool = False):
        # The check only reports newer releases, but this is the last line
        # of defence: a manifest naming the version already running is never
        # shown as an update, whatever called us.
        if not release.is_offerable:
            if release.is_newer:
                log.info("Update %s skipped: needs %s or newer first", release.version, release.min_version)
            self.hide()
            return
        if release.version in self._dismissed and not force:
            return                          # Later was pressed: no nagging this session
        if not force and (self._installer_running or release.version == self._resumed_version):
            return                          # resume_pending() put this version up with its own words
        if self._downloader is not None or self._downloaded:
            return                          # already on its way
        self._installer_running = False
        self.release = release
        self.title.setText("Update available: {} → {}".format(VERSION, release.version))
        notes = release.notes.strip()
        text = ("Press Update now: the app closes, the installer runs by itself and the app "
                "reopens on the new version. Projects, exports and settings are kept.")
        if notes:
            text = "What's new: {}.  {}".format(notes.rstrip("."), text)
        self.detail.setText(text)
        self.btn_update.setVisible(True)
        self.btn_update.setEnabled(True)
        self.btn_update.setText("Update now")
        self.btn_later.setVisible(True)
        self.btn_later.setEnabled(True)
        self.btn_close.setVisible(False)
        self.progress.setVisible(False)
        self.show()

    def resume_pending(self) -> str:
        """At sign-in: finish what the last "Update now" started.

        The installer it launched needs the app closed and, on builds
        before 9.14, a click on Install; an editor who reopened the app
        instead saw the old version with the notice again and downloaded
        the same 346 MB once more. The record written when the installer
        was started says what happened now: this build IS that version --
        say so once, with what is new -- or it is still older, and the
        downloaded installer is offered again (Update now checks the file
        against the manifest's checksum and reuses it when it matches).
        Returns "updated", "pending" or ""."""
        pending = read_pending(self.state_dir)
        if pending is None:
            return ""
        release, installer = pending
        if not release.is_newer:
            clear_pending(self.state_dir)
            if is_newer(VERSION, release.version):
                # A later build was installed by hand; its notes are not these.
                log.info("Pending update %s is behind the running %s; record dropped", release.version, VERSION)
                return ""
            notes = release.notes.strip().rstrip(".")
            self._notice("Updated to version {}.{}".format(
                VERSION, "  What's new: {}.".format(notes) if notes else ""))
            log.info("Update %s is installed (running %s); the notice is shown once", release.version, VERSION)
            return "updated"
        if installer_running():
            # The installer this app started is still there, waiting for the
            # app to close -- the editor reopened it in the meantime. Say so;
            # never offer the same update on top of it.
            log.info("Update %s is installing; the app was reopened while the installer waits", release.version)
            self._show_installing(release)
            return "installing"
        if not installer or not Path(installer).is_file():
            clear_pending(self.state_dir)         # nothing to resume; the check offers it afresh
            return ""
        log.info("Update %s was downloaded earlier but not installed; offering it again", release.version)
        self._toasted.add(release.version)        # the strip explains it; no second notification
        self.offer(release, force=True)
        self._resumed_version = release.version
        self.detail.setText("Version {} was downloaded earlier but was not installed. Press Update now: "
                            "the installer runs by itself and the app reopens updated.".format(release.version))
        return "pending"

    def _show_installing(self, release: Release):
        self.release = release
        self._installer_running = True
        self._resumed_version = release.version
        self._toasted.add(release.version)
        self.title.setText("Version {} is installing".format(release.version))
        self.detail.setText("The installer is waiting for this app to close. Press Close and install; "
                            "the app reopens on version {}.".format(release.version))
        self.btn_update.setVisible(True)
        self.btn_update.setEnabled(True)
        self.btn_update.setText("Close and install")
        self.btn_later.setVisible(False)
        self.btn_close.setVisible(False)
        self.progress.setVisible(False)
        self.status.emit("Version {} is installing; close the app to let it finish.".format(release.version))
        self.show()

    def defer(self):
        """Later: away for this session, back once at the next launch."""
        self._resumed_version = ""
        if self.release is not None:
            self._dismissed.add(self.release.version)
            write_deferred(self.release.version, self.state_dir)
            log.info("Update %s deferred until the next launch", self.release.version)
        self.hide()

    # -------------------------------------------------------------- download
    def _on_update_clicked(self):
        if self._installer_running:
            self.install_started.emit()     # get out of the running installer's way
            return
        if self._downloaded and Path(self._downloaded).exists():
            self._install()                 # a retry after a failed launch, or "Install now"
        else:
            self.start_download()

    def start_download(self):
        if self.release is None or self._downloader is not None:
            return
        self._resumed_version = ""
        self._downloaded = ""
        self.btn_update.setEnabled(False)
        self.btn_update.setText("Downloading...")
        self.btn_later.setEnabled(False)
        self.progress.setRange(0, 0)
        self.progress.setFormat("Starting download")
        self.progress.setVisible(True)

        self._downloader = Downloader(self.release, self)
        self._downloader.progress.connect(self._on_progress)
        self._downloader.finished_ok.connect(self._on_downloaded)
        self._downloader.failed.connect(self._on_failed)
        self._downloader.start()

    def _on_progress(self, done: int, total: int):
        if total:
            self.progress.setRange(0, total)
            self.progress.setValue(done)
            self.progress.setFormat("{} of {}".format(_mb(done), _mb(total)))
        else:
            self.progress.setRange(0, 0)
            self.progress.setFormat(_mb(done))

    def _on_downloaded(self, path: str):
        self._downloader = None
        self._downloaded = path
        self._asked = False
        self.progress.setRange(0, 1)
        self.progress.setValue(1)
        reason = self._busy_provider() or ""
        if reason:
            self._show_waiting(reason)
            self._poll.start()
            return
        self._install()

    def _show_waiting(self, reason: str):
        self.progress.setFormat("Downloaded. It will install when {} finishes".format(reason))
        self.btn_update.setText("Waiting...")
        self.btn_update.setEnabled(False)
        self.detail.setText("The update is downloaded and checked. It installs as soon as {} "
                            "finishes; the app closes while the installer runs.".format(reason))
        self.status.emit("Update downloaded; it installs when {} finishes.".format(reason))

    def _poll_busy(self):
        reason = self._busy_provider() or ""
        if reason:
            self._show_waiting(reason)
            return
        self._poll.stop()
        if self.ask_before_install and not self._asked:
            self._asked = True
            if not self._ask_install():
                self.btn_update.setText("Install now")
                self.btn_update.setEnabled(True)
                self.progress.setFormat("Downloaded. Press Install now when ready")
                return
        self._install()

    def _ask_install(self) -> bool:
        release = self.release.version if self.release else ""
        answer = QMessageBox.question(
            self, "Install update",
            "Version {} is downloaded and the app is free now. Install it? "
            "The app closes while the installer runs and reopens updated.".format(release),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        return answer == QMessageBox.Yes

    def _install(self):
        reason = self._busy_provider() or ""
        if reason:
            self._show_waiting(reason)
            self._poll.start()
            return
        if installer_running():
            # One is already there (waiting for this app to close): leave.
            log.info("An installer is already running; closing the app for it instead of starting another")
            self.progress.setFormat("The installer is already running. Closing the app for it")
            self.install_started.emit()
            return
        self.progress.setFormat("Downloaded. Starting the installer")
        if self.release is not None:
            write_pending(self.release, self._downloaded, self.state_dir)
        if launch_installer(self._downloaded):
            self.install_started.emit()
        else:
            self._on_failed("could not start the installer at " + self._downloaded, keep_file=True)

    def _on_failed(self, message: str, keep_file: bool = False):
        self._downloader = None
        self._poll.stop()
        if not keep_file:
            self._downloaded = ""
        self.progress.setVisible(False)
        self.btn_update.setEnabled(True)
        self.btn_update.setText("Retry")
        self.btn_later.setEnabled(True)
        if keep_file:
            self.detail.setText("The installer could not be started ({}). Press Retry.".format(message))
        else:
            self.detail.setText("The update was not installed: {}. Check the connection "
                                "and press Retry.".format(message))
        self.status.emit("Update failed: " + message)
