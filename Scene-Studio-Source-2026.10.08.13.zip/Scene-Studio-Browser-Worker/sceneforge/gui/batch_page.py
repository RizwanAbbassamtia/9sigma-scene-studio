"""New batch / Multi-episode automation: seven episodes (or seventy) chosen
together, one stage range, one Start.

The page is a table of rows over a batch folder. Rows come from folders
picked together, from a parent folder with one sub-folder per episode, or
from a CSV / Excel sheet (a template is written on request). Every row is
checked before anything runs; invalid rows stay blocked while the valid
ones start. The scheduler (production/batch.py) runs on its own thread,
one episode at a time, and the table follows it.
"""
from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import List, Optional, Set

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QListView, QMessageBox, QPushButton, QScrollArea, QSpinBox, QTableWidget, QTableWidgetItem,
    QTreeView, QVBoxLayout, QWidget,
)

from ..config import Config
from ..logging_setup import get
from ..product import PRODUCT
from ..production import batch as batch_mod
from ..production.batch import (
    Batch, BatchEvent, BatchRow, BatchRunner, BLOCKED, CANCELLED, COMPLETED, FAILED, PAUSED, QUEUED, RUNNING,
    SOURCE_WORDS, STATUS_WORDS, WAITING, import_sheet, resolve, rows_from_folders, rows_from_parent, validate_all,
    write_template,
)
from ..production.credentials import Credentials
from ..production.frameworks import Frameworks
from ..production.manifest import EditingMode, ORDER, SOURCE_TYPES, Stage
from ..production.stages import STAGE_NAMES, range_text
from . import theme

log = get("production.batch.page")

COLUMNS = ["Episode", "Title", "Source", "Source path", "Range", "Status", "Stage / progress", "Output", "Error"]


def _hint(text: str) -> QLabel:
    label = QLabel(text)
    label.setObjectName("hint")
    label.setWordWrap(True)
    return label


def pick_folders(parent, title: str = "Choose the episode folders") -> List[Path]:
    """A folder picker that allows more than one folder: Qt's own dialog
    with its file lists switched to extended selection."""
    dialog = QFileDialog(parent, title)
    dialog.setFileMode(QFileDialog.Directory)
    dialog.setOption(QFileDialog.DontUseNativeDialog, True)
    dialog.setOption(QFileDialog.ShowDirsOnly, True)
    for view in dialog.findChildren((QListView, QTreeView)):
        view.setSelectionMode(QAbstractItemView.ExtendedSelection)
    if dialog.exec() != QDialog.Accepted:
        return []
    return [Path(p) for p in dialog.selectedFiles() if Path(p).is_dir()]


class _BatchThread(QThread):
    event = Signal(object)
    finished_counts = Signal(object)
    failed = Signal(str)

    def __init__(self, runner: BatchRunner, only: Optional[Set[str]], parent=None):
        super().__init__(parent)
        self.runner = runner
        self.only = only

    def run(self):
        try:
            counts = self.runner.run(self.only)
        except Exception as exc:                                   # noqa: BLE001
            log.exception("batch run crashed")
            self.failed.emit(str(exc))
            return
        self.finished_counts.emit(counts)


class NewBatchDialog(QDialog):
    """Name, folder and defaults for a new batch."""

    def __init__(self, config: Config, frameworks: Frameworks, parent=None):
        super().__init__(parent)
        self.setWindowTitle("New batch / Multi-episode automation")
        self.setMinimumWidth(640)
        self.batch: Optional[Batch] = None
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 16)
        outer.addWidget(_hint("A batch is several episodes run one after another with one set of defaults. "
                              "Each episode becomes its own production in a sub-folder of the batch folder; "
                              "nothing runs until Start. Keep a sheet of folders (Save sheet template…), "
                              "import it, and batch-status.csv in the batch folder shows each one's status."))
        form = QFormLayout()
        self.name = QLineEdit()
        self.name.setPlaceholderText("e.g. Season 2, episodes 8–14")
        self.folder = QLineEdit()
        self.folder.setPlaceholderText("where the batch record and each episode's production live")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        folder_row = QHBoxLayout()
        folder_row.addWidget(self.folder, 1)
        folder_row.addWidget(browse)
        self.output = QLineEdit()
        self.output.setPlaceholderText("default output folder for the finished videos (optional)")
        out_browse = QPushButton("Browse…")
        out_browse.clicked.connect(lambda: self._browse_into(self.output))
        out_row = QHBoxLayout()
        out_row.addWidget(self.output, 1)
        out_row.addWidget(out_browse)
        self.start = QComboBox()
        self.start.addItem("Decided by each row's source (recommended)", "")
        for stage in ORDER:
            self.start.addItem(STAGE_NAMES[stage], stage.value)
        self.end = QComboBox()
        for stage in ORDER:
            self.end.addItem(STAGE_NAMES[stage], stage.value)
        self.end.setCurrentIndex(len(ORDER) - 1)
        self.editing = QComboBox()
        self.editing.addItem("Fully automatic", EditingMode.AUTOMATIC.value)
        self.editing.addItem("Automatic + review (pause before export)", EditingMode.REVIEW.value)
        self.editing.addItem("Manual editor (pause at Editing)", EditingMode.MANUAL.value)
        self.aspect = QComboBox()
        self.aspect.addItem("Follow the clips (recommended)", "auto")
        self.aspect.addItem("YouTube Long — 16:9", "16:9")
        self.aspect.addItem("YouTube Shorts — 9:16", "9:16")
        self.resolution = QComboBox()
        self.resolution.addItem("1080p", 1080)
        self.resolution.addItem("720p", 720)
        self.limit = QSpinBox()
        self.limit.setRange(0, 5000)
        self.limit.setSpecialValueText("none (live generation refused)")
        self.limit.setSuffix(" clips per episode")
        self.budget = QSpinBox()
        self.budget.setRange(0, 50000)
        self.budget.setValue(int(getattr(config, "worker_max_generations", 200) or 200))
        self.budget.setSpecialValueText("no batch budget")
        self.budget.setSuffix(" clips per Start, whole batch")
        self.script_fw = QComboBox()
        self.prompt_fw = QComboBox()
        for combo, kind in ((self.script_fw, "script"), (self.prompt_fw, "prompt")):
            combo.addItem("— none —", "")
            for name in frameworks.names(kind):
                combo.addItem(name, name)
        self.mock = QCheckBox("Test mode: mock providers — no keys, no cost, test-pattern clips")
        form.addRow("Batch name", self.name)
        form.addRow("Batch folder", folder_row)
        form.addRow("Output folder", out_row)
        form.addRow("Start from", self.start)
        form.addRow("Continue until", self.end)
        form.addRow("Editing", self.editing)
        form.addRow("Video format", self.aspect)
        form.addRow("Resolution", self.resolution)
        form.addRow("Generation limit", self.limit)
        form.addRow("Batch budget", self.budget)
        form.addRow("Scriptwriting framework", self.script_fw)
        form.addRow("Scene-prompt framework", self.prompt_fw)
        outer.addLayout(form)
        outer.addWidget(self.mock)
        outer.addWidget(_hint("Every setting here is a default; a row may override any of them. Frameworks are "
                              "only used by rows that start from a title or a script."))
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        create = QPushButton("Create batch")
        create.setObjectName("primary")
        create.clicked.connect(self._create)
        buttons.addWidget(cancel)
        buttons.addWidget(create)
        outer.addLayout(buttons)

    def _browse(self):
        self._browse_into(self.folder)

    def _browse_into(self, field: QLineEdit):
        path = QFileDialog.getExistingDirectory(self, "Choose a folder", field.text() or "")
        if path:
            field.setText(path)

    def _create(self):
        name = self.name.text().strip()
        folder = self.folder.text().strip()
        if not name or not folder:
            QMessageBox.information(self, "New batch", "A batch name and a batch folder are needed.")
            return
        if (Path(folder) / batch_mod.BATCH_FILE).exists():
            QMessageBox.information(self, "New batch", "That folder already holds a batch. Open it instead, or "
                                    "choose another folder.")
            return
        batch = Batch.new(name, Path(folder), mock=self.mock.isChecked(),
                          start_stage=self.start.currentData() or "", end_stage=self.end.currentData(),
                          editing_mode=self.editing.currentData(), aspect_ratio=self.aspect.currentData(),
                          resolution=int(self.resolution.currentData()), output_dir=self.output.text().strip(),
                          generation_limit=self.limit.value(), script_framework=self.script_fw.currentData() or "",
                          prompt_framework=self.prompt_fw.currentData() or "")
        batch.max_generations = self.budget.value()
        try:
            batch.save()
        except OSError as exc:
            QMessageBox.warning(self, "New batch", "The batch folder could not be written: {}".format(exc))
            return
        self.batch = batch
        self.accept()


class BatchPage(QWidget):
    back_requested = Signal()
    open_production = Signal(str)          # a production's working folder

    def __init__(self, config: Config, frameworks: Frameworks, credentials: Credentials, parent=None):
        super().__init__(parent)
        self.config = config
        self.frameworks = frameworks
        self.credentials = credentials
        self.batch: Optional[Batch] = None
        self.runner: Optional[BatchRunner] = None
        self.thread: Optional[_BatchThread] = None
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()
        self.editor_name = ""
        self._problems = {}
        self._build()

    # ------------------------------------------------------------ building
    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(theme.SPACE_2, theme.SPACE_1, theme.SPACE_2, theme.SPACE_1)
        outer.setSpacing(theme.SPACE_1)
        bar = QHBoxLayout()
        back = QPushButton("‹ Editor")
        back.clicked.connect(self.back_requested.emit)
        self.heading = QLabel("No batch open")
        self.heading.setObjectName("title")
        bar.addWidget(back)
        bar.addSpacing(theme.SPACE_2)
        bar.addWidget(self.heading, 1)
        outer.addLayout(bar)
        self.summary = _hint("")
        outer.addWidget(self.summary)

        gather = QHBoxLayout()
        self.btn_add_row = QPushButton("Add episode row")
        self.btn_add_row.clicked.connect(self._add_row)
        self.btn_add_folders = QPushButton("Add episode folders…")
        self.btn_add_folders.setToolTip("Choose several clip folders at once (Ctrl-click); each becomes an episode.")
        self.btn_add_folders.clicked.connect(self._add_folders)
        self.btn_add_parent = QPushButton("Add a parent folder…")
        self.btn_add_parent.setToolTip("One sub-folder per episode, in natural order.")
        self.btn_add_parent.clicked.connect(self._add_parent)
        self.btn_import = QPushButton("Import sheet (CSV / Excel)…")
        self.btn_import.clicked.connect(self._import_sheet)
        self.btn_template = QPushButton("Save sheet template…")
        self.btn_template.setObjectName("quiet")
        self.btn_template.clicked.connect(self._save_template)
        for button in (self.btn_add_row, self.btn_add_folders, self.btn_add_parent, self.btn_import, self.btn_template):
            gather.addWidget(button)
        gather.addStretch(1)
        outer.addLayout(gather)

        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        header.setSectionResizeMode(6, QHeaderView.Stretch)
        header.setSectionResizeMode(8, QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self._sync_buttons)
        self.table.itemDoubleClicked.connect(lambda _i: self._edit_row())
        outer.addWidget(self.table, 2)

        row_actions = QHBoxLayout()
        self.btn_edit = QPushButton("Edit row…")
        self.btn_edit.clicked.connect(self._edit_row)
        self.btn_remove = QPushButton("Remove row")
        self.btn_remove.setObjectName("quiet")
        self.btn_remove.clicked.connect(self._remove_rows)
        self.btn_up = QPushButton("Run earlier")
        self.btn_up.setObjectName("quiet")
        self.btn_up.clicked.connect(lambda: self._priority(-1))
        self.btn_down = QPushButton("Run later")
        self.btn_down.setObjectName("quiet")
        self.btn_down.clicked.connect(lambda: self._priority(+1))
        self.btn_validate = QPushButton("Check all rows")
        self.btn_validate.clicked.connect(self.validate)
        for button in (self.btn_edit, self.btn_remove, self.btn_up, self.btn_down, self.btn_validate):
            row_actions.addWidget(button)
        row_actions.addStretch(1)
        outer.addLayout(row_actions)

        self.status_line = QLabel("")
        self.status_line.setObjectName("readyBanner")
        self.status_line.setWordWrap(True)
        outer.addWidget(self.status_line)

        run_actions = QHBoxLayout()
        self.btn_start_all = QPushButton("Start all ready")
        self.btn_start_all.setObjectName("primary")
        self.btn_start_all.clicked.connect(lambda: self.start(None))
        self.btn_start_selected = QPushButton("Start selected")
        self.btn_start_selected.clicked.connect(lambda: self.start(self._selected_ids()))
        self.btn_pause = QPushButton("Pause scheduling")
        self.btn_pause.setCheckable(True)
        self.btn_pause.setToolTip("Finish the running episode and start no more until unpaused.")
        self.btn_pause.toggled.connect(self._toggle_pause)
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.setToolTip("Stop after the current step; the running episode goes back to the queue.")
        self.btn_stop.clicked.connect(self.stop)
        self.btn_cancel = QPushButton("Cancel selected")
        self.btn_cancel.clicked.connect(lambda: self._each(self._selected_ids(), "cancel"))
        self.btn_retry = QPushButton("Retry selected")
        self.btn_retry.clicked.connect(lambda: self._each(self._selected_ids(), "retry"))
        self.btn_approve = QPushButton("Approve selected")
        self.btn_approve.setObjectName("actApprove")
        self.btn_approve.setToolTip("Approve the stage the selected episode is waiting on. Only the selected ones.")
        self.btn_approve.clicked.connect(self._approve)
        self.btn_open_prod = QPushButton("Open production")
        self.btn_open_prod.clicked.connect(self._open_production)
        self.btn_open_out = QPushButton("Open output folder")
        self.btn_open_out.setObjectName("quiet")
        self.btn_open_out.clicked.connect(self._open_output)
        for button in (self.btn_start_all, self.btn_start_selected, self.btn_pause, self.btn_stop, self.btn_cancel,
                       self.btn_retry, self.btn_approve, self.btn_open_prod, self.btn_open_out):
            run_actions.addWidget(button)
        run_actions.addStretch(1)
        outer.addLayout(run_actions)
        self._sync_buttons()

    # ------------------------------------------------------------- loading
    def load(self, batch: Batch):
        self.batch = batch
        self._problems = {}
        self.heading.setText("Batch: {}".format(batch.name))
        # Nothing from the previous batch may read as this one's: the status
        # line and the pause toggle start clean.
        self.btn_pause.blockSignals(True)          # unticking must not write "Unpaused." to the line
        self.btn_pause.setChecked(False)
        self.btn_pause.blockSignals(False)
        self.pause_event.clear()
        self.status_line.setText("")
        self._refresh()

    def clear(self):
        if self.running:
            return
        self.batch = None
        self.runner = None
        self._problems = {}
        self.heading.setText("No batch open")
        self.summary.setText("")
        self.status_line.setText("")
        self.table.setRowCount(0)
        self._sync_buttons()

    @property
    def running(self) -> bool:
        return self.thread is not None and self.thread.isRunning()

    def _refresh(self):
        if self.batch is None:
            self.table.setRowCount(0)
            self._sync_buttons()
            return
        keep = self._selected_ids()
        self.table.setRowCount(len(self.batch.rows))
        for index, row in enumerate(self.batch.rows):
            spec = resolve(self.batch, row)
            problems = self._problems.get(row.id, [])
            cells = [row.episode, row.title, SOURCE_WORDS.get(spec["source_type"], spec["source_type"]),
                     spec["source_path"], range_text(spec["start_stage"], spec["end_stage"]),
                     STATUS_WORDS.get(row.status, row.status), row.progress or row.stage,
                     Path(row.export_path).name if row.export_path else spec["output_dir"],
                     row.error or ("; ".join(problems) if problems else "")]
            for column, text in enumerate(cells):
                item = QTableWidgetItem(str(text))
                item.setData(Qt.UserRole, row.id)
                item.setToolTip("\n".join(row.history[-6:]) if column == 5 else str(text))
                self.table.setItem(index, column, item)
        self._select_ids(keep)
        counts = self.batch.counts()
        self.summary.setText("{} episode(s): {} queued, {} running, {} waiting for approval, {} completed, "
                             "{} failed, {} blocked, {} cancelled   ·   {}   ·   folder: {}".format(
                                 len(self.batch.rows), counts[QUEUED], counts[RUNNING], counts[WAITING],
                                 counts[COMPLETED], counts[FAILED], counts[BLOCKED], counts[CANCELLED],
                                 "test mode" if self.batch.mock else "LIVE", self.batch.folder))
        self._sync_buttons()

    def _sync_buttons(self):
        has = self.batch is not None
        running = self.running
        selected = self._selected_ids()
        for button in (self.btn_add_row, self.btn_add_folders, self.btn_add_parent, self.btn_import, self.btn_validate):
            button.setEnabled(has and not running)
        self.btn_template.setEnabled(True)
        self.btn_edit.setEnabled(has and len(selected) == 1 and not running)
        self.btn_remove.setEnabled(has and bool(selected) and not running)
        self.btn_up.setEnabled(has and bool(selected))
        self.btn_down.setEnabled(has and bool(selected))
        self.btn_start_all.setEnabled(has and not running and bool(self.batch and self.batch.rows))
        self.btn_start_selected.setEnabled(has and not running and bool(selected))
        self.btn_pause.setEnabled(has)
        self.btn_stop.setEnabled(running)
        self.btn_cancel.setEnabled(has and bool(selected))
        self.btn_retry.setEnabled(has and bool(selected))
        self.btn_approve.setEnabled(has and bool(selected))
        self.btn_open_prod.setEnabled(has and len(selected) == 1)
        self.btn_open_out.setEnabled(has and len(selected) == 1)

    def _selected_ids(self) -> List[str]:
        seen = []
        for item in self.table.selectedItems():
            row_id = item.data(Qt.UserRole)
            if row_id not in seen:
                seen.append(row_id)
        return seen

    def _select_ids(self, ids: List[str]):
        self.table.clearSelection()
        for index in range(self.table.rowCount()):
            item = self.table.item(index, 0)
            if item is not None and item.data(Qt.UserRole) in ids:
                self.table.selectRow(index)

    # ---------------------------------------------------------- gathering
    def _add_rows(self, rows: List[BatchRow], what: str):
        if self.batch is None or not rows:
            return
        added, skipped = self.batch.add_new(rows)
        self.batch.save()
        self._refresh()
        self.status_line.setText("{} episode(s) added from {}{}. Press Check all rows, then Start. Status is "
                                 "mirrored to {}.".format(
                                     len(added), what,
                                     "; {} already in the batch, left as they are".format(len(skipped)) if skipped else "",
                                     self.batch.status_sheet.name))

    def _add_row(self):
        if self.batch is None:
            return
        row = BatchRow(episode="{:03d}".format(len(self.batch.rows) + 1))
        dialog = RowDialog(self.batch, row, self)
        if dialog.exec() == QDialog.Accepted:
            self._add_rows([row], "the form")

    def _add_folders(self):
        folders = pick_folders(self)
        self._add_rows(rows_from_folders(folders), "the chosen folders")

    def _add_parent(self):
        parent = QFileDialog.getExistingDirectory(self, "The folder that holds one sub-folder per episode", "")
        if not parent:
            return
        rows = rows_from_parent(Path(parent))
        if not rows:
            QMessageBox.information(self, "Add a parent folder", "No sub-folder of {} holds video files.".format(parent))
            return
        self._add_rows(rows, Path(parent).name)

    def _import_sheet(self):
        path, _ = QFileDialog.getOpenFileName(self, "The batch sheet", "", "Sheets (*.csv *.xlsx);;All files (*)")
        if not path:
            return
        rows, problems = import_sheet(Path(path))
        if problems:
            QMessageBox.information(self, "Import sheet", "Some rows were not imported:\n• " + "\n• ".join(problems[:20]))
        self._add_rows(rows, Path(path).name)

    def _save_template(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save the sheet template", "batch-template.csv", "CSV (*.csv)")
        if path:
            write_template(Path(path))
            self.status_line.setText("Template saved: {}. Fill one row per episode and import it.".format(path))

    def _edit_row(self):
        ids = self._selected_ids()
        if self.batch is None or len(ids) != 1 or self.running:
            return
        row = self.batch.row(ids[0])
        if RowDialog(self.batch, row, self).exec() == QDialog.Accepted:
            row.note("edited")
            if row.status in (BLOCKED, FAILED):
                row.status = QUEUED
                row.error = ""
            self.batch.save()
            self._problems.pop(row.id, None)
            self._refresh()

    def _remove_rows(self):
        ids = self._selected_ids()
        if self.batch is None or not ids or self.running:
            return
        self.batch.rows = [r for r in self.batch.rows if r.id not in ids]
        self.batch.save()
        self._refresh()

    def _priority(self, delta: int):
        if self.batch is None:
            return
        for row_id in self._selected_ids():
            row = self.batch.row(row_id)
            row.priority = max(1, min(9, row.priority + delta))
            row.note("priority {}".format(row.priority))
        self.batch.save()
        self._refresh()

    # ---------------------------------------------------------- checking
    def validate(self) -> bool:
        if self.batch is None:
            return False
        self._problems = validate_all(self.batch, self.credentials)
        for row in self.batch.rows:
            if row.id in self._problems and row.status in (QUEUED, BLOCKED):
                row.status = BLOCKED
                row.error = "; ".join(self._problems[row.id])
            elif row.id not in self._problems and row.status == BLOCKED:
                row.status = QUEUED
                row.error = ""
        self.batch.save()
        self._refresh()
        blocked = len(self._problems)
        ready = sum(1 for r in self.batch.rows if r.status == QUEUED)
        self.status_line.setText("{} ready, {} blocked. {}".format(
            ready, blocked, "Fix the blocked rows (Edit row…) or start the ready ones." if blocked else
            "Start all ready runs them one after another."))
        return blocked == 0

    # ------------------------------------------------------------ running
    def start(self, only: Optional[List[str]]):
        if self.batch is None or self.running:
            return
        self.validate()
        wanted = [r for r in self.batch.rows if r.status == QUEUED and (only is None or r.id in only)]
        if not wanted:
            QMessageBox.information(self, "Start batch", "No ready episode to start.")
            return
        live = not self.batch.mock
        generates = any(Stage.CLIPS.value in [s.value for s in batch_mod.stages_between(
            resolve(self.batch, r)["start_stage"], resolve(self.batch, r)["end_stage"])] for r in wanted)
        text = ("Start {} episode(s), one after another?\n\n{}\n{}".format(
            len(wanted), "LIVE: clips will be paid for." if live and generates else
            ("Test mode: no keys, no cost." if not live else "No clip generation in this range."),
            "Batch budget: {} clips.".format(self.batch.max_generations) if generates else ""))
        if QMessageBox.question(self, "Start batch", text, QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()
        self.btn_pause.setChecked(False)
        self.runner = BatchRunner(self.batch, self.credentials, self.frameworks, self.config,
                                  stop=self.stop_event, pause=self.pause_event)
        self.thread = _BatchThread(self.runner, set(only) if only else None, self)
        self.runner.on_event = self.thread.event.emit
        self.thread.event.connect(self._on_event)
        self.thread.finished_counts.connect(self._on_finished)
        self.thread.failed.connect(lambda why: self._on_finished({"error": why}))
        self.thread.start()
        self.status_line.setText("Running.")
        self._sync_buttons()

    def stop(self):
        self.stop_event.set()
        self.status_line.setText("Stopping after the current step…")

    def _toggle_pause(self, on: bool):
        if on:
            self.pause_event.set()
            self.status_line.setText("Paused: the running episode finishes; no new one starts.")
        else:
            self.pause_event.clear()
            self.status_line.setText("Unpaused.")

    def _on_event(self, event: BatchEvent):
        if event.row_id and self.batch is not None:
            self._refresh()
        if event.status == "summary":
            self.status_line.setText("Batch: " + event.message)

    def _on_finished(self, counts):
        self.thread = None
        self._refresh()
        if isinstance(counts, dict) and "error" in counts:
            self.status_line.setText("The batch stopped with an error: {}".format(counts["error"]))
            return
        counts = counts or {}
        failed = counts.get(FAILED, 0) + counts.get(BLOCKED, 0)
        waiting = counts.get(WAITING, 0)
        text = "Batch finished: {} completed, {} failed, {} waiting for approval.".format(
            counts.get(COMPLETED, 0), failed, waiting)
        self.status_line.setText(text + (" Some episodes need attention." if failed or waiting else ""))
        try:
            window = self.window()
            tray = getattr(window, "tray", None)
            if tray is not None:
                tray.showMessage(PRODUCT.name + " — batch", text, tray.Information, 10000)
        except Exception:                                          # noqa: BLE001 - a courtesy
            pass

    def _each(self, ids: List[str], action: str):
        if self.batch is None or not ids:
            return
        runner = self.runner or BatchRunner(self.batch, self.credentials, self.frameworks, self.config)
        for row_id in ids:
            getattr(runner, action)(row_id)
        self._refresh()

    def _approve(self):
        ids = self._selected_ids()
        if self.batch is None or not ids:
            return
        runner = self.runner or BatchRunner(self.batch, self.credentials, self.frameworks, self.config)
        done = sum(1 for row_id in ids if runner.approve(row_id, self.editor_name or "editor"))
        self._refresh()
        self.status_line.setText("{} episode(s) approved and queued. {}".format(
            done, "They continue when the batch is next started." if not self.running else ""))

    def _open_production(self):
        ids = self._selected_ids()
        if self.batch is None or len(ids) != 1:
            return
        row = self.batch.row(ids[0])
        if row.production_dir:
            self.open_production.emit(row.production_dir)
        else:
            self.status_line.setText("That episode has not started yet; it has no production to open.")

    def _open_output(self):
        ids = self._selected_ids()
        if self.batch is None or len(ids) != 1:
            return
        row = self.batch.row(ids[0])
        folder = Path(row.export_path).parent if row.export_path else Path(resolve(self.batch, row)["output_dir"])
        if folder.is_dir():
            try:
                os.startfile(str(folder))                          # noqa: S606
            except OSError:
                pass

    def shutdown(self, timeout_ms: int = 10000) -> bool:
        self.stop_event.set()
        if self.thread is not None and self.thread.isRunning():
            return self.thread.wait(timeout_ms)
        return True


class RowDialog(QDialog):
    """One episode's row: the source, and any setting that differs from the
    batch defaults."""

    def __init__(self, batch: Batch, row: BatchRow, parent=None):
        super().__init__(parent)
        self.batch = batch
        self.row = row
        self.setWindowTitle("Episode row")
        self.setMinimumWidth(680)
        # The form is taller than a 768-pixel laptop screen, so it scrolls
        # and the Save row button stays in view at the bottom.
        shell = QVBoxLayout(self)
        shell.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget()
        outer = QVBoxLayout(inner)
        outer.setContentsMargins(24, 20, 24, 8)
        scroll.setWidget(inner)
        shell.addWidget(scroll, 1)
        form = QFormLayout()
        self.episode = QLineEdit(row.episode)
        self.title = QLineEdit(row.title)
        self.project = QLineEdit(row.project)
        self.source = QComboBox()
        for value in SOURCE_TYPES:
            self.source.addItem(SOURCE_WORDS[value], value)
        self.source.setCurrentIndex(max(0, self.source.findData(row.source_type)))
        self.source.currentIndexChanged.connect(self._sync_source)
        self.brief = QLineEdit(row.brief)
        self.script_path = self._path_row(form, "Script file", row.script_path, file=True)
        self.prompts_path = self._path_row(form, "Scene-prompt file", row.prompts_path, file=True)
        self.clips_folder = self._path_row(form, "Clips folder", row.clips_folder, file=False)
        self.timeline_path = self._path_row(form, "Composition folder", row.timeline_path, file=False)
        form.insertRow(0, "Episode", self.episode)
        form.insertRow(1, "Title", self.title)
        form.insertRow(2, "Project", self.project)
        form.insertRow(3, "Source", self.source)
        form.insertRow(4, "Brief (for a title start)", self.brief)
        self.start = QComboBox()
        self.start.addItem("batch default / by source", "")
        for stage in ORDER:
            self.start.addItem(STAGE_NAMES[stage], stage.value)
        self.start.setCurrentIndex(max(0, self.start.findData(row.start_stage)))
        self.end = QComboBox()
        self.end.addItem("batch default", "")
        for stage in ORDER:
            self.end.addItem(STAGE_NAMES[stage], stage.value)
        self.end.setCurrentIndex(max(0, self.end.findData(row.end_stage)))
        self.editing = QComboBox()
        self.editing.addItem("batch default", "")
        for value, label in ((EditingMode.AUTOMATIC.value, "Fully automatic"), (EditingMode.REVIEW.value, "Automatic + review"),
                             (EditingMode.MANUAL.value, "Manual editor")):
            self.editing.addItem(label, value)
        self.editing.setCurrentIndex(max(0, self.editing.findData(row.editing_mode)))
        self.aspect = QComboBox()
        self.aspect.addItem("batch default", "")
        for value, label in (("auto", "Follow the clips"), ("16:9", "16:9"), ("9:16", "9:16")):
            self.aspect.addItem(label, value)
        self.aspect.setCurrentIndex(max(0, self.aspect.findData(row.aspect_ratio)))
        self.resolution = QComboBox()
        self.resolution.addItem("batch default", 0)
        self.resolution.addItem("1080p", 1080)
        self.resolution.addItem("720p", 720)
        self.resolution.setCurrentIndex(max(0, self.resolution.findData(row.resolution)))
        self.output_dir = self._path_row(form, "Output folder (override)", row.output_dir, file=False)
        self.final_filename = QLineEdit(row.final_filename)
        self.limit = QSpinBox()
        self.limit.setRange(-1, 5000)
        self.limit.setSpecialValueText("batch default")
        self.limit.setValue(row.generation_limit)
        self.priority = QSpinBox()
        self.priority.setRange(1, 9)
        self.priority.setValue(row.priority)
        form.addRow("Start from", self.start)
        form.addRow("Continue until", self.end)
        form.addRow("Editing", self.editing)
        form.addRow("Video format", self.aspect)
        form.addRow("Resolution", self.resolution)
        form.addRow("Final filename", self.final_filename)
        form.addRow("Generation limit", self.limit)
        form.addRow("Priority (1 first)", self.priority)
        outer.addLayout(form)
        self.preview = _hint("")
        outer.addWidget(self.preview)
        outer.addStretch(1)
        buttons = QHBoxLayout()
        buttons.setContentsMargins(24, 8, 24, 16)
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.setAutoDefault(False)
        cancel.clicked.connect(self.reject)
        ok = QPushButton("Save row")
        ok.setObjectName("primary")
        ok.setDefault(True)                        # Enter in any field saves; Esc cancels
        ok.clicked.connect(self._save)
        buttons.addWidget(cancel)
        buttons.addWidget(ok)
        shell.addLayout(buttons)
        self.btn_save = ok
        self._sync_source()
        screen = self.screen() if hasattr(self, "screen") else None
        available = screen.availableGeometry().height() if screen is not None else 720
        self.resize(760, min(700, available - 80))

    def _path_row(self, form: QFormLayout, label: str, value: str, file: bool) -> QLineEdit:
        field = QLineEdit(value)
        browse = QPushButton("Browse…")

        def pick():
            if file:
                path, _ = QFileDialog.getOpenFileName(self, label, field.text() or "", "Text (*.txt *.md);;All files (*)")
            else:
                path = QFileDialog.getExistingDirectory(self, label, field.text() or "")
            if path:
                field.setText(path)
        browse.clicked.connect(pick)
        row = QHBoxLayout()
        row.addWidget(field, 1)
        row.addWidget(browse)
        form.addRow(label, row)
        field.setProperty("rowLabel", label)
        field.textChanged.connect(lambda _t: self._preview())
        return field

    def _sync_source(self, *_):
        source = self.source.currentData()
        shown = {"script_path": source in ("script", "script_prompts"),
                 "prompts_path": source in ("prompts", "script_prompts"),
                 "clips_folder": source == "clips", "timeline_path": source == "composition",
                 "brief": source == "title"}
        for name, on in shown.items():
            widget = getattr(self, name)
            widget.setEnabled(on)
        self._preview()

    def _preview(self):
        source = self.source.currentData()
        text = ""
        if source in ("clips", "composition"):
            folder = (self.clips_folder if source == "clips" else self.timeline_path).text().strip()
            if folder:
                from ..production.stages import clip_folder_report
                report = clip_folder_report(folder)
                if report["problems"]:
                    text = "Check: " + "; ".join(report["problems"])
                else:
                    text = "Expected clips: {}   Found: {}   Missing: {}   Composition saved: {}".format(
                        report["expected"] if report["expected"] is not None else "unknown", report["found"],
                        len(report["missing"]), "yes" if report["composition"] else "no")
        self.preview.setText(text)

    def _save(self):
        r = self.row
        r.episode = self.episode.text().strip()
        r.title = self.title.text().strip()
        r.project = self.project.text().strip()
        r.source_type = self.source.currentData()
        r.brief = self.brief.text().strip()
        r.script_path = self.script_path.text().strip()
        r.prompts_path = self.prompts_path.text().strip()
        r.clips_folder = self.clips_folder.text().strip()
        r.timeline_path = self.timeline_path.text().strip()
        r.start_stage = self.start.currentData() or ""
        r.end_stage = self.end.currentData() or ""
        r.editing_mode = self.editing.currentData() or ""
        r.aspect_ratio = self.aspect.currentData() or ""
        r.resolution = int(self.resolution.currentData() or 0)
        r.output_dir = self.output_dir.text().strip()
        r.final_filename = self.final_filename.text().strip()
        r.generation_limit = self.limit.value()
        r.priority = self.priority.value()
        if not (r.episode or r.title):
            QMessageBox.information(self, "Episode row", "An episode label or a title is needed.")
            return
        self.accept()


def remember_batch(config: Config, folder, directory) -> None:
    path = str(Path(folder))
    recent = [p for p in getattr(config, "recent_batches", []) if p != path]
    recent.insert(0, path)
    config.recent_batches = recent[:40]
    try:
        config.save(directory)
    except OSError:
        pass


class OpenBatchDialog(QDialog):
    """The batches this machine knows, with their counts; or browse."""

    def __init__(self, config: Config, parent=None):
        super().__init__(parent)
        self.config = config
        self.chosen: Optional[Path] = None
        self.setWindowTitle("Open batch")
        self.setMinimumSize(760, 420)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 16)
        outer.addWidget(_hint("A batch is reopened exactly where it was; a row that was running resumes from its "
                              "checkpoints when the batch is next started. Nothing starts by opening it."))
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Batch", "Episodes", "Status", "Last updated", "Folder"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.table.itemDoubleClicked.connect(lambda _i: self._open())
        outer.addWidget(self.table, 1)
        buttons = QHBoxLayout()
        browse = QPushButton("Browse for a batch folder…")
        browse.clicked.connect(self._browse)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        self.btn_open = QPushButton("Open batch")
        self.btn_open.setObjectName("primary")
        self.btn_open.clicked.connect(self._open)
        buttons.addWidget(browse)
        buttons.addStretch(1)
        buttons.addWidget(cancel)
        buttons.addWidget(self.btn_open)
        outer.addLayout(buttons)
        self._fill()

    def _fill(self):
        rows = []
        for folder in getattr(self.config, "recent_batches", []):
            if not (Path(folder) / batch_mod.BATCH_FILE).is_file():
                continue
            try:
                batch = Batch.load(Path(folder))
            except (OSError, ValueError, KeyError, TypeError) as exc:
                log.warning("Batch at %s could not be read: %s", folder, exc)
                continue
            counts = batch.counts()
            rows.append((batch.name, str(len(batch.rows)), "{} done, {} queued, {} failed, {} waiting".format(
                counts[COMPLETED], counts[QUEUED], counts[FAILED] + counts[BLOCKED], counts[WAITING]),
                batch.updated[:16].replace("T", " "), folder))
        self.table.setRowCount(len(rows))
        for index, cells in enumerate(rows):
            for column, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setData(Qt.UserRole, cells[-1])
                self.table.setItem(index, column, item)
        if rows:
            self.table.selectRow(0)
        self.btn_open.setEnabled(bool(rows))

    def _open(self):
        items = self.table.selectedItems()
        if items:
            self.chosen = Path(items[0].data(Qt.UserRole))
            self.accept()

    def _browse(self):
        folder = QFileDialog.getExistingDirectory(self, "The batch folder (holds batch.json)", "")
        if folder and (Path(folder) / batch_mod.BATCH_FILE).is_file():
            self.chosen = Path(folder)
            self.accept()
