"""Timeline strip: detected speech, the kept segments, and a draggable playhead.

A clip plays as one or more segments of its source file. The strip draws all
of them, lets one be selected, and gives the selected one a pair of trim
handles. Cutting itself (split, remove left/right, delete) is done by the
window from the playhead, since it needs the undo history and the status
line; the strip only reports what was dragged or clicked.
"""
from __future__ import annotations

from typing import List, Optional

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import QSizePolicy, QWidget

from ..models import SpeechSpan
from . import theme

# Colours come from the one token file; see `theme.py`.
#
# Four things have to be told apart at a glance: what is kept, what is cut,
# where the handles are and where the playhead is. The retained range is a
# blue-tinted ground, the excluded range stays plain slate, and blue marks the
# handles and the playhead -- the same blue that means "selected" everywhere
# else. Speech is neutral grey: it is information, not a control. An
# unselected segment keeps the kept tint but gets a thin muted outline
# instead of handles, so the selected one is the only one that looks
# grabbable.
_BG = QColor(theme.BG_PANEL)
_TRACK = QColor(theme.TRIM_TRACK)
_SPEECH = QColor(theme.TRIM_SPEECH)
_KEEP = QColor(theme.TRIM_KEPT)
_KEEP_EDGE = QColor(theme.ACCENT)
_OTHER_EDGE = QColor(theme.TEXT_MUTED)
_PLAYHEAD = QColor(theme.ACCENT)
_TEXT = QColor(theme.TEXT_MUTED)
_MUTED = QColor(theme.WARNING)

_HANDLE_GRAB_PX = 7
_MIN_SEGMENT = 0.1                    # the strip's own floor; the window applies the config's


class Timeline(QWidget):
    seek_requested = Signal(float)
    # (segment index, new start, new end) after a handle drag or a nudge
    segment_changed = Signal(int, float, float)
    segment_selected = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(84)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.NoFocus)

        self.duration: float = 10.0
        self.speech: List[SpeechSpan] = []
        self.segments: List[SpeechSpan] = [SpeechSpan(0.0, 10.0)]
        self.selected: int = 0
        self.muted: bool = False
        self.min_length: float = _MIN_SEGMENT
        self.position: float = 0.0
        self._drag: Optional[str] = None
        self.empty = True                  # nothing loaded: draw that, not a range

    # -- data ---------------------------------------------------------------
    def clear(self):
        self.empty = True
        self.speech = []
        self.position = 0.0
        self.update()

    def set_clip(self, duration: float, speech: List[SpeechSpan], start: float, end: float):
        """One segment from start to end: the shape every clip starts with."""
        self.set_segments(duration, speech, [SpeechSpan(start, end)], 0, False)

    def set_segments(self, duration: float, speech: List[SpeechSpan],
                     segments: List[SpeechSpan], selected: int = 0,
                     muted: bool = False, keep_position: bool = False):
        self.empty = False
        self.duration = max(0.1, duration)
        self.speech = list(speech)
        self.segments = [SpeechSpan(s.start, s.end) for s in segments] or [
            SpeechSpan(0.0, self.duration)]
        self.selected = max(0, min(len(self.segments) - 1, selected))
        self.muted = muted
        if not keep_position:
            self.position = 0.0
        self.update()

    def set_position(self, seconds: float):
        self.position = seconds
        self.update()

    @property
    def cut_start(self) -> float:
        return self.segments[self.selected].start

    @property
    def cut_end(self) -> float:
        return self.segments[self.selected].end

    def _bounds(self, index: int):
        """(lowest start, highest end) the segment may reach without
        crossing its neighbours or the ends of the clip."""
        low = self.segments[index - 1].end if index > 0 else 0.0
        high = self.segments[index + 1].start if index + 1 < len(self.segments) else self.duration
        return low, high

    # -- geometry -----------------------------------------------------------
    def _track_rect(self) -> QRectF:
        return QRectF(10, 24, max(1, self.width() - 20), 34)

    def _x_for(self, seconds: float) -> float:
        track = self._track_rect()
        return track.left() + (seconds / self.duration) * track.width()

    def _time_at(self, x: float) -> float:
        track = self._track_rect()
        ratio = (x - track.left()) / max(1.0, track.width())
        return max(0.0, min(self.duration, ratio * self.duration))

    # -- painting -----------------------------------------------------------
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), _BG)
        if self.empty:
            font = QFont()
            font.setPointSize(9)
            painter.setFont(font)
            painter.setPen(QPen(_TEXT))
            painter.drawText(self.rect(), Qt.AlignCenter, "No clip loaded")
            painter.end()
            return

        track = self._track_rect()
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(_TRACK))
        painter.drawRoundedRect(track, 4, 4)

        keep = QColor(_KEEP)
        if self.muted:
            keep.setAlpha(110)
        painter.setBrush(QBrush(keep))
        for span in self.segments:
            left = self._x_for(span.start)
            painter.drawRect(QRectF(left, track.top(), self._x_for(span.end) - left, track.height()))

        painter.setBrush(QBrush(_SPEECH))
        for span in self.speech:
            left = self._x_for(span.start)
            painter.drawRect(QRectF(left, track.top() + 6,
                                    max(1.0, self._x_for(span.end) - left), track.height() - 12))

        # Segment edges: thin and grey for the others, bold and blue with a
        # grab tab for the selected one.
        small = QFont()
        small.setPointSize(7)
        painter.setFont(small)
        for index, span in enumerate(self.segments):
            left, right = self._x_for(span.start), self._x_for(span.end)
            chosen = index == self.selected
            painter.setPen(QPen(_KEEP_EDGE if chosen else _OTHER_EDGE, 2 if chosen else 1))
            painter.drawLine(QPointF(left, track.top()), QPointF(left, track.bottom()))
            painter.drawLine(QPointF(right, track.top()), QPointF(right, track.bottom()))
            if chosen:
                painter.setBrush(QBrush(_KEEP_EDGE))
                painter.setPen(Qt.NoPen)
                painter.drawRect(QRectF(left - 3, track.bottom() - 8, 6, 8))
                painter.drawRect(QRectF(right - 3, track.bottom() - 8, 6, 8))
            if len(self.segments) > 1 and right - left > 14:
                painter.setPen(QPen(_KEEP_EDGE if chosen else _TEXT))
                painter.drawText(QRectF(left + 3, track.top() + 1, right - left - 6, 10),
                                 Qt.AlignLeft | Qt.AlignTop, str(index + 1))

        head = self._x_for(self.position)
        painter.setPen(QPen(_PLAYHEAD, 2))
        painter.drawLine(QPointF(head, track.top() - 6), QPointF(head, track.bottom() + 6))
        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(_PLAYHEAD))
        painter.drawPolygon(QPolygonF([QPointF(head - 5, track.top() - 7),
                                       QPointF(head + 5, track.top() - 7),
                                       QPointF(head, track.top() - 1)]))

        font = QFont()
        font.setPointSize(8)
        painter.setFont(font)
        painter.setPen(QPen(_TEXT))
        chosen = self.segments[self.selected]
        if len(self.segments) > 1:
            label = "segment {} of {}   {:.2f}s - {:.2f}s   ({:.2f}s kept in all)".format(
                self.selected + 1, len(self.segments), chosen.start, chosen.end,
                sum(s.end - s.start for s in self.segments))
        else:
            label = "cut {:.2f}s - {:.2f}s   ({:.2f}s kept)".format(
                chosen.start, chosen.end, chosen.end - chosen.start)
        painter.drawText(QRectF(10, 4, self.width() - 200, 16), Qt.AlignLeft, label)
        painter.drawText(QRectF(self.width() - 170, 4, 160, 16), Qt.AlignRight,
                         "{:.2f}s / {:.2f}s".format(self.position, self.duration))
        painter.drawText(QRectF(10, track.bottom() + 6, 120, 16), Qt.AlignLeft, "0.00s")
        if self.muted:
            painter.setPen(QPen(_MUTED))
            painter.drawText(QRectF(0, track.bottom() + 6, self.width(), 16),
                             Qt.AlignCenter, "MUTED  -  exported silent")
            painter.setPen(QPen(_TEXT))
        painter.drawText(QRectF(self.width() - 130, track.bottom() + 6, 120, 16),
                         Qt.AlignRight, "{:.2f}s".format(self.duration))

    # -- interaction --------------------------------------------------------
    def _hit(self, x: float) -> Optional[str]:
        if self.empty:
            return None
        if abs(x - self._x_for(self.cut_start)) <= _HANDLE_GRAB_PX:
            return "start"
        if abs(x - self._x_for(self.cut_end)) <= _HANDLE_GRAB_PX:
            return "end"
        return None

    def _segment_at(self, seconds: float) -> Optional[int]:
        for index, span in enumerate(self.segments):
            if span.start <= seconds <= span.end:
                return index
        return None

    def mousePressEvent(self, event):
        x = event.position().x()
        self._drag = self._hit(x)
        if self._drag is not None:
            return
        time = self._time_at(x)
        index = self._segment_at(time)
        if index is not None and index != self.selected:
            self.selected = index
            self.update()
            self.segment_selected.emit(index)
        self.seek_requested.emit(time)

    def mouseMoveEvent(self, event):
        x = event.position().x()
        if self._drag is None:
            self.setCursor(Qt.SizeHorCursor if self._hit(x) else Qt.ArrowCursor)
            return
        self._move(self._drag, self._time_at(x))
        self.update()

    def _move(self, edge: str, time: float):
        low, high = self._bounds(self.selected)
        span = self.segments[self.selected]
        gap = max(_MIN_SEGMENT, self.min_length)
        if edge == "start":
            start = max(low, min(time, span.end - gap))
            self.segments[self.selected] = SpeechSpan(start, span.end)
        else:
            end = min(high, max(time, span.start + gap))
            self.segments[self.selected] = SpeechSpan(span.start, end)

    def mouseReleaseEvent(self, event):
        if self._drag is not None:
            self._drag = None
            self.segment_changed.emit(self.selected, self.cut_start, self.cut_end)

    def nudge(self, edge: str, delta: float):
        if self.empty:
            return
        span = self.segments[self.selected]
        self._move(edge, (span.start if edge == "start" else span.end) + delta)
        self.update()
        self.segment_changed.emit(self.selected, self.cut_start, self.cut_end)
