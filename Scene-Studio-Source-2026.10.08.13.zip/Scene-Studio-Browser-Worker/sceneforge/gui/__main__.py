"""Launch the application window (9 Sigma Automation or 9 Sigma Omni Flow,
whichever sceneforge/product.py says this install is).

    python -m sceneforge.gui                     open empty
    python -m sceneforge.gui "path\\to\\clips"     open that folder and start analysing
"""
from __future__ import annotations

import sys
from pathlib import Path

# Qt must be imported before onnxruntime or the process segfaults on Windows.
# Importing QApplication here guarantees the right order no matter what the
# analysis code pulls in later. See _claim_dll_slot_before_onnx in vad.py.
from PySide6.QtWidgets import QApplication, QMessageBox

from ..config import Config
from ..logging_setup import LOG_FILE, get, install_exception_hook, setup
from .branding import APP_NAME, app_icon
from .main_window import MainWindow
from .master_page import wait_for_orphans


def main(argv=None) -> int:
    argv = sys.argv if argv is None else argv

    setup()
    log = get("gui")

    folder = None
    if len(argv) > 1:
        candidate = Path(argv[1])
        if candidate.is_dir():
            folder = candidate
        else:
            print("Not a folder: {}".format(candidate), file=sys.stderr)
            log.error("Folder argument is not a directory: %s", candidate)
            return 1

    app = QApplication(argv[:1])
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(APP_NAME)
    app.setWindowIcon(app_icon())

    def report(text: str) -> None:
        """A GUI has no console, so show the crash and say where the log is."""
        QMessageBox.critical(
            None,
            APP_NAME + " hit an error",
            "Something went wrong. The full details are in:\n\n{}\n\n{}".format(
                LOG_FILE, text.strip().splitlines()[-1] if text.strip() else ""),
        )

    install_exception_hook(report)

    window = MainWindow(Config.load(Path.cwd()))
    window.show()
    log.info("Window shown")

    if folder is not None:
        log.info("Opening folder from command line: %s", folder)
        window.open_folder(folder, analyse_now=True)

    code = app.exec()
    # Quit can arrive without a close (the update installer asks for it), so
    # the page is told to stop here too; and a step the window could not
    # wait out finishes before the process ends, because a thread that is
    # still running at exit takes the process down with it.
    window.master_page.shutdown()
    wait_for_orphans()
    return code


if __name__ == "__main__":
    raise SystemExit(main())
