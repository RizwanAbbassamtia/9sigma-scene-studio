"""Command line entry point.

    python -m sceneforge.cli scan  <folder>
    python -m sceneforge.cli plan  <folder>
    python -m sceneforge.cli build <folder> -o episode.mp4
    python -m sceneforge.cli worker <master folder> --mock|--live [--once]
"""
from __future__ import annotations

import argparse
import sys
import time
from collections import Counter
from pathlib import Path

from .assemble import planned_seconds
from .auth import AuthError, UserStore, generate_password
from .autocut import calibrate_chars_per_second
from .config import Config
from .ingest import missing_scene_numbers, scan
from .models import Episode, Flag, ReviewState


def _fmt(seconds: float) -> str:
    minutes, secs = divmod(int(round(seconds)), 60)
    return "{}m {:02d}s".format(minutes, secs)


def _bar(done: int, total: int, label: str) -> None:
    """Live bar on a terminal; sparse lines when the output is piped to a file."""
    if sys.stdout.isatty():
        width = 28
        filled = int(width * done / max(1, total))
        count = "{}%".format(done // 10) if total == 1000 else "{}/{}".format(done, total)
        sys.stdout.write("\r  [{}{}] {}  {:<90}".format(
            "#" * filled, "." * (width - filled), count, label[:90]))
        sys.stdout.flush()
        if done >= total:
            sys.stdout.write("\n")
    else:
        # Piped to a file: one line per tenth of the job, and the last one.
        tenth = done * 10 // max(1, total)
        if done == total or tenth != getattr(_bar, "last_tenth", -1):
            _bar.last_tenth = tenth
            count = "{}%".format(done // 10) if total == 1000 else "{}/{}".format(done, total)
            print("  {}  {}".format(count, label))


def report_scan(episode: Episode, config: Config) -> None:
    clips = episode.clips
    print("Episode : {}".format(episode.name))
    print("Script  : {}".format(episode.script_path.name if episode.script_path else "NOT FOUND"))
    if not clips:
        print("No video files found.")
        return
    numbers = [c.number for c in clips]
    print("Clips   : {}  (numbered {}..{})".format(len(clips), min(numbers), max(numbers)))

    probed = [c for c in clips if c.media and c.media.duration > 0]
    if probed:
        shapes = Counter("{} {} {}fps {}".format(
            c.media.resolution, c.media.video_codec, c.media.fps,
            "audio" if c.media.has_audio else "NO AUDIO") for c in probed)
        for shape, count in shapes.most_common():
            print("          {:>4} x  {}".format(count, shape))
        print("Runtime : {} of source footage".format(_fmt(sum(c.media.duration for c in probed))))

    with_d = [c for c in clips if c.scene and c.scene.has_dialogue]
    no_d = [c for c in clips if c.scene and not c.scene.has_dialogue]
    print("Script  : {} with dialogue, {} 'no says'".format(len(with_d), len(no_d)))
    missing = missing_scene_numbers(episode)
    if missing:
        print("          scenes with no clip: {}".format(", ".join(map(str, missing[:12]))))


def report_plan(episode: Episode, config: Config) -> None:
    clips = episode.clips
    source = episode.source_seconds
    # The assembler's own arithmetic, so `plan` quotes the length `build`
    # produces -- a dissolve join overlaps its two clips and shortens the total.
    planned = planned_seconds(episode, config)
    dropped = [c for c in clips if c.state == ReviewState.REJECTED]

    print()
    print("CUT PLAN")
    print("  source runtime  : {}".format(_fmt(source)))
    print("  planned runtime : {}   (saves {}, {:.0f}%)   [joins decided at export]".format(
        _fmt(planned), _fmt(source - planned),
        100 * (source - planned) / max(1e-9, source)))
    if dropped:
        print("  clips dropped   : {}".format(len(dropped)))
    jumps = [c for c in clips if c.is_jump_cut]
    if jumps:
        print("  mid-clip cuts   : {} clips (these produce visible jump cuts)".format(len(jumps)))

    speaking = [c for c in clips if c.scene and c.scene.has_dialogue and c.speech]
    if speaking:
        rate = calibrate_chars_per_second(episode)
        if rate:
            print("  measured pace   : {:.1f} chars/sec  (config has {:.1f})".format(
                rate, config.chars_per_second))

    flags = Counter()
    for clip in clips:
        for flag in clip.flags:
            flags[flag] += 1
    print()
    if flags:
        print("NEEDS A LOOK")
        for flag, count in flags.most_common():
            examples = [str(c.number) for c in clips if flag in c.flags][:10]
            print("  {:<22} {:>3}   clips {}".format(flag.value, count, ", ".join(examples)))
    else:
        print("NEEDS A LOOK: nothing flagged.")

    clean = [c for c in clips if not c.flags and c.state != ReviewState.REJECTED]
    print()
    print("  {} of {} clips are clean and need no human review".format(len(clean), len(clips)))


def _user_command(args) -> int:
    """Account management. Passwords are shown once and never stored in clear."""
    store = UserStore(Path.cwd())

    if args.user_command == "list":
        users = store.list_users()
        if not users:
            print("No accounts on this machine yet.")
            print("Create one with:  9sigma-cli.bat user add <username>")
            return 0
        print("{:<20} {:<24} {:<8} {}".format("USERNAME", "NAME", "ROLE", "LAST SIGN-IN"))
        for user in users:
            print("{:<20} {:<24} {:<8} {}".format(
                user.username, user.display_name[:23], user.role,
                user.last_login or "never"))
        return 0

    if args.user_command == "add":
        try:
            user, password = store.add(args.username, display_name=args.name,
                                       role=args.role)
        except AuthError as exc:
            print("error: {}".format(exc), file=sys.stderr)
            return 1
        print()
        print("  Account created on this machine")
        print("  ------------------------------------")
        print("  Username : {}".format(user.username))
        print("  Password : {}".format(password))
        print()
        print("  Write this down and give it to the editor now. It is stored")
        print("  only as a hash, so it cannot be read back or recovered -- if")
        print("  it is lost, set a new one with:  user passwd {}".format(user.username))
        print()
        return 0

    if args.user_command == "remove":
        if store.remove(args.username):
            print("Removed {}".format(args.username))
            return 0
        print("No such user: {}".format(args.username), file=sys.stderr)
        return 1

    if args.user_command == "passwd":
        password = generate_password()
        try:
            store.set_password(args.username, password)
        except AuthError as exc:
            print("error: {}".format(exc), file=sys.stderr)
            return 1
        print()
        print("  New password for {} : {}".format(args.username, password))
        print("  Give it to them now; it cannot be shown again.")
        print()
        return 0

    return 1


def _utf8_streams() -> None:
    """A worker run at night has its output sent to a file, and Python
    opens that file in the ANSI code page, which cannot hold an Urdu title
    or niche: the first such line would end the run with a traceback. A
    console keeps its own encoding but stops raising on the odd character."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            if stream.isatty():
                reconfigure(errors="replace")
            else:
                reconfigure(encoding="utf-8", errors="replace")
        except (OSError, ValueError):
            pass


def _print_worker_plan(records, queued, live: bool) -> None:
    for record in records:
        count = sum(1 for j in queued if j.framework_id == record.framework_id)
        cap = (getattr(record, "generation_settings", None) or {}).get("max_generations")
        note = ""
        if not record.enabled:
            note = "  (disabled: skipped)"
        elif live and not (isinstance(cap, int) and not isinstance(cap, bool) and cap > 0):
            note = "  (no generation limit: its titles are refused in live mode)"
        print("  {:<24} {:<20} {:<16} {} queued{}".format(
            record.framework_id[:24], (record.niche or "")[:20], (record.editor_name or "")[:16], count, note))
    if not records:
        print("  no framework records yet")


def _worker_command(args) -> int:
    """The master-log worker from a terminal, for a machine that runs it
    unattended. Settings come from the app's own folder rather than the
    shell's current directory, so its exports match the GUI's; the log file
    is opened before anything else, so a crash at night leaves a trace; and
    with neither --mock nor --live it only says what it would do, because
    this is the one command that spends money without a click per title."""
    import signal
    from .logging_setup import setup
    from .production.credentials import Credentials
    from .production.master import MasterLog
    from .production.notify import EmailSettings, Notifier
    from .production.worker import (
        MasterWorker, WorkerEvent, budget_text, live_budget_problem, make_providers, poll_interval,
    )

    _utf8_streams()
    root = Path(__file__).resolve().parent.parent
    config = Config.load(root)
    log_file = setup()
    folder = Path(args.folder)
    try:
        master = MasterLog(folder)
        records = list(master.records())
        queued = list(master.jobs(status="queued"))
    except (OSError, ValueError) as exc:
        print("error: the master log at {} could not be read: {}".format(folder, exc), file=sys.stderr)
        return 1
    live = bool(args.live)
    if not args.mock and not live:
        print("Neither --mock nor --live was given, so nothing was started. With one of them this would run:")
        _print_worker_plan(records, queued, live=True)
        print("Add --mock (no keys, no cost, test-pattern clips) or --live (real keys; every clip is paid for).")
        return 2
    problem = live_budget_problem(config.worker_max_generations, config.worker_max_titles) if live else ""
    if problem:
        print("error: {}".format(problem), file=sys.stderr)
        return 2
    # A config with no interval (0, or the key missing) gets the worker's
    # floor, never a loop on the share's lock; the line says what will run.
    try:
        poll_seconds = poll_interval(float(getattr(config, "worker_poll_minutes", 0) or 0) * 60.0)
    except (TypeError, ValueError):
        poll_seconds = poll_interval(0)
    print("Master log : {}".format(folder))
    print("Mode       : {}".format("LIVE: real keys, every clip is paid for" if live
                                   else "test mode: mock providers, no keys, no cost"))
    print("Budget     : {} clips, {} titles for this run (config.json: worker_max_generations, "
          "worker_max_titles)".format(budget_text(config.worker_max_generations),
                                      budget_text(config.worker_max_titles)))
    print("Polling    : every {:g} min; Ctrl+C stops after the current step".format(poll_seconds / 60.0))
    print("Log file   : {}".format(log_file))
    _print_worker_plan(records, queued, live)
    credentials = Credentials()
    notifier = Notifier(EmailSettings.load(), credentials)
    frameworks = master.frameworks

    def on_event(event):
        if isinstance(event, WorkerEvent):
            print(event.line(), flush=True)
        elif isinstance(event, str):
            print("  " + event, flush=True)

    worker = MasterWorker(master, frameworks, config,
                          lambda record, is_live: make_providers(credentials, record, is_live, config),
                          notifier=notifier, on_event=on_event, poll_seconds=poll_seconds,
                          max_generations=config.worker_max_generations, max_jobs=config.worker_max_titles,
                          live=live)
    # Ctrl+C is a Stop press: the step in hand finishes, the job goes back
    # to the queue with a note, and nothing is left half-written.
    signal.signal(signal.SIGINT, lambda *_: worker.stop.set())
    worker.run_forever(once=bool(args.once))
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="sceneforge")
    sub = parser.add_subparsers(dest="command", required=True)

    p_scan = sub.add_parser("scan", help="inspect a clip folder and its script")
    p_scan.add_argument("folder", type=Path)

    p_plan = sub.add_parser("plan", help="detect speech and compute cut points")
    p_plan.add_argument("folder", type=Path)

    p_user = sub.add_parser("user", help="manage who can sign in on this machine")
    user_sub = p_user.add_subparsers(dest="user_command", required=True)
    u_add = user_sub.add_parser("add", help="create an account")
    u_add.add_argument("username")
    u_add.add_argument("--name", default="", help="display name, if different")
    u_add.add_argument("--role", default="editor", choices=["editor", "admin"])
    user_sub.add_parser("list", help="show the accounts on this machine")
    u_rm = user_sub.add_parser("remove", help="delete an account")
    u_rm.add_argument("username")
    u_pw = user_sub.add_parser("passwd", help="set a new password")
    u_pw.add_argument("username")

    p_build = sub.add_parser("build", help="plan, then export the finished episode")
    p_build.add_argument("folder", type=Path)
    p_build.add_argument("-o", "--output", type=Path, default=None)
    p_build.add_argument("--keep-segments", type=Path, default=None,
                         help="keep the individual trimmed clips in this folder")

    p_worker = sub.add_parser("worker", help="run the master-log worker: queued titles to exported videos, unattended")
    p_worker.add_argument("folder", type=Path, help="the master log folder (local, mapped drive or share)")
    mode = p_worker.add_mutually_exclusive_group()
    mode.add_argument("--mock", action="store_true", help="mock providers: no keys, no cost, test-pattern clips")
    mode.add_argument("--live", action="store_true", help="real providers from the sealed keys; every clip is paid for")
    p_worker.add_argument("--once", action="store_true",
                          help="work through what is queued now, then exit instead of polling")

    args = parser.parse_args(argv)

    if args.command == "worker":
        return _worker_command(args)

    config = Config.load(Path.cwd())

    if args.command == "user":
        return _user_command(args)

    try:
        if args.command == "scan":
            report_scan(scan(args.folder, config), config)
            return 0

        from .pipeline import analyse

        print("Analysing {}".format(args.folder))
        started = time.time()
        episode = analyse(args.folder, config, progress=_bar)
        print("  voice detection took {:.0f}s".format(time.time() - started))
        report_scan(episode, config)
        report_plan(episode, config)

        if args.command == "plan":
            print()
            print("Nothing was written. Run `build` to export the episode.")
            return 0

        from .assemble import build as assemble_build

        output = args.output or (Path(config.output_dir) / (episode.name[:60] + ".mp4"))
        print()
        print("Building {}".format(output))
        started = time.time()
        assemble_build(episode, config, output, include_pending=True,
                       progress=_bar, keep_segments_dir=args.keep_segments)
        size = output.stat().st_size / (1024 * 1024)
        print("  done in {:.0f}s  ->  {:.1f} MB".format(time.time() - started, size))
        return 0

    except Exception as exc:                                  # noqa: BLE001
        print("error: {}".format(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
