'use strict';
const $ = id => document.getElementById(id);
const token = location.hash.slice(1) || sessionStorage.getItem('omni-token') || '';
if (location.hash) { sessionStorage.setItem('omni-token', token); history.replaceState(null, '', location.pathname); }
let accounts = [], order = [], selected = new Set(), selectedScenes = new Set(), currentRun = '', busy = false, pollInProgress = false;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notice(message, error=false) { $('notice').hidden=false; $('notice').className=error?'error':''; $('notice').textContent=message; }
async function api(path, data) {
  const response = await fetch('/api/'+path, {method:data===undefined?'GET':'POST', headers:{'X-Omni-Token':token,'Content-Type':'application/json'}, body:data===undefined?undefined:JSON.stringify(data)});
  const result = await response.json(); if(!response.ok) throw new Error(result.error || 'Request failed'); return result;
}
async function action(path, data) { try {const value=await api(path,data); await refresh(); return value;} catch(e){notice(e.message,true);return null;} }
let accountPage = 0;
const PAGE_SIZE = 25;
function bothConnected(a) { return ['flow','gemini'].every(p=>a.connections?.[p]?.state==='connected'); }
function connectionLabel(a,provider) {
  const c=a.connections?.[provider]; const title=provider==='flow'?'Flow':'Gemini';
  const label=c?.state==='connected'?'Connected':c?.state==='waiting'?'Waiting for sign-in':c?.state==='needs_login'?'Sign in again':'Not connected';
  const checked=c?.checked_at ? new Date(c.checked_at*1000).toLocaleString() : '';
  return `<span class="connection-badge ${c?.state==='connected'?'connected':''}" title="${esc(checked)}">${title}: ${label}</span>`;
}
function renderAccounts() {
  const map = new Map(accounts.map(a=>[a.id,a]));
  const query=$('account-search').value.trim().toLowerCase(), filter=$('account-filter').value;
  const visible=order.filter(id=>{const a=map.get(id);return a && a.email.toLowerCase().includes(query) && (filter==='all'||filter==='connected'&&bothConnected(a)||filter==='needs_login'&&!bothConnected(a)||filter==='selected'&&selected.has(id));});
  const pages=Math.max(1,Math.ceil(visible.length/PAGE_SIZE));accountPage=Math.min(accountPage,pages-1);
  const shown=visible.slice(accountPage*PAGE_SIZE,(accountPage+1)*PAGE_SIZE);
  $('account-count').textContent=`${accounts.length} accounts · ${accounts.filter(bothConnected).length} connected · ${selected.size} selected`;
  $('account-page').textContent=`Page ${accountPage+1} of ${pages}`;
  $('accounts-prev').disabled=accountPage===0; $('accounts-next').disabled=accountPage>=pages-1;
  $('login-next').disabled=busy||!accounts.some(a=>!bothConnected(a));
  $('accounts').innerHTML=shown.map(id=>{const a=map.get(id),index=order.indexOf(id);return `<div class="account"><div class="account-top"><input type="checkbox" data-select="${esc(id)}" ${selected.has(id)?'checked':''} ${a.status==='paused'||busy?'disabled':''} aria-label="Use ${esc(a.email)}"><strong>${esc(a.email)}</strong><span class="order"><button class="secondary" data-move="${index}" data-delta="-1" aria-label="Move ${esc(a.email)} up">↑</button><button class="secondary" data-move="${index}" data-delta="1" aria-label="Move ${esc(a.email)} down">↓</button></span></div><div class="connection-badges">${connectionLabel(a,'flow')}${connectionLabel(a,'gemini')}</div><div class="account-balance">Flow: ${a.credits_last_seen} recorded credits · Gemini: ${a.gemini_remaining}/3 local attempts left${a.gemini_usage?.next_slot_at?' · Next local slot '+esc(new Date(a.gemini_usage.next_slot_at*1000).toLocaleString()):''}</div><div class="account-actions"><button data-connect="${esc(id)}" data-provider="both">${bothConnected(a)?'Check sign-in':'Sign in'}</button><button class="secondary" data-connect="${esc(id)}" data-provider="flow">Flow only</button><button class="secondary" data-connect="${esc(id)}" data-provider="gemini">Gemini only</button><button class="secondary" data-password="${esc(id)}">Login password</button><button class="secondary" data-edit="${esc(id)}">Credits / plan</button></div></div>`;}).join('')||'<div class="empty-accounts"><b>No accounts to show</b><p>Add your Gmail addresses or change the search filter.</p></div>';
  $('accounts').querySelectorAll('button').forEach(b=>b.disabled=busy&&!b.dataset.password);
}
$('account-search').oninput=()=>{accountPage=0;renderAccounts();};
$('account-filter').onchange=()=>{accountPage=0;renderAccounts();};
$('accounts-prev').onclick=()=>{accountPage--;renderAccounts();};
$('accounts-next').onclick=()=>{accountPage++;renderAccounts();};
$('open-add').onclick=()=>{$('import-message').textContent='';$('add-dialog').showModal();$('emails').focus();};
$('cancel-add').onclick=()=>$('add-dialog').close();
$('login-next').onclick=()=>{const a=order.map(id=>accounts.find(a=>a.id===id)).find(a=>a&&!bothConnected(a));if(a)action('connect',{id:a.id,provider:'both'});};
$('cancel-login').onclick=()=>action('stop',{});
function editAccount(id) {
  const a=accounts.find(a=>a.id===id); $('edit-id').value=id; $('account-email').textContent=a.email;
  $('edit-daily').value=a.daily_credits; $('edit-daily-remaining').value=a.daily_remaining; $('edit-monthly').value=a.monthly_credits;
  $('edit-other').value=Math.max(0,a.credits_last_seen-a.daily_remaining); $('edit-renewal').value=a.renews_on_day; $('edit-paused').checked=a.status==='paused'; $('account-dialog').showModal();
}
$('accounts').addEventListener('change', e=>{const id=e.target.dataset.select;if(id){e.target.checked?selected.add(id):selected.delete(id);renderAccounts();}});
$('accounts').addEventListener('click',async e=>{
  const b=e.target.closest('button');if(!b)return;
  if(b.dataset.move!==undefined){const i=+b.dataset.move,j=i+(+b.dataset.delta);if(j>=0&&j<order.length){[order[i],order[j]]=[order[j],order[i]];localStorage.setItem('omni-order',JSON.stringify(order));renderAccounts();}}
  if(b.dataset.connect)await action('connect',{id:b.dataset.connect,provider:b.dataset.provider});
  if(b.dataset.edit)editAccount(b.dataset.edit);
  if(b.dataset.password)await openPassword(b.dataset.password);
});
$('account-form').addEventListener('submit',async e=>{e.preventDefault();const r=await action('account',{id:$('edit-id').value,daily:+$('edit-daily').value,daily_remaining:+$('edit-daily-remaining').value,monthly:+$('edit-monthly').value,other_remaining:+$('edit-other').value,renewal:+$('edit-renewal').value,paused:$('edit-paused').checked});if(r)$('account-dialog').close();});
$('cancel-account').onclick=()=>$('account-dialog').close();
$('import').onclick=async()=>{
  $('import').disabled=true;$('import-message').textContent='Adding accounts…';
  try {const r=await api('import',{emails:$('emails').value});$('emails').value='';$('add-dialog').close();notice(`${r.added} accounts added; ${r.skipped} duplicates skipped. Click Sign in beside each account to complete Google login.`);if(!selected.size&&r.accounts.length)selected.add(r.accounts[0]);await refresh();}
  catch(e){$('import-message').textContent=e.message;}
  finally{$('import').disabled=busy;}
};
$('prompt-file').onchange=async e=>{const file=e.target.files[0];if(file){if(file.size>2000000){notice('Prompt file is too large',true);return;}$('prompts').value=await file.text();}};
$('start').onclick=async()=>{
  const result=await action('create',{prompts:$('prompts').value,accounts:order.filter(id=>selected.has(id)),settings:{model:$('model').value,aspect:$('aspect').value,resolution:$('resolution').value,duration:$('duration').value},budget:$('budget').value?+$('budget').value:null,gemini_limit:+$('gemini-limit').value});
  if(result){currentRun=result.run;selectedScenes.clear();await refresh();}
};
$('stop').onclick=()=>action('stop',{});
$('refresh').onclick=()=>refresh();
$('open-root').onclick=()=>action('folder',{});
$('folder').onclick=()=>currentRun&&action('folder',{run:currentRun});
$('runs').onchange=()=>{currentRun=$('runs').value;selectedScenes.clear();loadRun();};
$('resume').onclick=()=>currentRun&&action('resume',{run:currentRun});
$('retry').onclick=async()=>{
  if(!currentRun||!selectedScenes.size){notice('Select unfinished scenes first.',true);return;}
  const reviewed=confirm('For scenes marked REVIEW: check the Google conversation and local files first. Continue only if no usable video exists. Retrying can consume allowance. Confirm retry of the selected scenes?');
  if(reviewed){const r=await action('retry',{run:currentRun,numbers:[...selectedScenes],reviewed:true});if(r)selectedScenes.clear();}
};
async function download(name){try{const response=await fetch(`/api/file?run=${encodeURIComponent(currentRun)}&name=${encodeURIComponent(name)}`,{headers:{'X-Omni-Token':token}});if(!response.ok)throw new Error((await response.json()).error);const url=URL.createObjectURL(await response.blob());const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}catch(e){notice(e.message,true);}}
$('export').onclick=()=>currentRun&&download('retry-prompts.txt');
$('export-review').onclick=()=>currentRun&&download('review-prompts.txt');
$('scenes').addEventListener('change',e=>{if(e.target.dataset.scene){const n=+e.target.dataset.scene;e.target.checked?selectedScenes.add(n):selectedScenes.delete(n);}});
$('scenes').addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.download)download(b.dataset.download);if(b.dataset.accept&&confirm('Accept this saved video after reviewing its content and format?'))await action('accept',{run:currentRun,number:+b.dataset.accept});});
function outputName(scene){ return scene.file ? scene.file.split(/[\\/]/).pop() : ''; }
async function loadRun(){if(!currentRun)return;try{const r=await api('run?run='+encodeURIComponent(currentRun));$('total').textContent=r.rows.length;$('done').textContent=r.rows.filter(x=>x.status==='done').length;$('pending').textContent=r.rows.filter(x=>x.status!=='done').length;$('stage').textContent=r.stage;
  $('scenes').innerHTML=r.rows.map(s=>`<tr><td>${s.status!=='done'?`<input type="checkbox" data-scene="${s.number}" ${selectedScenes.has(s.number)?'checked':''} aria-label="Select scene ${s.number}">`:''}</td><td>${s.number}</td><td class="prompt-cell">${esc(s.prompt)}</td><td><span class="status ${esc(s.status)}">${esc(s.status)}</span>${s.note?`<div class="row-note">${esc(s.note)}</div>`:''}</td><td>${esc(s.provider||'—')}<br>${esc(s.account||'')}</td><td>${s.file?`<button class="secondary" data-download="${esc(outputName(s))}">Download</button>`:''}${s.status==='review'&&s.file?`<button class="secondary" data-accept="${s.number}" ${busy?'disabled':''}>Accept saved clip</button>`:''}</td></tr>`).join('');
}catch(e){notice(e.message,true);}}
async function refresh(){if(pollInProgress)return;pollInProgress=true;try{const s=await api('state');busy=s.busy;accounts=s.accounts;
  if(!order.length){try{order=JSON.parse(localStorage.getItem('omni-order')||'[]');if(!Array.isArray(order))order=[];}catch{order=[];}}
  order=[...new Set([...order,...accounts.map(a=>a.id)])].filter(id=>accounts.some(a=>a.id===id));
  accounts.forEach(a=>{if(a.status==='paused')selected.delete(a.id);});renderAccounts();
  if(!currentRun)currentRun=s.current||s.runs[0]||'';
  $('runs').innerHTML=s.runs.map(r=>`<option value="${esc(r)}" ${r===currentRun?'selected':''}>${esc(r)}</option>`).join('')||'<option value="">No saved runs yet</option>';
  $('connection-panel').hidden=!s.connection;if(s.connection){$('connection-title').textContent='Sign in: '+s.connection.email;$('connection-message').textContent='Opening '+(s.connection.provider==='flow'?'Google Flow':'Gemini')+'. Enter your password and verification on Google in the Chrome window. Keep this page open; the status updates automatically.';}$('activity').textContent=s.connection?'Waiting for Google sign-in':busy?'Working…':'Ready';$('stop').disabled=!busy;['start','import','open-add','resume','retry'].forEach(id=>$(id).disabled=busy);$('log').textContent=s.messages.join('\n')||'Ready when you are.';$('output-path').textContent='Saved on this computer: '+s.output;await loadRun();
}catch(e){notice(e.message,true);}finally{pollInProgress=false;}}
refresh();setInterval(refresh,2500);

function syncModelSettings() {
  const veo = $('model').value.startsWith('Veo');
  for (const option of $('duration').options) option.disabled = veo && option.value === '10s';
  for (const option of $('resolution').options) option.disabled = veo && option.value === '360p';
  if (veo && $('duration').value === '10s') $('duration').value = '8s';
  if (veo && $('resolution').value === '360p') $('resolution').value = '720p';
}
$('model').addEventListener('change', syncModelSettings);
syncModelSettings();

let passwordAccount = '', passwordTimer;
async function openPassword(id) {
  try {
    const result = await api('login-password', {id});
    passwordAccount=id;
    $('password-email').textContent=accounts.find(a=>a.id===id).email;
    $('login-password').type='password';
    $('login-password').value=result.password;
    $('password-status').textContent='Paste the password into Google. Enter the authentication code yourself.';
    $('password-dialog').showModal();
    clearTimeout(passwordTimer);passwordTimer=setTimeout(()=>$('password-dialog').close(),60000);
  } catch(e){notice(e.message,true);}
}
$('password-close').onclick=()=>$('password-dialog').close();
$('password-dialog').addEventListener('close',()=>{clearTimeout(passwordTimer);$('login-password').value='';passwordAccount='';});
$('password-show').onclick=()=>{$('login-password').type=$('login-password').type==='password'?'text':'password';};
$('password-copy').onclick=async()=>{try{await navigator.clipboard.writeText($('login-password').value);$('password-status').textContent='Copied. Paste into Google; enter your verification code manually.';}catch{$('password-status').textContent='Clipboard unavailable. Use Show and copy manually.';}};
$('password-save').onclick=async()=>{try{await api('save-login-password',{id:passwordAccount,password:$('login-password').value});$('password-status').textContent='Saved locally, protected by your Windows user account. An empty password removes the saved entry.';}catch(e){$('password-status').textContent=e.message;}};
