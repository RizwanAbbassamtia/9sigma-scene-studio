'use strict';
const poolPanel=document.createElement('section');poolPanel.className='card';
poolPanel.style.marginBottom='20px';
poolPanel.innerHTML=`<h2>Managed Google account pool</h2><p>Our own persistent Chrome profiles. No ixBrowser connection is required. Import Gmail addresses below; each receives a separate profile automatically.</p><details><summary>Multiple Gmails in one profile</summary><p>Map existing addresses: email,profile name,Google slot (starting at 0). Changing a mapping requires signing in and verifying the account again.</p><textarea id="pool-rows" rows="4" placeholder="name@gmail.com,video-team-1,0"></textarea><button id="pool-map">Save profile mappings</button></details><p id="pool-status" role="status"></p><div style="max-height:320px;overflow:auto"><table><thead><tr><th>Gmail</th><th>Profile</th><th>Google slot</th><th>Status</th></tr></thead><tbody id="pool-list"></tbody></table></div><p>All sessions remain on this worker computer. Users submit jobs through the main portal.</p>`;
document.querySelector('main').prepend(poolPanel);
const basePoolApi=api;
api=async function(path,data){
 if(data && ['create','connect'].includes(path))data={...data,transport:'managed'};
 const result=await basePoolApi(path,data);
 if(path==='state')$('pool-list').innerHTML=(result.managed_pool||[]).map(a=>`<tr><td>${esc(a.email)}</td><td>${esc(a.profile_id)}</td><td>${a.google_slot}</td><td>${esc(a.status)}</td></tr>`).join('');
 return result;
};
$('pool-map').onclick=async()=>{const r=await action('pool-map',{rows:$('pool-rows').value});if(r){$('pool-rows').value='';$('pool-status').textContent='Saved. Verify Google sign-in for each changed account.';}};
