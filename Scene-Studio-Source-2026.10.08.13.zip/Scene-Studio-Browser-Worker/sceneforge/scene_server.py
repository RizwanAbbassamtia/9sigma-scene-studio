"""Local-only scene dashboard; no hosting account or extra web framework needed."""
import argparse
from dataclasses import asdict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import re
import secrets
import threading
from urllib.parse import parse_qs, urlparse
import webbrowser
from urllib.request import Request, urlopen

from .production.flow_accounts import FlowAccountBook
from .production.master import MasterLog
from .production.flow_browser import FlowBrowser
from .production.flow_browser_run import BrowserSettings
from .production.gemini_browser import GeminiBrowser
from .production.prompts import parse_report
from .production.providers import validate_clip
from .production.scene_queue import SceneQueue, GeminiUsage, browser_lock, execute_queue
from .production.scene_connections import ConnectionBook
from .production.login_vault import LoginVault
from .production.managed_pool import ManagedPool
from .production.profile_proxy import ProfileProxies, password_storage_available
from .production.profile_network import check_profile_connection
from .production.manual_browser import open_manual_profile
from .production.saved_profiles import generation_account
from .production.output_recovery import recovery_record, recover_scene_output


class SceneService:
    def __init__(self, root, accounts_folder):
        self.root = Path(root).resolve()
        if str(self.root).startswith('\\\\'):
            raise ValueError('Choose a local drive for browser profiles and runs')
        self.root.mkdir(parents=True, exist_ok=True)
        self.profiles = self.root / 'browser-profiles'
        self.runs = self.root / 'scene-runs'
        self.runs.mkdir(exist_ok=True)
        self.book = FlowAccountBook(MasterLog(accounts_folder))
        self.token = secrets.token_urlsafe(32)
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.worker = None
        self.messages = []
        self.current = None
        self.active_account = None
        self.last_renewal = 0
        self.connections = ConnectionBook(self.root)
        self.connection = None
        self.vault = LoginVault(self.root)
        self.pool = ManagedPool(self.root)
        self.proxy_password_storage = password_storage_available()
        self.shutting_down = False
        self.shutdown_callback = None
        self.network_checks = {}

    def generation_accounts(self):
        accounts = []
        seen = set()
        for item in self.book.accounts():
            if item.status == 'paused':
                continue
            try:
                candidate = generation_account(self.root, self.pool.account(asdict(item)), self.connections.get(item.id))
            except ValueError:
                continue
            if candidate['email'].casefold() not in seen:
                seen.add(candidate['email'].casefold())
                accounts.append(candidate)
        return accounts

    def log(self, message):
        with self.lock:
            checking = re.fullmatch(r'Checking (?:flow|gemini) / (FA-\d{3,}) saved session before submission', str(message))
            if checking:
                self.active_account = checking.group(1)
            self.messages.append(str(message)[:1000])
            self.messages = self.messages[-150:]

    def busy(self):
        return self.worker is not None and self.worker.is_alive()

    def folder(self, run):
        if not isinstance(run, str) or not re.fullmatch(r'\d{8}-\d{6}-\d{6}', run):
            raise ValueError('Invalid run identifier')
        folder = self.runs / run
        if not (folder / 'queue.sqlite').is_file():
            raise ValueError('Saved run was not found')
        return folder

    def state(self):
        import time
        with self.lock:
            if not self.busy() and time.time() - self.last_renewal > 60:
                self.book.renew()
                self.last_renewal = time.time()
            usage = GeminiUsage(self.root / 'gemini-usage.sqlite')
            try:
                accounts = []
                for account in self.book.accounts():
                    item = asdict(account)
                    # Avoid transmitting irrelevant private account notes/history to the page.
                    for key in ('notes', 'history'):
                        item.pop(key, None)
                    item['gemini_usage'] = usage.snapshot(account.email)
                    item['gemini_remaining'] = item['gemini_usage']['remaining']
                    item['connections'] = self.connections.get(account.id)
                    accounts.append(item)
            finally:
                usage.close()
            runs = sorted((p.name for p in self.runs.iterdir() if p.is_dir() and (p / 'queue.sqlite').is_file()), reverse=True)
            proxies = ProfileProxies(self.root)
            mappings = [{**row, 'proxy': proxies.summary(row['profile_id'])} for row in self.pool.data.values()]
            return dict(accounts=accounts, runs=runs, busy=self.busy(), current=self.current, shutting_down=self.shutting_down,
                        managed_pool=mappings, proxy_password_storage=self.proxy_password_storage,
                        messages=list(self.messages), output=str(self.runs), connection=self.connection,
                        login_workflow='manual-chrome-v1', network_checks=dict(self.network_checks),
                        generation_window_mode='headless', max_generation_profiles=1,
                        saved_profile_generation=6, existing_output_recovery=True,
                        generation_candidates=[{'id': a['id'], 'email': a['email']} for a in self.generation_accounts()])

    def launch(self, operation):
        with self.lock:
            if self.shutting_down:
                raise ValueError('Worker is restarting. Retry after it is ready.')
            if self.busy():
                raise ValueError('A browser operation is already running')
            self.stop.clear()
            def work():
                try:
                    with browser_lock(self.profiles):
                        operation()
                except Exception as exc:
                    self.log('Stopped: ' + str(exc))
                finally:
                    self.active_account = None
            self.worker = threading.Thread(target=work, daemon=False)
            self.worker.start()

    def start(self, run):
        folder = self.folder(run)
        saved = SceneQueue(folder)
        try:
            selected = saved.get('accounts') or []
            available = {a['id']: a for a in self.generation_accounts()}
            if any(account_id not in available for account_id in selected):
                raise ValueError('A selected profile has no unambiguous saved account for generation preflight. No prompt was submitted.')
            # Snapshot expected identities; every provider verifies these live.
            generation_accounts = [available[account_id] for account_id in selected]
        finally:
            saved.close()
        self.current = run
        def work():
            queue = SceneQueue(folder)
            usage = GeminiUsage(self.root / 'gemini-usage.sqlite')
            def observe(account_id, balance, cost):
                self.book.set_credits(account_id, balance, by='Google Flow browser', note='Live Flow balance')
                if cost is not None:
                    self.book.update(account_id, cost=cost, by='Google Flow browser')
            flow = FlowBrowser(self.profiles, folder, self.log, observe, headless=True)
            gemini = GeminiBrowser(self.profiles, folder, self.log, headless=True)
            try:
                accounts = generation_accounts
                self.log('Starting Flow → Gemini run ' + run)
                self.log(execute_queue(queue, accounts, flow, gemini, usage, self.log, self.stop.is_set))
            finally:
                queue.close()
                usage.close()
        self.launch(work)

    def post(self, action, data):
        with self.lock:
            if self.shutting_down:
                raise ValueError('Worker is restarting. Retry after it is ready.')
            if action == 'shutdown':
                if self.busy():raise ValueError('Finish or cancel the active browser operation before restarting the worker.')
                if self.shutdown_callback is None:raise ValueError('Worker shutdown is unavailable.')
                self.shutting_down = True
                threading.Thread(target=self.shutdown_callback, daemon=True).start()
                return {'stopping': True}
            if action == 'pool-proxy':
                if self.busy():raise ValueError('Wait for the active browser operation before changing its proxy.')
                account = self.pool.account(asdict(self.book.account(data['id'])))
                ProfileProxies(self.root).save(account['managed_profile'], data)
                self.network_checks.pop(account['id'], None)
                return {}
            if action == 'pool-proxy-test':
                if self.busy():raise ValueError('Cancel or finish the active sign-in before testing the connection.')
                account = self.pool.account(asdict(self.book.account(data['id'])))
                result = check_profile_connection(self.root, account['managed_profile'])
                self.network_checks[account['id']] = result
                self.log('Connection check for ' + account['id'] + ': ' + result['message'])
                return result
            if action == 'pool-map':
                if self.busy():raise ValueError('Wait for the active operation')
                self.pool.map(data.get('rows',''))
                return {}
            if action == 'pool-status':
                if self.busy():raise ValueError('Wait for the current operation')
                account = self.book.account(data['id'])
                if data.get('paused') is True:self.book.pause(account.id, by='Central admin')
                elif data.get('paused') is False:self.book.resume(account.id, by='Central admin')
                else:raise ValueError('Expected a paused flag')
                return {}
            if action in ('login-password', 'save-login-password'):

                account = self.book.account(data['id'])
                if action == 'save-login-password':
                    self.vault.save_many({account.email: data['password']})
                    return {}
                return {'password': self.vault.get(account.email)}
            if action == 'stop':
                self.stop.set()
                self.log('Cancelling sign-in…' if self.connection else
                         'Stopping after the current scene. Keep the browser open until it finishes.')
                return {}
            if action in ('connect', 'open-services'):
                account = asdict(self.book.account(data['id']))
                if data.get('transport') == 'managed':
                    account = self.pool.account(account)
                if self.busy() and self.active_account:
                    active = self.pool.account(asdict(self.book.account(self.active_account)))
                    if active.get('managed_profile', active['id']) == account.get('managed_profile', account['id']):
                        raise ValueError('This profile is generating a scene. Wait for that scene to finish before opening its login window. Other profiles remain available.')
                result = open_manual_profile(self.root, account, services=action == 'open-services')
                for service in ('flow', 'gemini'):
                    self.connections.record(account['id'], service, 'manual',
                                            'Saved Chrome profile. The generation worker will verify the live account before submitting.')
                self.log(account['id'] + ': ' + result['message'])
                if result['proxy_authentication']:
                    self.log('Chrome may request proxy authentication. Enter your proxy username and password in Chrome, then sign in to Google.')
                return result
            if self.busy():
                raise ValueError('Wait for the current browser operation to finish')
            if action == 'recover-output':
                run = data['run']
                folder = self.folder(run)
                number = int(data['number'])
                saved = SceneQueue(folder)
                try:
                    row, _, _ = recovery_record(saved, number)
                    account = next((a for a in self.generation_accounts() if a['id'] == row['account']), None)
                    if account is None:
                        raise ValueError('The original saved account is unavailable. Restore it before recovering the result.')
                finally:
                    saved.close()
                self.current = run
                def recover():
                    self.active_account = account['id']
                    queue = SceneQueue(folder)
                    browser = GeminiBrowser(self.profiles, folder, self.log, headless=True)
                    try:
                        recover_scene_output(queue, number, account, browser, self.log, self.stop.is_set)
                    finally:
                        queue.close()
                self.launch(recover)
                return {'run': run, 'number': number, 'new_generation': False}
            if action == 'import':
                raw = data.get('emails', '')
                if not isinstance(raw, str):
                    raise ValueError('Enter email addresses only')
                emails = [e for e in re.split(r'[\s,;]+', raw.strip()) if e]
                if not emails or len(emails) > 1000 or any(
                    not re.fullmatch(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}', e) for e in emails):
                    raise ValueError('Enter up to 1,000 email addresses only. Do not paste passwords or verification codes.')
                result = self.book.add_many(raw, daily=0, by='Local dashboard')
                self.pool.add(self.book.accounts())
                wanted = {e.casefold() for e in emails}
                result['accounts'] = [a.id for a in self.book.accounts() if a.email.casefold() in wanted]
                return result
            if action == 'account':
                account = self.book.account(data['id'])
                if int(data['daily_remaining']) > int(data['daily']):
                    raise ValueError('Daily remaining cannot exceed the allowance')
                self.book.update(account.id, monthly_credits=int(data['monthly']),
                                 renews_on_day=int(data['renewal']), daily_credits=int(data['daily']), by='Local dashboard')
                self.book.set_balances(account.id, int(data['daily_remaining']), int(data['other_remaining']), by='Local dashboard')
                if data.get('paused'):
                    self.book.pause(account.id, by='Local dashboard')
                else:
                    self.book.resume(account.id, by='Local dashboard')
                return {}
            if action == 'create':
                request_id = data.get('request_id')
                if request_id:
                    if not re.fullmatch(r'[a-f0-9-]{36}', request_id):
                        raise ValueError('Invalid job request identifier')
                    for saved in self.runs.iterdir():
                        if not (saved / 'queue.sqlite').is_file():continue
                        previous = SceneQueue(saved)
                        try:
                            if previous.get('request_id') == request_id:
                                return {'run': saved.name}
                        finally:previous.close()
                items, problems = parse_report(data['prompts'])
                if len(items) > 100:
                    raise ValueError('Use at most 100 prompts per batch')
                if problems or not items:
                    raise ValueError('Use numbered prompts: 1: scene… then 2: scene… ' + '; '.join(map(str, problems)))
                transport = data.get('transport', 'chrome')
                if transport not in ('chrome', 'managed'):
                    raise ValueError('Unknown browser transport')
                known = {a.id for a in self.book.accounts() if a.status != 'paused'}
                if transport == 'managed':
                    known &= {row['id'] for row in self.pool.data.values()}
                if not set(data['accounts']) <= known:
                    raise ValueError('An account is missing or paused')
                run = datetime.now().strftime('%Y%m%d-%H%M%S-%f')
                queue = SceneQueue(self.runs / run)
                try:
                    queue.create([item.prompt for item in items], data['accounts'], BrowserSettings(**data['settings']),
                                 data.get('budget'), data.get('gemini_limit', 3))
                    queue.put('transport', transport)
                    if request_id:queue.put('request_id', request_id)
                finally:
                    queue.close()
                if not data.get('defer_start'):
                    self.start(run)
                return {'run': run}
            if action in ('resume', 'retry', 'accept'):
                run = data['run']
                folder = self.folder(run)
                if action != 'resume':
                    queue = SceneQueue(folder)
                    try:
                        queue.recover()
                        if action == 'retry':
                            queue.retry(data['numbers'], data.get('reviewed') is True)
                        else:
                            number = int(data['number'])
                            row = next(r for r in queue.rows() if r['number'] == number)
                            path = Path(row['file']) if row['file'] else folder / 'missing'
                            if path.resolve().parent != folder.resolve():
                                raise ValueError('Saved video must be inside this run')
                            if row['status'] != 'review' or not path.is_file() or validate_clip(path):
                                raise ValueError('No valid saved review video exists for this scene')
                            queue.update(number, status='done', file=str(path), note='Saved video accepted after review')
                            queue.export()
                    finally:
                        queue.close()
                if action != 'accept':
                    if action == 'resume':
                        queue = SceneQueue(folder)
                        try:
                            if queue.get('stage') == 'complete':
                                queue.put('stage', 'flow')
                        finally:
                            queue.close()
                    self.start(run)
                return {'run': run}
            if action == 'folder':
                folder = self.folder(data['run']) if data.get('run') else self.runs
                if os.name == 'nt':
                    os.startfile(str(folder))
                return {'folder': str(folder)}
            raise ValueError('Unknown action')


class Handler(BaseHTTPRequestHandler):
    server_version = 'OmniFlowLocal/1.06'

    def log_message(self, *args):
        pass

    def send(self, data, status=200, content_type='application/json; charset=utf-8'):
        if not isinstance(data, bytes):
            data = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; media-src 'self' blob:; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(data)

    def allowed(self, auth=False):
        expected = f'127.0.0.1:{self.server.server_port}'
        if self.headers.get('Host') != expected:
            self.send({'error': 'Invalid local host'}, 403)
            return False
        origin = self.headers.get('Origin')
        if origin and origin != 'http://' + expected:
            self.send({'error': 'Cross-origin requests are blocked'}, 403)
            return False
        if auth and not secrets.compare_digest(self.headers.get('X-Omni-Token', ''), self.server.service.token):
            self.send({'error': 'Open the dashboard using its launcher to authenticate'}, 403)
            return False
        return True

    def do_GET(self):
        parsed = urlparse(self.path)
        if not self.allowed(parsed.path.startswith('/api/')):
            return
        try:
            service = self.server.service
            query = parse_qs(parsed.query)
            if parsed.path == '/api/state':
                self.send(service.state())
            elif parsed.path == '/api/run':
                queue = SceneQueue(service.folder(query['run'][0]))
                try:
                    self.send(dict(rows=queue.rows(), stage=queue.get('stage'), accounts=queue.get('accounts')))
                finally:
                    queue.close()
            elif parsed.path == '/api/file':
                folder = service.folder(query['run'][0])
                name = query['name'][0]
                if not re.fullmatch(r'(retry-prompts\.txt|review-prompts\.txt|unfinished-prompts\.json|\d{4,5}_(flow|gemini)(_attempt\d+)?\.mp4)', name):
                    raise ValueError('Invalid output file')
                path = folder / name
                self.send(path.read_bytes(), content_type='video/mp4' if name.endswith('.mp4') else 'text/plain; charset=utf-8')
            else:
                files = {'/': ('index.html', 'text/html'), '/app.js': ('app.js', 'text/javascript'), '/pool.js': ('pool.js', 'text/javascript'),
                         '/style.css': ('style.css', 'text/css'), '/accounts.css': ('accounts.css', 'text/css'),
                         '/guide': ('guide.html', 'text/html')}
                if parsed.path not in files:
                    self.send({'error': 'Not found'}, 404)
                    return
                name, kind = files[parsed.path]
                self.send((Path(__file__).parent / 'scene_web' / name).read_bytes(), content_type=kind + '; charset=utf-8')
        except (ValueError, KeyError, OSError) as exc:
            self.send({'error': str(exc)}, 400)

    def do_POST(self):
        if not self.allowed(True):
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 2_000_000:
                raise ValueError('Request is empty or too large')
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                raise ValueError('JSON requests only')
            data = json.loads(self.rfile.read(length))
            self.send(self.server.service.post(self.path.removeprefix('/api/'), data))
        except (ValueError, TypeError, KeyError, OSError, RuntimeError, StopIteration) as exc:
            self.send({'error': str(exc)}, 400)


def make_server(root, accounts_folder, port=8765):
    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.service = SceneService(root, accounts_folder)
    server.service.shutdown_callback = server.shutdown
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--accounts-folder', type=Path)
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    session = args.root / 'scene-server' / 'session.json'
    if session.exists() and not args.no_browser:
        try:
            saved = json.loads(session.read_text(encoding='utf-8'))
            port = int(saved['port'])
            if not 1 <= port <= 65535:
                raise ValueError('Invalid port')
            base = f'http://127.0.0.1:{port}/'
            request = Request(base + 'api/state', headers={'X-Omni-Token': saved['token']})
            with urlopen(request, timeout=2) as response:
                if response.status == 200:
                    webbrowser.open(base + '#' + saved['token'])
                    return
        except Exception:
            pass
    folder = args.accounts_folder
    if folder is None:
        config_path = args.root / 'config.json'
        config = json.loads(config_path.read_text(encoding='utf-8-sig')) if config_path.exists() else {}
        folder = Path(config['master_log_dir']) if config.get('master_log_dir') else args.root / 'scene-accounts'
    with browser_lock(args.root / 'scene-server'):
        server = make_server(args.root, folder, args.port)
        from .production.master import _write_atomic
        _write_atomic(session, json.dumps({'port': server.server_port, 'token': server.service.token}))
        url = f'http://127.0.0.1:{server.server_port}/#{server.service.token}'
        if not args.no_browser:
            webbrowser.open(url)
        print(f'Omni Flow dashboard: http://127.0.0.1:{server.server_port}/ (use the launcher to sign in)', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            server.service.stop.set()
        finally:
            server.server_close()
            if server.service.worker:
                server.service.worker.join()


if __name__ == '__main__':
    main()
