"""Self-test: check every dependency SceneForge needs before an editor hits a wall.

    python -m sceneforge.doctor
"""
from __future__ import annotations

import platform
import sys
from pathlib import Path

OK = "  OK   "
BAD = "  FAIL "
WARN = "  WARN "


def _check_python() -> bool:
    version = sys.version_info
    if version >= (3, 9):
        print(OK + "Python {}.{}.{}".format(*version[:3]))
        return True
    print(BAD + "Python {}.{} is too old, need 3.9 or newer".format(*version[:2]))
    return False


def _check_numpy() -> bool:
    try:
        import numpy
        print(OK + "numpy " + numpy.__version__)
        return True
    except ImportError as exc:
        print(BAD + "numpy missing ({})".format(exc))
        return False


def _check_onnx() -> bool:
    try:
        import onnxruntime
        print(OK + "onnxruntime " + onnxruntime.__version__)
        return True
    except ImportError as exc:
        message = str(exc)
        print(BAD + "onnxruntime will not load")
        if "DLL load failed" in message:
            print("         The Visual C++ runtime on this machine is too old for this build.")
            print("         Fix: .venv\\Scripts\\python.exe -m pip install onnxruntime==1.19.2")
        else:
            print("         " + message)
        return False


def _check_qt() -> bool:
    try:
        import PySide6
        from PySide6.QtMultimedia import QMediaPlayer  # noqa: F401
        print(OK + "PySide6 " + PySide6.__version__ + " (with multimedia)")
        return True
    except ImportError as exc:
        print(BAD + "PySide6 missing or incomplete ({})".format(exc))
        return False


def _check_ffmpeg() -> bool:
    from .ffmpeg_tools import find_tool, run

    ffmpeg = find_tool("ffmpeg")
    if not ffmpeg:
        print(BAD + "ffmpeg not found")
        print("         Fix: winget install --id Gyan.FFmpeg --scope user")
        return False
    result = run([ffmpeg, "-version"])
    if result.returncode != 0:
        print(BAD + "ffmpeg found but will not run: " + ffmpeg)
        return False
    first = result.stdout.decode("utf-8", "replace").splitlines()[0]
    print(OK + first[:60])
    return True


def _check_model() -> bool:
    from .vad import MODEL_PATH

    if not Path(MODEL_PATH).exists():
        print(BAD + "voice detection model missing at " + str(MODEL_PATH))
        print("         Fix: re-run setup.bat, it downloads the model")
        return False
    try:
        from .vad import VoiceDetector
        import numpy as np

        detector = VoiceDetector()
        probs = detector.probabilities(np.zeros(16000, dtype=np.float32))
        if probs.size == 0:
            print(BAD + "model loaded but returned nothing")
            return False
        print(OK + "voice detection model loads and runs")
        return True
    except Exception as exc:                                   # noqa: BLE001
        print(BAD + "model failed to run ({})".format(exc))
        return False


def main() -> int:
    print()
    print("  SceneForge self-test")
    print("  " + platform.platform())
    print()

    # Order is load-bearing, not cosmetic. Importing onnxruntime before Qt
    # Multimedia segfaults the interpreter on Windows -- both pull in native
    # runtimes and onnxruntime first wins the DLL race with an incompatible one.
    # Qt must come first here, and in any other process that uses both.
    checks = [
        _check_python,
        _check_numpy,
        _check_qt,
        _check_onnx,
        _check_ffmpeg,
        _check_model,
    ]
    results = [check() for check in checks]

    print()
    if all(results):
        print("  Everything is ready.")
        print()
        return 0
    print("  {} of {} checks failed. Fix the lines marked FAIL above.".format(
        results.count(False), len(results)))
    print()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
