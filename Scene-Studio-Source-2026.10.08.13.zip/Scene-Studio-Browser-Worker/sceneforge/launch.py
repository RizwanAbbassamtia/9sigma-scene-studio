"""Start the app, and if it cannot start, say so on screen.

    pythonw -m sceneforge.launch

The desktop shortcut runs this rather than sceneforge.gui directly. pythonw
has no console, so an import error in the ordinary entry point -- a missing
DLL, a half-copied install, an antivirus quarantine -- used to end the process
with nothing on screen at all. The editor double-clicked, nothing happened,
and there was nothing to send anyone.

Everything here stays inside the standard library until the app itself has
imported cleanly. A failure is shown with the Windows message box that every
machine has, along with where the log is and what to try.
"""
from __future__ import annotations

import ctypes
import os
import sys
import traceback
from datetime import datetime
from pathlib import Path

from .product import PRODUCT      # standard library only, so it is safe this early

APP_NAME = PRODUCT.name


def _log_dir() -> Path:
    here = Path(__file__).resolve().parent.parent
    for candidate in (here / "logs", Path(os.environ.get("LOCALAPPDATA", "")) / PRODUCT.folder / "logs"):
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate
        except OSError:
            continue
    return Path(os.environ.get("TEMP", "."))


def _message_box(title: str, text: str) -> None:
    MB_ICONERROR = 0x10
    try:
        ctypes.windll.user32.MessageBoxW(None, text, title, MB_ICONERROR)
    except Exception:                                   # noqa: BLE001 - last resort
        sys.stderr.write(title + "\n" + text + "\n")


def _explain(exc: BaseException) -> str:
    text = str(exc)
    if "DLL load failed" in text or "onnxruntime" in text:
        return ("A component could not be loaded. This usually means the "
                "install is incomplete or antivirus removed a file.\n\n"
                "Try: run the installer again. If it happens again, send the "
                "log file below.")
    if isinstance(exc, ModuleNotFoundError):
        return ("Part of the program is missing ({}). The install is "
                "incomplete.\n\nTry: run the installer again.".format(exc.name))
    if isinstance(exc, PermissionError):
        return ("Windows refused access to a file the program needs.\n\n"
                "Try: close any other copy of {} that is open, then start it "
                "again.".format(APP_NAME))
    return "Try: run the installer again. If it happens again, send the log file below."


def main() -> int:
    log_path = _log_dir() / "startup.log"
    try:
        # Working directory is where config.json, users.json and logs live.
        os.chdir(Path(__file__).resolve().parent.parent)
        from .gui.__main__ import main as run
        return run()
    except BaseException as exc:                        # noqa: BLE001 - it is the point
        if isinstance(exc, SystemExit):
            raise
        detail = traceback.format_exc()
        try:
            with open(log_path, "a", encoding="utf-8") as handle:
                handle.write("\n===== {} failed to start  {}\n{}".format(
                    APP_NAME, datetime.now().strftime("%Y-%m-%d %H:%M:%S"), detail))
        except OSError:
            pass
        _message_box(
            APP_NAME + " could not start",
            "{}\n\n{}\n\nLog file:\n{}\n\nTechnical detail:\n{}".format(
                APP_NAME + " did not open.", _explain(exc), log_path,
                detail.strip().splitlines()[-1][:300]))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
