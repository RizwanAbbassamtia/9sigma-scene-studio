@echo off
setlocal
where winget >nul 2>nul
if errorlevel 1 (
  echo Windows Package Manager was not found. Install Google Chrome and FFmpeg with ffprobe, then retry setup.
  pause
  exit /b 1
)
echo Installing Google Chrome through Windows Package Manager.
echo Read and accept any package or source agreements when prompted.
winget install --id Google.Chrome --exact --source winget
if errorlevel 1 (
  echo Chrome returned a nonzero status. It may already be installed; review the message above.
)
echo Installing the Gyan FFmpeg package, including ffprobe, through Windows Package Manager.
winget install --id Gyan.FFmpeg --exact --source winget
if errorlevel 1 (
  echo FFmpeg returned a nonzero status. Review the message above before starting Scene Studio.
)
echo Dependency commands finished. Review their results, then start Scene Studio again.
pause

