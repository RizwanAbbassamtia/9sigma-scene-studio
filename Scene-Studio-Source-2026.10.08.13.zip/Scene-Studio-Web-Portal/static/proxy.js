/* UI-only paste convenience. Python validates every saved setting. */
(() => {
  const host = document.getElementById('id_host');
  const mode = document.getElementById('id_mode');
  const status = document.getElementById('proxy-paste-status');
  if (!host || !mode) return;
  function unpack() {
    const raw = host.value.trim();
    let parts;
    try {
      if (raw.includes('://')) {
        const url = new URL(raw);
        if (url.protocol !== mode.value + ':' || !url.hostname || !url.port || (url.pathname && url.pathname !== '/') || url.search || url.hash) throw Error();
        parts = [url.hostname, url.port, url.username ? decodeURIComponent(url.username) : undefined, decodeURIComponent(url.password)];
      } else {
        const match = raw.match(/^(\[[0-9a-f:]+\]|[^:\s/@]+):([0-9]{1,5})(?::([^:\r\n]*):(.*))?$/i);
        if (!match) return;
        parts = match.slice(1);
      }
      if (+parts[1] < 1 || +parts[1] > 65535) throw Error();
      host.value = parts[0].replace(/^\[|\]$/g, '');
      document.getElementById('id_port').value = parts[1];
      if (parts[2] !== undefined) {
        document.getElementById('id_username').value = parts[2];
        document.getElementById('id_password').value = parts[3] || '';
        document.getElementById('id_clear_auth').checked = false;
      }
      status.textContent = mode.value === 'direct' ? 'Proxy fields filled. Select a proxy type before saving.' : 'Proxy fields filled. Review them, then save.';
    } catch (_) {
      status.textContent = 'Check the proxy format and selected type. Nothing has been saved.';
    }
  }
  host.addEventListener('paste', () => setTimeout(unpack, 0));
  host.addEventListener('change', unpack);
})();
