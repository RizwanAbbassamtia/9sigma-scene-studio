"use strict";
const accountRefresh=document.getElementById('account-auto-refresh');
if(accountRefresh){
  accountRefresh.checked=sessionStorage.getItem('account-auto-refresh')!=='0';
  accountRefresh.addEventListener('change',()=>sessionStorage.setItem('account-auto-refresh',accountRefresh.checked?'1':'0'));
  setInterval(()=>{const draft=document.querySelector('textarea[name="emails"]');
    if(accountRefresh.checked&&!document.hidden&&!document.querySelector('input:focus,textarea:focus,select:focus')&&!(draft&&draft.value.trim()))location.reload();
  },10000);
}
document.querySelectorAll('.nav-link').forEach(a=>{if(a.pathname===location.pathname)a.classList.add('active');});
document.getElementById('menu-toggle')?.addEventListener('click',()=>document.body.classList.toggle('menu-open'));
const prompts=document.getElementById('id_prompts'),counter=document.getElementById('prompt-count');
function countPrompts(){const s=prompts.value.trim();const n=!s?0:/^1[.:)]\s+/.test(s)?s.split(/^\d+[.:)]\s+/m).slice(1).filter(p=>p.trim()).length:s.split(/\r?\n/).filter(p=>p.trim()).length;counter.textContent=n+' / 100 prompts';counter.classList.toggle('over-limit',n>100);}
if(prompts&&counter){prompts.addEventListener('input',countPrompts);countPrompts();}
const refresh=document.getElementById('auto-refresh');
if(refresh){refresh.checked=sessionStorage.getItem('studio-refresh')==='1';refresh.addEventListener('change',()=>sessionStorage.setItem('studio-refresh',refresh.checked?'1':'0'));setInterval(()=>{if(refresh.checked&&![...document.querySelectorAll('video')].some(v=>!v.paused)&&!document.querySelector('input:focus,textarea:focus,select:focus')&&!document.querySelector('input[name=confirm]:checked,input[name=reviewed]:checked'))location.reload();},10000);}

if(prompts){try{const draft=sessionStorage.getItem("studio-draft-prompt");if(draft&&!prompts.value){prompts.value=draft;sessionStorage.removeItem("studio-draft-prompt");if(counter)countPrompts();}}catch{}}
