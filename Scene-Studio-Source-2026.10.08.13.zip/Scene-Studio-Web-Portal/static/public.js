"use strict";
const toggle=document.getElementById('toggle-password'),password=document.getElementById('id_password');
if(toggle&&password){toggle.addEventListener('click',()=>{const show=password.type==='password';password.type=show?'text':'password';toggle.textContent=show?'Hide':'Show';toggle.setAttribute('aria-label',show?'Hide password':'Show password');toggle.setAttribute('aria-pressed',String(show));});}
document.getElementById('prompt-launch')?.addEventListener('submit',()=>{try{sessionStorage.setItem('studio-draft-prompt',document.getElementById('landing-prompt').value);}catch{}});
