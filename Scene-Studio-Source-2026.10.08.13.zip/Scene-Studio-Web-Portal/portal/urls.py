from django.contrib import admin
from django.contrib.auth import views as auth
from django.urls import path
from workspace import views
admin.site.site_header='Scene Studio Administration'
urlpatterns=[path('admin/',admin.site.urls),path('login/',auth.LoginView.as_view(template_name='login.html',redirect_authenticated_user=True),name='login'),path('logout/',auth.LogoutView.as_view(),name='logout'),path('password/',auth.PasswordChangeView.as_view(template_name='password.html',success_url='/'),name='password'),path('',views.dashboard,name='dashboard'),path('accounts/',views.accounts,name='accounts'),path('support/',views.support,name='support'),path('support/<int:pk>/',views.ticket,name='ticket')]

from workspace import batch_views
from workspace.google_login import google_login,profile_proxy
urlpatterns += [path('google-login/',google_login,name='google_login')]
urlpatterns += [path('google-login/<str:account_id>/proxy/',profile_proxy,name='profile_proxy')]
from workspace.browser_identity import helper_setup,helper_receiver,helper_download
urlpatterns += [path('google-login/<str:account_id>/helper/',helper_setup,name='helper_setup'),
                path('google-login/helper-download/',helper_download,name='helper_download'),
                path('browser-helper/<str:operation>/',helper_receiver,name='helper_receiver')]
urlpatterns += [path('jobs/',batch_views.jobs,name='jobs'),path('batches/<uuid:pk>/zip/',batch_views.download_zip,name='download_zip')]
urlpatterns += [path('batches/',batch_views.batches,name='batches'),path('batches/<uuid:pk>/',batch_views.batch,name='batch'),path('batches/<uuid:pk>/unfinished/',batch_views.unfinished,name='unfinished'),path('scenes/<int:pk>/download/',batch_views.download,name='download')]
