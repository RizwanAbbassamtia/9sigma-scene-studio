from django.urls import path
from workspace.desktop_setup import first_run, health
from .urls import urlpatterns as portal_patterns

urlpatterns = [path('setup/', first_run, name='desktop_setup'),
               path('desktop-health/', health, name='desktop_health')] + portal_patterns
