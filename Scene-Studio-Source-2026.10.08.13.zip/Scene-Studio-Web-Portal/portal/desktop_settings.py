"""Local Windows hub settings. Public web hosting uses portal.settings instead."""
from .settings import *

DEBUG = False
ALLOWED_HOSTS = ['127.0.0.1', 'localhost']
ROOT_URLCONF = 'portal.desktop_urls'
MIDDLEWARE = MIDDLEWARE + ['workspace.desktop_setup.FirstRunMiddleware']
AXES_CLIENT_IP_CALLABLE = 'workspace.desktop_setup.client_ip'
# The executable binds only to loopback. These are not public hosting settings.
SECURE_SSL_REDIRECT = False
SECURE_PROXY_SSL_HEADER = None
SECURE_HSTS_SECONDS = 0
SECURE_HSTS_INCLUDE_SUBDOMAINS = False
SECURE_HSTS_PRELOAD = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False
CSRF_TRUSTED_ORIGINS = []
