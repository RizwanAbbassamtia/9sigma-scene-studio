Scene Studio Web Portal

Read ../README.md, ../SETUP.md and ../DEVELOPMENT.md for the current Windows browser workflow, setup, tests and release status.

The Docker Compose files are a separate API-backed Linux deployment example. They do not connect a hosted portal to local Windows Chrome profiles. Keep production secrets outside source control and use a supported production web server with HTTPS.
