import os
from pathlib import Path
from django.conf import settings
from django.db import transaction
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import FileResponse,HttpResponse,Http404
from django.shortcuts import render,redirect,get_object_or_404
from django.views.decorators.http import require_http_methods
from .models import Batch,Scene
from .forms import BatchForm
from .browser_dispatch import browser_generation_block
from .google_login import worker
from django.db.models import Count,Q
import tempfile,zipfile

@login_required
def jobs(request):
    rows=Batch.objects.filter(owner=request.user).annotate(total=Count('scenes'),done=Count('scenes',filter=Q(scenes__status='done')),review=Count('scenes',filter=Q(scenes__status='review'))).order_by('-created')
    return render(request,'jobs.html',{'active':rows.filter(status='running'),'history':rows.exclude(status='running')[:50]})

@login_required
def download_zip(request,pk):
    item=get_object_or_404(Batch,pk=pk,owner=request.user)
    output=tempfile.TemporaryFile()
    try:
        with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_STORED) as archive:
            for scene in item.scenes.filter(status='done').order_by('number'):
                path=(settings.DATA/scene.file).resolve()
                if path.is_relative_to((settings.DATA/'videos').resolve()) and path.is_file():
                    archive.write(path,f'scene-{scene.number:03d}.mp4')
        output.seek(0)
        return FileResponse(output,as_attachment=True,filename='scene-batch.zip',content_type='application/zip')
    except Exception:
        output.close()
        raise
@login_required
@require_http_methods(['GET','POST'])
def batches(request):
    form=BatchForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        with transaction.atomic():
            batch=Batch.objects.create(owner=request.user,title=form.cleaned_data['title'],aspect=form.cleaned_data['aspect'])
            Scene.objects.bulk_create([Scene(batch=batch,number=i,prompt=p) for i,p in enumerate(form.cleaned_data['prompts'],1)])
        return redirect('batch',pk=batch.pk)
    return render(request,'batches.html',{'form':form,'batches':Batch.objects.filter(owner=request.user).order_by('-created')[:50], 'generation_block':browser_generation_block()})

def can_continue_queued(item):
    return (item.backend=='browser' and bool(item.worker_run)
        and item.status in ('paused','draft')
        and item.scenes.filter(status__in=['review','failed']).exists()
        and item.scenes.filter(status='queued').exists()
        and not item.scenes.filter(status='processing').exists()
        and not item.scenes.filter(status='queued',note='User reviewed provider and requested retry.').exists())

@login_required
@require_http_methods(['GET','POST'])
def batch(request,pk):
    item=get_object_or_404(Batch,pk=pk,owner=request.user)
    if request.method=='POST':
        action=request.POST.get('action')
        if action=='pause':
            Batch.objects.filter(pk=item.pk,status='running').update(status='paused')
        elif action in ('start','continue'):
            if not request.user.has_perm('workspace.generate_video'):
                messages.error(request,'Ask your administrator to grant generation access.')
            elif item.backend=='browser' and os.environ.get('BROWSER_GENERATION_ENABLED')!='1':
                messages.error(request,'Browser generation is disabled until the admin finishes account setup.')
            elif item.backend!='browser' and os.environ.get('GENERATION_ENABLED')!='1':
                messages.error(request,'API generation is not enabled by your administrator.')
            elif item.backend!='browser' and request.POST.get('confirm')!='yes':
                messages.error(request,'Confirm separately billed API usage before starting.')
            elif action=='continue' and not can_continue_queued(item):
                messages.error(request,'Continue queued scenes is available for a paused browser batch with queued scenes, no active scene, and no queued retry requests.')
            elif action=='start' and item.scenes.filter(status__in=['review','failed','processing']).exists():
                messages.error(request,'Resolve scenes needing review or wait for the current scene.')
            else:
                blocked=browser_generation_block() if item.backend=='browser' else ''
                if blocked:
                    Batch.objects.filter(pk=item.pk).update(status='paused',worker_note=blocked)
                    messages.error(request,blocked)
                else:Batch.objects.filter(pk=item.pk).update(status='running',worker_note='')
        elif action=='recover':
            if not request.user.has_perm('workspace.generate_video'):
                messages.error(request,'Generation access is required to recover account results.')
            elif item.backend!='browser' or not item.worker_run:
                messages.error(request,'This batch has no saved browser result.')
            else:
                scene=get_object_or_404(Scene,pk=request.POST.get('scene'),batch=item,status='review')
                try:
                    worker(action='recover-output',payload={'run':item.worker_run,'number':scene.number})
                except Exception:
                    messages.error(request,'Recovery could not start. Keep the saved job and check the worker; no new generation was requested.')
                else:
                    item.status='running'
                    item.worker_note='Dispatched to browser worker.'
                    item.save(update_fields=['status','worker_note'])
                    messages.success(request,'Checking the existing Gemini result. No new prompt was submitted.')
        elif action=='retry' and request.POST.get('reviewed')=='yes':
            item.scenes.filter(pk=request.POST.get('scene'),status='review').update(status='queued',note='User reviewed provider and requested retry.')
        return redirect('batch',pk=pk)
    blocked=browser_generation_block() if item.backend=='browser' and item.status in ('draft','paused') else ''
    return render(request,'batch.html',{'batch':item,'scenes':item.scenes.order_by('number'),'done':item.scenes.filter(status='done').count(),'total':item.scenes.count(),'generation_block':blocked,'can_continue_queued':can_continue_queued(item)})
@login_required
def download(request,pk):
    scene=get_object_or_404(Scene,pk=pk,batch__owner=request.user,status='done')
    path=(settings.DATA/scene.file).resolve()
    if not path.is_relative_to((settings.DATA/'videos').resolve()) or not path.is_file():raise Http404()
    return FileResponse(path.open('rb'),as_attachment=request.GET.get('preview')!='1',filename=f'scene-{scene.number:03d}.mp4',content_type='video/mp4')
@login_required
def unfinished(request,pk):
    item=get_object_or_404(Batch,pk=pk,owner=request.user)
    text='\n\n'.join(f'{s.number}: {s.prompt}' for s in item.scenes.exclude(status='done').order_by('number'))
    response=HttpResponse(text,content_type='text/plain; charset=utf-8')
    response['Content-Disposition']='attachment; filename="unfinished-prompts.txt"'
    return response
