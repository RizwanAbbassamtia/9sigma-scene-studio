import os
from unittest.mock import patch
from django.test import TestCase, override_settings
from django.contrib.auth.models import User,Permission
from .models import Batch,Scene
from .browser_dispatch import tick, SAVED_PROFILE_BLOCK, eligible_profiles

@override_settings(AXES_ENABLED=False)
class BrowserDispatchTests(TestCase):
    def setUp(self):
        self.user=User.objects.create_user('maker',password='test-password-long-991')
        self.user.user_permissions.add(Permission.objects.get(codename='generate_video'))
        self.batch=Batch.objects.create(owner=self.user,title='Browser test',status='running')
        self.scene=Scene.objects.create(batch=self.batch,number=1,prompt='A tree')

    def test_disabled_never_contacts_worker(self):
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'0'}),patch('workspace.browser_dispatch.worker') as call:
            tick();call.assert_not_called()

    def test_no_connected_accounts_pauses(self):
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.worker',return_value={'busy':False,'accounts':[],'managed_pool':[]}):tick()
        self.batch.refresh_from_db();self.assertEqual(self.batch.status,'paused')
        self.assertEqual(self.batch.worker_run,'')

    def test_saved_generation_candidates_are_eligible_without_faking_connection(self):
        state={'saved_profile_generation':1,'generation_candidates':[{'id':'FA-002','email':'actual@example.test'}],
               'accounts':[{'id':'FA-002','connections':{'flow':{'state':'manual'}}}]}
        self.assertEqual(eligible_profiles(state),['FA-002'])

    def test_deferred_handoff_persists_before_resume(self):
        calls=[]
        def fake(request=None,action=None,payload=None,path=None):
            calls.append(action or path)
            if not action and not path:return {'busy':False,'accounts':[{'id':'FA-001','status':'available','connections':{'flow':{'state':'connected'}}}],'managed_pool':[{'id':'FA-001','status':'connected'}]}
            if action=='create':
                self.assertTrue(payload['defer_start']);self.assertEqual(payload['request_id'],str(self.batch.pk))
                return {'run':'20261007-100000-000001'}
            if path:return {'rows':[{'number':1,'status':'todo'}]}
            if action=='resume':
                self.assertEqual(Batch.objects.get(pk=self.batch.pk).worker_run,payload['run'])
                raise TimeoutError()
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.worker',side_effect=fake):
            with self.assertRaises(TimeoutError):tick()
        self.batch.refresh_from_db();self.assertEqual(self.batch.status,'paused')
        self.assertEqual(calls.count('create'),1)

    def test_browser_start_requires_permission_and_enablement(self):
        self.batch.status='draft';self.batch.save();self.client.force_login(self.user)
        state={'accounts':[{'id':'FA-001','status':'available','connections':{'flow':{'state':'connected'}}}],
               'managed_pool':[{'id':'FA-001','status':'connected'}]}
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.worker',return_value=state):
            self.client.post(f'/batches/{self.batch.pk}/',{'action':'start'})
        self.batch.refresh_from_db();self.assertEqual(self.batch.status,'running')

    def test_saved_manual_profiles_never_enter_running_or_request_login_again(self):
        self.batch.status='draft';self.batch.save();self.client.force_login(self.user)
        state={'busy':False,'accounts':[{'id':'FA-002','status':'available','connections':{'flow':{'state':'manual'}}}],
               'managed_pool':[{'id':'FA-002','status':'needs_login'}]}
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.worker',return_value=state) as call:
            response=self.client.post(f'/batches/{self.batch.pk}/',{'action':'start'},follow=True)
            self.assertContains(response,SAVED_PROFILE_BLOCK)
            self.assertContains(response,'Waiting for generation connection')
            self.assertNotContains(response,'Ask admin to sign in')
            self.assertTrue(all(not args.kwargs for args in call.call_args_list))
        self.batch.refresh_from_db();self.scene.refresh_from_db()
        self.assertEqual(self.batch.status,'paused')
        self.assertEqual(self.batch.worker_note,SAVED_PROFILE_BLOCK)
        self.assertEqual(self.scene.status,'queued')
        self.assertEqual(self.scene.attempts,0)
        self.assertEqual(self.batch.worker_run,'')

    def test_scheduler_reports_manual_integration_gap_without_submitting(self):
        state={'busy':False,'accounts':[{'id':'FA-002','status':'available','connections':{'flow':{'state':'manual'}}}],
               'managed_pool':[]}
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.worker',return_value=state) as call:
            tick()
            self.assertEqual(call.call_count,1)
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.worker_note,SAVED_PROFILE_BLOCK)

    def test_mixed_manual_and_connected_profile_matches_worker_restriction(self):
        state={'accounts':[{'id':'FA-002','status':'available','connections':{'flow':{'state':'connected'},'gemini':{'state':'manual'}}}],
               'managed_pool':[{'id':'FA-002','status':'connected'}]}
        self.assertEqual(eligible_profiles(state),[])

    def test_offline_worker_does_not_start_or_lose_prompts(self):
        self.batch.status='draft';self.batch.save();self.client.force_login(self.user)
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.worker',side_effect=ConnectionError('private details')):
            response=self.client.post(f'/batches/{self.batch.pk}/',{'action':'start'},follow=True)
        self.assertContains(response,'worker is unavailable')
        self.assertNotContains(response,'private details')
        self.batch.refresh_from_db();self.scene.refresh_from_db()
        self.assertEqual(self.batch.status,'paused')
        self.assertEqual(self.scene.prompt,'A tree')

    def test_finished_video_copied_and_batch_completed(self):
        from tempfile import TemporaryDirectory
        from pathlib import Path
        from .browser_dispatch import sync_batch
        self.batch.worker_run='20261007-100000-000001';self.batch.save()
        self.scene.status='processing';self.scene.save()
        def fake(**kwargs):
            if kwargs['path'].startswith('file?'):return b'test-video'
            return {'rows':[{'number':1,'status':'done','file':'0001_flow_attempt1.mp4','provider':'flow','account':'FA-001','note':None}]}
        with TemporaryDirectory() as folder,override_settings(DATA=Path(folder)),patch('workspace.browser_dispatch.worker',side_effect=fake):
            sync_batch(self.batch,{'busy':False})
            self.scene.refresh_from_db();self.batch.refresh_from_db()
            self.assertEqual(self.batch.status,'complete')
            self.assertEqual((Path(folder)/self.scene.file).read_bytes(),b'test-video')

    def test_running_job_stops_after_user_pauses(self):
        self.batch.worker_run='20261007-100000-000001';self.batch.status='paused';self.batch.save()
        with patch.dict(os.environ,{'BROWSER_GENERATION_ENABLED':'1'}),patch('workspace.browser_dispatch.sync_batch'),patch('workspace.browser_dispatch.worker',return_value={'busy':True,'current':self.batch.worker_run}) as call:
            tick()
        self.assertEqual(call.call_args.kwargs,{'action':'stop','payload':{}})
