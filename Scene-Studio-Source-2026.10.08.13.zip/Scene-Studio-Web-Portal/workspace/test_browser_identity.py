import hashlib
import json
from datetime import timedelta
from unittest.mock import patch
from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from django.utils import timezone
from .browser_identity import EXTENSION_ORIGIN, annotate_accounts
from .models import BrowserIdentity


@override_settings(AXES_ENABLED=False)
class BrowserIdentityTests(TestCase):
    def setUp(self):
        self.now=timezone.now()
        self.code='FA-001.'+'a'*43
        self.identity=BrowserIdentity.objects.create(account_id='FA-001',expected_email='one@example.test',
            token_hash=hashlib.sha256(self.code.encode()).hexdigest())
        self.account={'id':'FA-001','email':'one@example.test','connections':{'flow':{'state':'manual'}}}
        self.headers={'HTTP_ORIGIN':EXTENSION_ORIGIN,'HTTP_AUTHORIZATION':'Bearer '+self.code,'REMOTE_ADDR':'127.0.0.1'}
        self.report={'state':'observed','email':'one@example.test','page_origin':'https://myaccount.google.com',
            'observed_at':self.now.timestamp()*1000,'reported_at':self.now.timestamp()*1000}

    def post(self,data=None,**headers):
        return self.client.post('/browser-helper/report/',json.dumps(self.report if data is None else data),
            content_type='application/json',**(self.headers|headers))

    def test_matching_email_is_confirmed_without_marking_services_connected(self):
        self.assertEqual(self.post().status_code,200)
        self.identity.refresh_from_db()
        rows,counts=annotate_accounts([self.account],{'FA-001':self.identity},timezone.now())
        self.assertEqual(counts['confirmed'],1)
        self.assertEqual(rows[0]['observed_email'],'one@example.test')
        self.assertEqual(rows[0]['connections']['flow']['state'],'manual')

    def test_sort_actual_email_and_stale_or_missing_heartbeat(self):
        records={}
        accounts=[]
        for i,email,age,heartbeat in [(1,'different@example.test',0,0),(2,'two@example.test',0,0),(3,'three@example.test',301,0),(4,'four@example.test',0,91)]:
            key=f'FA-{i:03d}'
            expected=['one','two','three','four'][i-1]+'@example.test'
            accounts.append({'id':key,'email':expected})
            records[key]=BrowserIdentity(account_id=key,observed_email=email,observation='observed',
                observed_at=self.now-timedelta(seconds=age),received_at=self.now-timedelta(seconds=heartbeat))
        rows,counts=annotate_accounts(accounts,records,self.now)
        self.assertEqual([r['id'] for r in rows],['FA-001','FA-002','FA-003','FA-004'])
        self.assertEqual(rows[0]['observed_email'],'different@example.test')
        self.assertEqual((counts['confirmed'],counts['unique_emails'],counts['stale']),(2,2,2))

    def test_opened_is_never_a_login_count(self):
        _,counts=annotate_accounts([self.account],{},self.now)
        self.assertEqual((counts['confirmed'],counts['opened'],counts['unverified']),(0,1,1))

    def test_requires_pairing_origin_and_loopback_even_for_signed_in_admin(self):
        user=User.objects.create_user('helper-admin',is_staff=True)
        self.client.force_login(user)
        for header in [{'HTTP_ORIGIN':'https://evil.example'}, {'REMOTE_ADDR':'192.0.2.1'},
                       {'HTTP_AUTHORIZATION':''},{'HTTP_AUTHORIZATION':'Bearer FA-002.'+'b'*43}]:
            self.assertEqual(self.post(**header).status_code,403)
        self.identity.refresh_from_db()
        self.assertIsNone(self.identity.received_at)

    def test_invalid_inputs_do_not_change_identity(self):
        for data in [[],self.report|{'email':None},self.report|{'state':[]},self.report|{'email':'bad'},
                     self.report|{'page_origin':'https://accounts.google.com'},
                     self.report|{'observed_at':float('nan')},self.report|{'reported_at':float('inf')},
                     self.report|{'reported_at':(self.now+timedelta(minutes=2)).timestamp()*1000},
                     self.report|{'pad':'x'*2100}]:
            self.assertEqual(self.post(data).status_code,400)
        self.identity.refresh_from_db()
        self.assertIsNone(self.identity.received_at)

    def test_new_report_may_retain_old_observation_after_unknown(self):
        # Pairing/another tab can report unknown before an already-open page sends its first heartbeat.
        self.assertEqual(self.post(self.report|{'state':'unknown','email':''}).status_code,200)
        old=self.report|{'observed_at':(self.now-timedelta(seconds=120)).timestamp()*1000,
                         'reported_at':self.report['reported_at']+1}
        self.assertTrue(self.post(old).json()['accepted'])
        self.identity.refresh_from_db()
        self.assertEqual(self.identity.observation,'observed')
        self.assertLess(self.identity.observed_at,self.now-timedelta(seconds=100))
        self.assertFalse(self.post().json()['accepted'])

    def test_stale_page_heartbeat_cannot_renew_verified_status(self):
        old=self.report|{'observed_at':(self.now-timedelta(minutes=10)).timestamp()*1000}
        self.assertTrue(self.post(old).json()['accepted'])
        self.identity.refresh_from_db()
        _,counts=annotate_accounts([self.account],{'FA-001':self.identity},timezone.now())
        self.assertEqual(counts['stale'],1)

    def test_unknown_clears_current_confirmation(self):
        self.post()
        self.post(self.report|{'state':'unknown','email':'','reported_at':self.report['reported_at']+1})
        self.identity.refresh_from_db()
        _,counts=annotate_accounts([self.account],{'FA-001':self.identity},self.now)
        self.assertEqual(counts['confirmed'],0)

    def test_profile_download_configures_reports_without_email_or_pairing_code(self):
        import io,zipfile
        url='/google-login/FA-001/helper/'
        user=User.objects.create_user('pair-admin',is_staff=True)
        self.assertEqual(self.client.get(url).status_code,302)
        self.client.force_login(user)
        with patch('workspace.google_login.worker',return_value={'accounts':[self.account]}):
            response=self.client.post(url,{'action':'download'},HTTP_HOST='127.0.0.1:8792')
            self.assertEqual(response.status_code,200)
            with zipfile.ZipFile(io.BytesIO(b''.join(response.streaming_content))) as archive:
                config=json.loads(archive.read('Scene-Studio-Login-Helper-FA-001/profile-config.json'))
                manifest=json.loads(archive.read('Scene-Studio-Login-Helper-FA-001/manifest.json'))
                self.assertEqual(len(archive.namelist()),8)
            code=config['code']
            self.assertEqual(config['portal'],'http://127.0.0.1:8792')
            self.assertEqual(config['account_id'],'FA-001')
            self.assertNotIn('email',config)
            self.assertIn('FA-001',manifest['name'])
            self.identity.refresh_from_db()
            self.assertEqual(self.identity.token_hash,hashlib.sha256(code.encode()).hexdigest())
            self.assertNotIn(code,self.identity.token_hash)
            self.assertEqual(self.post().status_code,403)
            self.assertIn('no-store',response['Cache-Control'])
            self.assertNotContains(self.client.get(url),'Create pairing code')
            self.assertNotContains(self.client.get(url),code)
            self.client.post(url,{'action':'revoke'})
            self.assertEqual(self.post(HTTP_AUTHORIZATION='Bearer '+code).status_code,403)
            user.is_staff=False;user.save()
            self.assertEqual(self.client.post(url,{'action':'download'},HTTP_HOST='127.0.0.1:8792').status_code,403)

    def test_preflight_is_narrow(self):
        response=self.client.options('/browser-helper/report/',HTTP_ORIGIN=EXTENSION_ORIGIN)
        self.assertEqual(response['Access-Control-Allow-Origin'],EXTENSION_ORIGIN)
        self.assertEqual(self.client.options('/browser-helper/report/',HTTP_ORIGIN='https://evil.example').status_code,403)
        self.assertEqual(self.client.get('/browser-helper/report/',**self.headers).status_code,405)

    def test_download_is_staff_only_and_contains_only_helper_sources(self):
        import io,zipfile
        url='/google-login/helper-download/'
        self.assertEqual(self.client.get(url).status_code,302)
        user=User.objects.create_user('download-admin',is_staff=True)
        self.client.force_login(user)
        response=self.client.get(url)
        self.assertEqual(response.status_code,200)
        with zipfile.ZipFile(io.BytesIO(b''.join(response.streaming_content))) as archive:
            self.assertEqual(len(archive.namelist()),7)
            self.assertIn('Scene-Studio-Login-Helper/manifest.json',archive.namelist())
        user.is_staff=False;user.save()
        self.assertEqual(self.client.get(url).status_code,403)

    def test_inventory_searches_observed_email_and_renders_badges(self):
        self.post(self.report|{'email':'actual@example.test'})
        user=User.objects.create_user('view-admin',is_staff=True)
        self.client.force_login(user)
        with patch('workspace.google_login.worker',return_value={'accounts':[self.account],'managed_pool':[]}):
            response=self.client.get('/google-login/?q=actual')
            self.assertContains(response,'actual@example.test')
            self.assertContains(response,'Signed in · email confirmed')
            self.assertContains(response,'Imported address: one@example.test')
            self.assertNotContains(response,'Different Google email')
            self.assertEqual(response.context['counts']['confirmed'],1)

    def test_email_switch_updates_profile_and_does_not_modify_imported_inventory(self):
        self.post()
        self.assertTrue(self.post(self.report|{'email':'next@example.test','reported_at':self.report['reported_at']+1}).json()['accepted'])
        self.identity.refresh_from_db()
        rows,counts=annotate_accounts([self.account],{'FA-001':self.identity},timezone.now())
        self.assertEqual(rows[0]['observed_email'],'next@example.test')
        self.assertEqual(rows[0]['identity_state'],'confirmed')
        self.assertEqual(rows[0]['email'],'one@example.test')
        self.assertEqual(self.identity.expected_email,'one@example.test')
        self.post(self.report|{'state':'unknown','email':'','reported_at':self.report['reported_at']+2})
        self.identity.refresh_from_db()
        rows,counts=annotate_accounts([self.account],{'FA-001':self.identity},timezone.now())
        self.assertEqual(rows[0]['observed_email'],'next@example.test')
        self.assertEqual(counts['confirmed'],0)

    def test_same_gmail_in_two_profiles_counts_once(self):
        self.post()
        self.identity.refresh_from_db()
        second={'id':'FA-002','email':'another@example.test'}
        _,counts=annotate_accounts([self.account,second],{'FA-001':self.identity,'FA-002':self.identity},timezone.now())
        self.assertEqual(counts['confirmed'],2)
        self.assertEqual(counts['unique_emails'],1)

    def test_offline_worker_shows_recovery_without_debug_exception(self):
        user=User.objects.create_user('offline-admin',is_staff=True)
        self.client.force_login(user)
        with patch('workspace.google_login.worker',side_effect=ConnectionError('internal-error-detail')):
            response=self.client.get('/google-login/FA-001/helper/')
        self.assertContains(response,'Desktop profile host is offline',status_code=503)
        self.assertNotContains(response,'internal-error-detail',status_code=503)
        self.assertNotContains(response,'Download automatic helper',status_code=503)
