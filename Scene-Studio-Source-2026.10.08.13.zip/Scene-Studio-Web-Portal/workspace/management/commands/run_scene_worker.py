import time
from django.core.management.base import BaseCommand
from django.conf import settings
from workspace.models import Scene,Batch
from workspace.generation import generate,ProviderPause,NeedsReview
class Command(BaseCommand):
    help='Process saved batches sequentially. Run exactly one worker.'
    def handle(self,*args,**options):
        import fcntl
        lock=open(settings.DATA/'worker.lock','a')
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        # A crash may have happened after Google accepted a submission.
        interrupted=list(Scene.objects.filter(status='processing').values_list('batch_id',flat=True))
        Scene.objects.filter(status='processing').update(status='review',note='Worker restarted; check provider before retrying.')
        Batch.objects.filter(pk__in=interrupted).update(status='paused')
        while True:
            scene=Scene.objects.filter(status='queued',batch__status='running',batch__backend='api',batch__owner__is_active=True).select_related('batch').order_by('batch__created','number').first()
            if not scene:time.sleep(3);continue
            if not scene.batch.owner.has_perm('workspace.generate_video'):
                Batch.objects.filter(pk=scene.batch_id).update(status='paused');continue
            if not Scene.objects.filter(pk=scene.pk,status='queued').update(status='processing',attempts=scene.attempts+1):continue
            scene.refresh_from_db()
            try:
                generate(scene)
                scene.status='done';scene.note='Saved and validated.'
            except ProviderPause as exc:
                scene.status='queued';scene.note=str(exc)
                Batch.objects.filter(pk=scene.batch_id).update(status='paused')
            except NeedsReview as exc:
                scene.status='review';scene.note=str(exc)
                Batch.objects.filter(pk=scene.batch_id).update(status='paused')
            except Exception:
                scene.status='review';scene.note='Unexpected interruption. Review before retrying.'
                Batch.objects.filter(pk=scene.batch_id).update(status='paused')
            scene.save(update_fields=['status','note'])
            if not Scene.objects.filter(batch=scene.batch).exclude(status='done').exists():
                Batch.objects.filter(pk=scene.batch_id).update(status='complete')
            time.sleep(2)
