import os,time
from django.core.management.base import BaseCommand
from django.conf import settings
from workspace.browser_dispatch import tick

class Command(BaseCommand):
    help='Run one central browser scheduler. Keep Chrome worker running on the same host.'
    def handle(self,*args,**options):
        lock=open(settings.DATA/'browser-dispatch.lock','a+b')
        lock.seek(0);lock.write(b'0');lock.flush();lock.seek(0)
        if os.name=='nt':
            import msvcrt
            msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:
            while True:
                try:tick()
                except Exception:self.stderr.write('Browser worker unavailable; saved jobs retained. Check admin status.')
                time.sleep(3)
        finally:lock.close()
