from ipaddress import ip_address
from django.conf import settings


def client_ip(request):
    # Caddy overwrites this header; the web service has no public port mapping.
    value=request.META.get('REMOTE_ADDR','') if settings.DEBUG else request.META.get('HTTP_X_PORTAL_CLIENT_IP','')
    try:return str(ip_address(value))
    except ValueError:return None
