"""Durable portal-to-worker scheduler. No browser secrets enter user responses."""
import os
from pathlib import Path
from urllib.parse import urlencode
from django.conf import settings
from .models import Batch
from .google_login import worker

SAVED_PROFILE_BLOCK = ('Automatic video generation is not connected to the saved Chrome profiles yet. '
                       'Your accounts and prompts are saved; signing in again will not resolve this.')

def eligible_profiles(state):
    if state.get('saved_profile_generation', 0) >= 1:
        return [a['id'] for a in state.get('generation_candidates', [])]
    mapped={a['id'] for a in state.get('managed_pool',[]) if a.get('status')=='connected'}
    eligible=[]
    for account in state.get('accounts',[]):
        connections=list(account.get('connections',{}).values())
        if (account.get('status')!='paused' and account['id'] in mapped
                and any(c.get('state')=='connected' for c in connections)
                and not any(c.get('state')=='manual' for c in connections)):
            eligible.append(account['id'])
    return eligible

def generation_block(state):
    if eligible_profiles(state):return ''
    if state.get('saved_profile_generation', 0) >= 1:
        return 'No saved profile has one identifiable Google account for generation. Open an app profile and complete Google sign-in, then retry.'
    if any(c.get('state')=='manual' for a in state.get('accounts',[]) for c in a.get('connections',{}).values()):
        return SAVED_PROFILE_BLOCK
    return 'No account is connected to the automatic generation worker. Complete the generation connection before starting.'

def browser_generation_block():
    if os.environ.get('BROWSER_GENERATION_ENABLED')!='1':
        return 'Automatic browser generation is not enabled on this server.'
    try:return generation_block(worker())
    except Exception:
        return 'The desktop generation worker is unavailable. Your prompts are saved; restore the worker before starting.'

def sync_batch(batch, state):
    result=worker(path='run?'+urlencode({'run':batch.worker_run}))
    for row in result['rows']:
        scene=batch.scenes.get(number=row['number'])
        # A human has explicitly released this scene for retry; retain that decision.
        if scene.status=='queued' and scene.note=='User reviewed provider and requested retry.' and row['status'] in ('review','failed'):
            continue
        status={'done':'done','review':'review','failed':'review','todo':'queued','submitting':'processing','generating':'processing'}[row['status']]
        if status=='done' and not scene.file:
            name=Path(row['file']).name
            content=worker(path='file?'+urlencode({'run':batch.worker_run,'name':name}))
            relative=Path('videos')/str(batch.pk)/f'{scene.number:04d}.mp4'
            dest=settings.DATA/relative;dest.parent.mkdir(parents=True,exist_ok=True)
            tmp=dest.with_suffix('.partial');tmp.write_bytes(content);tmp.replace(dest)
            scene.file=str(relative)
        scene.status=status
        scene.provider_id=f"{row.get('provider') or ''}/{row.get('account') or ''}"
        scene.note=(row.get('note') or '')[:500]
        scene.save(update_fields=['status','file','provider_id','note'])
    if not batch.scenes.exclude(status='done').exists():
        batch.status='complete';batch.worker_note='All scenes saved.';batch.save()
    elif not state['busy'] and batch.status=='running':
        detail=next((m for m in reversed(state.get('messages', [])) if 'Stopped:' in m or 'admin attention:' in m), '')
        batch.status='paused';batch.worker_note=(detail or 'Worker stopped or accounts unavailable. Review remaining scenes and account allowances before resuming.')[:500];batch.save()

def tick():
    if os.environ.get('BROWSER_GENERATION_ENABLED')!='1':return
    state=worker()
    linked=Batch.objects.filter(backend='browser').exclude(worker_run='').exclude(status='complete')
    current=linked.filter(worker_run=state.get('current')).first()
    if state['busy']:
        if current:
            if current.status=='paused' or not current.owner.is_active or not current.owner.has_perm('workspace.generate_video'):
                worker(action='stop',payload={})
            sync_batch(current,state)
        return
    # Synchronize only runs with scenes already dispatched; new/resumed jobs below remain runnable.
    for item in linked.filter(worker_note='Dispatched to browser worker.'):sync_batch(item,state)
    batch=Batch.objects.filter(backend='browser',status='running',owner__is_active=True).order_by('created').first()
    if not batch:return
    if not batch.owner.has_perm('workspace.generate_video'):
        batch.status='paused';batch.worker_note='Generation permission required.';batch.save();return
    eligible=eligible_profiles(state)
    if not eligible:
        batch.status='paused';batch.worker_note=generation_block(state);batch.save();return
    if not batch.worker_run:
        scenes=list(batch.scenes.order_by('number'))
        created=worker(action='create',payload={'request_id':str(batch.pk),'defer_start':True,'transport':'managed','accounts':eligible,
            'prompts':'\n\n'.join(f'{s.number}: {s.prompt}' for s in scenes),
            'settings':{'model':'Omni 1.1 Flash','aspect':batch.aspect,'resolution':'720p','duration':'10s'},'gemini_limit':3,'budget':None})
        batch.worker_run=created['run'];batch.save(update_fields=['worker_run'])
    saved=worker(path='run?'+urlencode({'run':batch.worker_run}))
    retry=[r['number'] for r in saved['rows'] if r['status'] in ('review','failed') and batch.scenes.filter(number=r['number'],status='queued',note='User reviewed provider and requested retry.').exists()]
    batch.scenes.filter(status='queued').update(status='processing')
    batch.worker_note='Dispatched to browser worker.';batch.save(update_fields=['worker_note'])
    try:
        if retry:worker(action='retry',payload={'run':batch.worker_run,'numbers':retry,'reviewed':True})
        else:worker(action='resume',payload={'run':batch.worker_run})
    except Exception:
        # Run identifier is durable. Next poll reconciles it; never create a replacement run.
        batch.worker_note='Start response uncertain; reconcile the saved worker run before resuming.'
        batch.status='paused';batch.save();raise
