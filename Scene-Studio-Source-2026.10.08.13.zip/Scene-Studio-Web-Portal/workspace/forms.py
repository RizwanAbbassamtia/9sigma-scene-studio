from django import forms
from .models import Ticket
class EmailsForm(forms.Form):
    emails=forms.CharField(max_length=60000,widget=forms.Textarea(attrs={'rows':5,'placeholder':'first@gmail.com\nsecond@gmail.com'}),label='Email addresses')
    def clean_emails(self):
        import re
        emails=list(dict.fromkeys(x.lower() for x in re.split(r'[\s,;]+',self.cleaned_data['emails'].strip()) if x))
        if not emails or len(emails)>1000:raise forms.ValidationError('Enter between 1 and 1,000 email addresses.')
        for email in emails:
            forms.EmailField().clean(email)
        return emails
class SupportForm(forms.ModelForm):
    class Meta:
        model=Ticket
        fields=['subject','message']
        widgets={'message':forms.Textarea(attrs={'rows':5})}

class BatchForm(forms.Form):
    title=forms.CharField(max_length=120)
    aspect=forms.ChoiceField(choices=[('16:9','Landscape · 16:9'),('9:16','Portrait · 9:16')])
    prompts=forms.CharField(max_length=200000,widget=forms.Textarea(attrs={'rows':12,'placeholder':'1: Your first scene...\n2: Your next scene...'}))
    def clean_prompts(self):
        import re
        raw=self.cleaned_data['prompts'].strip()
        if re.match(r'^1[.:)]\s+',raw):
            blocks=re.split(r'(?m)^\d+[.:)]\s+',raw)[1:]
        else:blocks=raw.splitlines()
        prompts=[s.strip() for s in blocks if s.strip()]
        if not 1<=len(prompts)<=100:raise forms.ValidationError('Enter 1–100 prompts, one per line or in numbered blocks.')
        if any(len(p)>10000 for p in prompts):raise forms.ValidationError('Each scene must be at most 10,000 characters.')
        return prompts
