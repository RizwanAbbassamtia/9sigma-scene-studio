"""Official Gemini Interactions REST adapter. No automatic submission retries."""
import base64,json,os,subprocess
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from django.conf import settings
class ProviderPause(Exception):pass
class NeedsReview(Exception):pass
def generate(scene):
    key=os.environ.get('GEMINI_API_KEY','')
    if os.environ.get('GENERATION_ENABLED')!='1' or not key:
        raise ProviderPause('Generation is disabled. Ask your administrator to configure the API.')
    body={'model':'gemini-omni-1.1-flash','input':scene.prompt,
          'background':False,'store':False,'stream':False,
          'response_format':{'type':'video','aspect_ratio':scene.batch.aspect,'resolution':'720p'}}
    request=Request('https://generativelanguage.googleapis.com/v1beta/interactions',
                    data=json.dumps(body).encode(),headers={'Content-Type':'application/json','x-goog-api-key':key})
    try:
        with urlopen(request,timeout=900) as response:
            raw=response.read(128*1024*1024+1)
        if len(raw)>128*1024*1024:raise NeedsReview('Response too large. Review the provider before retrying.')
        result=json.loads(raw)
    except HTTPError as exc:
        if exc.code in (401,403,429):raise ProviderPause('API access or quota requires administrator attention.') from None
        raise NeedsReview('Provider rejected or interrupted the request. Review before retrying.') from None
    except (TimeoutError,OSError,ValueError):
        raise NeedsReview('Submission outcome is uncertain. Review the provider before retrying.') from None
    scene.provider_id=str(result.get('id',''))[:300]
    scene.save(update_fields=['provider_id'])
    videos=[c for step in result.get('steps',[]) if step.get('type')=='model_output'
            for c in step.get('content',[]) if c.get('type')=='video' and c.get('mime_type')=='video/mp4' and c.get('data')]
    if len(videos)!=1:raise NeedsReview('No single inline MP4 returned. Review the provider result before retrying.')
    folder=settings.DATA/'videos'/str(scene.batch.owner_id)/str(scene.batch_id)
    folder.mkdir(parents=True,exist_ok=True)
    target=folder/f'{scene.number:03d}-attempt-{scene.attempts}.mp4'
    temporary=target.with_suffix('.part')
    try:
        temporary.write_bytes(base64.b64decode(videos[0]['data'],validate=True))
        probe=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration:stream=codec_type,width,height','-of','json',str(temporary)],capture_output=True,text=True,timeout=45,check=True)
        info=json.loads(probe.stdout)
        duration=float(info['format']['duration'])
        if duration<=0 or not any(s.get('codec_type')=='video' for s in info['streams']):raise ValueError('Missing video')
        temporary.replace(target)
        scene.file=str(target.relative_to(settings.DATA))
        scene.duration=duration
        scene.save(update_fields=['file','duration'])
    except Exception:
        raise NeedsReview('Output could not be validated. Administrator should inspect the saved partial file.') from None
