import json
import tempfile
from datetime import timedelta
from pathlib import Path
from unittest.mock import patch

from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from django.utils import timezone

from .browser_identity import annotate_accounts
from .models import BrowserIdentity
from .profile_inventory import MAX_METADATA_BYTES, profile_inventory


@override_settings(AXES_ENABLED=False)
class SavedProfileTests(TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.accounts = [{'id': f'FA-{i:03}', 'email': f'imported{i}@example.test'} for i in range(1, 7)]

    def save(self, profile, data, relative='Default/Preferences'):
        path = self.root / profile / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data), encoding='utf-8')
        return path

    def test_saved_gmail_appears_without_helper_and_without_changing_inventory(self):
        self.save('FA-003', {'account_info': [{'email': 'Actual@Example.test', 'token': 'never-return-this'}]})
        inventory = profile_inventory(self.accounts, self.root)
        rows, counts = annotate_accounts(self.accounts, {}, inventory=inventory)
        self.assertEqual(rows[0]['id'], 'FA-003')
        self.assertEqual(rows[0]['display_email'], 'actual@example.test')
        self.assertEqual(rows[0]['identity_state'], 'saved')
        self.assertEqual(rows[0]['email'], 'imported3@example.test')
        self.assertFalse(rows[0]['helper_configured'])
        self.assertEqual((counts['saved_profiles'], counts['confirmed']), (1, 0))
        self.assertNotIn('never-return-this', repr(inventory))
        self.assertNotIn('token', repr(inventory))

    def test_new_profiles_and_account_changes_are_discovered_without_setup(self):
        path = self.save('FA-006', {'account_info': [{'email': 'old@example.test'}]})
        self.assertEqual(profile_inventory(self.accounts, self.root)['FA-006']['emails'], ('old@example.test',))
        path.write_text(json.dumps({'account_info': [{'email': 'new-account@example.test'}]}))
        self.assertEqual(profile_inventory(self.accounts, self.root)['FA-006']['emails'], ('new-account@example.test',))
        self.save('FA-007', {'account_info': [{'email': 'seventh@example.test'}]})
        accounts = self.accounts + [{'id': 'FA-007', 'email': 'unused@example.test'}]
        self.assertEqual(profile_inventory(accounts, self.root)['FA-007']['emails'], ('seventh@example.test',))

    def test_multiple_accounts_are_listed_without_guessing_the_active_one(self):
        self.save('FA-001', {'account_info': [{'email': 'one@example.test'}, {'email': 'two@example.test'}, {'email': 'ONE@example.test'}]})
        self.save('FA-002', {'account_info': [{'email': 'one@example.test'}]})
        rows, counts = annotate_accounts(self.accounts, {}, inventory=profile_inventory(self.accounts, self.root))
        first = next(row for row in rows if row['id'] == 'FA-001')
        self.assertEqual(first['display_email'], '')
        self.assertEqual(first['display_title'], 'Multiple saved Gmails')
        self.assertEqual(counts['saved_profiles'], 2)
        self.assertEqual(counts['unique_saved_emails'], 2)
        self.assertEqual(counts['confirmed'], 0)

    def test_recent_live_observation_wins_over_saved_chrome_identity(self):
        now = timezone.now()
        self.save('FA-002', {'account_info': [{'email': 'saved@example.test'}]})
        identity = BrowserIdentity(account_id='FA-002', observed_email='live@example.test',
            observation='observed', observed_at=now, received_at=now)
        rows, counts = annotate_accounts(self.accounts, {'FA-002': identity}, now,
            inventory=profile_inventory(self.accounts, self.root))
        self.assertEqual(rows[0]['display_email'], 'live@example.test')
        self.assertEqual(rows[0]['identity_state'], 'confirmed')
        self.assertEqual(counts['saved_profiles'], 1)
        self.assertEqual(counts['confirmed'], 1)
        identity.observed_at = now - timedelta(minutes=6)
        rows, counts = annotate_accounts(self.accounts, {'FA-002': identity}, now,
            inventory=profile_inventory(self.accounts, self.root))
        self.assertEqual(rows[0]['display_email'], 'saved@example.test')
        self.assertEqual(rows[0]['identity_label'], 'Account saved')
        self.assertEqual(counts['confirmed'], 0)

    def test_missing_or_invalid_metadata_does_not_claim_a_signed_out_account(self):
        path = self.save('FA-001', {'account_info': []})
        path.write_text('temporarily incomplete JSON')
        self.save('FA-002', {'account_info': [{'email': 'invalid'}, {'email': None}, 'bad']})
        large = self.save('FA-003', {})
        large.write_bytes(b' ' * (MAX_METADATA_BYTES + 1))
        rows, counts = annotate_accounts(self.accounts, {}, inventory=profile_inventory(self.accounts, self.root))
        self.assertEqual(counts['confirmed'], 0)
        self.assertEqual(counts['saved_profiles'], 0)
        self.assertEqual(counts['profile_folders'], 3)
        self.assertEqual(counts['unidentified'], 6)
        self.assertIn('Profile saved', rows[0]['identity_label'])

    def test_fallback_uses_chrome_email_not_user_chosen_profile_name(self):
        self.save('FA-001', {'profile': {'name': 'not-proof@example.test'}})
        self.save('FA-001', {'profile': {'info_cache': {'Default': {'user_name': 'cached@example.test'}}}}, 'Local State')
        self.assertEqual(profile_inventory(self.accounts, self.root)['FA-001']['emails'], ('cached@example.test',))

    def test_mapped_profile_is_used_and_path_traversal_is_rejected(self):
        self.save('Team-A', {'account_info': [{'email': 'team@example.test'}]})
        accounts = [{'id': 'FA-001', 'mapping': {'profile_id': 'Team-A'}},
                    {'id': 'FA-002', 'mapping': {'profile_id': '../outside'}}]
        inventory = profile_inventory(accounts, self.root)
        self.assertEqual(inventory['FA-001']['emails'], ('team@example.test',))
        self.assertNotIn('FA-002', inventory)

    def test_dashboard_searches_saved_emails_and_does_not_require_per_profile_setup(self):
        user = User.objects.create_user('saved-view-admin', is_staff=True)
        self.client.force_login(user)
        self.save('FA-004', {'account_info': [{'email': 'fourth@example.test'}]})
        inventory = profile_inventory(self.accounts, self.root)
        with patch('workspace.google_login.worker', return_value={'accounts': self.accounts, 'managed_pool': []}), \
             patch('workspace.google_login.profile_inventory', return_value=inventory):
            response = self.client.get('/google-login/?q=fourth@example.test')
        self.assertContains(response, 'fourth@example.test')
        self.assertContains(response, 'Account saved')
        self.assertContains(response, 'account-saved')
        self.assertContains(response, 'Open saved profile')
        self.assertNotContains(response, 'Automatic detection settings')
        self.assertEqual(response.context['counts']['confirmed'], 0)
        self.assertEqual(response.context['counts']['saved_profiles'], 1)
