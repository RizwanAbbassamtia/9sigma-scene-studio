"""Profile-scoped observations; a profile can contain any signed-in Google email."""
import hashlib,io,json,re,secrets,zipfile
from datetime import datetime,timezone as dt_timezone
from django.contrib.auth.decorators import login_required
from django.conf import settings
from django.core.exceptions import PermissionDenied,ValidationError
from django.core.validators import validate_email
from django.db import transaction
from django.http import FileResponse,JsonResponse,Http404
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.http import require_http_methods
from .models import BrowserIdentity

EXTENSION_ID='lmmpapnomiefobelfcjohopbgnpmpmic'
EXTENSION_ORIGIN='chrome-extension://'+EXTENSION_ID
FRESH_SECONDS=300
HELPER_FILES=['manifest.json','background.js','observe.js','popup.html','popup.js','popup.css','README.txt']

def helper_archive(profile_id=None,code=None,portal_origin=None):
    root=settings.BASE_DIR.parent/'Scene-Studio-Login-Helper'
    if not all((root/name).is_file() for name in HELPER_FILES):raise Http404('Helper package is not installed on this server.')
    folder='Scene-Studio-Login-Helper'+('-'+profile_id if profile_id else '')
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as archive:
        for name in HELPER_FILES:
            if name=='manifest.json' and profile_id:
                manifest=json.loads((root/name).read_text(encoding='utf-8'))
                manifest['name']='9 Sigma Login Observer - '+profile_id
                archive.writestr(folder+'/'+name,json.dumps(manifest))
            else:archive.write(root/name,folder+'/'+name)
        if profile_id:
            archive.writestr(folder+'/profile-config.json',json.dumps({'account_id':profile_id,'code':code,'portal':portal_origin}))
    stream.seek(0)
    return FileResponse(stream,as_attachment=True,filename=folder+'.zip',content_type='application/zip')

@login_required
@never_cache
@require_http_methods(['GET'])
def helper_download(request):
    if not request.user.is_staff:raise PermissionDenied('Administrator access required.')
    return helper_archive()

def annotate_accounts(accounts,identities,now=None,inventory=None):
    now=now or timezone.now()
    inventory=inventory or {}
    counts=dict(total=len(accounts),confirmed=0,unique_emails=0,stale=0,saved=0,unverified=0,opened=0,
                saved_profiles=0,unique_saved_emails=0,profile_folders=0,unidentified=0)
    confirmed_emails=set()
    saved_emails=set()
    rows=[]
    for account in accounts:
        row=dict(account)
        identity=identities.get(row['id'])
        profile=inventory.get(row['id'],{})
        profile_emails=profile.get('emails',())
        counts['saved_profiles']+=int(bool(profile_emails))
        counts['profile_folders']+=int(bool(profile.get('saved')))
        saved_emails.update(profile_emails)
        opened=any(v.get('state')=='manual' for v in row.get('connections',{}).values())
        counts['opened']+=int(opened)
        state='unverified'; label='Opened · login unverified' if opened else 'Login unverified'
        email=identity.observed_email if identity else ''
        checked=identity.observed_at if identity else None
        if identity and identity.observation=='observed' and email:
            fresh=checked and 0 <= (now-checked).total_seconds() <= FRESH_SECONDS
            alive=identity.received_at and 0 <= (now-identity.received_at).total_seconds() <= 90
            if not fresh or not alive:
                state='stale';label='Last observed · recheck needed'
            else:
                state='confirmed';label='Signed in · email confirmed'
                confirmed_emails.add(email.casefold())
        elif identity and identity.observation=='ambiguous':
            label='Several Google emails · check profile'
        elif identity and identity.observation=='rejected':
            label='Google rejected sign-in'
        elif email:
            label='Last detected email · check needed'
        display_email=email
        email_source='Last live observation' if email else 'Email not detected yet'
        if state=='confirmed':
            email_source='Live Google Account observation'
        elif profile_emails:
            display_email=profile_emails[0] if len(profile_emails)==1 else ''
            email_source='Saved Chrome account record'
            if not identity or identity.observation not in ('rejected','ambiguous'):
                state='saved'
                label='Account saved' if len(profile_emails)==1 else 'Multiple saved Gmails · active account unverified'
        elif profile.get('saved') and not email and label in ('Opened · login unverified','Login unverified'):
            label='Profile saved · email not detected yet'
        counts['unidentified']+=int(not display_email and not profile_emails)
        counts[state]+=1
        row.update(identity_state=state,identity_label=label,observed_email=email,identity_checked=checked,
                   helper_configured=bool(identity and identity.token_hash),opened=opened,
                   display_email=display_email,display_title=display_email or ('Multiple saved Gmails' if profile_emails else 'Email not detected yet'),
                   email_source=email_source,saved_emails=profile_emails,profile_saved=bool(profile.get('saved')))
        rows.append(row)
    counts['unique_emails']=len(confirmed_emails)
    counts['unique_saved_emails']=len(saved_emails)
    ranks={'confirmed':0,'saved':1,'stale':2,'unverified':3}
    rows.sort(key=lambda a:(ranks[a['identity_state']],not a['opened'],a['id']))
    return rows,counts

@login_required
@never_cache
@sensitive_post_parameters()
@require_http_methods(['GET','POST'])
def helper_setup(request,account_id):
    if not request.user.is_staff:raise PermissionDenied('Administrator access required.')
    from .google_login import worker
    try:state=worker(request)
    except Exception:
        return render(request,'helper_setup.html',{'worker_offline':True},status=503)
    account=next((a for a in state['accounts'] if a['id']==account_id),None)
    if not account:raise PermissionDenied('Unknown account.')
    identity=BrowserIdentity.objects.filter(account_id=account_id).first()
    if request.method=='POST':
        if request.POST.get('action')=='download':
            # Scope the detector to the container, never to a Gmail address.
            if request.scheme!='http' or request.get_host().split(':',1)[0]!='127.0.0.1':
                raise PermissionDenied('Automatic setup requires this local portal at 127.0.0.1.')
            token=secrets.token_urlsafe(32)
            code=account_id+'.'+token
            response=helper_archive(account_id,code,request.scheme+'://'+request.get_host())
            BrowserIdentity.objects.update_or_create(account_id=account_id,defaults={
                'expected_email':account['email'],'token_hash':hashlib.sha256(code.encode()).hexdigest(),
                'observation':'unknown','reported_at':None,'received_at':None})
            return response
        elif request.POST.get('action')=='revoke' and identity:
            identity.token_hash='';identity.observation='unknown';identity.save()
        else:raise PermissionDenied('Unknown action.')
    return render(request,'helper_setup.html',dict(account=account,identity=identity,
        extension_id=EXTENSION_ID,portal_origin=request.scheme+'://'+request.get_host()))

def reply(request,data,status=200):
    response=JsonResponse(data,status=status)
    response['Cache-Control']='no-store'
    if request.headers.get('Origin')==EXTENSION_ORIGIN:
        response['Access-Control-Allow-Origin']=EXTENSION_ORIGIN
        response['Vary']='Origin'
        response['Access-Control-Allow-Headers']='Authorization, Content-Type'
        response['Access-Control-Allow-Methods']='POST, OPTIONS'
    return response

@csrf_exempt
@never_cache
@require_http_methods(['POST','OPTIONS'])
def helper_receiver(request,operation):
    # Cookie-based portal authentication cannot authorize helper reports.
    if request.META.get('REMOTE_ADDR') not in ('127.0.0.1','::1') or request.headers.get('Origin')!=EXTENSION_ORIGIN:
        return reply(request,{'error':'Local profile detector required.'},403)
    if operation not in ('identify','pair','report'):return reply(request,{'error':'Unknown operation.'},404)
    if request.method=='OPTIONS':return reply(request,{})
    authorization=request.headers.get('Authorization','')
    code=authorization.removeprefix('Bearer ')
    if not authorization.startswith('Bearer ') or not re.fullmatch(r'FA-\d{3,}\.[A-Za-z0-9_-]{40,64}',code):
        return reply(request,{'error':'Invalid profile detector configuration.'},403)
    account_id=code.split('.',1)[0]
    if request.content_type!='application/json':
        return reply(request,{'error':'Invalid report.'},400)
    try:
        if int(request.META.get('CONTENT_LENGTH') or 0)>2048 or len(request.body)>2048:raise ValueError()
        data=json.loads(request.body)
        if not isinstance(data,dict):raise ValueError()
    except (ValueError,UnicodeDecodeError):return reply(request,{'error':'Invalid report.'},400)
    with transaction.atomic():
        identity=BrowserIdentity.objects.select_for_update().filter(account_id=account_id).first()
        if not identity or not identity.token_hash or not secrets.compare_digest(identity.token_hash,hashlib.sha256(code.encode()).hexdigest()):
            return reply(request,{'error':'Invalid profile detector configuration.'},403)
        if operation in ('identify','pair'):return reply(request,{'account_id':account_id})
        try:
            state=data['state']; email=data.get('email','')
            if not isinstance(email,str):raise ValueError()
            email=email.strip()
            if state not in ('observed','unknown','ambiguous','rejected'):raise ValueError()
            if state=='observed':validate_email(email)
            elif email:raise ValueError()
            if len(email)>254 or data.get('page_origin') not in ('https://myaccount.google.com','https://accounts.google.com'):raise ValueError()
            if state=='observed' and data['page_origin']!='https://myaccount.google.com':raise ValueError()
            checked=datetime.fromtimestamp(float(data['observed_at'])/1000,tz=dt_timezone.utc)
            reported=datetime.fromtimestamp(float(data['reported_at'])/1000,tz=dt_timezone.utc)
            now=timezone.now()
            if (checked-now).total_seconds()>30 or abs((reported-now).total_seconds())>60 or checked>reported:raise ValueError()
        except (KeyError,ValueError,TypeError,OverflowError,OSError,ValidationError):
            return reply(request,{'error':'Invalid observation.'},400)
        if identity.reported_at and reported<identity.reported_at:
            return reply(request,{'accepted':False,'reason':'Older report ignored.'})
        identity.observation=state
        # Retain the last observed email when the page closes, without green status.
        if state=='observed':identity.observed_email=email;identity.observed_at=checked
        identity.reported_at=reported;identity.received_at=now
        identity.save(update_fields=['observation','observed_email','observed_at','reported_at','received_at'])
    return reply(request,{'accepted':True})
