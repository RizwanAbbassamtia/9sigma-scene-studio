import copy
import os
from unittest.mock import patch

from django.contrib.auth.models import Permission, User
from django.test import TestCase, override_settings

from .browser_dispatch import tick
from .models import Batch, Scene


@override_settings(AXES_ENABLED=False,
                   PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class ContinueQueuedSceneTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user('continue-owner', password='test-password')
        self.owner.user_permissions.add(Permission.objects.get(codename='generate_video'))
        self.batch = Batch.objects.create(owner=self.owner, title='Four scenes', status='paused',
            backend='browser', worker_run='20261008-182233-904313', worker_note='Scene 1 needs review')
        self.review = Scene.objects.create(batch=self.batch, number=1, prompt='Original scene',
            status='review', provider_id='gemini/FA-004', attempts=1, note='Existing result needs review')
        for number in range(2, 5):
            Scene.objects.create(batch=self.batch, number=number, prompt=f'Next scene {number}', status='queued')
        self.url = f'/batches/{self.batch.pk}/'
        self.client.force_login(self.owner)
        environment = patch.dict(os.environ, {'BROWSER_GENERATION_ENABLED': '1', 'GENERATION_ENABLED': '1'})
        environment.start()
        self.addCleanup(environment.stop)
        block = patch('workspace.batch_views.browser_generation_block', return_value='')
        block.start()
        self.addCleanup(block.stop)

    def assert_review_preserved(self):
        self.review.refresh_from_db()
        self.assertEqual(self.review.status, 'review')
        self.assertEqual(self.review.provider_id, 'gemini/FA-004')
        self.assertEqual(self.review.attempts, 1)
        self.assertEqual(self.review.prompt, 'Original scene')
        self.assertEqual(self.review.note, 'Existing result needs review')

    def test_continue_dispatches_only_resume_and_preserves_review_receipt(self):
        saved_rows = [{'number': 1, 'status': 'review', 'provider': 'gemini', 'account': 'FA-004',
                       'receipt': 'original-receipt', 'file': None, 'note': self.review.note}]
        saved_rows += [{'number': n, 'status': 'todo'} for n in range(2, 5)]
        original_rows = copy.deepcopy(saved_rows)
        calls = []

        def worker(action=None, payload=None, path=None):
            calls.append((action, payload, path))
            if path:
                self.assertEqual(path, 'run?run=' + self.batch.worker_run)
                return {'rows': saved_rows}
            if action:
                self.assertEqual(action, 'resume')
                self.assertEqual(payload, {'run': self.batch.worker_run})
                return {}
            return {'busy': False, 'current': self.batch.worker_run, 'saved_profile_generation': 5,
                    'generation_candidates': [{'id': 'FA-004', 'email': 'saved@example.test'}]}

        response = self.client.post(self.url, {'action': 'continue'})
        self.assertEqual(response.status_code, 302)
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'running')
        self.assert_review_preserved()
        with patch('workspace.browser_dispatch.worker', side_effect=worker):
            tick()
        self.assertEqual([call[0] for call in calls if call[0]], ['resume'])
        self.assertEqual(saved_rows, original_rows)
        self.assert_review_preserved()
        self.assertEqual(self.batch.scenes.filter(status='processing').count(), 3)

    def test_template_offers_continue_and_explains_preserved_reviews(self):
        response = self.client.get(self.url)
        self.assertContains(response, 'Continue queued scenes', count=1)
        self.assertContains(response, 'name="action" value="continue"', count=1)
        self.assertContains(response, 'Scenes needing review stay unchanged. Only queued scenes will continue.')

    def test_processing_scene_blocks_continue(self):
        self.batch.scenes.filter(number=2).update(status='processing')
        with patch('workspace.batch_views.worker') as worker:
            response = self.client.post(self.url, {'action': 'continue'}, follow=True)
        worker.assert_not_called()
        self.assertNotContains(response, 'value="continue"')
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assert_review_preserved()

    def test_queued_retry_request_cannot_be_silently_included(self):
        self.batch.scenes.filter(number=2).update(note='User reviewed provider and requested retry.')
        self.client.post(self.url, {'action': 'continue'})
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assert_review_preserved()

    def test_no_pending_scene_or_no_saved_run_blocks_continue(self):
        self.batch.scenes.filter(status='queued').update(status='done')
        self.client.post(self.url, {'action': 'continue'})
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.batch.scenes.filter(number=2).update(status='queued')
        self.batch.worker_run = ''
        self.batch.save()
        self.client.post(self.url, {'action': 'continue'})
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assert_review_preserved()

    def test_continue_requires_owner_and_generation_permission(self):
        self.owner.user_permissions.clear()
        self.client.post(self.url, {'action': 'continue'})
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        other = User.objects.create_user('other', password='test-password')
        other.user_permissions.add(Permission.objects.get(codename='generate_video'))
        self.client.force_login(other)
        self.assertEqual(self.client.post(self.url, {'action': 'continue'}).status_code, 404)
        self.assert_review_preserved()

    def test_api_cannot_use_browser_continue_to_bypass_billing_confirmation(self):
        self.batch.backend = 'api'
        self.batch.save()
        for confirm in ('', 'yes'):
            with self.subTest(confirm=confirm):
                self.client.post(self.url, {'action': 'continue', 'confirm': confirm})
                self.batch.refresh_from_db()
                self.assertEqual(self.batch.status, 'paused')
        response = self.client.get(self.url)
        self.assertNotContains(response, 'value="continue"')
        self.assertContains(response, 'Authorize separately billed API use.')

    def test_normal_start_still_does_not_release_review_scene(self):
        self.client.post(self.url, {'action': 'start'})
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assert_review_preserved()

    def test_worker_readiness_failure_preserves_all_scene_states(self):
        with patch('workspace.batch_views.browser_generation_block', return_value='Worker unavailable'):
            self.client.post(self.url, {'action': 'continue'})
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assertEqual(self.batch.scenes.filter(status='queued').count(), 3)
        self.assert_review_preserved()
