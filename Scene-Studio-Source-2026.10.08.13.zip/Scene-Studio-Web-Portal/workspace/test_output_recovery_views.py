import io
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from django.contrib.auth.models import Permission, User
from django.test import SimpleTestCase, TestCase, override_settings

from .google_login import worker as real_worker
from .models import Batch, Scene


class ExistingOutputRecoveryWorkerTransportTests(SimpleTestCase):
    def setUp(self):
        self.folder = TemporaryDirectory(prefix='scene-worker-recovery-')
        self.addCleanup(self.folder.cleanup)
        session = Path(self.folder.name) / 'session.json'
        session.write_text(json.dumps({'port': 8788, 'token': 'test-token-not-a-real-secret'}), encoding='utf-8')
        self.environment = patch.dict(os.environ, {
            'SCENE_LOGIN_SESSION': str(session), 'SCENE_WORKER_PORT': '8788'})
        self.environment.start()
        self.addCleanup(self.environment.stop)

    def test_real_worker_allows_recovery_endpoint_and_exact_post_body(self):
        payload = {'run': '20261008-182233-904313', 'number': 1}
        expected = {'run': payload['run'], 'number': 1, 'new_generation': False}
        response = io.BytesIO(json.dumps(expected).encode())
        with patch('workspace.google_login.urlopen', return_value=response) as transport:
            result = real_worker(action='recover-output', payload=payload)
        self.assertEqual(result, expected)
        transport.assert_called_once()
        request = transport.call_args.args[0]
        self.assertEqual(request.full_url, 'http://127.0.0.1:8788/api/recover-output')
        self.assertEqual(request.get_method(), 'POST')
        self.assertEqual(json.loads(request.data), payload)
        self.assertEqual(request.get_header('X-omni-token'), 'test-token-not-a-real-secret')
        self.assertEqual(transport.call_args.kwargs, {'timeout': 30})

    def test_unsupported_action_still_rejected_before_network(self):
        with patch('workspace.google_login.urlopen') as transport:
            with self.assertRaisesMessage(ValueError, 'Unsupported worker action'):
                real_worker(action='unsupported-action', payload={'run': '20261008-182233-904313'})
        transport.assert_not_called()

    def test_recovery_cannot_be_sent_as_unapproved_read_path(self):
        with patch('workspace.google_login.urlopen') as transport:
            with self.assertRaisesMessage(ValueError, 'Unsupported worker read'):
                real_worker(path='recover-output')
        transport.assert_not_called()


@override_settings(AXES_ENABLED=False,
                   PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class ExistingOutputRecoveryViewTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user('recovery-owner', password='test-password')
        self.other = User.objects.create_user('other-owner', password='test-password')
        self.owner.user_permissions.add(Permission.objects.get(codename='generate_video'))
        self.batch = Batch.objects.create(owner=self.owner, title='Saved result', status='paused',
            backend='browser', worker_run='20261008-182233-904313', worker_note='Saved request needs review')
        self.scene = Scene.objects.create(batch=self.batch, number=1, prompt='A tree', status='review',
            attempts=1, provider_id='gemini/FA-004', note='Saved receipt is waiting for download')
        self.url = f'/batches/{self.batch.pk}/'
        self.client.force_login(self.owner)
        self.block_patch = patch('workspace.batch_views.browser_generation_block', return_value='')
        self.block_patch.start()
        self.addCleanup(self.block_patch.stop)

    def recover(self, **kwargs):
        return self.client.post(self.url, {'action': 'recover', 'scene': self.scene.pk}, **kwargs)

    def assert_saved_scene_unchanged(self):
        self.scene.refresh_from_db()
        self.assertEqual(self.scene.status, 'review')
        self.assertEqual(self.scene.prompt, 'A tree')
        self.assertEqual(self.scene.provider_id, 'gemini/FA-004')
        self.assertEqual(self.scene.attempts, 1)
        self.assertEqual(self.scene.note, 'Saved receipt is waiting for download')
        self.assertEqual(self.scene.file, '')

    def test_recovery_requires_login(self):
        self.client.logout()
        with patch('workspace.batch_views.worker') as worker:
            response = self.recover()
        self.assertEqual(response.status_code, 302)
        self.assertIn('/login/', response.url)
        worker.assert_not_called()
        self.assert_saved_scene_unchanged()

    def test_other_owner_cannot_recover_saved_batch(self):
        self.other.user_permissions.add(Permission.objects.get(codename='generate_video'))
        self.client.force_login(self.other)
        with patch('workspace.batch_views.worker') as worker:
            response = self.recover()
        self.assertEqual(response.status_code, 404)
        worker.assert_not_called()
        self.assert_saved_scene_unchanged()

    def test_owner_without_generation_permission_cannot_recover(self):
        self.owner.user_permissions.clear()
        with patch('workspace.batch_views.worker') as worker:
            response = self.recover(follow=True)
        self.assertContains(response, 'Generation access is required')
        worker.assert_not_called()
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assert_saved_scene_unchanged()

    def test_scene_must_belong_to_selected_batch(self):
        other_batch = Batch.objects.create(owner=self.owner, title='Another batch')
        other_scene = Scene.objects.create(batch=other_batch, number=1, prompt='Other', status='review')
        with patch('workspace.batch_views.worker') as worker:
            response = self.client.post(self.url, {'action': 'recover', 'scene': other_scene.pk})
        self.assertEqual(response.status_code, 404)
        worker.assert_not_called()

    def test_recovery_rejects_scene_that_is_not_needing_review(self):
        self.scene.status = 'queued'
        self.scene.save()
        with patch('workspace.batch_views.worker') as worker:
            response = self.recover()
        self.assertEqual(response.status_code, 404)
        worker.assert_not_called()

    def test_batch_needs_saved_browser_run(self):
        for backend, run in [('api', self.batch.worker_run), ('browser', '')]:
            with self.subTest(backend=backend, run=run):
                self.batch.backend = backend
                self.batch.worker_run = run
                self.batch.save()
                with patch('workspace.batch_views.worker') as worker:
                    response = self.recover(follow=True)
                self.assertContains(response, 'no saved browser result')
                worker.assert_not_called()
                self.assert_saved_scene_unchanged()

    def test_success_calls_only_recover_output_and_marks_batch_running(self):
        with patch('workspace.batch_views.worker', return_value={'new_generation': False}) as worker:
            response = self.recover(follow=True)
        worker.assert_called_once_with(action='recover-output',
            payload={'run': self.batch.worker_run, 'number': 1})
        self.assertContains(response, 'No new prompt was submitted')
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'running')
        self.assertEqual(self.batch.worker_run, '20261008-182233-904313')
        self.assert_saved_scene_unchanged()

    def test_failed_worker_keeps_paused_batch_and_scene_reference(self):
        with patch('workspace.batch_views.worker', side_effect=ConnectionError('private worker detail')) as worker:
            response = self.recover(follow=True)
        worker.assert_called_once_with(action='recover-output',
            payload={'run': self.batch.worker_run, 'number': 1})
        self.assertContains(response, 'Recovery could not start')
        self.assertNotContains(response, 'private worker detail')
        self.batch.refresh_from_db()
        self.assertEqual(self.batch.status, 'paused')
        self.assertEqual(self.batch.worker_note, 'Saved request needs review')
        self.assertEqual(self.batch.worker_run, '20261008-182233-904313')
        self.assert_saved_scene_unchanged()

    def test_template_exposes_recovery_for_gemini_review_without_local_file(self):
        with patch('workspace.batch_views.worker') as worker:
            response = self.client.get(self.url)
        self.assertContains(response, 'Check existing result', count=1)
        self.assertContains(response, 'name="action" value="recover"', count=1)
        self.assertContains(response, 'Reopens the saved result without generating again.')
        worker.assert_not_called()

    def test_template_hides_recovery_for_other_provider_status_or_saved_file(self):
        for provider, status, file in [('flow/FA-004', 'review', ''),
                                       ('gemini/FA-004', 'queued', ''),
                                       ('gemini/FA-004', 'review', 'videos/saved.mp4')]:
            with self.subTest(provider=provider, status=status, file=file):
                self.scene.provider_id, self.scene.status, self.scene.file = provider, status, file
                self.scene.save()
                response = self.client.get(self.url)
                self.assertNotContains(response, 'Check existing result')
                self.assertNotContains(response, 'value="recover"')
