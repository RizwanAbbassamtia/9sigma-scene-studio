import base64
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch, MagicMock
from django.test import TestCase, Client, override_settings
from django.contrib.auth.models import User, Permission
from .models import Batch, Scene, GoogleAccount, Ticket
from .forms import BatchForm
from .generation import generate, NeedsReview, ProviderPause


@override_settings(AXES_ENABLED=False)
class PortalTests(TestCase):
    def setUp(self):
        self.user=User.objects.create_user('alice',password='a-long-test-password-295!')
        self.other=User.objects.create_user('bob',password='another-test-password-296!')
        self.client.force_login(self.user)

    def test_anonymous_and_non_admin_access(self):
        self.assertContains(Client().get('/'),'Turn your imagination')
        self.assertEqual(Client().get('/jobs/').status_code,302)
        self.assertEqual(self.client.get('/admin/').status_code,302)

    def test_private_accounts_and_tickets(self):
        GoogleAccount.objects.create(owner=self.other,email='private@example.com')
        ticket=Ticket.objects.create(owner=self.other,subject='Private',message='Secret')
        self.assertNotContains(self.client.get('/accounts/'),'private@example.com')
        self.assertEqual(self.client.get(f'/support/{ticket.pk}/').status_code,404)

    def test_100_prompts_and_limit(self):
        fields={'title':'Batch','aspect':'16:9','prompts':'\n'.join(f'{i}: Scene {i}' for i in range(1,101))}
        self.assertEqual(self.client.post('/batches/',fields).status_code,302)
        self.assertEqual(Scene.objects.count(),100)
        self.assertEqual(Batch.objects.get().status,'draft')
        fields['prompts']+='\n101: extra'
        self.assertFalse(BatchForm(fields).is_valid())

    def test_multiline_prompts(self):
        form=BatchForm({'title':'X','aspect':'9:16','prompts':'1: First\ncontinued\n2: Next'})
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['prompts'],['First\ncontinued','Next'])

    def test_batch_isolation_and_download(self):
        batch=Batch.objects.create(owner=self.other,title='Private')
        scene=Scene.objects.create(batch=batch,number=1,prompt='Private',status='done',file='secret.mp4')
        self.assertEqual(self.client.get(f'/batches/{batch.pk}/').status_code,404)
        self.assertEqual(self.client.post(f'/batches/{batch.pk}/',{'action':'pause'}).status_code,404)
        self.assertEqual(self.client.get(f'/scenes/{scene.pk}/download/').status_code,404)
        self.assertEqual(self.client.get(f'/batches/{batch.pk}/zip/').status_code,404)
        self.assertNotContains(self.client.get('/jobs/'),'Private')

    def test_spending_requires_permission_enablement_and_confirmation(self):
        batch=Batch.objects.create(owner=self.user,title='X',backend='api')
        Scene.objects.create(batch=batch,number=1,prompt='Test')
        url=f'/batches/{batch.pk}/'
        self.client.post(url,{'action':'start','confirm':'yes'})
        batch.refresh_from_db();self.assertEqual(batch.status,'draft')
        self.user.user_permissions.add(Permission.objects.get(codename='generate_video'))
        with patch.dict(os.environ,{'GENERATION_ENABLED':'1'}):
            self.client.post(url,{'action':'start'})
            batch.refresh_from_db();self.assertEqual(batch.status,'draft')
            self.client.post(url,{'action':'start','confirm':'yes'})
            batch.refresh_from_db();self.assertEqual(batch.status,'running')

    def test_csrf_and_logout_method(self):
        client=Client(enforce_csrf_checks=True);client.force_login(self.user)
        self.assertEqual(client.post('/accounts/',{'emails':'a@example.com'}).status_code,403)
        self.assertEqual(self.client.get('/logout/').status_code,405)

    def test_review_retry_does_not_start_spending(self):
        batch=Batch.objects.create(owner=self.user,title='X',status='paused')
        scene=Scene.objects.create(batch=batch,number=1,prompt='X',status='review')
        url=f'/batches/{batch.pk}/'
        self.client.post(url,{'action':'retry','scene':scene.pk})
        scene.refresh_from_db();self.assertEqual(scene.status,'review')
        self.client.post(url,{'action':'retry','scene':scene.pk,'reviewed':'yes'})
        scene.refresh_from_db();batch.refresh_from_db()
        self.assertEqual(scene.status,'queued');self.assertEqual(batch.status,'paused')

    def test_saved_mock_video_and_download(self):
        batch=Batch.objects.create(owner=self.user,title='X')
        scene=Scene.objects.create(batch=batch,number=1,prompt='X',attempts=1)
        payload={'id':'fake-id','steps':[{'type':'model_output','content':[{'type':'video','mime_type':'video/mp4','data':base64.b64encode(b'FAKE-MOCK-VIDEO').decode()}]}]}
        response=MagicMock();response.__enter__.return_value.read.return_value=json.dumps(payload).encode()
        probe=MagicMock(stdout=json.dumps({'format':{'duration':'10.005'},'streams':[{'codec_type':'video'}]}))
        with TemporaryDirectory() as folder,override_settings(DATA=Path(folder)),patch.dict(os.environ,{'GENERATION_ENABLED':'1','GEMINI_API_KEY':'fake'}),patch('workspace.generation.urlopen',return_value=response) as call,patch('workspace.generation.subprocess.run',return_value=probe):
            generate(scene);self.assertEqual(call.call_count,1)
            scene.status='done';scene.save()
            download=self.client.get(f'/scenes/{scene.pk}/download/')
            self.assertEqual(download.status_code,200)
            download.close()
            archive=self.client.get(f'/batches/{batch.pk}/zip/')
            import io,zipfile
            contents=b''.join(archive.streaming_content)
            archive.close()
            with zipfile.ZipFile(io.BytesIO(contents)) as packed:
                self.assertEqual(packed.namelist(),['scene-001.mp4'])
                self.assertEqual(packed.read('scene-001.mp4'),b'FAKE-MOCK-VIDEO')
            self.assertEqual(scene.duration,10.005)

    def test_uncertain_submission_is_not_retried(self):
        scene=Scene.objects.create(batch=Batch.objects.create(owner=self.user,title='X'),number=1,prompt='X')
        with patch.dict(os.environ,{'GENERATION_ENABLED':'1','GEMINI_API_KEY':'fake'}),patch('workspace.generation.urlopen',side_effect=TimeoutError) as call:
            with self.assertRaises(NeedsReview):generate(scene)
            self.assertEqual(call.call_count,1)

    def test_disabled_provider_never_calls_network(self):
        scene=Scene.objects.create(batch=Batch.objects.create(owner=self.user,title='X'),number=1,prompt='X')
        with patch.dict(os.environ,{'GENERATION_ENABLED':'0'}),patch('workspace.generation.urlopen') as call:
            with self.assertRaises(ProviderPause):generate(scene)
            call.assert_not_called()

    def test_pages_render(self):
        batch=Batch.objects.create(owner=self.user,title='<script>')
        for url in ['/', '/accounts/','/support/','/batches/','/jobs/','/password/',f'/batches/{batch.pk}/']:
            self.assertEqual(self.client.get(url).status_code,200)
        self.assertContains(self.client.get(f'/batches/{batch.pk}/'),'&lt;script&gt;')

    def test_google_login_is_staff_only(self):
        with patch('workspace.google_login.worker') as worker:
            self.assertEqual(self.client.get('/google-login/').status_code,403)
            worker.assert_not_called()

    def test_google_admin_can_connect_known_worker_account(self):
        self.user.is_staff=True;self.user.save()
        state={'accounts':[{'id':'FA-1','email':'test@example.com'}],'busy':False}
        with patch('workspace.google_login.worker',return_value=state) as worker:
            self.assertContains(self.client.get('/google-login/'),'Sign in to Google')
            self.client.post('/google-login/',{'action':'connect','account':'FA-1'})
            self.assertEqual(worker.call_args.args[1: ],('connect',{'id':'FA-1','provider':'both','transport':'managed'}))

    @override_settings(DEBUG=False)
    def test_google_worker_disabled_for_hosted_deployment(self):
        from workspace.google_login import worker
        from django.test import RequestFactory
        with patch.dict(os.environ,{'SCENE_LOGIN_SESSION':''}):
            with self.assertRaisesMessage(ValueError,'not configured'):
                worker(RequestFactory().get('/google-login/'))


class LockoutTests(TestCase):
    def test_repeated_failed_login_locks_account(self):
        User.objects.create_user('locked',password='valid-long-password!')
        for _ in range(5):
            self.client.post('/login/',{'username':'locked','password':'wrong'})
        result=self.client.post('/login/',{'username':'locked','password':'valid-long-password!'})
        self.assertEqual(result.status_code,429)
