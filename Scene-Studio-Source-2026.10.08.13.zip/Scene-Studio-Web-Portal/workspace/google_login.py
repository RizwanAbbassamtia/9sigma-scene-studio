"""Staff controls for the app-owned central browser worker."""
import json,os,ipaddress
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.contrib import messages
from django.shortcuts import render,redirect
from django.core.paginator import Paginator
from django.views.decorators.http import require_http_methods
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.cache import never_cache
from .proxy_input import split_proxy_input
from .browser_identity import annotate_accounts
from .models import BrowserIdentity
from .profile_inventory import profile_inventory

def worker(request=None,action=None,payload=None,path=None):
    session=os.environ.get('SCENE_LOGIN_SESSION')
    if not session:raise ValueError('Central browser worker is not configured.')
    saved=json.loads(Path(session).read_text(encoding='utf-8'))
    port=int(os.environ.get('SCENE_WORKER_PORT','8788'))
    if saved.get('port')!=port:raise ValueError('Unexpected worker port.')
    if action not in (None,'connect','open-services','stop','import','pool-map','pool-status','pool-proxy','pool-proxy-test','create','resume','retry','recover-output'):
        raise ValueError('Unsupported worker action.')
    endpoint=action or path or 'state'
    if not action and not (endpoint=='state' or endpoint.startswith('run?run=') or endpoint.startswith('file?run=')):
        raise ValueError('Unsupported worker read.')
    req=Request(f'http://127.0.0.1:{port}/api/'+endpoint,
        data=json.dumps(payload or {}).encode() if action else None,
        headers={'X-Omni-Token':saved['token'],'Content-Type':'application/json'})
    try:
        with urlopen(req,timeout=30) as response:
            return response.read() if endpoint.startswith('file?') else json.load(response)
    except HTTPError as exc:
        if action in ('pool-proxy', 'pool-proxy-test') and exc.code == 400:
            body=json.loads(exc.read(4096))
            raise ValueError(body.get('error','Proxy settings were rejected.')) from None
        raise


class ProxyForm(forms.Form):
    mode=forms.ChoiceField(label='Connection',choices=[('direct','Direct connection (no proxy)'),('http','HTTP proxy'),('https','HTTPS proxy'),('socks5','SOCKS5 proxy (no authentication)')])
    host=forms.CharField(label='Proxy Host / paste complete proxy',required=False,max_length=5000,widget=forms.TextInput(attrs={'placeholder':'host:port:username:password','autocomplete':'off','spellcheck':'false'}),help_text='Paste host:port:username:password to fill the fields below, or enter the host separately.')
    port=forms.IntegerField(label='Port',required=False,min_value=1,max_value=65535,widget=forms.NumberInput(attrs={'placeholder':'8080'}))
    username=forms.CharField(label='Proxy username (optional)',required=False,max_length=512,strip=False,widget=forms.TextInput(attrs={'autocomplete':'off'}))
    password=forms.CharField(label='Proxy password (optional)',required=False,max_length=4096,strip=False,widget=forms.PasswordInput(attrs={'autocomplete':'new-password'}),help_text='Leave blank to keep the saved password for the same server and username.')
    clear_auth=forms.BooleanField(label='Remove saved proxy authentication',required=False)

    def clean(self):
        values=super().clean()
        if values.get('mode')!='direct':
            try:
                parsed=split_proxy_input(values.get('host',''),values.get('mode'))
                if parsed:
                    values.update(parsed)
                    self._errors.pop('port',None)
            except ValueError as exc:
                self.add_error('host',str(exc))
            for field in ('host','port'):
                if not values.get(field):self.add_error(field,'Required when using a proxy.')
        return values


@login_required
@never_cache
@sensitive_post_parameters('password','host')
@require_http_methods(['GET','POST'])
def profile_proxy(request,account_id):
    if not request.user.is_staff:raise PermissionDenied('Administrator access required.')
    state={}; account=None; mapping={}; error=''; shared=0; network_result=None
    form=ProxyForm(request.POST if request.method=='POST' and request.POST.get('action')!='test' else None)
    try:
        state=worker(request)
        account=next((a for a in state['accounts'] if a['id']==account_id),None)
        mapping=next((a for a in state.get('managed_pool',[]) if a['id']==account_id),None)
        if not account or not mapping:raise ValueError('This account has no managed browser profile.')
        network_result=state.get('network_checks',{}).get(account_id)
        shared=sum(a['profile_id'].casefold()==mapping['profile_id'].casefold() for a in state['managed_pool'])
        if request.method=='POST':
            if state.get('busy'):raise ValueError('Wait for the active browser operation before changing its proxy.')
            if request.POST.get('action')=='test':
                network_result=worker(request,'pool-proxy-test',{'id':account_id})
                safe=mapping.get('proxy',{})
                form=ProxyForm(initial={k:safe.get(k,'') for k in ('mode','host','port','username')} | {'mode':safe.get('mode','direct')})
            elif form.is_valid():
                worker(request,'pool-proxy',{'id':account_id,**form.cleaned_data})
                messages.success(request,f"Proxy settings saved for {account['email']}. They apply the next time its browser opens.")
                return redirect('google_login')
        else:
            safe=mapping.get('proxy',{})
            form=ProxyForm(initial={k:safe.get(k,'') for k in ('mode','host','port','username') } | {'mode':safe.get('mode','direct')})
    except Exception as exc:
        error=str(exc) if isinstance(exc,ValueError) else 'Worker unavailable or request rejected. Check the worker and retry.'
    if request.method=='POST' and request.POST.get('action')!='test':
        # Never echo a packed proxy credential after a validation failure.
        safe_data=request.POST.copy()
        safe_data['host']=getattr(form,'cleaned_data',{}).get('host','')
        if ':' in safe_data['host']:
            try:ipaddress.ip_address(safe_data['host'].strip('[]'))
            except ValueError:safe_data['host']=''
        if '@' in safe_data['host']:
            safe_data['host']=''
        form.data=safe_data
    return render(request,'profile_proxy.html',{'form':form,'account':account,'mapping':mapping,'shared':shared,'state':state,'error':error,'network_result':network_result})

@login_required
@never_cache
@require_http_methods(['GET','POST'])
def google_login(request):
    if not request.user.is_staff:raise PermissionDenied('Administrator access required.')
    state={};error=''
    try:
        state=worker(request)
        if request.method=='POST':
            action=request.POST.get('action')
            if action in ('connect','open-services'):
                account=request.POST.get('account')
                if account not in {a['id'] for a in state['accounts']}:raise ValueError('Unknown account.')
                worker(request,action,{'id':account,'provider':'both','transport':'managed'})
                messages.success(request,'Your saved Chrome profile opened. Existing sessions are preserved. Saved account labels update automatically; sign in only if Google asks.')
            elif action=='import':
                result=worker(request,'import',{'emails':request.POST.get('emails','')})
                messages.success(request,f"{result['added']} Gmail addresses added to the shared pool.")
            elif action=='pool-map':worker(request,'pool-map',{'rows':request.POST.get('rows','')})
            elif action=='pool-status':
                account=request.POST.get('account')
                if account not in {a['id'] for a in state['accounts']}:raise ValueError('Unknown account.')
                worker(request,'pool-status',{'id':account,'paused':request.POST.get('paused')=='1'})
            elif action=='stop':worker(request,'stop',{})
            else:raise ValueError('Unknown action.')
            return redirect('google_login')
    except Exception as exc:
        error=str(exc) if isinstance(exc,ValueError) else 'Worker unavailable or request rejected. Check the worker dashboard and retry.'
    query=request.GET.get('q','').strip()[:254]
    mappings={a['id']:a for a in state.get('managed_pool',[])}
    mapped=[{**a,'mapping':mappings.get(a['id'])} for a in state.get('accounts',[])]
    accounts,counts=annotate_accounts(mapped,{row.account_id:row for row in BrowserIdentity.objects.all()},
                                     inventory=profile_inventory(mapped))
    accounts=[a for a in accounts if query.casefold() in (a['email']+' '+a['observed_email']+' '+' '.join(a['saved_emails'])+' '+a['id']).casefold()]
    return render(request,'google_login.html',{'page':Paginator(accounts,25).get_page(request.GET.get('page')),'query':query,'state':state,'error':error,'counts':counts})
