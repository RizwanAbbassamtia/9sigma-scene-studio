from django.db import migrations,models

class Migration(migrations.Migration):
    dependencies=[('workspace','0002_batch_backend_batch_worker_note_batch_worker_run')]
    operations=[migrations.CreateModel(name='BrowserIdentity',fields=[
        ('id',models.BigAutoField(auto_created=True,primary_key=True,serialize=False,verbose_name='ID')),
        ('account_id',models.CharField(max_length=32,unique=True)),
        ('expected_email',models.EmailField(max_length=254)),
        ('token_hash',models.CharField(max_length=64,blank=True)),
        ('observed_email',models.EmailField(max_length=254,blank=True)),
        ('observation',models.CharField(max_length=16,default='unknown')),
        ('observed_at',models.DateTimeField(null=True)),
        ('reported_at',models.DateTimeField(null=True)),
        ('received_at',models.DateTimeField(null=True)),
    ])]
