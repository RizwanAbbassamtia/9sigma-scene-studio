from django.conf import settings
from django.db import models

class BrowserIdentity(models.Model):
    account_id=models.CharField(max_length=32,unique=True)
    expected_email=models.EmailField()
    token_hash=models.CharField(max_length=64,blank=True)
    observed_email=models.EmailField(blank=True)
    observation=models.CharField(max_length=16,default='unknown')
    observed_at=models.DateTimeField(null=True)
    reported_at=models.DateTimeField(null=True)
    received_at=models.DateTimeField(null=True)

class GoogleAccount(models.Model):
    owner=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    email=models.EmailField()
    created=models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['owner','email'],name='unique_owner_email')]
class Ticket(models.Model):
    owner=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    subject=models.CharField(max_length=160)
    message=models.TextField(max_length=5000)
    response=models.TextField(blank=True,max_length=5000)
    status=models.CharField(max_length=12,choices=[('open','Open'),('answered','Answered'),('closed','Closed')],default='open')
    created=models.DateTimeField(auto_now_add=True)
    updated=models.DateTimeField(auto_now=True)
    def __str__(self):return self.subject

import uuid
class Batch(models.Model):
    id=models.UUIDField(primary_key=True,default=uuid.uuid4,editable=False)
    owner=models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    title=models.CharField(max_length=120)
    worker_run=models.CharField(max_length=32,blank=True)
    worker_note=models.CharField(max_length=500,blank=True)
    backend=models.CharField(max_length=12,default='browser')
    aspect=models.CharField(max_length=5,default='16:9')
    status=models.CharField(max_length=12,default='draft')
    created=models.DateTimeField(auto_now_add=True)
    class Meta:
        permissions=[('generate_video','Can submit separately billed video generation')]
class Scene(models.Model):
    batch=models.ForeignKey(Batch,on_delete=models.CASCADE,related_name='scenes')
    number=models.PositiveIntegerField()
    prompt=models.TextField()
    status=models.CharField(max_length=12,default='queued')
    attempts=models.PositiveIntegerField(default=0)
    provider_id=models.CharField(max_length=300,blank=True)
    file=models.CharField(max_length=500,blank=True)
    duration=models.FloatField(null=True)
    note=models.CharField(max_length=500,blank=True)
    class Meta:
        constraints=[models.UniqueConstraint(fields=['batch','number'],name='unique_scene_number')]
