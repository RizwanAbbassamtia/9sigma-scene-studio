from unittest.mock import patch
from django.test import TestCase, override_settings
from django.contrib.auth.models import User

from .google_login import ProxyForm
from .proxy_input import split_proxy_input


@override_settings(AXES_ENABLED=False)
class ProfileProxyTests(TestCase):
    def setUp(self):
        self.user=User.objects.create_user('proxy-admin',password='test-credential-only',is_staff=True)
        self.client.force_login(self.user)
        self.url='/google-login/FA-001/proxy/'
        self.state={'accounts':[{'id':'FA-001','email':'one@example.test'}],'busy':False,
            'managed_pool':[{'id':'FA-001','profile_id':'FA-001','proxy':{'mode':'http','host':'proxy.test','port':8080,'username':'demo','password_saved':True}}]}

    def test_staff_only_even_for_post(self):
        self.user.is_staff=False;self.user.save()
        with patch('workspace.google_login.worker') as worker:
            self.assertEqual(self.client.get(self.url).status_code,403)
            self.assertEqual(self.client.post(self.url,{'mode':'direct'}).status_code,403)
            worker.assert_not_called()

    def test_form_and_inventory_render(self):
        with patch('workspace.google_login.worker',return_value=self.state):
            response=self.client.get(self.url)
            self.assertContains(response,'Proxy Host / paste complete proxy')
            self.assertContains(response,'type="password"')
            self.assertContains(response,'A proxy password is saved')
            self.assertIn('no-store',response['Cache-Control'])
            self.assertContains(self.client.get('/google-login/'),'Proxy settings')

    def test_complete_proxy_parsed_without_javascript(self):
        with patch('workspace.google_login.worker',return_value=self.state) as worker:
            response=self.client.post(self.url,{'mode':'http','host':'proxy.test:8080:demo:test-pass'})
            self.assertEqual(response.status_code,302)
            self.assertEqual(worker.call_args.args[1: ],('pool-proxy',{'id':'FA-001','mode':'http','host':'proxy.test','port':8080,'username':'demo','password':'test-pass','clear_auth':False}))

    def test_save_separate_fields_and_direct(self):
        with patch('workspace.google_login.worker',return_value=self.state) as worker:
            response=self.client.post(self.url,{'mode':'http','host':'proxy.test','port':'8080','username':'demo','password':''})
            self.assertEqual(response.status_code,302)
            self.assertEqual(worker.call_args.args[2]['password'],'')
            self.assertEqual(self.client.post(self.url,{'mode':'direct'}).status_code,302)

    def test_busy_and_unknown_accounts_do_not_write(self):
        for state in [self.state | {'busy':True}, {'accounts':[],'managed_pool':[]}]:
            with patch('workspace.google_login.worker',return_value=state) as worker:
                response=self.client.post(self.url,{'mode':'direct'})
                self.assertEqual(response.status_code,200)
                self.assertEqual(worker.call_count,1)

    def test_server_error_never_echoes_pasted_secret(self):
        with patch('workspace.google_login.worker',side_effect=[self.state,ValueError('Proxy unavailable')]):
            response=self.client.post(self.url,{'mode':'http','host':'proxy.test:8080:demo:private-password'})
            self.assertContains(response,'Proxy unavailable')
            self.assertNotContains(response,'private-password')

    def test_invalid_paste_does_not_echo_secret_or_write(self):
        with patch('workspace.google_login.worker',return_value=self.state) as worker:
            response=self.client.post(self.url,{'mode':'http','host':'proxy.test:999999:demo:private-password'})
            self.assertEqual(worker.call_count,1)
            self.assertNotContains(response,'private-password')

    def test_python_parser_formats_and_validation(self):
        self.assertEqual(split_proxy_input('proxy.test:8080','http'),{'host':'proxy.test','port':8080})
        self.assertEqual(split_proxy_input('[2001:db8::1]:1080','socks5'),{'host':'2001:db8::1','port':1080})
        self.assertEqual(split_proxy_input('https://u:p%40ss@proxy.test:8080','https')['password'],'p@ss')
        self.assertEqual(split_proxy_input('proxy.test:8080:u:pass:with:colons','http')['password'],'pass:with:colons')
        with self.assertRaises(ValueError):split_proxy_input('socks5://proxy.test:8080','http')
        self.assertIsNone(split_proxy_input('proxy.test','http'))

    def test_required_proxy_fields(self):
        self.assertFalse(ProxyForm({'mode':'http','host':'proxy.test'}).is_valid())
        self.assertTrue(ProxyForm({'mode':'direct'}).is_valid())

    def test_saved_connection_does_not_save_posted_settings(self):
        result={'ok':True,'message':'Google is reachable','seconds':0.2}
        with patch('workspace.google_login.worker',side_effect=[self.state,result]) as worker:
            response=self.client.post(self.url,{'action':'test','host':'private-secret','mode':'direct'})
            self.assertContains(response,'Google is reachable')
            self.assertNotContains(response,'private-secret')
            self.assertEqual(worker.call_args.args[1:],('pool-proxy-test',{'id':'FA-001'}))

    def test_connection_test_rejected_while_busy_or_unknown(self):
        for state in [self.state | {'busy':True}, {'accounts':[],'managed_pool':[]}]:
            with patch('workspace.google_login.worker',return_value=state) as worker:
                response=self.client.post(self.url,{'action':'test','host':'private-secret'})
                self.assertEqual(worker.call_count,1)
                self.assertNotContains(response,'private-secret')

    def test_manual_login_controls_stay_available_when_busy(self):
        with patch('workspace.google_login.worker',return_value=self.state | {'busy':True}) as worker:
            response=self.client.get('/google-login/')
            self.assertContains(response,'value="connect">Sign in to Google')
            self.assertContains(response,'Open Flow &amp; Gemini')
            response=self.client.post('/google-login/',{'action':'open-services','account':'FA-001'})
            self.assertEqual(response.status_code,302)
            self.assertEqual(worker.call_args.args[1],'open-services')
