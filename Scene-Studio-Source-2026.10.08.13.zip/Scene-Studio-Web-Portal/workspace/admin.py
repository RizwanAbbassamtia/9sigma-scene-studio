from django.contrib import admin
from .models import GoogleAccount,Ticket
@admin.register(GoogleAccount)
class AccountAdmin(admin.ModelAdmin):
    list_display=['email','owner','created']
    search_fields=['email','owner__username']
    readonly_fields=['created']
@admin.register(Ticket)
class TicketAdmin(admin.ModelAdmin):
    list_display=['subject','owner','status','updated']
    list_filter=['status']
    search_fields=['subject','owner__username']
    readonly_fields=['owner','subject','message','created','updated']
