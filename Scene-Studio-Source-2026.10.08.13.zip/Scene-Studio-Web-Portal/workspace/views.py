from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.shortcuts import render,redirect,get_object_or_404
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator
from .models import GoogleAccount,Ticket
from .forms import EmailsForm,SupportForm
def dashboard(request):
    if not request.user.is_authenticated:
        return render(request,'landing.html')
    return render(request,'dashboard.html',{'account_count':GoogleAccount.objects.filter(owner=request.user).count(),'open_count':Ticket.objects.filter(owner=request.user,status='open').count()})
@login_required
@require_http_methods(['GET','POST'])
def accounts(request):
    form=EmailsForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        created=0
        for email in form.cleaned_data['emails']:
            _,added=GoogleAccount.objects.get_or_create(owner=request.user,email=email)
            created+=added
        messages.success(request,f'{created} accounts added. Existing addresses skipped.')
        return redirect('accounts')
    rows=GoogleAccount.objects.filter(owner=request.user).order_by('email')
    query=request.GET.get('q','')[:254]
    if query:rows=rows.filter(email__icontains=query)
    return render(request,'accounts.html',{'form':form,'page':Paginator(rows,25).get_page(request.GET.get('page')),'query':query})
@login_required
@require_http_methods(['GET','POST'])
def support(request):
    form=SupportForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        item=form.save(commit=False);item.owner=request.user;item.save()
        messages.success(request,'Your request was sent to the administrator.')
        return redirect('support')
    return render(request,'support.html',{'form':form,'tickets':Ticket.objects.filter(owner=request.user).order_by('-created')[:50]})
@login_required
def ticket(request,pk):
    item=get_object_or_404(Ticket,pk=pk,owner=request.user)
    return render(request,'ticket.html',{'ticket':item})
