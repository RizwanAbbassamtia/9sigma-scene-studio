"""Parse a pasted proxy locally, without contacting it or logging credentials."""
import re
from urllib.parse import urlsplit, unquote


def split_proxy_input(raw, mode):
    raw=raw.strip()
    if '://' in raw:
        try:
            parsed=urlsplit(raw)
            if parsed.scheme!=mode or not parsed.hostname or not parsed.port or parsed.path not in ('','/') or parsed.query or parsed.fragment:
                raise ValueError()
            result={'host':parsed.hostname,'port':parsed.port}
            if parsed.username is not None:
                result.update(username=unquote(parsed.username),password=unquote(parsed.password or ''))
            return result
        except ValueError:
            raise ValueError('Use a valid proxy URL matching the selected proxy type.') from None
    match=re.fullmatch(r'(\[[0-9A-Fa-f:]+\]|[^:\s/@]+):([0-9]{1,5})(?::([^:\r\n]*):(.*))?',raw)
    if match:
        host,port,username,password=match.groups()
        if not 1<=int(port)<=65535:raise ValueError('Proxy port must be between 1 and 65535.')
        result={'host':host.strip('[]'),'port':int(port)}
        if username is not None:result.update(username=username,password=password)
        return result
    if '@' in raw or (':' in raw and not re.fullmatch(r'\[?[0-9A-Fa-f:]+\]?',raw)):
        raise ValueError('Paste host:port:username:password, host:port, or a proxy URL. Use brackets around IPv6 addresses.')
    return None
