"""One-time local administrator setup; no bundled user or shared password."""
from ipaddress import ip_address
import threading
from django.contrib.auth import get_user_model, login
from django.contrib.auth.forms import UserCreationForm
from django.db import transaction
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse
from django.shortcuts import redirect
from django.template import engines
from django.views.decorators.cache import never_cache
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.http import require_http_methods

_setup_lock = threading.Lock()
_template = '''{% extends 'base.html' %}{% block content %}
<p class="eyebrow">FIRST RUN / THIS COMPUTER</p><h1>Set up Scene Studio</h1>
<section class="card"><h2>Create your administrator login</h2>
<p>Choose the login for this installation. Your Google profiles and generated videos stay on this computer.</p>
<form method="post">{% csrf_token %}{{ form.as_p }}<button type="submit">Create administrator</button></form>
<p class="small">Google sign-in uses installed Google Chrome. <a href="https://www.google.com/chrome/" target="_blank" rel="noopener">Get Chrome from Google</a>.</p>
<p class="small">Video validation needs FFmpeg's ffprobe on your PATH. <a href="https://ffmpeg.org/download.html" target="_blank" rel="noopener">Get FFmpeg from its official download page</a>. Python is included in this desktop package.</p>
</section>{% endblock %}'''


def client_ip(request):
    try:
        return str(ip_address(request.META.get('REMOTE_ADDR', '')))
    except ValueError:
        return None


def _local(request):
    value = client_ip(request)
    return value is not None and ip_address(value).is_loopback


class FirstRunMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if not _local(request):
            return HttpResponseForbidden('This desktop hub is available on this computer only.')
        allowed = request.path in ('/setup/', '/desktop-health/') or request.path.startswith('/static/')
        if not allowed and not get_user_model().objects.exists():
            return redirect('desktop_setup')
        return self.get_response(request)


@never_cache
def health(request):
    return JsonResponse({'application': '9sigma-scene-studio-hub', 'version': '2026.10.08.1',
                         'setup_required': not get_user_model().objects.exists()})


@never_cache
@sensitive_post_parameters('password1', 'password2')
@require_http_methods(['GET', 'POST'])
def first_run(request):
    if not _local(request):
        return HttpResponseForbidden('First-run setup is local to this computer.')
    with _setup_lock:
        if get_user_model().objects.exists():
            return redirect('login')
        form = UserCreationForm(request.POST or None, initial={'username': 'admin'})
        if request.method == 'POST' and form.is_valid():
            with transaction.atomic():
                if get_user_model().objects.exists():
                    return redirect('login')
                user = form.save(commit=False)
                user.is_staff = True
                user.is_superuser = True
                user.save()
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            return redirect('google_login')
    return HttpResponse(engines['django'].from_string(_template).render({'form': form}, request))
