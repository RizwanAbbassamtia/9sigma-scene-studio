"""Read account labels from this app's saved Chrome profiles, without opening Chrome.

These are saved identities, not proof that Google's web session is still valid.
Only email labels are returned. Cookies, passwords and browser tokens are never read.
"""
import json
import os
import re
from functools import lru_cache
from pathlib import Path

from django.core.exceptions import ValidationError
from django.core.validators import validate_email


MAX_METADATA_BYTES = 2 * 1024 * 1024


def _emails(values):
    result = set()
    for value in values:
        if not isinstance(value, str):
            continue
        value = value.strip().casefold()
        try:
            if len(value) > 254:
                continue
            validate_email(value)
        except ValidationError:
            continue
        result.add(value)
    return tuple(sorted(result))


@lru_cache(maxsize=2048)
def _metadata_emails(filename, modified_ns, size, kind):
    # Cache only extracted email labels, not the rest of Chrome's preferences.
    try:
        with open(filename, 'rb') as source:
            raw = source.read(MAX_METADATA_BYTES + 1)
        if len(raw) > MAX_METADATA_BYTES:
            return ()
        data = json.loads(raw)
        if not isinstance(data, dict):
            return ()
        if kind == 'preferences':
            entries = data.get('account_info', [])
            if not isinstance(entries, list):
                return ()
            return _emails(row.get('email') for row in entries if isinstance(row, dict))
        info = data.get('profile', {}).get('info_cache', {}).get('Default', {})
        return _emails([info.get('user_name')])
    except (OSError, ValueError, TypeError, AttributeError):
        # Chrome may be replacing a file while the page refreshes.
        return ()


def profile_inventory(accounts, root=None):
    """Apply the same read-only discovery to every mapped profile, including new ones."""
    if root is None:
        configured = os.environ.get('SCENE_PROFILE_DATA')
        session = os.environ.get('SCENE_LOGIN_SESSION')
        if configured:
            root = Path(configured) / 'manual-browser-profiles'
        elif session:
            root = Path(session).parent.parent / 'manual-browser-profiles'
        else:
            return {}
    try:
        root = Path(root).resolve()
        # List existing containers once instead of probing hundreds of unopened IDs.
        folders = {path.name.casefold(): path for path in root.iterdir() if path.is_dir()}
    except OSError:
        return {}
    result = {}
    for account in accounts:
        profile = (account.get('mapping') or {}).get('profile_id') or account['id']
        if not isinstance(profile, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', profile):
            continue
        row = {'saved': False, 'emails': ()}
        result[account['id']] = row
        existing = folders.get(profile.casefold())
        if existing is None:
            continue
        try:
            folder = existing.resolve()
            if not folder.is_relative_to(root):
                continue
            row['saved'] = (folder / 'Default').is_dir()
            for relative, kind in [('Default/Preferences', 'preferences'), ('Local State', 'local_state')]:
                path = (folder / relative).resolve()
                if not path.is_relative_to(folder):
                    continue
                try:
                    stat = path.stat()
                except OSError:
                    continue
                if stat.st_size > MAX_METADATA_BYTES:
                    continue
                emails = _metadata_emails(str(path), stat.st_mtime_ns, stat.st_size, kind)
                if emails:
                    row['emails'] = emails
                    break
        except OSError:
            continue
    return result
