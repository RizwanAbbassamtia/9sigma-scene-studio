# Build with Python 3.12 + requirements.txt + PyInstaller. No private data is collected.
import os
import sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules, copy_metadata

project = Path(SPECPATH).resolve()
scratch = Path(os.environ.get('SCENE_BUILD_DATA', project.parent.parent / 'work' / 'hub-build-empty-data'))
os.environ['DJANGO_SETTINGS_MODULE'] = 'portal.desktop_settings'
os.environ['DJANGO_SECRET_KEY'] = 'build-time-inspection-only-not-used-by-the-installed-application'
os.environ['DJANGO_ALLOWED_HOSTS'] = '127.0.0.1,localhost'
os.environ['PORTAL_DATA'] = str(scratch)
os.environ['PORTAL_DEV'] = '0'

datas = [(str(project / 'templates'), 'templates'), (str(project / 'static'), 'static')]
datas += collect_data_files('django') + collect_data_files('axes')
for package in ('Django', 'django-axes', 'asgiref', 'sqlparse', 'tzdata', 'PyInstaller'):
    datas += copy_metadata(package)
python_license = Path(sys.base_prefix) / 'LICENSE.txt'
if python_license.is_file():
    datas.append((str(python_license), 'licenses/python'))
hiddenimports = collect_submodules('workspace') + collect_submodules('axes') + collect_submodules('portal')
hiddenimports += ['django.db.backends.sqlite3', 'django.template.loaders.filesystem',
                  'django.template.loaders.app_directories', 'django.template.loaders.cached']
a = Analysis([str(project / 'desktop_hub.py')], pathex=[str(project)],
             binaries=[], datas=datas, hiddenimports=hiddenimports, hookspath=[], hooksconfig={},
             runtime_hooks=[], excludes=['gunicorn', 'tkinter', 'PIL', 'numpy'], noarchive=False, optimize=0)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='SceneStudioHub',
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
          console=False, disable_windowed_traceback=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name='SceneStudioHub')
