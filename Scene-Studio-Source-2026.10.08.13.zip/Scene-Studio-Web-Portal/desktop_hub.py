"""Portable loopback hub: bundled portal, first-run setup, and browser scheduler."""
import argparse
import contextlib
import json
import os
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
from urllib.request import build_opener, ProxyHandler
import webbrowser

BUILD_VERSION = '2026.10.08.1'
PORT = 8792
APPLICATION = '9sigma-scene-studio-hub'


def install_folder():
    return Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent


def data_folder():
    base = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData' / 'Local'))
    return Path(os.environ.get('SCENE_HUB_DATA', base / '9Sigma' / 'SceneStudio' / 'portal')).resolve()


def profile_folder():
    return Path(os.environ.get('SCENE_PROFILE_DATA', Path.home() / 'Documents' / 'Codex' / 'SceneStudioVideoPool')).resolve()


def configure(data, profiles):
    data.mkdir(parents=True, exist_ok=True)
    secret_path = data / 'django-secret.key'
    try:
        with secret_path.open('x', encoding='ascii') as stream:
            stream.write(secrets.token_urlsafe(64))
    except FileExistsError:
        pass
    secret = secret_path.read_text(encoding='ascii').strip()
    if len(secret) < 50:
        raise RuntimeError('The local portal secret is invalid; restore it from your installation backup.')
    os.environ.update(DJANGO_SETTINGS_MODULE='portal.desktop_settings', DJANGO_SECRET_KEY=secret,
                      DJANGO_ALLOWED_HOSTS='127.0.0.1,localhost', PORTAL_DEV='0', PORTAL_DATA=str(data),
                      SCENE_PROFILE_DATA=str(profiles), SCENE_LOGIN_SESSION=str(profiles / 'scene-server' / 'session.json'),
                      SCENE_WORKER_PORT='8788', BROWSER_GENERATION_ENABLED='1')
    import django
    django.setup()


@contextlib.contextmanager
def hub_lock(data):
    with (data / 'desktop-hub.lock').open('a+b') as stream:
        stream.seek(0)
        stream.write(b'0')
        stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def existing_hub(port=PORT):
    try:
        with build_opener(ProxyHandler({})).open(f'http://127.0.0.1:{port}/desktop-health/', timeout=2) as response:
            return json.load(response).get('application') == APPLICATION
    except Exception:
        return False


def listening(port):
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=1):
            return True
    except OSError:
        return False


def find_desktop_worker(folder=None):
    folder = Path(folder) if folder else install_folder()
    for base in (folder, folder.parent):
        for name in ('SceneStudioDesktop', 'SceneStudioDesktop-2026.10.08.13'):
            candidate = base / name / 'SceneStudioDesktop.exe'
            if candidate.is_file():
                return candidate
    raise RuntimeError('Keep the SceneStudioDesktop folder beside the SceneStudioHub folder. Extract the complete download first.')


def start_desktop_worker(profiles, folder=None):
    # An existing host is retained. Its authenticated portal integration reports readiness.
    if listening(8788):
        return None
    executable = find_desktop_worker(folder)
    profiles.mkdir(parents=True, exist_ok=True)
    config = profiles / 'config.json'
    if not config.exists():
        with config.open('x', encoding='utf-8') as stream:
            json.dump({'portal_port': PORT}, stream)
    env = os.environ.copy()
    env['SCENE_PROFILE_DATA'] = str(profiles)
    return subprocess.Popen([str(executable)], cwd=str(executable.parent), env=env,
                            creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0,
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def application():
    from django.core.wsgi import get_wsgi_application
    from django.contrib.staticfiles.handlers import StaticFilesHandler
    return StaticFilesHandler(get_wsgi_application())


def make_http_server(port=PORT):
    from socketserver import ThreadingMixIn
    from wsgiref.simple_server import WSGIServer, WSGIRequestHandler, make_server

    class LocalServer(ThreadingMixIn, WSGIServer):
        daemon_threads = True
        allow_reuse_address = True

    class QuietHandler(WSGIRequestHandler):
        def log_message(self, format, *args):
            pass  # Avoid logging setup form data, query strings, or account URLs.

    return make_server('127.0.0.1', port, application(), server_class=LocalServer, handler_class=QuietHandler)


def self_test(report_path):
    report = {'build_version': BUILD_VERSION}
    with tempfile.TemporaryDirectory(prefix='scene-hub-check-') as temporary:
        root = Path(temporary)
        configure(root / 'portal', root / 'profiles')
        from django.core.management import call_command
        from django.test import Client
        from django.contrib.auth import get_user_model
        from django.contrib.staticfiles import finders
        from workspace.models import Batch, GoogleAccount
        call_command('migrate', interactive=False, verbosity=0)
        call_command('check', verbosity=0)
        client = Client(enforce_csrf_checks=True, REMOTE_ADDR='127.0.0.1', HTTP_HOST='127.0.0.1')
        report['first_run_redirect'] = client.get('/login/').url == '/setup/'
        setup = client.get('/setup/')
        report['setup_page'] = setup.status_code == 200 and b'Create your administrator login' in setup.content
        report['csrf_enforced'] = client.post('/setup/', {'username': 'testadmin', 'password1': 'Not-used', 'password2': 'Not-used'}).status_code == 403
        password = secrets.token_urlsafe(24)
        created = client.post('/setup/', {'username': 'testadmin', 'password1': password, 'password2': password,
                                         'csrfmiddlewaretoken': client.cookies['csrftoken'].value})
        report['admin_created'] = created.status_code == 302 and get_user_model().objects.get(username='testadmin').is_superuser
        report['first_run_disabled'] = client.get('/setup/').url == '/login/'
        report['authenticated_jobs'] = client.get('/jobs/').status_code == 200
        client.logout()
        login_page = client.get('/login/')
        report['login_page'] = login_page.status_code == 200
        signed_in = client.post('/login/', {'username': 'testadmin', 'password': password,
                                           'csrfmiddlewaretoken': client.cookies['csrftoken'].value})
        report['login_works'] = signed_in.status_code == 302 and client.get('/jobs/').status_code == 200
        report['no_bundled_data'] = not Batch.objects.exists() and not GoogleAccount.objects.exists()
        report['portal_static'] = bool(finders.find('portal.css') and finders.find('theme.css'))
        report['admin_static'] = bool(finders.find('admin/css/base.css'))
        from workspace.browser_dispatch import tick
        report['scheduler_import'] = callable(tick)
        server = make_http_server(0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            report['loopback_http'] = existing_hub(server.server_port)
            with build_opener(ProxyHandler({})).open(f'http://127.0.0.1:{server.server_port}/static/portal.css', timeout=5) as response:
                report['static_http'] = response.status == 200 and len(response.read()) > 0
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
        from django.db import connections
        connections.close_all()
    Path(report_path).write_text(json.dumps(report, indent=2), encoding='utf-8')
    return 0 if all(value is True for key, value in report.items() if key != 'build_version') else 1


def main():
    if existing_hub():
        webbrowser.open(f'http://127.0.0.1:{PORT}/')
        return
    if listening(PORT):
        raise RuntimeError('Port 8792 is already used by another local application. Close that app before opening Scene Studio Hub.')
    data, profiles = data_folder(), profile_folder()
    data.mkdir(parents=True, exist_ok=True)
    with hub_lock(data):
        log = (data / 'hub.log').open('a', encoding='utf-8', buffering=1)
        sys.stdout = sys.stderr = log
        configure(data, profiles)
        from django.core.management import call_command
        call_command('migrate', interactive=False, verbosity=0)
        server = make_http_server()
        try:
            start_desktop_worker(profiles)
            thread = threading.Thread(target=lambda: call_command('run_browser_worker'), name='scene-scheduler', daemon=True)
            thread.start()
            webbrowser.open(f'http://127.0.0.1:{PORT}/')
            server.serve_forever()
        finally:
            server.server_close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--self-test', metavar='REPORT_PATH', help='Check a fresh temporary installation without launching Chrome.')
    args = parser.parse_args()
    if args.self_test:
        stream = Path(args.self_test).with_suffix('.log').open('w', encoding='utf-8', buffering=1)
        sys.stdout = sys.stderr = stream
    try:
        if args.self_test:
            sys.exit(self_test(args.self_test))
        main()
    except Exception as exc:
        if args.self_test:
            Path(args.self_test).write_text(json.dumps({'build_version': BUILD_VERSION, 'error': str(exc)}), encoding='utf-8')
            import traceback
            traceback.print_exc()
            sys.exit(1)
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, str(exc), 'Scene Studio Hub needs attention', 0x10)
        else:
            raise
        sys.exit(1)
