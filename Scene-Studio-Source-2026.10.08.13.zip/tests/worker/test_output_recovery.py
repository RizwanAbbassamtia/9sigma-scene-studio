import json
import threading
from unittest.mock import Mock

import pytest

from sceneforge.production.flow_browser_run import BrowserSettings
from sceneforge.production.gemini_browser import GeminiBrowser
from sceneforge.production.output_recovery import recover_scene_output, recovery_record
from sceneforge.production.scene_queue import SceneQueue
from sceneforge.scene_server import SceneService


ACCOUNT = {'id': 'FA-004', 'email': 'saved@example.test'}
RECEIPT = json.dumps({'url': 'https://gemini.google.com/u/0/app/saved_result',
                      'account': ACCOUNT['id'], 'submitted': 1})


@pytest.fixture
def pending(tmp_path):
    queue = SceneQueue(tmp_path / 'run')
    queue.create(['A tree in the wind', 'Another scene'], [ACCOUNT['id']], BrowserSettings())
    attempt = queue.begin(1, 'gemini', ACCOUNT['id'])
    queue.update(1, status='review', receipt=RECEIPT, note='Download response was lost')
    queue.attempt(attempt, 'review', receipt=RECEIPT, note='Download response was lost')
    try:
        yield queue, attempt
    finally:
        queue.close()


def browser_fixture(tmp_path):
    browser = GeminiBrowser(tmp_path / 'profiles', tmp_path / 'run')
    browser.page = Mock()
    browser.page.goto.side_effect = lambda url, **kwargs: setattr(browser.page, 'url', url)
    browser._start = Mock(side_effect=lambda account: setattr(browser, 'account', account))
    browser.identity = Mock()
    browser.finish = Mock(side_effect=lambda receipt, dest, **kwargs: dest.write_bytes(b'validated clip fixture'))
    browser.close = Mock()
    browser.open = Mock()
    browser.prepare = Mock()
    browser.submit = Mock()
    return browser


def assert_no_order(browser):
    browser.open.assert_not_called()
    browser.prepare.assert_not_called()
    browser.submit.assert_not_called()


def test_existing_result_recovery_creates_no_attempt_or_generation(pending, tmp_path):
    queue, attempt = pending
    browser = browser_fixture(tmp_path)
    recover_scene_output(queue, 1, ACCOUNT, browser)
    first, second = queue.rows()
    assert first['status'] == 'done'
    assert first['receipt'] == RECEIPT
    assert second['status'] == 'todo'
    attempts = queue.db.execute('SELECT * FROM attempts').fetchall()
    assert len(attempts) == 1
    assert attempts[0]['id'] == attempt
    assert attempts[0]['receipt'] == RECEIPT
    assert attempts[0]['status'] == 'done'
    browser.page.goto.assert_called_once_with(json.loads(RECEIPT)['url'], wait_until='domcontentloaded')
    browser.finish.assert_called_once()
    browser.close.assert_called_once()
    assert_no_order(browser)


@pytest.mark.parametrize('saved_file', [False, True])
def test_failed_recovery_preserves_receipt_attempt_and_optional_output(pending, tmp_path, saved_file):
    queue, attempt = pending
    browser = browser_fixture(tmp_path)

    def failed_finish(receipt, dest, **kwargs):
        if saved_file:
            dest.write_bytes(b'clip needing format review')
        raise RuntimeError('Existing result needs review')

    browser.finish.side_effect = failed_finish
    with pytest.raises(RuntimeError, match='needs review'):
        recover_scene_output(queue, 1, ACCOUNT, browser)
    row = queue.rows()[0]
    assert row['status'] == 'review'
    assert row['receipt'] == RECEIPT
    assert bool(row['file']) == saved_file
    attempts = queue.db.execute('SELECT * FROM attempts').fetchall()
    assert len(attempts) == 1
    assert attempts[0]['id'] == attempt
    assert attempts[0]['receipt'] == RECEIPT
    assert attempts[0]['status'] == 'review'
    browser.close.assert_called_once()
    assert_no_order(browser)


def test_cancel_recovery_preserves_original_receipt_without_opening_profile(pending, tmp_path):
    queue, attempt = pending
    browser = browser_fixture(tmp_path)
    with pytest.raises(RuntimeError, match='output check stopped'):
        recover_scene_output(queue, 1, ACCOUNT, browser, stopped=lambda: True)
    row = queue.rows()[0]
    assert row['status'] == 'review'
    assert row['receipt'] == RECEIPT
    assert queue.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0] == 1
    browser._start.assert_not_called()
    browser.finish.assert_not_called()
    browser.close.assert_called_once()
    assert_no_order(browser)


@pytest.mark.parametrize('receipt', [None, '', '{broken', '{}', '[]',
    json.dumps({'url': 'https://gemini.google.com/app/other', 'account': 'FA-009'}),
    json.dumps({'url': 'https://example.test/app/other', 'account': ACCOUNT['id']}),
    json.dumps({'url': 'https://gemini.google.com/app', 'account': ACCOUNT['id']})])
def test_missing_or_mismatched_receipt_never_opens_browser(pending, receipt):
    queue, attempt = pending
    queue.update(1, receipt=receipt)
    browser = Mock()
    with pytest.raises(ValueError):
        recover_scene_output(queue, 1, ACCOUNT, browser)
    browser.recover_output.assert_not_called()
    assert queue.rows()[0]['status'] == 'review'
    assert queue.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0] == 1


def test_different_runtime_profile_never_opens_browser(pending):
    queue, _ = pending
    browser = Mock()
    with pytest.raises(ValueError, match='original profile'):
        recover_scene_output(queue, 1, {'id': 'FA-005'}, browser)
    browser.recover_output.assert_not_called()
    assert queue.rows()[0]['receipt'] == RECEIPT


def test_attempt_receipt_must_match_scene_receipt(pending):
    queue, attempt = pending
    queue.attempt(attempt, 'review', receipt=json.dumps({'url': 'https://gemini.google.com/app/other'}))
    with pytest.raises(ValueError, match='latest attempt'):
        recovery_record(queue, 1)


@pytest.mark.parametrize('partial', [False, True])
def test_existing_output_is_not_overwritten(pending, partial):
    queue, attempt = pending
    dest = queue.folder / f'0001_gemini_attempt{attempt}.mp4'
    if partial:
        dest = dest.with_suffix('.partial.mp4')
    dest.write_bytes(b'preserve existing clip')
    browser = Mock()
    with pytest.raises(ValueError, match='already exists'):
        recover_scene_output(queue, 1, ACCOUNT, browser)
    assert dest.read_bytes() == b'preserve existing clip'
    browser.recover_output.assert_not_called()
    assert queue.rows()[0]['status'] == 'review'
    assert queue.rows()[0]['receipt'] == RECEIPT


def test_recorded_output_path_is_not_redownloaded(pending):
    queue, _ = pending
    queue.update(1, file='existing_clip_needing_review.mp4')
    with pytest.raises(ValueError, match='saved clip'):
        recovery_record(queue, 1)


def test_service_requires_available_original_account_before_launch(pending):
    queue, _ = pending
    service = SceneService.__new__(SceneService)
    service.lock = threading.RLock()
    service.shutting_down = False
    service.busy = Mock(return_value=False)
    service.folder = Mock(return_value=queue.folder)
    service.generation_accounts = Mock(return_value=[{'id': 'FA-005'}])
    service.launch = Mock()
    with pytest.raises(ValueError, match='original saved account is unavailable'):
        service.post('recover-output', {'run': '20261008-182233-904313', 'number': 1})
    service.launch.assert_not_called()
    assert queue.rows()[0]['status'] == 'review'


@pytest.mark.parametrize('identifier', ['../other', '/absolute', '20261008-182233-904313/../../other'])
def test_service_rejects_run_path_traversal_before_open(identifier, tmp_path):
    service = SceneService.__new__(SceneService)
    service.runs = tmp_path / 'runs'
    with pytest.raises(ValueError, match='Invalid run identifier'):
        service.folder(identifier)
