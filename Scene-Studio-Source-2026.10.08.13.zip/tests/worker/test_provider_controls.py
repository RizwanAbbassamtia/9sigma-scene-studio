import json
from unittest.mock import Mock
import pytest
from sceneforge.production.gemini_browser import GeminiBrowser
from sceneforge.production.flow_browser import FlowBrowser


@pytest.mark.parametrize('actual,valid', [('saved@example.test', True), ('different@example.test', False)])
def test_gemini_sidebar_link_checks_actual_email(tmp_path, actual, valid):
    browser = GeminiBrowser(tmp_path, tmp_path)
    browser.account = {'email': 'saved@example.test'}
    browser.page = Mock()
    button, link = Mock(), Mock()
    button.or_.return_value = link
    link.count.return_value = 1
    link.first.is_visible.return_value = True
    link.filter.return_value = link
    link.get_attribute.return_value = f'Google Account: Person ({actual})'
    browser.page.get_by_role.side_effect = lambda role, **kw: link if role == 'link' else button
    if valid:
        browser.identity()
    else:
        with pytest.raises(RuntimeError, match='different account'):
            browser.identity()
    link.get_attribute.assert_called_once_with('aria-label')


def test_flow_receipt_tracks_new_result_not_full_prompt_text(tmp_path):
    browser = FlowBrowser(tmp_path, tmp_path)
    browser.account = {'email':'saved@example.test'}
    browser.pending_prompt = 'A prompt that Flow replaces with a short title'
    browser.project_url = 'https://flow.google.com/u/0/project/test'
    browser.quote_value = Mock()
    browser.page = Mock()
    old = Mock()
    old.get_attribute.return_value = 'Previous scene'
    tiles = browser.page.locator.return_value
    tiles.all.return_value = [old]
    tiles.count.return_value = 2
    radio, submit = Mock(), Mock()
    radio.is_visible.return_value = False
    submit.is_enabled.return_value = True
    browser.page.get_by_role.side_effect = lambda role, **kw: radio if role == 'radio' else submit
    receipt = json.loads(browser.submit(browser.pending_prompt))
    assert receipt['previous_labels'] == ['Previous scene']
    submit.press.assert_called_once_with('Space')
    tiles.filter.assert_not_called()


def test_missing_flow_controls_falls_back_before_any_flow_submission(tmp_path):
    from sceneforge.production.scene_queue import SceneQueue, GeminiUsage, execute_queue
    from sceneforge.production.flow_browser_run import BrowserSettings
    queue = SceneQueue(tmp_path / 'run')
    queue.create(['A tree'], ['FA-001'], BrowserSettings())
    usage = GeminiUsage(tmp_path / 'usage.sqlite')
    flow, gemini = Mock(), Mock()
    flow.quote.side_effect = RuntimeError('Settings unavailable')
    gemini.submit.return_value = 'receipt'
    gemini.finish.side_effect = lambda receipt, dest: dest.write_bytes(b'test fixture')
    try:
        execute_queue(queue, [{'id':'FA-001','email':'saved@example.test'}], flow, gemini, usage)
        flow.submit.assert_not_called()
        gemini.submit.assert_called_once_with('A tree')
        assert queue.rows()[0]['status'] == 'done'
        assert queue.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0] == 1
    finally:
        queue.close()
        usage.close()


def test_uncertain_submission_stops_without_fallback_or_duplicate(tmp_path):
    import time
    from sceneforge.production.scene_queue import SceneQueue, GeminiUsage, execute_queue
    from sceneforge.production.flow_browser_run import BrowserSettings, LiveQuote
    queue = SceneQueue(tmp_path / 'run')
    queue.create(['A tree'], ['FA-001'], BrowserSettings())
    usage = GeminiUsage(tmp_path / 'usage.sqlite')
    flow, gemini = Mock(), Mock()
    flow.quote.return_value = LiveQuote('saved@example.test', 100, 10, time.time())
    flow.submit.side_effect = TimeoutError('Response lost')
    try:
        with pytest.raises(TimeoutError):
            execute_queue(queue, [{'id':'FA-001','email':'saved@example.test'}], flow, gemini, usage)
        gemini.submit.assert_not_called()
        assert queue.rows()[0]['status'] == 'review'
        assert queue.db.execute('SELECT COUNT(*) FROM attempts').fetchone()[0] == 1
    finally:
        queue.close()
        usage.close()
