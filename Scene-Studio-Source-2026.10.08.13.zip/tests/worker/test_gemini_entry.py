from unittest.mock import Mock

import pytest

from sceneforge.production.gemini_browser import GeminiBrowser


def browser_with_entry(tmp_path, monkeypatch, *, entry_role='button', ready=False,
                       delayed_redirect=False, sign_in=False, stuck=False):
    browser = GeminiBrowser(tmp_path, tmp_path)
    browser.account = {'id': 'FA-005', 'email': 'saved@example.test', 'google_slot': 0}
    browser.page = page = Mock()
    browser.identity = Mock()
    page.url = 'https://gemini.google.com/u/0/app' if ready or delayed_redirect else 'https://gemini.google.com/u/0/'
    state = {'now': 0.0, 'ready': ready, 'pressed': False, 'waits': 0}
    monkeypatch.setattr('sceneforge.production.gemini_browser.time.monotonic', lambda: state['now'])
    editor = Mock()
    editor.or_.return_value = editor
    editor.filter.return_value = editor
    editor.count.side_effect = lambda: int(state['ready'])
    editor.is_enabled.return_value = True
    page.get_by_label.return_value = editor
    entries = {role: Mock() for role in ('button', 'link')}
    for role, entry in entries.items():
        entry.count.side_effect = lambda role=role: int(role == entry_role and page.url.endswith('/u/0/'))
        entry.is_visible.return_value = True
        entry.is_enabled.return_value = True

        def press(key):
            assert key == 'Enter'
            state['pressed'] = True
            if sign_in:
                page.url = 'https://accounts.google.com/v3/signin/identifier'

        entry.press.side_effect = press

    def locate(role, **kwargs):
        return editor if role == 'textbox' else entries[role]

    page.get_by_role.side_effect = locate

    def wait(milliseconds):
        state['now'] += milliseconds / 1000
        state['waits'] += 1
        if sign_in and state['pressed']:
            return
        if delayed_redirect and not state['pressed']:
            page.url = 'https://gemini.google.com/u/0/'
        if state['pressed'] and state['waits'] >= 3 and not stuck:
            page.url = 'https://gemini.google.com/u/0/app'
            state['ready'] = True

    page.wait_for_timeout.side_effect = wait
    return browser, entries, state


@pytest.mark.parametrize('entry_role', ['button', 'link'])
def test_public_entry_is_followed_once_then_visible_identity_checked(tmp_path, monkeypatch, entry_role):
    browser, entries, _ = browser_with_entry(tmp_path, monkeypatch, entry_role=entry_role,
                                             delayed_redirect=True)
    browser._open_app()
    entries[entry_role].press.assert_called_once_with('Enter')
    browser.identity.assert_called_once_with()
    assert browser.page.url.endswith('/app')
    browser.page.goto.assert_called_once_with('https://gemini.google.com/u/0/app', wait_until='domcontentloaded')


def test_ready_editor_never_activates_public_entry(tmp_path, monkeypatch):
    browser, entries, _ = browser_with_entry(tmp_path, monkeypatch, ready=True)
    browser._open_app()
    for entry in entries.values():
        entry.press.assert_not_called()
    browser.identity.assert_called_once_with()


def test_google_sign_in_redirect_stops_without_interaction(tmp_path, monkeypatch):
    browser, entries, _ = browser_with_entry(tmp_path, monkeypatch, sign_in=True)
    with pytest.raises(RuntimeError, match='sign-in or verification'):
        browser._open_app()
    entries['button'].press.assert_called_once_with('Enter')
    browser.identity.assert_not_called()
    # The only navigation is to the Gemini app; no Google form control is queried.
    browser.page.goto.assert_called_once()
    assert all(call.kwargs.get('name') in ('Enter a prompt for Gemini', 'Chat with Gemini')
               for call in browser.page.get_by_role.call_args_list)


def test_stalled_entry_is_not_clicked_again(tmp_path, monkeypatch):
    browser, entries, _ = browser_with_entry(tmp_path, monkeypatch, stuck=True)
    with pytest.raises(RuntimeError, match='No prompt submitted'):
        browser._open_app()
    entries['button'].press.assert_called_once_with('Enter')
    browser.identity.assert_not_called()


def test_wrong_visible_account_remains_blocked_after_entry(tmp_path, monkeypatch):
    browser, entries, _ = browser_with_entry(tmp_path, monkeypatch)
    browser.identity.side_effect = RuntimeError('Gemini is signed in to a different account.')
    with pytest.raises(RuntimeError, match='different account'):
        browser._open_app()
    entries['button'].press.assert_called_once_with('Enter')


def test_unknown_public_page_is_not_guessed_or_submitted(tmp_path, monkeypatch):
    browser, entries, _ = browser_with_entry(tmp_path, monkeypatch, entry_role=None)
    with pytest.raises(RuntimeError, match='No prompt submitted'):
        browser._open_app()
    for entry in entries.values():
        entry.press.assert_not_called()
    browser.identity.assert_not_called()
