import json
from unittest.mock import Mock, call

import pytest

from sceneforge.production.flow_browser_run import BrowserSettings
from sceneforge.production.gemini_browser import GeminiBrowser


ACCOUNT = {'id': 'FA-004', 'email': 'saved@example.test'}
URL = 'https://gemini.google.com/u/0/app/saved-conversation'
RECEIPT = json.dumps({'account': ACCOUNT['id'], 'url': URL})


def browser(tmp_path):
    result = GeminiBrowser(tmp_path / 'profiles', tmp_path / 'run', emit=Mock())
    result.account = dict(ACCOUNT)
    result.page = Mock()
    result.page.url = URL
    result.identity = Mock()
    return result


def test_wait_reports_once_a_minute_and_saves_final_timeout(tmp_path, monkeypatch):
    instance = browser(tmp_path)
    clock = {'now': 0.0}
    monkeypatch.setattr('sceneforge.production.gemini_browser.time.monotonic', lambda: clock['now'])
    instance.page.wait_for_timeout.side_effect = lambda milliseconds: clock.update(now=clock['now'] + milliseconds / 1000)
    instance.page.get_by_role.return_value.all_text_contents.return_value = []
    instance.page.locator.return_value.count.return_value = 0
    instance._wait_diagnostic = Mock()
    instance.submit = Mock(side_effect=AssertionError('Must not resubmit'))
    with pytest.raises(RuntimeError, match='within 20 minutes'):
        instance.finish(RECEIPT, tmp_path / 'clip.mp4')
    assert instance._wait_diagnostic.call_args_list == [call('waiting', t) for t in range(0, 1200, 60)] + [call('timeout', 1200)]
    instance.page.reload.assert_called_once_with(wait_until='domcontentloaded')
    instance.identity.assert_called_once_with()
    instance.submit.assert_not_called()
    assert sum('Waiting for Gemini video' in c.args[0] for c in instance.emit.call_args_list) == 19


def test_diagnostic_is_bounded_and_has_no_url_query_or_fragment(tmp_path):
    instance = browser(tmp_path)
    instance.page.url = URL + '?private_query=do-not-save#private-fragment'
    instance.page.locator.return_value.evaluate.return_value = {
        'response_text': 'x' * 20000,
        'controls': [{'role': 'button', 'label': 'l' * 500, 'text': 't' * 500}] * 100,
    }
    instance._wait_diagnostic('waiting', 60)
    path = instance.run_folder / 'wait_FA-004_gemini.json'
    content = path.read_text(encoding='utf-8')
    detail = json.loads(content)
    assert detail['page'] == URL
    assert 'private_query' not in content and 'private-fragment' not in content
    assert len(detail['response_text']) == 12000
    assert len(detail['controls']) == 60
    assert all(len(c['label']) == 200 and len(c['text']) == 160 for c in detail['controls'])
    instance.page.screenshot.assert_called_once_with(path=str(instance.run_folder / 'wait_FA-004_gemini.png'), timeout=10000)
    # Only rendered DOM is requested; no browser storage or auth APIs are used.
    instance.page.locator.assert_called_once_with('body')
    assert 'input, textarea, [contenteditable="true"]' in instance.page.locator.return_value.evaluate.call_args.args[0]
    assert instance.page.locator.return_value.evaluate.call_args.kwargs['timeout'] == 5000


@pytest.mark.parametrize('url', ['https://accounts.google.com/v3/signin/challenge?secret=value',
                                  'https://example.test/page?secret=value'])
def test_diagnostic_never_captures_login_or_foreign_page(tmp_path, url):
    instance = browser(tmp_path)
    instance.page.url = url
    instance._wait_diagnostic('timeout', 1200)
    detail = json.loads((instance.run_folder / 'wait_FA-004_gemini.json').read_text())
    assert detail['capture'].startswith('Skipped')
    assert '?' not in detail['page']
    instance.page.screenshot.assert_not_called()
    instance.page.locator.assert_not_called()


def test_unavailable_diagnostic_does_not_abort_wait(tmp_path):
    instance = browser(tmp_path)
    instance.page.screenshot.side_effect = RuntimeError('Screenshot unavailable')
    instance.page.locator.return_value.evaluate.side_effect = RuntimeError('DOM unavailable')
    instance._wait_diagnostic('waiting', 60)
    detail = json.loads((instance.run_folder / 'wait_FA-004_gemini.json').read_text())
    assert detail['screenshot'] == 'Unavailable'
    assert detail['capture'] == 'Visible page text unavailable.'


def test_recovery_only_reopens_receipt_and_finishes_download(tmp_path):
    instance = browser(tmp_path)
    instance._start = Mock()
    instance.finish = Mock()
    instance.prepare = Mock(side_effect=AssertionError('Must not prepare a new prompt'))
    instance.submit = Mock(side_effect=AssertionError('Must not resubmit'))
    settings = BrowserSettings()
    dest = tmp_path / 'existing-request.mp4'
    stopped = Mock(return_value=False)
    instance.recover_output(ACCOUNT, RECEIPT, settings, dest, stopped=stopped)
    instance._start.assert_called_once_with(ACCOUNT)
    instance.page.goto.assert_called_once_with(URL, wait_until='domcontentloaded')
    instance.identity.assert_called_once_with()
    assert instance.settings is settings
    instance.finish.assert_called_once_with(RECEIPT, dest, stopped=stopped)
    instance.prepare.assert_not_called()
    instance.submit.assert_not_called()


@pytest.mark.parametrize('receipt', [json.dumps({'account': 'FA-005', 'url': URL}),
                                    json.dumps({'account': 'FA-004', 'url': 'https://gemini.google.com/app'}),
                                    json.dumps({'account': 'FA-004', 'url': 'https://example.test/app/id'})])
def test_invalid_recovery_receipt_is_rejected_before_launch(tmp_path, receipt):
    instance = browser(tmp_path)
    instance._start = Mock()
    with pytest.raises(RuntimeError, match='receipt'):
        instance.recover_output(ACCOUNT, receipt, BrowserSettings(), tmp_path / 'clip.mp4')
    instance._start.assert_not_called()


def test_recovery_requires_matching_live_email(tmp_path):
    instance = browser(tmp_path)
    instance._start = Mock()
    instance.finish = Mock()
    instance.identity.side_effect = RuntimeError('Different account')
    with pytest.raises(RuntimeError, match='Different account'):
        instance.recover_output(ACCOUNT, RECEIPT, BrowserSettings(), tmp_path / 'clip.mp4')
    instance.finish.assert_not_called()


def test_recovery_rejects_redirect_to_different_conversation(tmp_path):
    instance = browser(tmp_path)
    instance.page.url = URL + '-different'
    instance._start = Mock()
    instance.finish = Mock()
    with pytest.raises(RuntimeError, match='did not reopen'):
        instance.recover_output(ACCOUNT, RECEIPT, BrowserSettings(), tmp_path / 'clip.mp4')
    instance.finish.assert_not_called()


def test_recovery_does_not_overwrite_an_existing_partial_download(tmp_path):
    instance = browser(tmp_path)
    instance._start = Mock()
    dest = tmp_path / 'clip.mp4'
    partial = dest.with_suffix('.partial.mp4')
    partial.write_bytes(b'preserve this download')
    with pytest.raises(RuntimeError, match='already exists'):
        instance.recover_output(ACCOUNT, RECEIPT, BrowserSettings(), dest)
    instance._start.assert_not_called()
    assert partial.read_bytes() == b'preserve this download'


def test_recovery_stop_before_launch_preserves_receipt(tmp_path):
    instance = browser(tmp_path)
    instance._start = Mock()
    with pytest.raises(RuntimeError, match='receipt is retained'):
        instance.recover_output(ACCOUNT, RECEIPT, BrowserSettings(), tmp_path / 'clip.mp4', stopped=lambda: True)
    instance._start.assert_not_called()


def test_wait_stop_leaves_existing_request_untouched(tmp_path, monkeypatch):
    instance = browser(tmp_path)
    instance._wait_diagnostic = Mock()
    instance.page.get_by_role.return_value.all_text_contents.return_value = []
    instance.page.locator.return_value.count.return_value = 0
    clock = {'now': 0.0}
    monkeypatch.setattr('sceneforge.production.gemini_browser.time.monotonic', lambda: clock['now'])
    instance.page.wait_for_timeout.side_effect = lambda milliseconds: clock.update(now=clock['now'] + milliseconds / 1000)
    instance.submit = Mock(side_effect=AssertionError('Must not resubmit'))
    with pytest.raises(RuntimeError, match='receipt is retained'):
        instance.finish(RECEIPT, tmp_path / 'clip.mp4', stopped=lambda: clock['now'] >= 3)
    instance.submit.assert_not_called()
    instance.page.reload.assert_not_called()
    instance.page.wait_for_timeout.assert_called_once_with(3000)
    assert not (tmp_path / 'clip.mp4').exists()
