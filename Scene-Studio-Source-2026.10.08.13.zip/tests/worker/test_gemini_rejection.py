import json
from unittest.mock import Mock

import pytest

from sceneforge.production.gemini_browser import GeminiBrowser
from sceneforge.production.scene_queue import GenerationRejected


REFUSAL = ("I can't make videos that seem to show minors in dangerous or compromising situations. "
           'Can I help you with something else?')


def reply_browser(tmp_path, response_text=REFUSAL, *, response_count=1, content_count=1,
                  feedback_count=1, video_count=0):
    browser = GeminiBrowser(tmp_path, tmp_path, emit=Mock())
    browser.account = {'id': 'FA-004', 'email': 'saved@example.test'}
    page = browser.page = Mock()
    page.url = 'https://gemini.google.com/u/0/app/saved-conversation'
    label, responses, content, feedback, videos = (Mock() for _ in range(5))
    for locator in (label, responses, content, feedback):
        locator.filter.return_value = locator
    responses.count.return_value = response_count
    responses.locator.return_value = content
    content.count.return_value = content_count
    content.inner_text.return_value = response_text
    feedback.count.return_value = feedback_count
    videos.count.return_value = video_count
    locators = {'h6': label, 'div.response-content': responses, 'video': videos}
    page.locator.side_effect = lambda selector: locators[selector]
    page.get_by_role.side_effect = lambda role, **kwargs: feedback
    # User text is intentionally not available through the reply selector.
    page.get_by_text.side_effect = AssertionError('Do not inspect user prompt for a refusal')
    browser._wait_diagnostic = Mock()
    return browser, responses, content


def test_observed_completed_reply_is_rejected_without_wait_or_resubmit(tmp_path):
    browser, responses, content = reply_browser(tmp_path)
    receipt = json.dumps({'account': 'FA-004', 'url': browser.page.url})
    browser.submit = Mock(side_effect=AssertionError('Do not resubmit'))
    with pytest.raises(GenerationRejected, match='Gemini declined'):
        browser.finish(receipt, tmp_path / 'clip.mp4')
    responses.locator.assert_called_once_with('message-content')
    content.inner_text.assert_called_once_with(timeout=5000)
    browser.page.wait_for_timeout.assert_not_called()
    browser.submit.assert_not_called()
    assert browser._wait_diagnostic.call_args_list[-1].args[0] == 'provider_rejected'


def test_refusal_words_in_user_prompt_cannot_match_assistant_reply(tmp_path):
    browser, _, _ = reply_browser(tmp_path, response_text='Your video is ready!')
    browser.page.user_prompt = REFUSAL
    assert browser._completed_assistant_rejection() is False
    browser.page.get_by_text.assert_not_called()
    assert all(c.args[0] in ('h6', 'div.response-content', 'video') for c in browser.page.locator.call_args_list)


@pytest.mark.parametrize('changes', [{'response_count': 2}, {'content_count': 2},
                                     {'feedback_count': 0}, {'feedback_count': 2}, {'video_count': 1}])
def test_ambiguous_or_unfinished_response_is_not_classified(tmp_path, changes):
    browser, _, _ = reply_browser(tmp_path, **changes)
    assert browser._completed_assistant_rejection() is False


@pytest.mark.parametrize('text', ["I can't make videos", REFUSAL.split(' Can I')[0],
                                  'A character says: ' + REFUSAL])
def test_partial_or_quoted_phrase_is_not_guessed_as_rejection(tmp_path, text):
    browser, _, _ = reply_browser(tmp_path, response_text=text)
    assert browser._completed_assistant_rejection() is False


def test_curly_apostrophe_and_layout_whitespace_do_not_hide_observed_reply(tmp_path):
    browser, _, _ = reply_browser(tmp_path, response_text=REFUSAL.replace("can't", 'can’t').replace(' Can I', '\n\nCan I'))
    assert browser._completed_assistant_rejection() is True
