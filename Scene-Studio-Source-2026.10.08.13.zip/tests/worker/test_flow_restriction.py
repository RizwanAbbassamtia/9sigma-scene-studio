from unittest.mock import Mock

import pytest

from sceneforge.production.flow_browser import FlowAccessRestricted, FlowBrowser


def browser_fixture(tmp_path, url):
    browser = FlowBrowser(tmp_path / 'profiles', tmp_path / 'run')
    browser._start = Mock(side_effect=lambda account: setattr(browser, 'account', account))
    browser.page = Mock(url=url)
    browser.preflight_failure = Mock(return_value='Generic missing account diagnostic')
    browser.balance = Mock(return_value=('saved@example.test', 100))
    return browser


def test_initial_age_restriction_preserves_reason_without_waiting(tmp_path):
    browser = browser_fixture(tmp_path, 'https://flow.google.com/u/0/age-restricted')
    with pytest.raises(FlowAccessRestricted, match='age requirement.*No prompt submitted'):
        browser.open({'id': 'FA-002', 'email': 'saved@example.test'})
    browser.page.get_by_role.assert_not_called()
    browser.balance.assert_not_called()
    browser.preflight_failure.assert_called_once_with('flow')


def test_delayed_age_redirect_preserves_reason_after_control_timeout(tmp_path):
    browser = browser_fixture(tmp_path, 'https://flow.google.com/u/0/')

    def delayed_redirect(**kwargs):
        browser.page.url = 'https://flow.google.com/u/0/age-restricted'
        raise TimeoutError('Account details was not found')

    browser.page.get_by_role.return_value.wait_for.side_effect = delayed_redirect
    with pytest.raises(FlowAccessRestricted, match='age requirement.*No prompt submitted'):
        browser.open({'id': 'FA-002', 'email': 'saved@example.test'})
    browser.balance.assert_not_called()
    browser.preflight_failure.assert_called_once_with('flow')


def test_unrestricted_control_failure_keeps_single_diagnostic(tmp_path):
    browser = browser_fixture(tmp_path, 'https://flow.google.com/u/0/')
    browser.page.get_by_role.return_value.wait_for.side_effect = TimeoutError('Missing control')
    with pytest.raises(RuntimeError, match='Generic missing account diagnostic') as caught:
        browser.open({'id': 'FA-005', 'email': 'saved@example.test'})
    assert not isinstance(caught.value, FlowAccessRestricted)
    browser.preflight_failure.assert_called_once_with('flow')
    browser.balance.assert_not_called()


@pytest.mark.parametrize('label', ['Settings trigger', 'Settings'])
def test_settings_accepts_each_observed_label(tmp_path, label):
    browser = browser_fixture(tmp_path, 'https://flow.google.com/u/0/')
    candidate = Mock()
    candidate.is_enabled.return_value = True
    buttons = Mock()
    buttons.count.return_value = 1
    buttons.all.return_value = [candidate]

    def match_controls(role, **kwargs):
        assert role == 'button'
        assert kwargs['name'].fullmatch(label)
        assert not kwargs['name'].fullmatch('Tile grid settings')
        return Mock(filter=Mock(return_value=buttons))

    browser.page.get_by_role.side_effect = match_controls
    assert browser._settings_button() is candidate
    candidate.press.assert_not_called()


@pytest.mark.parametrize('enabled', [[], [False], [True, True]])
def test_settings_rejects_disabled_or_ambiguous_candidates(tmp_path, enabled):
    browser = browser_fixture(tmp_path, 'https://flow.google.com/u/0/')
    buttons = browser.page.get_by_role.return_value.filter.return_value
    buttons.count.return_value = len(enabled)
    candidates = [Mock(is_enabled=Mock(return_value=value)) for value in enabled]
    buttons.all.return_value = candidates
    with pytest.raises(RuntimeError, match='one enabled generation Settings'):
        browser._settings_button()
    for candidate in candidates:
        candidate.press.assert_not_called()


@pytest.mark.parametrize('diagnostic_fails', [False, True])
def test_quote_preserves_failed_setting_check_and_saves_diagnostic(tmp_path, diagnostic_fails):
    browser = browser_fixture(tmp_path, 'https://flow.google.com/u/0/')
    error = RuntimeError('Flow does not offer the requested setting: 10 seconds')
    browser._quote = Mock(side_effect=error)
    if diagnostic_fails:
        browser.preflight_failure.side_effect = RuntimeError('Page closed')
    with pytest.raises(RuntimeError) as caught:
        browser.quote(Mock(), 'A tree')
    assert caught.value is error
    browser.preflight_failure.assert_called_once_with('flow')
