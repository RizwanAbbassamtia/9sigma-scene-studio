import json
from pathlib import Path
from unittest.mock import Mock, patch
import pytest
from sceneforge.production.saved_profiles import saved_folder, saved_emails, generation_account
from sceneforge.scene_server import SceneService


def saved(root, profile='FA-002', emails=('actual@example.test',)):
    folder = root / 'manual-browser-profiles' / profile / 'Default'
    folder.mkdir(parents=True)
    (folder / 'Preferences').write_text(json.dumps({'account_info': [{'email': e} for e in emails]}))
    return folder.parent


def test_saved_identity_replaces_import_label_only_for_runtime(tmp_path):
    saved(tmp_path)
    original = {'id': 'FA-002', 'email': 'import@example.test', 'managed_profile': 'FA-002'}
    result = generation_account(tmp_path, original, {'flow': {'state': 'manual'}})
    assert result['email'] == 'actual@example.test'
    assert original['email'] == 'import@example.test'
    assert result['profile_storage'] == 'saved'
    assert saved_folder(tmp_path, 'FA-002') == tmp_path / 'manual-browser-profiles' / 'FA-002'


@pytest.mark.parametrize('emails', [(), ('one@example.test', 'two@example.test')])
def test_ambiguous_identity_cannot_submit(tmp_path, emails):
    saved(tmp_path, emails=emails)
    with pytest.raises(ValueError, match='one saved Google email'):
        generation_account(tmp_path, {'id': 'FA-002'}, {'flow': {'state': 'manual'}})


def test_profile_name_cannot_escape_owned_storage(tmp_path):
    with pytest.raises(ValueError):
        saved_folder(tmp_path, '../other')
    assert saved_emails(tmp_path, '../other') == []


def test_no_cookies_or_password_files_read(tmp_path):
    saved(tmp_path)
    opened = []
    original_open = Path.open
    def record(path, *args, **kwargs):
        opened.append(path.name)
        return original_open(path, *args, **kwargs)
    with patch.object(Path, 'open', record):
        assert saved_emails(tmp_path, 'FA-002') == ['actual@example.test']
    assert opened == ['Preferences']


def test_candidate_is_not_reported_as_live_connected(tmp_path):
    service = SceneService(tmp_path / 'root', tmp_path / 'accounts')
    service.post('import', {'emails': 'import@example.test second@example.test'})
    for profile in ('FA-001', 'FA-002'):
        saved(service.root, profile)
        service.connections.record(profile, 'flow', 'manual')
    state = service.state()
    assert state['generation_candidates'] == [{'id': 'FA-001', 'email': 'actual@example.test'}]
    assert state['accounts'][0]['connections']['flow']['state'] == 'manual'
    assert state['managed_pool'][0]['status'] == 'needs_login'


def test_manual_profile_without_identity_is_rejected_before_worker(tmp_path):
    service = SceneService(tmp_path / 'root', tmp_path / 'accounts')
    service.post('import', {'emails': 'import@example.test'})
    service.connections.record('FA-001', 'flow', 'manual')
    service.folder = Mock(return_value=tmp_path)
    with patch('sceneforge.scene_server.SceneQueue') as queue, patch.object(service, 'launch') as launch:
        queue.return_value.get.return_value = ['FA-001']
        with pytest.raises(ValueError, match='No prompt was submitted'):
            service.start('test')
        launch.assert_not_called()


def test_saved_runtime_launches_exact_owned_folder(tmp_path):
    from sceneforge.production.flow_browser import FlowBrowser
    folder = saved(tmp_path)
    browser = FlowBrowser(tmp_path / 'browser-profiles', tmp_path / 'run', headless=True)
    with patch('playwright.sync_api.sync_playwright') as runtime, patch('sceneforge.production.flow_browser.resolve_chrome', return_value=Path('chrome.exe')):
        browser._start({'id': 'FA-002', 'email': 'actual@example.test', 'profile_storage': 'saved'})
        launch = runtime.return_value.start.return_value.chromium.launch_persistent_context
        assert launch.call_args.args == (str(folder),)
        assert launch.call_args.kwargs['headless'] is True
        assert launch.call_args.kwargs['chromium_sandbox'] is True
        browser.close()
