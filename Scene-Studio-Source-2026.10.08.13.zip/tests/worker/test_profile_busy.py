from unittest.mock import Mock, patch
import pytest
from sceneforge.scene_server import SceneService


def busy_service(tmp_path):
    service=SceneService(tmp_path/'root',tmp_path/'accounts')
    service.post('import',{'emails':'one@example.test two@example.test'})
    service.worker=Mock()
    service.worker.is_alive.return_value=True
    service.log('Checking gemini / FA-001 saved session before submission')
    return service


def test_manual_login_cannot_reopen_generating_profile(tmp_path):
    service=busy_service(tmp_path)
    with patch('sceneforge.scene_server.open_manual_profile') as opening:
        with pytest.raises(ValueError,match='This profile is generating'):
            service.post('connect',{'id':'FA-001','transport':'managed'})
        opening.assert_not_called()


def test_other_profile_remains_available(tmp_path):
    service=busy_service(tmp_path)
    with patch('sceneforge.scene_server.open_manual_profile',return_value={'message':'Opened','proxy_authentication':False}) as opening:
        service.post('connect',{'id':'FA-002','transport':'managed'})
        assert opening.call_args.args[1]['id']=='FA-002'
