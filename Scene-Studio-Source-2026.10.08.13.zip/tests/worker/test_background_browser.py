from pathlib import Path
from unittest.mock import Mock, patch

import pytest

from sceneforge.production.flow_browser import FlowBrowser
from sceneforge.production.gemini_browser import GeminiBrowser
from sceneforge.scene_server import SceneService


@pytest.mark.parametrize('browser_class', [FlowBrowser, GeminiBrowser])
def test_generation_uses_headless_chrome_and_keeps_profile_and_sandbox(tmp_path, browser_class):
    browser = browser_class(tmp_path/'profiles', tmp_path/'run', headless=True)
    runtime = Mock()
    context = runtime.chromium.launch_persistent_context.return_value
    context.pages = [Mock()]
    with patch('playwright.sync_api.sync_playwright') as start, \
         patch('sceneforge.production.flow_browser.resolve_chrome', return_value=Path('chrome.exe')), \
         patch('sceneforge.production.flow_browser.ProfileProxies') as proxies:
        start.return_value.start.return_value = runtime
        proxies.return_value.launch_options.return_value = None
        browser._start({'id':'FA-002', 'email':'saved@example.test'})
        args = runtime.chromium.launch_persistent_context.call_args
        assert args.kwargs['headless'] is True
        assert args.kwargs['chromium_sandbox'] is True
        assert args.args[0] == str(tmp_path/'profiles'/'FA-002')
        browser.close()
    context.close.assert_called_once()


@pytest.mark.parametrize('browser_class', [FlowBrowser, GeminiBrowser])
def test_login_remains_visible_even_on_background_worker(tmp_path, browser_class):
    browser = browser_class(tmp_path, tmp_path, headless=True)
    def start(account):
        assert browser.headless is False
        browser.page = Mock()
    browser._start = Mock(side_effect=start)
    browser._wait_for_account = Mock(side_effect=RuntimeError('verification needed'))
    browser.close = Mock()
    with pytest.raises(RuntimeError, match='verification needed'):
        browser.connect({'id':'FA-002', 'email':'saved@example.test'})
    assert browser.headless is True
    browser.close.assert_called_once()


def test_worker_advertises_serial_background_generation(tmp_path):
    service = SceneService(tmp_path/'root', tmp_path/'accounts')
    state = service.state()
    assert state['generation_window_mode'] == 'headless'
    assert state['max_generation_profiles'] == 1


def test_existing_idle_host_can_be_upgraded_without_touching_chrome_profiles(tmp_path):
    from worker_bootstrap import prepare_existing_worker
    with patch('worker_bootstrap.listening', side_effect=[True,False]), \
         patch('worker_bootstrap.call_worker', side_effect=[{'proxy_password_storage':True,'busy':False}, {'stopping':True}]) as call:
        assert prepare_existing_worker(tmp_path,generation_window_mode='headless') is False
    assert call.call_args.args == (tmp_path,'shutdown')


def test_busy_host_is_never_replaced_for_background_upgrade(tmp_path):
    from worker_bootstrap import prepare_existing_worker
    with patch('worker_bootstrap.listening', return_value=True), \
         patch('worker_bootstrap.call_worker', return_value={'proxy_password_storage':True,'busy':True}) as call:
        with pytest.raises(RuntimeError,match='busy'):
            prepare_existing_worker(tmp_path,generation_window_mode='headless')
    assert call.call_count == 1
