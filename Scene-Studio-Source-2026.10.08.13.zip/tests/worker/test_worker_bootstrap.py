import importlib.util
from pathlib import Path
import sys
from unittest.mock import Mock
import pytest

path=Path(__file__).resolve().parents[2]/'Scene-Studio-Browser-Worker'/'worker_bootstrap.py'
spec=importlib.util.spec_from_file_location('worker_bootstrap_test',path)
boot=importlib.util.module_from_spec(spec);spec.loader.exec_module(boot)


def test_unknown_service_is_not_stopped(monkeypatch):
    monkeypatch.setattr(boot,'listening',lambda port:True)
    called=Mock(side_effect=ValueError())
    monkeypatch.setattr(boot,'call_worker',called)
    with pytest.raises(RuntimeError,match='could not be verified'):boot.prepare_existing_worker(Path('unused'))
    assert called.call_count==1


def test_existing_healthy_worker_preserved(monkeypatch):
    monkeypatch.setattr(boot,'listening',lambda port:True)
    called=Mock(return_value={'proxy_password_storage':True})
    monkeypatch.setattr(boot,'call_worker',called)
    assert boot.prepare_existing_worker(Path('unused')) is True
    assert called.call_count==1


def test_busy_preview_preserved(monkeypatch):
    monkeypatch.setattr(boot,'listening',lambda port:True)
    called=Mock(return_value={'proxy_password_storage':False,'busy':True})
    monkeypatch.setattr(boot,'call_worker',called)
    with pytest.raises(RuntimeError,match='busy'):boot.prepare_existing_worker(Path('unused'))
    assert called.call_count==1


def test_only_idle_authenticated_preview_is_replaced(monkeypatch):
    monkeypatch.setattr(boot,'listening',Mock(side_effect=[True,False]))
    called=Mock(side_effect=[{'proxy_password_storage':False,'busy':False},{'stopping':True}])
    monkeypatch.setattr(boot,'call_worker',called)
    assert boot.prepare_existing_worker(Path('unused')) is False
    assert called.call_args.args[1]=='shutdown'
