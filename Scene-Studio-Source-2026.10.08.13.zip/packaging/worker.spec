# Run from the repository root with: python -m PyInstaller packaging/worker.spec
# Chrome and ffprobe are external dependencies, never copied from a developer PC.
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

root = Path(SPECPATH).resolve().parent
source = root / 'Scene-Studio-Browser-Worker'
datas, binaries, hiddenimports = collect_all('playwright')
datas += [(str(source / 'sceneforge' / 'scene_web'), 'sceneforge/scene_web')]

a = Analysis([str(source / 'desktop_app.py')], pathex=[str(source)],
             binaries=binaries, datas=datas, hiddenimports=hiddenimports,
             hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=['tkinter'],
             noarchive=False, optimize=0)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], name='SceneStudioDesktop', exclude_binaries=True,
          debug=False, bootloader_ignore_signals=False, strip=False, upx=False,
          console=False, disable_windowed_traceback=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name='SceneStudioDesktop')

